locals {
  # Automatically load environment-level variables
  environment_vars = jsondecode(file("${path_relative_to_include()}/params.json"))

  arm_tenant_id = "2eb07b91-f9f8-437b-a89e-59f55e565c11"
  region = "West Europe"

  # Extract the variables we need for easy access
  arm_subscription_id = local.environment_vars.arm_subscription_id
  managed_storage_account_name = local.environment_vars.managed_storage_account_name
  managed_resource_group_name = "rg-vdwhanalytics-${local.environment_vars.workload_environment}-managed-resources"
}

# Generate an AzureRM provider block
generate "provider" {
  path      = "provider.tf"
  if_exists = "overwrite_terragrunt"
  contents  = <<EOF
provider "azurerm" {
  features {}
  subscription_id = "${local.arm_subscription_id}"
  tenant_id       = "${local.arm_tenant_id}"
}
provider "kubernetes" {
  config_context = "${local.environment_vars.managed_aks_name[0]}-admin"
}
provider "kubernetes" {
  alias          = "vdwhanalytics-test-vdwhanalytics-admin"
  config_context = "vdwhanalytics-test-vdwhanalytics-admin"
}
provider "helm" {
  kubernetes {
    config_context = "${local.environment_vars.managed_aks_name[0]}-admin"
  }
}
provider "helm" {
  alias          = "vdwhanalytics-test-vdwhanalytics-admin"
  kubernetes {
    config_context = "vdwhanalytics-test-vdwhanalytics-admin"
  }
}
provider "kubectl" {
  config_context = "${local.environment_vars.managed_aks_name[0]}-admin"
}
provider "kubectl" {
  alias          = "vdwhanalytics-test-vdwhanalytics-admin"
  config_context = "vdwhanalytics-test-vdwhanalytics-admin"
}
EOF
}

remote_state {
    backend = "azurerm"
    config = {
        resource_group_name  = "${local.managed_resource_group_name}"
        storage_account_name = "${local.managed_storage_account_name}"
        container_name       = "terraform-state"
        key                  = "vdwhanalytics.terraform.tfstate"
        subscription_id      = "${local.arm_subscription_id}"
        tenant_id            = "${local.arm_tenant_id}"
    }
}

# Terragrunt will copy the Terraform configurations specified by the source parameter, along with any files in the
# working directory, into a temporary folder, and execute your Terraform commands in that folder.
terraform {
  source = "../../terraform/modules/VDWHANALYTICS"
}

inputs = merge(
  local.environment_vars,
  local
)
