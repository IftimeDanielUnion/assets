SPOOL /tmp/40_create_vdwh_objects.log

WHENEVER SQLERROR CONTINUE NONE

-- ===========================================================================================
-- spec
-- ===========================================================================================

CREATE OR REPLACE package VDWH.LOAD_GUV_SALDEN_INIT
as

    /* Versionshistorie:
        13.05.2016 Arne Arnold, Infomotion GmbH: Anlage des Package
            Prozeduren für den Transfer der relevanten Daten für die Gewinn- und Verlustrechnung vom vDWH nach Astoria hinzugefügt.
    */
    
    function f_check_table_exists (in_owner varchar2 default 'VDWH', in_tabellenname varchar2) return boolean;
    
    procedure p_write_guv_abholungsprotokoll (in_gvap_key in number default null, in_tabelle in varchar2 default null, in_ladedatum in date default null, out_gvap_key out number);
    
    procedure p_write_guv_abholungslog (in_prozedur in varchar2, in_ladedatum in date, in_meldung in varchar2 default null);
    
    function f_get_naechstes_ladedatum (in_zieltabelle in varchar2) return date;
    
    procedure p_close_db_link (in_dbLinkName in varchar2 default 'VDWH.VDWH_DISPO');
    
    function if_dispop_beladung_moeglich (instanz_id in number default null) return number;
    
    /* GuV Depotinformationen */
    function f_sind_depot_infos_zu_laden (instanz_id in number default null) return number;
    procedure p_load_guv_depot_informationen (instanz_id in number default null, in_ladedatum in date default null, in_stZieltabelle in varchar2 default 'GUV_DEPOT_INFORMATIONEN', in_nbAnzahlDurchlaeufe in number default 20);

    procedure p_load_zeit (instanz_id in number default null, in_ladedatum in date default null);
    
    -- sonstige GuV
    function f_ist_guv_sonstige_zu_laden (instanz_id in number default null) return number;
    procedure p_merge_guv_sonstige (instanz_id in number default null, in_ladedatum in date default null, in_quelltabelle in varchar2 default 'GUV_SONSTIGE', in_stZieltabelle in varchar2 default 'GUV_SONSTIGE');
    
    -- Fondspreise
    procedure p_load_fondspreise (instanz_id in number default null, in_ladedatum in date default null, in_stZieltabelle in varchar2 default 'FONDSPREISE');
    function f_sind_fondspreise_zu_laden (instanz_id in number default null) return number;
    function f_sind_fondspreise_plausibel (instanz_id in number default null) return number;
    
    procedure p_load_salden (instanz_id in number default null, in_ladedatum in date default null, in_quelltabelle in varchar2 default 'SALDEN_DISPO_TRANSFER_2', in_stZieltabelle in varchar2 default 'SALDEN', in_nbAnzahlDurchlaeufe in number default null);
    procedure p_init_salden (instanz_id in number default null, in_ladedatum in date default null, in_quelltabelle in varchar2 default 'SALDEN', in_stZieltabelle in varchar2 default 'SALDEN', in_nbAnzahlDurchlaeufe in number default null, in_nbDurchlauf in number default null);
        
    procedure p_load_fondsanteilsscheine (instanz_id in number default null, in_ladedatum in date default null);

    function f_ist_zeit_zu_laden (instanz_id in number default null) return number;
    
    function f_sind_fonds_zu_laden (instanz_id in number default null) return number;
    
    function f_sind_salden_zu_laden (instanz_id in number default null) return number;   
    function f_sind_salden_zu_laden_alt (instanz_id in number default null) return number;
    
    procedure p_sende_guv_fopr_error_mail (instanz_id in number default null);

    /** 
        Löschung von anonymisierten Depots
    */
    procedure p_loesche_depots (instanz_id in number default null, debug in number default 0);
end;
/

-- ===========================================================================================
-- body
-- ===========================================================================================

CREATE OR REPLACE package body VDWH.LOAD_GUV_SALDEN_INIT
as

    /* Versionshistorie:
        13.05.2016 Arne Arnold, Infomotion GmbH: Anlage des Package
            Prozeduren für den Transfer der relevanten Daten für die Gewinn- und Verlustrechnung vom vDWH nach Astoria hinzugefügt.
    */
    
function f_check_table_exists (in_owner varchar2 default 'VDWH', in_tabellenname varchar2) return boolean
as

    nbReturnValue number;

begin

    execute immediate '
        select count(*)
        from all_tables
        where owner = :in_owner
            and table_name = :in_tabellenname
    ' into nbReturnValue using in_owner, in_tabellenname;
    
    if nbReturnValue = 1 then
        return true;
    else 
        return false;
    end if;

end f_check_table_exists;    
--------------------------------------------------------------------------------
procedure p_write_guv_abholungsprotokoll (in_gvap_key in number default null, in_tabelle in varchar2 default null, in_ladedatum in date default null, out_gvap_key out number)
as
    /*
        Beschreibung:
            Die Prozedur protokolliert den Start und das Ende der Abholung von vDWH-Daten und deren Beladung in eine Astoria-Zieltabelle.
        Versionshistorie:
            08.11.2016 Arne Arnold, Infomotion GmbH: Erstellung der Prozedur
    */
begin
    
    if in_gvap_key is null
    then
        execute immediate 'select dispo.sqc_gvap_key.nextval from dual' into out_gvap_key;
        execute immediate '
            insert into dispo.guv_abholungsprotokoll (gvap_key, gvap_tabelle, gvap_ladedatum)
            values(:key, :tabelle, :ladedatum)
        ' using out_gvap_key, in_tabelle, in_ladedatum;
        commit;
    else
        execute immediate '
            update dispo.guv_abholungsprotokoll
            set gvap_endezeit = sysdate
            where gvap_key = :key
        ' using in_gvap_key;
        commit;
    end if;
    
end p_write_guv_abholungsprotokoll;
--------------------------------------------------------------------------------
procedure p_write_guv_abholungslog (in_prozedur in varchar2, in_ladedatum in date, in_meldung in varchar2 default null)
as
    /*
        Beschreibung:
            Die Prozedur macht einen Log-Eintrag zu einem Abholungsereignis.
        Versionshistorie:
            08.11.2016 Arne Arnold, Infomotion GmbH: Erstellung der Prozedur
    */
begin

    execute immediate '
        insert into dispo.guv_abholungslog (gval_prozedur, gval_ladedatum, gval_meldung)
        values (:prozedur, :ladedatum, :meldung)
    ' using in_prozedur, in_ladedatum, in_meldung;
    commit;

end p_write_guv_abholungslog;
--------------------------------------------------------------------------------
function f_get_naechstes_ladedatum (in_zieltabelle in varchar2) return date
as
    dtNaechstesLadedatum date;
    stSQL varchar2(32767 char);
    nbDatenVorhanden number := 0;
    stMaxDISPOLadedatum varchar2(10 char);
begin
    
    if in_zieltabelle = 'GUV_DEPOT_INFORMATIONEN' then
    
        execute immediate '
            select max(lplb_ladedatum) as letztes_vdwh_ladedatum
            from dwh_repos_etl.llf_ko_Ladeblock_logisch@VDWH.VDWH_DISPO
                inner join dwh_repos_etl.llf_pr_ladeblock@VDWH.VDWH_DISPO 
                    on lplb_lblg_id = lblg_id
            where lblg_block_name = ''load_gvdi1dwh_tabellen - P50''
                and lplb_statuscode = ''110''
        ' into dtNaechstesLadedatum;        
    
    elsif in_zieltabelle = 'FONDSPREISE' then
        execute immediate '
            select max(lplb_ladedatum) as letztes_vdwh_ladedatum
            from dwh_repos_etl.llf_ko_Ladeblock_logisch@VDWH.VDWH_DISPO
                    inner join dwh_repos_etl.llf_pr_ladeblock@VDWH.VDWH_DISPO on lplb_lblg_id = lblg_id
            where lblg_block_name in (''load_befp_fopr1wpi_befp_bdkh - P60'', ''load_fopr1befp_bdkh - P60'')
            and lplb_statuscode = ''110''
        ' into dtNaechstesLadedatum;  

    elsif in_zieltabelle = 'SALDEN' then
    
        execute immediate '
            select count(rownum)
            from dwhload.SALDEN_DISPO_TRANSFER_2@VDWH.VDWH_DISPO
            where rownum <= 1
        ' into nbDatenVorhanden;
        
        if nbDatenVorhanden <> 0 then

            execute immediate '
                select to_char(max(gvap_ladedatum),''dd.mm.rrrr'') max_gvap_ladedatum
                from dispo.guv_abholungsprotokoll
                where gvap_tabelle = ''SALDEN''
            ' into stMaxDISPOLadedatum;
              
            execute immediate '
                select min(ladedatum)
                from dwhload.SALDEN_DISPO_TRANSFER_2@VDWH.VDWH_DISPO
                where ladedatum > to_date('''||stMaxDISPOLadedatum||''',''dd.mm.rrrr'')
            ' into dtNaechstesLadedatum;

        else 
            dtNaechstesLadedatum := null;
        end if;
   
    elsif in_zieltabelle = 'ZEIT' then
        
        dtNaechstesLadedatum := trunc(sysdate);

    else

        stSQL := '
            select min(zeit_datum) as naechstes_ladedatum
            from (
                select max(gvap_ladedatum) as letztes_ladedatum
                from dispo.guv_abholungsprotokoll
                where gvap_tabelle = :zieltabelle
                    and gvap_endezeit is not null
            ) letztes_ladedatum
                cross join dispo.zeit
            where zeit_datum > letztes_ladedatum       
                and zeit_ist_werktag = 1
        ';
        execute immediate stSQL into dtNaechstesLadedatum using in_zieltabelle;
    
    end if;
    
    if dtNaechstesLadedatum is null
    then
        p_write_guv_abholungslog (in_prozedur => 'F_GET_NAECHSTES_LADEDATUM', in_ladedatum => null, in_meldung => 'Es konnte kein Ladedatum fuer das Ziel '||in_zieltabelle||' ermittelt werden.');
        raise_application_error (-20001, 'Es konnte kein Ladedatum fuer das Ziel '||in_zieltabelle||' ermittelt werden. Manuelle Pruefung notwendig!');
    end if;      
    
    return dtNaechstesLadedatum;

end f_get_naechstes_ladedatum;
--------------------------------------------------------------------------------
procedure p_close_db_link (in_dbLinkName in varchar2 default 'VDWH.VDWH_DISPO')
as

    nbDBLinkExistiert number;
    stDBLinkOpen varchar2(3 char);

begin

    execute immediate '
        select count(*)
        from user_db_links
        where db_link = upper(:dblink)
    ' into nbDBLinkExistiert using in_dbLinkName;
    
    if nbDBLinkExistiert = 0 
    then
        raise_application_error (-20001, 'Unbekannter DB-Link '||in_dbLinkName||' uebergeben.'); 
    end if;

    execute immediate '
        select nvl(min(in_transaction), ''@'') 
        from v$dblink 
        where db_link = upper(:dblink)
    ' into stDBLinkOpen using in_dbLinkName;
    
    if stDBLinkOpen = 'NO'
    then
        begin
            execute immediate 'ALTER SESSION CLOSE DATABASE LINK '||in_dbLinkName||'';
        exception 
            -- Wenn der DB-Link nicht geschlossen werden kann, soll die Prozedur einfach verlassen werden.
            when others then 
                return;
        end;    
    end if;

end p_close_db_link;  
--------------------------------------------------------------------------------

function if_dispop_beladung_moeglich (instanz_id in number default null) return number
as
    /** DISPOP-Beladungen werden nur in Phasen geringerer Zugriffszahlen durchgeführt
        per aktueller Definition nach 20 Uhr und nicht mehr nach 7 Uhr
    */

    nbDISPOPBeladungmoeglich number := 0;
    
begin

    return 1;
    
--    execute immediate 'select case when to_number(to_char(sysdate,''HH24'')) between 12 and 19 then 0 else 1 end
--                       from dual '
--                       into nbDISPOPBeladungmoeglich; 
--                       
--    return nbDISPOPBeladungmoeglich;
    
end;

function f_sind_depot_infos_zu_laden (instanz_id in number default null) return number
as

    nbReturnValue number;

begin

    execute immediate '
        select case when guv_depot_infos_aktuell >= 1
                    then 0
                    else 1
                end as depot_infos_sind_zu_laden        
        from (            
            select count(*) as guv_depot_infos_aktuell
            from dispo.guv_abholungsprotokoll
                inner join (
                    select max(lplb_ladedatum) as letztes_vdwh_ladedatum
                    from dwh_repos_etl.llf_ko_Ladeblock_logisch@VDWH.VDWH_DISPO
                        inner join dwh_repos_etl.llf_pr_ladeblock@VDWH.VDWH_DISPO 
                            on lplb_lblg_id = lblg_id
                    where lblg_block_name = ''load_gvdi1dwh_tabellen - P50''
                        and lplb_statuscode = ''110''
                )          
                    on gvap_ladedatum >= letztes_vdwh_ladedatum       
            where upper(gvap_tabelle) = ''GUV_DEPOT_INFORMATIONEN''
                and gvap_endezeit is not null
        )
    ' into nbReturnValue;    
    p_close_db_link;
    
    return nbReturnValue;

end f_sind_depot_infos_zu_laden;

procedure p_init_guv_depot_informationen (instanz_id in number default null, in_stZieltabelle in varchar2 default 'GUV_DEPOT_INFORMATIONEN', in_nbAnzahlDurchlaeufe in number)
as

    /* 
        Versionshistorie        
        13.02.2017 Arne Arnold, Infomotion GmbH: 
            - Init-Prozedur für die Tabelle DISPO.GUV_DEPOT_INFORMATIONEN
    */
    
    type cursor_type is ref cursor;
    c_durchlaeufe cursor_type;
    stSQL varchar2(32767 char);
    stZieltabelle varchar2(30 char) := in_stZieltabelle;
    nbDurchlauf number;
    nbMinDepoKey number;
    nbMaxDepoKey number;


begin

    stSQL := '
        select distinct durchlauf
            , min(gvdi_akt_instanz_depo_key) over (partition by durchlauf) as min_depo_key
            , max(gvdi_akt_instanz_depo_key) over (partition by durchlauf) as max_depo_key
        from (    
            select gvdi_akt_instanz_depo_key
                , ntile(:anzahlDurchlaeufe) over (order by gvdi_akt_instanz_depo_key asc) as durchlauf
            from dwh.guv_depot_informationen@VDWH.VDWH_DISPO
        )      
        order by durchlauf asc
    ';
    open c_durchlaeufe for stSQL using in_nbAnzahlDurchlaeufe;
    loop
        fetch c_durchlaeufe into nbDurchlauf, nbMinDepoKey, nbMaxDepoKey;
        exit when c_durchlaeufe%notfound;
        
        p_write_guv_abholungslog (in_prozedur => 'P_INIT_GUV_DEPOT_INFORMATIONEN', in_ladedatum => trunc(Sysdate), in_meldung => 'Hole GUV_DEPOT_INFORMATIONEN fuer Durchlauf '||nbDurchlauf||' ab.');
        
        dispo.p_truncate_vor_tabelle (in_tabelle => 'VOR_GUV_DEPOT_INFORMATIONEN');

        stSQL := '
            insert into dispo.VOR_GUV_DEPOT_INFORMATIONEN (
                gvdi_depotnummer
                , gvdi_akt_instanz_depo_key
                , gvdi_stammdepotnummer
                , gvdi_kz_depotverfuegungsart
                , gvdi_kz_depotvertragsart
                , gvdi_depoteroeffnungsdatum
                , gvdi_aktuelle_vermittler_nr
                , gvdi_kz_ist_prod_oder_fonds
                , gvdi_produkt_fondsinformation
                , gvdi_depo_letztm_bestand_am
                , gvdi_kz_ist_papyrus_depot
                , gvdi_depo_ersteinzahlung
                , gvdi_assetklassen_gruppierung
            )
            select depo_nummer_anon as gvdi_depotnummer
                , gvdi_akt_instanz_depo_key
                , depo_stammnummer_anon as gvdi_stammdepotnummer
                , gvdi_kz_depotverfuegungsart
                , gvdi_kz_depotvertragsart
                , gvdi_depoteroeffnungsdatum
                , gvdi_aktuelle_vermittler_nr
                , gvdi_kz_ist_prod_oder_fonds
                , gvdi_produkt_fondsinformation
                , gvdi_depo_letztm_bestand_am
                , gvdi_kz_ist_papyrus_depot
                , gvdi_depo_ersteinzahlung
                , gvdi_assetklassen_gruppierung
            from dwh.guv_depot_informationen@VDWH.VDWH_DISPO
                    join dwhload.bekannt_azure_u_depots_anonym@VDWH.VDWH_DISPO on depo_key = gvdi_akt_instanz_depo_key
            where gvdi_akt_instanz_depo_key between :von and :bis
        ';
        execute immediate stSQL using nbMinDepoKey, nbMaxDepoKey;
        commit;
        p_close_db_link;   
                   
        p_write_guv_abholungslog (in_prozedur => 'P_INIT_GUV_DEPOT_INFORMATIONEN', in_ladedatum => trunc(Sysdate), in_meldung => 'Fuege GUV_DEPOT_INFORMATIONEN fuer Durchlauf '||nbDurchlauf||' ein.');
        execute immediate '
            insert into dispo.'||stZieltabelle||' z (gvdi_depotnummer, gvdi_akt_instanz_depo_key, gvdi_stammdepotnummer, gvdi_kz_depotverfuegungsart
                                                    , gvdi_kz_depotvertragsart, gvdi_depoteroeffnungsdatum, gvdi_aktuelle_vermittler_nr
                                                    , gvdi_kz_ist_prod_oder_fonds, gvdi_produkt_fondsinformation, gvdi_depo_letztm_bestand_am
                                                    , gvdi_kz_ist_papyrus_depot, gvdi_depo_ersteinzahlung, gvdi_zeitstempel, gvdi_assetklassen_gruppierung)
            select q.gvdi_depotnummer
                    , q.gvdi_akt_instanz_depo_key
                    , q.gvdi_stammdepotnummer
                    , q.gvdi_kz_depotverfuegungsart
                    , q.gvdi_kz_depotvertragsart
                    , q.gvdi_depoteroeffnungsdatum
                    , q.gvdi_aktuelle_vermittler_nr
                    , q.gvdi_kz_ist_prod_oder_fonds
                    , q.gvdi_produkt_fondsinformation
                    , q.gvdi_depo_letztm_bestand_am
                    , q.gvdi_kz_ist_papyrus_depot
                    , q.gvdi_depo_ersteinzahlung
                    , to_char(trunc(sysdate), ''yyyymmdd'')
                    , q.gvdi_assetklassen_gruppierung
                from dispo.VOR_GUV_DEPOT_INFORMATIONEN q
        ';
        commit;      
                
        p_write_guv_abholungslog (in_prozedur => 'P_INIT_GUV_DEPOT_INFORMATIONEN', in_ladedatum => trunc(Sysdate), in_meldung => 'GUV_DEPOT_INFORMATIONEN fuer Durchlauf '||nbDurchlauf||' fertig.');
        
    end loop;
    close c_durchlaeufe;

end p_init_guv_depot_informationen;

--------------------------------------------------------------------------------
procedure p_load_guv_depot_informationen (instanz_id in number default null, in_ladedatum in date default null, in_stZieltabelle in varchar2 default 'GUV_DEPOT_INFORMATIONEN', in_nbAnzahlDurchlaeufe in number default 20)
as

    type cursor_type is ref cursor;
    c_durchlaeufe cursor_type;
    stSQL varchar2(32767 char);
    dtLadedatum date;
    nbAnzahlSaetzeDML number;
    nbAnzahlSaetzeDMLGesamt number := 0;
    stErrorMessage varchar2(500 char);
    nbProtokollKey number;
    stZieltabelle varchar2(30 char) := in_stZieltabelle;
    nbDurchlauf number;
    nbMinDepoKey number;
    nbMaxDepoKey number;
    
begin

    if in_ladedatum is null then
        dtLadedatum := f_get_naechstes_ladedatum (in_zieltabelle => 'GUV_DEPOT_INFORMATIONEN');
    else
        dtLadedatum := in_ladedatum;
    end if;        
    
    p_write_guv_abholungsprotokoll (in_tabelle => 'GUV_DEPOT_INFORMATIONEN', in_ladedatum => dtLadedatum, out_gvap_key => nbProtokollKey);
 
    stSQL := '
            select distinct durchlauf
                , min(gvdi_akt_instanz_depo_key) over (partition by durchlauf) as min_depo_key
                , max(gvdi_akt_instanz_depo_key) over (partition by durchlauf) as max_depo_key
            from (    
                select gvdi_akt_instanz_depo_key
                    , ntile(:anzahlDurchlaeufe) over (order by gvdi_akt_instanz_depo_key asc) as durchlauf
                from dwh.guv_depot_informationen@VDWH.VDWH_DISPO
--                where gvdi_kz_depot_anzeigen = 1
            )      
            order by durchlauf asc
        ';
        open c_durchlaeufe for stSQL using in_nbAnzahlDurchlaeufe;
        loop
            fetch c_durchlaeufe into nbDurchlauf, nbMinDepoKey, nbMaxDepoKey;
            exit when c_durchlaeufe%notfound;

        <<Abholung_Quelldaten>>
        begin
        
            p_write_guv_abholungslog (in_prozedur => 'P_LOAD_GUV_DEPOT_INFORMATIONEN', in_ladedatum => dtLadedatum, in_meldung => 'Tranche '||nbDurchlauf||': Hole vDWH-Daten ab...');
            dispo.p_truncate_vor_tabelle (in_tabelle => 'VOR_GUV_DEPOT_INFORMATIONEN');

            stSQL := '
                insert into dispo.VOR_GUV_DEPOT_INFORMATIONEN (
                    gvdi_depotnummer
                    , gvdi_akt_instanz_depo_key
                    , gvdi_stammdepotnummer
                    , gvdi_kz_depotverfuegungsart
                    , gvdi_kz_depotvertragsart
                    , gvdi_depoteroeffnungsdatum
                    , gvdi_aktuelle_vermittler_nr
                    , gvdi_kz_ist_prod_oder_fonds
                    , gvdi_produkt_fondsinformation
                    , gvdi_depo_letztm_bestand_am
                    , gvdi_kz_ist_papyrus_depot
                    , gvdi_depo_ersteinzahlung
                    , gvdi_assetklassen_gruppierung
                    , gvdi_kz_depot_anzeigen
                )
                select gvdi_depotnummer
                    , gvdi_akt_instanz_depo_key
                    , gvdi_stammdepotnummer
                    , gvdi_kz_depotverfuegungsart
                    , gvdi_kz_depotvertragsart
                    , gvdi_depoteroeffnungsdatum
                    , gvdi_aktuelle_vermittler_nr
                    , gvdi_kz_ist_prod_oder_fonds
                    , gvdi_produkt_fondsinformation
                    , gvdi_depo_letztm_bestand_am
                    , gvdi_kz_ist_papyrus_depot
                    , gvdi_depo_ersteinzahlung
                    , gvdi_assetklassen_gruppierung
                    , gvdi_kz_depot_anzeigen
                from dwh.GUV_DEPOT_INFORMATIONEN@VDWH.VDWH_DISPO
                        join dwh.depots@VDWH.VDWH_DISPO on depo_key = gvdi_akt_instanz_depo_key
                                                and nvl(DEPO_IST_ANONYMISIERT,''@'') <> ''J''  
                where --gvdi_kz_depot_anzeigen = 1 and  
                gvdi_akt_instanz_depo_key between :von and :bis
            ';
            execute immediate stSQL using nbMinDepoKey, nbMaxDepoKey;
            nbAnzahlSaetzeDML := SQL%ROWCOUNT;
            commit;
            p_close_db_link;   
            
            p_write_guv_abholungslog (in_prozedur => 'P_LOAD_GUV_DEPOT_INFORMATIONEN', in_ladedatum => dtLadedatum, in_meldung => 'Tranche '||nbDurchlauf||': Es wurden '||to_char(nbAnzahlSaetzeDML)||' abgeholt.');
            
        end Abholung_Quelldaten;    

        <<Zieltabelle_aktualisieren>>
        begin
             
            p_write_guv_abholungslog (in_prozedur => 'P_LOAD_GUV_DEPOT_INFORMATIONEN', in_ladedatum => dtLadedatum, in_meldung => 'Tranche '||nbDurchlauf||': Aktualisiere die Tabelle DISPO.GUV_DEPOT_INFORMATIONEN...');        
            execute immediate '
                merge into dispo.'||stZieltabelle||' z
                using (
                    select /*+ parallel (gvdi,8) */ gvdi_depotnummer
                        , gvdi_akt_instanz_depo_key
                        , gvdi_stammdepotnummer
                        , gvdi_kz_depotverfuegungsart
                        , gvdi_kz_depotvertragsart
                        , gvdi_depoteroeffnungsdatum
                        , gvdi_aktuelle_vermittler_nr
                        , gvdi_kz_ist_prod_oder_fonds
                        , gvdi_produkt_fondsinformation
                        , gvdi_depo_letztm_bestand_am
                        , gvdi_kz_ist_papyrus_depot
                        , gvdi_depo_ersteinzahlung
                        , gvdi_assetklassen_gruppierung
                        , gvdi_kz_depot_anzeigen
                    from dispo.VOR_GUV_DEPOT_INFORMATIONEN gvdi
                    minus
                    select /*+ parallel (gvdi,8) */ gvdi_depotnummer
                        , gvdi_akt_instanz_depo_key
                        , gvdi_stammdepotnummer
                        , gvdi_kz_depotverfuegungsart
                        , gvdi_kz_depotvertragsart
                        , gvdi_depoteroeffnungsdatum
                        , gvdi_aktuelle_vermittler_nr
                        , gvdi_kz_ist_prod_oder_fonds
                        , gvdi_produkt_fondsinformation
                        , gvdi_depo_letztm_bestand_am
                        , gvdi_kz_ist_papyrus_depot
                        , gvdi_depo_ersteinzahlung
                        , gvdi_assetklassen_gruppierung
                        , gvdi_kz_depot_anzeigen
                    from dispo.'||stZieltabelle||' gvdi
                    where gvdi_akt_instanz_depo_key between :von and :bis
                ) q
                on (z.gvdi_depotnummer = q.gvdi_depotnummer)
                when matched then
                    update set z.gvdi_akt_instanz_depo_key = q.gvdi_akt_instanz_depo_key
                        , gvdi_stammdepotnummer = q.gvdi_stammdepotnummer
                        , z.gvdi_kz_depotverfuegungsart = q.gvdi_kz_depotverfuegungsart
                        , z.gvdi_kz_depotvertragsart = q.gvdi_kz_depotvertragsart
                        , z.gvdi_depoteroeffnungsdatum = q.gvdi_depoteroeffnungsdatum
                        , z.gvdi_aktuelle_vermittler_nr = q.gvdi_aktuelle_vermittler_nr
                        , z.gvdi_kz_ist_prod_oder_fonds = q.gvdi_kz_ist_prod_oder_fonds
                        , z.gvdi_produkt_fondsinformation = q.gvdi_produkt_fondsinformation
                        , z.gvdi_depo_letztm_bestand_am = q.gvdi_depo_letztm_bestand_am
                        , z.gvdi_kz_ist_papyrus_depot = q.gvdi_kz_ist_papyrus_depot
                        , z.gvdi_depo_ersteinzahlung = q.gvdi_depo_ersteinzahlung
                        , z.gvdi_zeitstempel = to_char(trunc(sysdate), ''yyyymmdd'')
                        , z.gvdi_assetklassen_gruppierung = q.gvdi_assetklassen_gruppierung
                        , z.gvdi_kz_depot_anzeigen = q.gvdi_kz_depot_anzeigen
                when not matched then
                    insert (gvdi_depotnummer, gvdi_akt_instanz_depo_key, gvdi_stammdepotnummer, gvdi_kz_depotverfuegungsart, gvdi_kz_depotvertragsart, gvdi_depoteroeffnungsdatum, gvdi_aktuelle_vermittler_nr
                                , gvdi_kz_ist_prod_oder_fonds, gvdi_produkt_fondsinformation, gvdi_depo_letztm_bestand_am, gvdi_kz_ist_papyrus_depot, gvdi_depo_ersteinzahlung, gvdi_zeitstempel, gvdi_assetklassen_gruppierung
                                , gvdi_kz_depot_anzeigen)
                    values (q.gvdi_depotnummer, q.gvdi_akt_instanz_depo_key, q.gvdi_stammdepotnummer, q.gvdi_kz_depotverfuegungsart, q.gvdi_kz_depotvertragsart, q.gvdi_depoteroeffnungsdatum, q.gvdi_aktuelle_vermittler_nr
                                , q.gvdi_kz_ist_prod_oder_fonds, q.gvdi_produkt_fondsinformation, q.gvdi_depo_letztm_bestand_am, q.gvdi_kz_ist_papyrus_depot, q.gvdi_depo_ersteinzahlung, to_char(trunc(sysdate), ''yyyymmdd''), q.gvdi_assetklassen_gruppierung
                                , q.gvdi_kz_depot_anzeigen)
            ' using nbMinDepoKey, nbMaxDepoKey;
            nbAnzahlSaetzeDML := SQL%ROWCOUNT;
            commit;
            
            nbAnzahlSaetzeDMLGesamt := nbAnzahlSaetzeDMLGesamt + nbAnzahlSaetzeDML;
            
        end Zieltabelle_aktualisieren;
    
    end loop;
    close c_durchlaeufe;
    
    p_write_guv_abholungslog (in_prozedur => 'P_LOAD_GUV_DEPOT_INFORMATIONEN', in_ladedatum => dtLadedatum, in_meldung => 'Es wurden '||to_char(nbAnzahlSaetzeDMLGesamt)||' Saetze in der Tabelle DISPO.GUV_DEPOT_INFORMATIONEN aktualsiert.');    
    p_write_guv_abholungsprotokoll (in_gvap_key => nbProtokollKey, out_gvap_key => nbProtokollKey);
    
end p_load_guv_depot_informationen;
--------------------------------------------------------------------------------
procedure p_load_fondspreise (instanz_id in number default null, in_ladedatum in date default null, in_stZieltabelle in varchar2 default 'FONDSPREISE')
as

    stSQL varchar2(32767 char);
    stErrorMessage varchar2(500 char);
    dtLadedatum date;
    dtLetztesLadedatum date;
    nbAnzahlSaetzeDML number;
    nbProtokollKey number;
    stZieltabelle varchar2(30 char) := in_stZieltabelle;
    
begin
    
    if in_ladedatum is null
    then
        dtLadedatum := f_get_naechstes_ladedatum (in_zieltabelle => 'FONDSPREISE'); 
    else
        dtLadedatum := in_ladedatum; 
    end if;
    
    /* Es können von Daska auch Fondspreise geliefert werden, deren Gültig-Von auf ein Wochenende fällt. Deshalb müssen alle Sätze zwischen dem aktuellen und dem letzten Ladedatum abgeholt werden. */

    p_write_guv_abholungsprotokoll (in_tabelle => 'FONDSPREISE', in_ladedatum => dtLadedatum, out_gvap_key => nbProtokollKey);
    
    <<Abholung_Quelldaten>>
    begin
    
        p_write_guv_abholungslog (in_prozedur => 'P_LOAD_FONDSPREISE', in_ladedatum => dtLadedatum, in_meldung => 'Hole vDWH-Daten ab...');
        dispo.p_truncate_vor_tabelle (in_tabelle => 'VOR_FONDSPREISE');
    
        stSQL := '
            insert into dispo.VOR_FONDSPREISE (
                fopr_fond_key
                , fopr_ruecknahmepreis_in_eur
                , fopr_gueltig_von
                , fopr_gueltig_bis
            )
            select fopr_fond_key
                , fopr_ruecknahmepreis_in_eur
                , fopr_gueltig_von
                , fopr_gueltig_bis 
            from dwh.fondspreise@VDWH.VDWH_DISPO
        ';
        execute immediate stSQL;
        nbAnzahlSaetzeDML := SQL%ROWCOUNT;
        commit;
        
        p_write_guv_abholungslog (in_prozedur => 'P_LOAD_FONDSPREISE', in_ladedatum => dtLadedatum, in_meldung => 'Es wurden '||to_char(nbAnzahlSaetzeDML)||' Saetze abgeholt.');
        p_close_db_link;
    end Abholung_Quelldaten;
    
    <<Zieltabelle_befuellen>>
    begin
    
        p_write_guv_abholungslog (in_prozedur => 'P_LOAD_FONDSPREISE', in_ladedatum => dtLadedatum, in_meldung => 'Aktualisiere die Tabelle Dispo.FONDSPREISE (Daten seit '||to_char(dtLetztesLadedatum,'dd.mm.yyyy')||') ...');

        stSQL := '
            merge into dispo.'||stZieltabelle||' z
            using (
                select fopr_fond_key
                    , fopr_ruecknahmepreis_in_eur
                    , fopr_gueltig_von
                    , fopr_gueltig_bis
                from dispo.VOR_FONDSPREISE
                minus
                select fopr_fond_key
                                , fopr_ruecknahmepreis_in_eur
                                , fopr_gueltig_von
                                , fopr_gueltig_bis
                from dispo.'||stZieltabelle||'
            ) q
            on (
                z.fopr_fond_key = q.fopr_fond_key
                and z.fopr_gueltig_von = q.fopr_gueltig_von
            )
            when matched then
                update set z.fopr_ruecknahmepreis_in_eur = q.fopr_ruecknahmepreis_in_eur
                    , z.fopr_gueltig_bis = q.fopr_gueltig_bis
                    , z.fopr_zeitstempel = to_char(trunc(sysdate), ''yyyymmdd'')
            when not matched then
                insert (fopr_fond_key, fopr_ruecknahmepreis_in_eur, fopr_gueltig_von, fopr_gueltig_bis, fopr_zeitstempel)
                values(q.fopr_fond_key, q.fopr_ruecknahmepreis_in_eur, q.fopr_gueltig_von, q.fopr_gueltig_bis, to_char(trunc(sysdate), ''yyyymmdd''))
        ';
        execute immediate stSQL;
        nbAnzahlSaetzeDML := SQL%ROWCOUNT;
        commit;
        
        p_write_guv_abholungslog (in_prozedur => 'P_LOAD_FONDSPREISE', in_ladedatum => dtLadedatum, in_meldung => 'Es wurden '||to_char(nbAnzahlSaetzeDML)||' Saetze in der Tabelle DISPO.FONDSPREISE aktualisiert.');
    end Zieltabelle_befuellen;
    
    p_write_guv_abholungsprotokoll (in_gvap_key => nbProtokollKey, out_gvap_key => nbProtokollKey);
            
end p_load_fondspreise;
--------------------------------------------------------------------------------
function f_sind_fondspreise_zu_laden (instanz_id in number default null) 
    return number
as

    nbReturnValue number(1);

begin

    execute immediate '
        select case when fondspreise_aktuell >= 1
                    then 0
                    else 1
                end as fondspreise_zu_laden        
        from (            
            select count(*) as fondspreise_aktuell
            from dispo.guv_abholungsprotokoll
                inner join (
                    select max(lplb_startzeit) max_lplb_startzeit
                    from dwh_repos_etl.llf_ko_Ladeblock_logisch@VDWH.VDWH_DISPO
                        inner join dwh_repos_etl.llf_pr_ladeblock@VDWH.VDWH_DISPO 
                            on lplb_lblg_id = lblg_id
                    where lblg_block_name in (''load_befp_fopr1wpi_befp_bdkh - P60'', ''load_fopr1befp_bdkh - P60'')
                        and lplb_statuscode = ''110''
                )          
                    on gvap_startzeit >= max_lplb_startzeit
            where upper(gvap_tabelle) = ''FONDSPREISE''
                and gvap_endezeit is not null
        )
    ' into nbReturnValue;    
    
    return nbReturnValue;

end f_sind_fondspreise_zu_laden;

function f_sind_fondspreise_plausibel (instanz_id in number default null) return number
as
    stSQL varchar2(32767 char);
    nbDatenPlausibel number := 0;
begin

    /** Aktuell wird nur geprüft, ob es mehrere offene Fondspreisintervalle gibt
        Wenn das der Fall sein sollte, wird keine DISPO-Fondspreisbeladung vorgenommen
    */
    
    /** doppelte Intervalle in den VDWH-Fondspreisen enthalten ??
    */
    stSQL := '
                select case when count(rownum) = 0 then 1 else 0 end
                from (
                        select fopr_fond_key, count(*)
                        from dwh.fondspreise@VDWH.VDWH_DISPO
                        where fopr_gueltig_bis = to_date(''30.12.9999'')
                        group by fopr_fond_key
                        having count(*) > 1
                )
                ';
    execute immediate stSQL into nbDatenPlausibel;

    return nbDatenPlausibel;   

end;

--------------------------------------------------------------------------------
procedure p_load_zeit (instanz_id in number default null, in_ladedatum in date default null)
as

    /*
        Beschreibung:
            Die Prozedur holt immer ab die komplette Zeit-Tabelle aus dem vDWH ab und aktualisiert damit die Zeit-Tabelle auf Astoria-Seite, sofern es Änderungen gibt. 
        
        Versionshistorie:
            - 07.11.2016 Arne Arnold, Infomotion GmbH: Erstellung
    */

    stErrorMessage varchar2(500 char);
    stSQL varchar2(32767 char);
    nbProtokollKey number;
    nbAnzahlSaetzeDML number;
    dtLadedatum date;

begin
   
    if in_ladedatum is null
    then
        dtLadedatum := f_get_naechstes_ladedatum (in_zieltabelle => 'ZEIT'); 
    else 
        dtLadedatum := in_ladedatum;
    end if;

    p_write_guv_abholungsprotokoll (in_tabelle => 'ZEIT', in_ladedatum => dtLadedatum, out_gvap_key => nbProtokollKey);
    
    <<Abholung_Quelldaten>>
    begin
    
        p_write_guv_abholungslog (in_prozedur => 'P_LOAD_ZEIT', in_ladedatum => dtLadedatum, in_meldung => 'Hole Daten vom vDWH ab...');
        dispo.p_truncate_vor_tabelle (in_tabelle => 'VOR_ZEIT');
        
        stSQL := '
            insert into dispo.VOR_ZEIT (
                zeit_datum
                , zeit_ist_werktag
            )  
            select zeit_datum
                , zeit_ist_werktag_t
            from dwh.zeit@VDWH.VDWH_DISPO
        ';
        execute immediate stSQL;
        nbAnzahlSaetzeDML := SQL%ROWCOUNT;
        commit;       
        
        p_write_guv_abholungslog (in_prozedur => 'P_LOAD_ZEIT', in_ladedatum => dtLadedatum, in_meldung => 'Es wurden '||to_char(nbAnzahlSaetzeDML)||' abgeholt.');
        p_close_db_link;
        
    end Abholung_Quelldaten;
    
    <<Zieltabelle_befuellen>>
    begin    
    
        p_write_guv_abholungslog (in_prozedur => 'P_LOAD_ZEIT', in_ladedatum => dtLadedatum, in_meldung => 'Aktualisiere die Tabelle DISPO.ZEIT...');
        
        stSQL := '
            merge into dispo.ZEIT z 
            using (
                select zeit_datum
                    , zeit_ist_werktag
                from dispo.VOR_ZEIT
                minus
                select zeit_datum
                    , zeit_ist_werktag
                from dispo.zeit     
            ) q
            on (z.zeit_datum = q.zeit_datum)
            when matched then 
                update set z.zeit_ist_werktag = q.zeit_ist_werktag
            when not matched then
                insert (zeit_datum, zeit_ist_werktag)
                values (q.zeit_datum, q.zeit_ist_werktag)
        ';    
        execute immediate stSQL;
        nbAnzahlSaetzeDML := SQL%ROWCOUNT;
        commit; 
        
        p_write_guv_abholungslog (in_prozedur => 'P_LOAD_ZEIT', in_ladedatum => dtLadedatum, in_meldung => 'Es wurden '||to_char(nbAnzahlSaetzeDML)||' Saetze in der Tabelle DISPO.ZEIT aktualisiert.');
    end Zieltabelle_befuellen;    
    
    -- Abschließender Protokolleintrag
    p_write_guv_abholungsprotokoll (in_gvap_key => nbProtokollKey, out_gvap_key => nbProtokollKey);
                
end p_load_zeit;
--------------------------------------------------------------------------------
procedure p_load_salden (instanz_id in number default null, in_ladedatum in date default null, in_quelltabelle in varchar2 default 'SALDEN_DISPO_TRANSFER_2', in_stZieltabelle in varchar2 default 'SALDEN', in_nbAnzahlDurchlaeufe in number default null)
as

    type cursor_type is ref cursor;
    c_durchlaeufe cursor_type;
    stSQL varchar2(32767 char);
    dtLadedatum date;
    nbProtokollKey number;
    nbAnzahlSaetzeDML number;
    nbAnzahlSaetzeDMLGesamt number := 0;
    nbDurchlauf number;
    nbAnzahlDurchlaeufe number;
    nbMinDepoKey number;
    nbMaxDepoKey number;
    
    stZieltabelle varchar2(30 char) := in_stZieltabelle;
    stQuelltabelle varchar2(30 char) := in_quelltabelle;
    
begin

    if in_ladedatum is null
    then
        dtLadedatum := f_get_naechstes_ladedatum (in_zieltabelle => 'SALDEN');
    else
        dtLadedatum := in_ladedatum;
    end if;

    if in_nbAnzahlDurchlaeufe is null then
        stSQL := '
                    select trunc(count(*) / 1000000) + 1 durchlaeufe
                    from dwhload.'||stQuelltabelle||'@VDWH.VDWH_DISPO 
                    where ladedatum = :dtLadedatum
                    group by ladedatum
                ';
        execute immediate stSQL into nbAnzahlDurchlaeufe using dtLadedatum;
    else
        nbAnzahlDurchlaeufe := in_nbAnzahlDurchlaeufe;
    end if;
    
    p_write_guv_abholungsprotokoll (in_tabelle => 'SALDEN', in_ladedatum => dtLadedatum, out_gvap_key => nbProtokollKey);

    stSQL := '
            select distinct durchlauf
                , min(sald_depo_key) over (partition by durchlauf) as min_depo_key
                , max(sald_depo_key) over (partition by durchlauf) as max_depo_key
            from (    
                select sald_depo_key
                    , ntile(:nbAnzahlDurchlaeufe) over (order by sald_depo_key asc) as durchlauf
                from dwhload.'||stQuelltabelle||'@VDWH.VDWH_DISPO 
                where ladedatum = :dtLadedatum
            )      
            order by durchlauf asc
        ';
        open c_durchlaeufe for stSQL using nbAnzahlDurchlaeufe, dtLadedatum;
        loop
            fetch c_durchlaeufe into nbDurchlauf, nbMinDepoKey, nbMaxDepoKey;
            exit when c_durchlaeufe%notfound;
            
            <<Vortabelle_befuellen>>
            begin 
            
                /* Aktuelle Salden */ 
                p_write_guv_abholungslog (in_prozedur => 'P_LOAD_SALDEN', in_ladedatum => dtLadedatum, in_meldung => 'Tranche '||nbDurchlauf||': Hole Salden zu Ladedatum aus vDWH ab...');        
                dispo.p_truncate_vor_tabelle (in_tabelle => 'VOR_SALDEN'); 

                execute immediate '
                    insert into dispo.vor_salden (sald_depo_stammnummer
                                                    , sald_depo_nummer
                                                    , sald_fond_isin
                                                    , sald_depo_key
                                                    , sald_fond_key
                                                    , sald_gueltig_von
                                                    , sald_gueltig_bis
                                                    , sald_zeitstempel
                                                    , sald_stck_storn_hist_bereinigt
                                                    , sald_stck_storn_hist_ber_vorg
                                                    , sald_zu_umsa_wa_im_ud_betrag
                                                    , sald_ab_betrag_steuer
                                                    , sald_ab_betrag_wa_dep_extern
                                                    , sald_zu_betr_esw_relevant_ges
                                                    , sald_ab_betr_esw_relevant_ges
                                                    , sald_zu_betr_realisierung_ges
                                                    , sald_ab_betr_realisierung_ges
                    )
                    select  sald_depo_stammnummer
                                , sald_depo_nummer
                                , sald_fond_isin
                                , sald_depo_key
                                , sald_fond_key
                                , sald_gueltig_von
                                , sald_gueltig_bis
                                , sald_zeitstempel
                                , case when sald_stck_storn_hist_bereinigt < 0 then 0 else sald_stck_storn_hist_bereinigt end as sald_stck_storn_hist_bereinigt
                                , case when sald_stck_storn_hist_ber_vorg < 0 then 0 else sald_stck_storn_hist_ber_vorg end as sald_stck_storn_hist_ber_vorg
                                , sald_zu_umsa_wa_im_ud_betrag
                                , sald_ab_betrag_steuer
                                , sald_ab_betrag_wa_dep_extern
                                , sald_zu_betr_esw_relevant_ges
                                , sald_ab_betr_esw_relevant_ges
                                , sald_zu_betr_realisierung_ges
                                , sald_ab_betr_realisierung_ges
                    from dwhload.'||stQuelltabelle||'@VDWH.VDWH_DISPO
                    where sald_depo_key between :nbMinDepoKey and :nbMaxDepoKey
                    and ladedatum = :dtLadedatum
                ' using nbMinDepoKey, nbMaxDepoKey, dtLadedatum;
                nbAnzahlSaetzeDML := SQL%ROWCOUNT;
                commit;

                p_write_guv_abholungslog (in_prozedur => 'P_LOAD_SALDEN', in_ladedatum => dtLadedatum, in_meldung => 'Tranche '||nbDurchlauf||': Es wurden '||to_char(nbAnzahlSaetzeDML)||' Saetze abgeholt.');
                p_close_db_link;
                            
            end Vortabelle_befuellen;         

            <<Zieltabelle_befuellen>>
            begin
                        
                p_write_guv_abholungslog (in_prozedur => 'P_LOAD_SALDEN', in_ladedatum => dtLadedatum, in_meldung => 'Tranche '||nbDurchlauf||': Merge in die Zieltabelle SALDEN ...'); 

                execute immediate '
                    merge /*+ use_nl(z) index(z sald_pk) */ into dispo.'||stZieltabelle||' z
                    using (
                          select sald_depo_stammnummer
                                    , sald_depo_nummer
                                    , sald_fond_isin
                                    , sald_depo_key
                                    , sald_fond_key
                                    , sald_gueltig_von
                                    , sald_gueltig_bis
                                    , sald_zeitstempel
                                    , sald_stck_storn_hist_bereinigt
                                    , sald_stck_storn_hist_ber_vorg
                                    , sald_zu_umsa_wa_im_ud_betrag
                                    , sald_ab_betrag_steuer
                                    , sald_ab_betrag_wa_dep_extern
                                    , sald_zu_betr_esw_relevant_ges
                                    , sald_ab_betr_esw_relevant_ges
                                    , sald_zu_betr_realisierung_ges
                                    , sald_ab_betr_realisierung_ges
                        from dispo.vor_salden
                        order by sald_depo_stammnummer
                                    , sald_depo_nummer
                                    , sald_fond_isin
                                    , sald_depo_key
                                    , sald_fond_key
                                    , sald_gueltig_von
                                    , sald_gueltig_bis
                    ) q
                    on (
                        z.sald_depo_stammnummer = q.sald_depo_stammnummer
                        and z.sald_depo_nummer = q.sald_depo_nummer
                        and z.sald_fond_isin = q.sald_fond_isin
                        and z.sald_depo_key = q.sald_depo_key
                        and z.sald_fond_key = q.sald_fond_key
                        and z.sald_gueltig_von = q.sald_gueltig_von
                    )
                    when matched then update 
                        set z.sald_stck_storn_hist_bereinigt = q.sald_stck_storn_hist_bereinigt
                            , z.sald_stck_storn_hist_ber_vorg = q.sald_stck_storn_hist_ber_vorg
                            , z.sald_zu_umsa_wa_im_ud_betrag = q.sald_zu_umsa_wa_im_ud_betrag
                            , z.sald_ab_betrag_steuer = q.sald_ab_betrag_steuer
                            , z.sald_ab_betrag_wa_dep_extern = q.sald_ab_betrag_wa_dep_extern
                            , z.sald_zu_betr_esw_relevant_ges = q.sald_zu_betr_esw_relevant_ges
                            , z.sald_ab_betr_esw_relevant_ges = q.sald_ab_betr_esw_relevant_ges
                            , z.sald_zu_betr_realisierung_ges = q.sald_zu_betr_realisierung_ges
                            , z.sald_ab_betr_realisierung_ges = q.sald_ab_betr_realisierung_ges  
                            , z.sald_gueltig_bis = q.sald_gueltig_bis
                            , z.sald_zeitstempel  = to_char(trunc(sysdate), ''yyyymmdd'')
                    when not matched then 
                        insert (z.sald_depo_stammnummer
                                    , z.sald_depo_nummer
                                    , z.sald_fond_isin
                                    , z.sald_depo_key
                                    , z.sald_fond_key
                                    , z.sald_gueltig_von
                                    , z.sald_gueltig_bis
                                    , z.sald_zeitstempel
                                    , z.sald_stck_storn_hist_bereinigt
                                    , z.sald_stck_storn_hist_ber_vorg
                                    , z.sald_zu_umsa_wa_im_ud_betrag
                                    , z.sald_ab_betrag_steuer
                                    , z.sald_ab_betrag_wa_dep_extern
                                    , z.sald_zu_betr_esw_relevant_ges
                                    , z.sald_ab_betr_esw_relevant_ges
                                    , z.sald_zu_betr_realisierung_ges
                                    , z.sald_ab_betr_realisierung_ges)
                        values (q.sald_depo_stammnummer
                                    , q.sald_depo_nummer
                                    , q.sald_fond_isin
                                    , q.sald_depo_key
                                    , q.sald_fond_key
                                    , q.sald_gueltig_von
                                    , q.sald_gueltig_bis
                                    , q.sald_zeitstempel
                                    , q.sald_stck_storn_hist_bereinigt
                                    , q.sald_stck_storn_hist_ber_vorg
                                    , q.sald_zu_umsa_wa_im_ud_betrag
                                    , q.sald_ab_betrag_steuer
                                    , q.sald_ab_betrag_wa_dep_extern
                                    , q.sald_zu_betr_esw_relevant_ges
                                    , q.sald_ab_betr_esw_relevant_ges
                                    , q.sald_zu_betr_realisierung_ges
                                    , q.sald_ab_betr_realisierung_ges
                                )                                                  
                ';
                nbAnzahlSaetzeDML := SQL%ROWCOUNT;
                commit;
                
                p_write_guv_abholungslog (in_prozedur => 'P_LOAD_SALDEN', in_ladedatum => dtLadedatum, in_meldung => 'Tranche '||nbDurchlauf||': Es wurden '||to_char(nbAnzahlSaetzeDML)||' neue Salden eingefuegt.');
                nbAnzahlSaetzeDMLGesamt := nbAnzahlSaetzeDMLGesamt + nbAnzahlSaetzeDML;
                
            end Zieltabelle_befuellen;

    end loop;
    close c_durchlaeufe;
    
    p_write_guv_abholungslog (in_prozedur => 'P_LOAD_SALDEN', in_ladedatum => dtLadedatum, in_meldung => 'Es wurden '||to_char(nbAnzahlSaetzeDMLGesamt)||' Saetze in der Tabelle DISPO.SALDEN aktualsiert.');
    p_write_guv_abholungsprotokoll (in_gvap_key => nbProtokollKey, out_gvap_key => nbProtokollKey);

end;

procedure p_init_salden (instanz_id in number default null, in_ladedatum in date default null, in_quelltabelle in varchar2 default 'SALDEN', in_stZieltabelle in varchar2 default 'SALDEN', in_nbAnzahlDurchlaeufe in number default null, in_nbDurchlauf in number default null)
as

    type cursor_type is ref cursor;
    c_durchlaeufe cursor_type;
    stSQL varchar2(32767 char);
    dtLadedatum date;
    nbProtokollKey number;
    nbAnzahlSaetzeDML number;
    nbAnzahlSaetzeDMLGesamt number := 0;
    nbDurchlauf number := in_nbDurchlauf;
    nbAnzahlDurchlaeufe number;
    nbMinDepoKey number;
    nbMaxDepoKey number;
    stFilterDurchlauf varchar2(32767 char);
    
    stZieltabelle varchar2(30 char) := in_stZieltabelle;
    stQuelltabelle varchar2(30 char) := in_quelltabelle;
    
begin

    if in_ladedatum is null
    then
        dtLadedatum := f_get_naechstes_ladedatum (in_zieltabelle => 'SALDEN');
    else
        dtLadedatum := in_ladedatum;
    end if;

    p_write_guv_abholungsprotokoll (in_tabelle => 'SALDEN', in_ladedatum => dtLadedatum, out_gvap_key => nbProtokollKey);
    
    if nbDurchlauf is not null then
        stFilterDurchlauf := ' and ko.durchlauf = '||nbDurchlauf||' ';
    end if;
        stSQL := '
                    select ko.durchlauf
                            , ko.min_depo_key
                            , ko.max_depo_key
                    from dwhload.ko_dispo_salden_transfer@VDWH.VDWH_DISPO ko
                            left outer join dwhload.pr_dispo_salden_transfer@VDWH.VDWH_DISPO pr on ko.durchlauf = pr.durchlauf
                    where pr.durchlauf is null
                    '||stFilterDurchlauf||'
                    order by ko.durchlauf
            ';

        open c_durchlaeufe for stSQL;
        loop
            fetch c_durchlaeufe into nbDurchlauf, nbMinDepoKey, nbMaxDepoKey;
            exit when c_durchlaeufe%notfound;
            
            stSQL := '
                        insert into dwhload.pr_dispo_salden_transfer@VDWH.VDWH_DISPO (durchlauf, min_depo_key, max_depo_key, ladedatum, startzeit)
                        values (:durchlauf, :min_depo_key, :max_depo_key, :ladedatum, :startzeit)
                    ';
            execute immediate stSQL using nbDurchlauf, nbMinDepoKey, nbMaxDepoKey, dtLadedatum, sysdate;
            commit;

--            <<Vortabelle_befuellen>>
--            begin 
--            
--                /* Aktuelle Salden */ 
--                p_write_guv_abholungslog (in_prozedur => 'P_LOAD_SALDEN', in_ladedatum => dtLadedatum, in_meldung => 'Tranche '||nbDurchlauf||': Hole Salden zu Ladedatum aus vDWH ab...');        
--                dispo.p_truncate_vor_tabelle (in_tabelle => 'VOR_SALDEN'); 
--
--                execute immediate '
--                    insert into dispo.vor_salden (sald_depo_stammnummer
--                                                    , sald_depo_nummer
--                                                    , sald_fond_isin
--                                                    , sald_depo_key
--                                                    , sald_fond_key
--                                                    , sald_gueltig_von
--                                                    , sald_gueltig_bis
--                                                    , sald_zeitstempel
--                                                    , sald_stck_storn_hist_bereinigt
--                                                    , sald_stck_storn_hist_ber_vorg
--                                                    , sald_zu_umsa_wa_im_ud_betrag
--                                                    , sald_ab_betrag_steuer
--                                                    , sald_ab_betrag_wa_dep_extern
--                                                    , sald_zu_betr_esw_relevant_ges
--                                                    , sald_ab_betr_esw_relevant_ges
--                                                    , sald_zu_betr_realisierung_ges
--                                                    , sald_ab_betr_realisierung_ges
--                    )
--                    select  depo_stammnummer_anon as sald_depo_stammnummer
--                                , depo_nummer_anon as sald_depo_nummer
--                                , fond_isin sald_fond_isin
--                                , sald_depo_key
--                                , sald_fond_key
--                                , sald_gueltig_von
--                                , sald_gueltig_bis
--                                , sald_zeitstempel
--                                , case when sald_stck_storn_hist_bereinigt < 0 then 0 else sald_stck_storn_hist_bereinigt end as sald_stck_storn_hist_bereinigt
--                                , case when sald_stck_storn_hist_ber_vorg < 0 then 0 else sald_stck_storn_hist_ber_vorg end as sald_stck_storn_hist_ber_vorg
--                                , sald_zu_umsa_wa_im_ud_betrag
--                                , sald_ab_betrag_steuer
--                                , sald_ab_betrag_wa_dep_extern
--                                , sald_zu_betr_esw_relevant_ges
--                                , sald_ab_betr_esw_relevant_ges
--                                , sald_zu_betr_realisierung_ges
--                                , sald_ab_betr_realisierung_ges
--                    from dwh.'||stQuelltabelle||'@VDWH.VDWH_DISPO
--                            join dwh.fondsanteilsscheine@vdwh.vdwh_dispo on fond_key = sald_fond_key
--                            join dwhload.bekannt_azure_u_depots_anonym@VDWH.VDWH_DISPO on depo_key = sald_depo_key
--                    where sald_depo_key between :nbMinDepoKey and :nbMaxDepoKey
--                ' using nbMinDepoKey, nbMaxDepoKey;
--                nbAnzahlSaetzeDML := SQL%ROWCOUNT;
--                commit;
--
--                p_write_guv_abholungslog (in_prozedur => 'P_LOAD_SALDEN', in_ladedatum => dtLadedatum, in_meldung => 'Tranche '||nbDurchlauf||': Es wurden '||to_char(nbAnzahlSaetzeDML)||' Saetze abgeholt.');
--                p_close_db_link;
--                            
--            end Vortabelle_befuellen;         

            <<Zieltabelle_befuellen>>
            begin
                        
                p_write_guv_abholungslog (in_prozedur => 'P_LOAD_SALDEN', in_ladedatum => dtLadedatum, in_meldung => 'Tranche '||nbDurchlauf||': Merge in die Zieltabelle SALDEN ...'); 

--                execute immediate '
--                    insert into dispo.'||stZieltabelle||' z
--                          select sald_depo_stammnummer
--                                    , sald_depo_nummer
--                                    , sald_fond_isin
--                                    , sald_depo_key
--                                    , sald_fond_key
--                                    , sald_gueltig_von
--                                    , sald_gueltig_bis
--                                    , sald_zeitstempel
--                                    , sald_stck_storn_hist_bereinigt
--                                    , sald_stck_storn_hist_ber_vorg
--                                    , sald_zu_umsa_wa_im_ud_betrag
--                                    , sald_ab_betrag_steuer
--                                    , sald_ab_betrag_wa_dep_extern
--                                    , sald_zu_betr_esw_relevant_ges
--                                    , sald_ab_betr_esw_relevant_ges
--                                    , sald_zu_betr_realisierung_ges
--                                    , sald_ab_betr_realisierung_ges
--                        from dispo.vor_salden
--                        order by sald_depo_stammnummer
--                                    , sald_depo_nummer
--                                    , sald_fond_isin
--                                    , sald_depo_key
--                                    , sald_fond_key
--                                    , sald_gueltig_von
--                                    , sald_gueltig_bis
--                ';
--                nbAnzahlSaetzeDML := SQL%ROWCOUNT;
--                commit;

                execute immediate '
                    insert into dispo.'||stZieltabelle||' z
                     select  depo_stammnummer_anon as sald_depo_stammnummer
                                , depo_nummer_anon as sald_depo_nummer
                                , fond_isin sald_fond_isin
                                , sald_depo_key
                                , sald_fond_key
                                , sald_gueltig_von
                                , sald_gueltig_bis
                                , sald_zeitstempel
                                , case when sald_stck_storn_hist_bereinigt < 0 then 0 else sald_stck_storn_hist_bereinigt end as sald_stck_storn_hist_bereinigt
                                , case when sald_stck_storn_hist_ber_vorg < 0 then 0 else sald_stck_storn_hist_ber_vorg end as sald_stck_storn_hist_ber_vorg
                                , sald_zu_umsa_wa_im_ud_betrag
                                , sald_ab_betrag_steuer
                                , sald_ab_betrag_wa_dep_extern
                                , sald_zu_betr_esw_relevant_ges
                                , sald_ab_betr_esw_relevant_ges
                                , sald_zu_betr_realisierung_ges
                                , sald_ab_betr_realisierung_ges
                    from dwh.'||stQuelltabelle||'@VDWH.VDWH_DISPO
                            join dwh.fondsanteilsscheine@vdwh.vdwh_dispo on fond_key = sald_fond_key
                            join dwhload.bekannt_azure_u_depots_anonym@VDWH.VDWH_DISPO on depo_key = sald_depo_key
                    where sald_depo_key between :nbMinDepoKey and :nbMaxDepoKey
                    order by sald_depo_stammnummer
                                , sald_depo_nummer
                                , sald_fond_isin
                                , sald_depo_key
                                , sald_fond_key
                                , sald_gueltig_von
                                , sald_gueltig_bis
                ' using nbMinDepoKey, nbMaxDepoKey;
                nbAnzahlSaetzeDML := SQL%ROWCOUNT;
                commit;

                stSQL := '
                            update dwhload.pr_dispo_salden_transfer@VDWH.VDWH_DISPO 
                            set endezeit = :endezeit
                                    , zeilen = :zeilen
                            where durchlauf = :durchlauf
                        ';
                execute immediate stSQL using sysdate, nbAnzahlSaetzeDML, nbDurchlauf;
                commit;
                                
                p_write_guv_abholungslog (in_prozedur => 'P_LOAD_SALDEN', in_ladedatum => dtLadedatum, in_meldung => 'Tranche '||nbDurchlauf||': Es wurden '||to_char(nbAnzahlSaetzeDML)||' neue Salden eingefuegt.');
                nbAnzahlSaetzeDMLGesamt := nbAnzahlSaetzeDMLGesamt + nbAnzahlSaetzeDML;
                
            end Zieltabelle_befuellen;

    end loop;
    close c_durchlaeufe;
    
    p_write_guv_abholungslog (in_prozedur => 'P_LOAD_SALDEN', in_ladedatum => dtLadedatum, in_meldung => 'Es wurden '||to_char(nbAnzahlSaetzeDMLGesamt)||' Saetze in der Tabelle DISPO.SALDEN aktualsiert.');
    p_write_guv_abholungsprotokoll (in_gvap_key => nbProtokollKey, out_gvap_key => nbProtokollKey);

end;

--------------------------------------------------------------------------------
procedure p_load_fondsanteilsscheine (instanz_id in number default null, in_ladedatum in date default null)
as

    stSQL varchar2(32767 char);
    nbAnzahlSaetzeDML number;
    nbProtokollKey number;
    dtLadedatum date;

begin

    if in_ladedatum is null
    then
        dtLadedatum := f_get_naechstes_ladedatum (in_zieltabelle => 'FONDSANTEILSSCHEINE'); 
    else 
        dtLadedatum := in_ladedatum;
    end if;

    p_write_guv_abholungsprotokoll (in_tabelle => 'FONDSANTEILSSCHEINE', in_ladedatum => dtLadedatum, out_gvap_key => nbProtokollKey);

    <<Abholung_Quelldaten>>
    begin
    
        p_write_guv_abholungslog (in_prozedur => 'P_LOAD_FONDSANTEILSSCHEINE', in_ladedatum => dtLadedatum, in_meldung => 'Hole Fondsanteilsscheine ab...');
        dispo.p_truncate_vor_tabelle (in_tabelle => 'VOR_FONDSANTEILSSCHEINE');

        stSQL := '
            insert into dispo.vor_fondsanteilsscheine (
                fond_key
                , fond_isin
                , fond_kz_mittelverwendung
                , fond_kz_geloescht
                , fond_ssp_switch
            )
            select fond_key
                , fond_isin
                , fond_kz_mittelverwendung
                , fond_kz_geloescht
                , fond_ssp_switch
            from dwh.fondsanteilsscheine@VDWH.VDWH_DISPO 
        ';
        execute immediate stSQL;
        nbAnzahlSaetzeDML := SQL%ROWCOUNT;
        commit;
        
        p_write_guv_abholungslog (in_prozedur => 'P_LOAD_FONDSANTEILSSCHEINE', in_ladedatum => dtLadedatum, in_meldung => 'Es wurden '||to_char(nbAnzahlSaetzeDML)||' Fondsanteilsscheine abgeholt');
        p_close_db_link;
        
    end Abholung_Quelldaten;    
    
    <<Zieltabelle_befuellen>>
    begin
         
        p_write_guv_abholungslog (in_prozedur => 'P_LOAD_FONDSANTEILSSCHEINE', in_ladedatum => dtLadedatum, in_meldung => 'Aktualisiere Fondsanteilsscheine...');
    
        stSQL := '
            merge into dispo.fondsanteilsscheine z
            using (
                select fond_key
                    , fond_isin
                    , fond_kz_mittelverwendung
                    , fond_kz_geloescht
                    , fond_ssp_switch
                from dispo.vor_fondsanteilsscheine
            ) q
            on (z.fond_key = q.fond_key)
            when matched then
                update set z.fond_isin = q.fond_isin
                    , z.fond_kz_mittelverwendung = q.fond_kz_mittelverwendung
                    , z.fond_kz_geloescht = q.fond_kz_geloescht
                    , z.fond_ssp_switch = q.fond_ssp_switch
            when not matched then
                insert (fond_key, fond_isin, fond_kz_mittelverwendung, fond_kz_geloescht, fond_ssp_switch)
                values (q.fond_key, q.fond_isin, q.fond_kz_mittelverwendung, q.fond_kz_geloescht, q.fond_ssp_switch)
        ';
        execute immediate stSQL;
        nbAnzahlSaetzeDML := SQL%ROWCOUNT;
        commit;
        
        p_write_guv_abholungslog (in_prozedur => 'P_LOAD_FONDSANTEILSSCHEINE', in_ladedatum => dtLadedatum, in_meldung => 'Es wurden '||to_char(nbAnzahlSaetzeDML)||' Fondsanteilsscheine aktualisiert.');
        
    end Zieltabelle_befuellen;
    
    p_write_guv_abholungsprotokoll (in_gvap_key => nbProtokollKey, out_gvap_key => nbProtokollKey);
    
end p_load_fondsanteilsscheine;
--------------------------------------------------------------------------------
function f_ist_zeit_zu_laden (instanz_id in number default null) 
    return number
as

    /*
        Beschreibung:
            Die Funktion prüft, ob die Zeit zu aktualisieren ist. Die Zeit soll jeden Tag einmal geladen werden.
        
        Versionshistorie:
            07.11.2016 Arne Arnold, Infomotion GmbH: Erstellung der Funktion    
    */

    nbReturnWert number(1);

begin
    
    execute immediate '
        select case when ist_zeit_bereits_aktualisiert >= 1
                    then 0
                    else 1
                end as ist_zeit_zu_aktualisieren 
        from (                    
            select count(*) as ist_zeit_bereits_aktualisiert
            from dispo.guv_abholungsprotokoll
            where upper(gvap_tabelle) = ''ZEIT''
                and gvap_ladedatum >= trunc(sysdate) 
                and gvap_endezeit is not null
        )
    ' into nbReturnWert;
    
    return nbReturnWert;
    
end f_ist_zeit_zu_laden;
--------------------------------------------------------------------------------
function f_sind_alle_abholungen_erfolgt (instanz_id in number default null)
    return number
as

    /*
        Beschreibung:
            Die Funktion prüft, ob nach dem Abschluss eines Ladelaufs schon alle Abholungen nach Astoria erfolgt sind.
        
        Versionshistorie: 
            08.11.2016 Arne Arnold, Infomotion GmbH: Erstellung der Funktion
    */

begin

    return 1;
    
end f_sind_alle_abholungen_erfolgt; 
--------------------------------------------------------------------------------
function f_sind_fonds_zu_laden (instanz_id in number default null) 
    return number
as

    /*
        Beschreibung:
            Die Funktion prüft, ob die Fondsanteilsscheine zu aktualisieren sind. 
        
        Versionshistorie:
            07.11.2016 Arne Arnold, Infomotion GmbH: Erstellung der Funktion    
    */

    nbReturnWert number(1);

begin
    
    execute immediate '
        select case when fondsanteilsscheine_erstellt >= 1
                    then 0
                    else 1
                end as fondsanteilsscheine_erstellen        
        from (            
            select count(*) as fondsanteilsscheine_erstellt
            from dispo.guv_abholungsprotokoll
                inner join (
                    select max(lplb_ladedatum) as letztes_vdwh_ladedatum
                    from dwh_repos_etl.llf_ko_Ladeblock_logisch@VDWH.VDWH_DISPO
                        inner join dwh_repos_etl.llf_pr_ladeblock@VDWH.VDWH_DISPO 
                            on lplb_lblg_id = lblg_id
                    where lblg_block_name = ''load_fond2ssp_switch - UNSPEZIFISCH'' --> damit ist auch der Block "fonds_essentiell_ready - UNSPEZIFISCH" abgeschlossen
                        and lplb_statuscode = ''110''
                )          
                    on gvap_ladedatum >= letztes_vdwh_ladedatum       
            where upper(gvap_tabelle) = ''FONDSANTEILSSCHEINE''
                and gvap_endezeit is not null
        )
    ' into nbReturnWert;    
    
    return nbReturnWert;
    
end f_sind_fonds_zu_laden;

--------------------------------------------------------------------------------
function f_sind_salden_zu_laden (instanz_id in number default null) 
    return number
as

    /*
        Beschreibung:
            Die Funktion prüft, ob die Salden zu aktualisieren sind. 
        
        Versionshistorie:
            23.11.2016 Arne Arnold, Infomotion GmbH: Erstellung der Funktion    
    */

    nbReturnWert number(1);

begin
    
    execute immediate '
        select case when salden_erstellt >= 1
                    then 0
                    else 1
                end as salden_sind_zu_erstellen        
        from (            
            select count(*) as salden_erstellt
            from dispo.guv_abholungsprotokoll
                inner join (
                    select max(lplb_ladedatum) as letztes_vdwh_ladedatum
                    from dwh_repos_etl.llf_ko_Ladeblock_logisch@VDWH.VDWH_DISPO
                        inner join dwh_repos_etl.llf_pr_ladeblock@VDWH.VDWH_DISPO 
                            on lplb_lblg_id = lblg_id
                    where lblg_block_name = ''load_saldenguv1umsa_eath - P50''
                        and lplb_statuscode = ''110''
                )          
                    on gvap_ladedatum >= letztes_vdwh_ladedatum       
            where upper(gvap_tabelle) = ''SALDEN''
                and gvap_endezeit is not null
        )
    ' into nbReturnWert;    
        
    return nbReturnWert;
    
end f_sind_salden_zu_laden;

function f_sind_salden_zu_laden_alt (instanz_id in number default null) 
    return number
as

    /*
        Beschreibung:
            Die Funktion prüft, ob die Salden zu aktualisieren sind. 
        
        Versionshistorie:
            23.11.2016 Arne Arnold, Infomotion GmbH: Erstellung der Funktion    
    */

    nbReturnWert number(1);

begin
    
    execute immediate '
        select case when salden_erstellt >= 1
                    then 0
                    else 1
                end as salden_sind_zu_erstellen        
        from (            
            select count(*) as salden_erstellt
            from dispo.guv_abholungsprotokoll
                inner join (
                    select max(lplb_ladedatum) as letztes_vdwh_ladedatum
                    from dwh_repos_etl.llf_ko_Ladeblock_logisch@VDWH.VDWH_DISPO
                        inner join dwh_repos_etl.llf_pr_ladeblock@VDWH.VDWH_DISPO 
                            on lplb_lblg_id = lblg_id
                    where lblg_block_name = ''load_sald1umsa_eath - P50''
                        and lplb_statuscode = ''110''
                )          
                    on gvap_ladedatum >= letztes_vdwh_ladedatum       
            where upper(gvap_tabelle) = ''SALDEN_ALT''
                and gvap_endezeit is not null
        )
    ' into nbReturnWert;    
        
    return nbReturnWert;
    
end f_sind_salden_zu_laden_alt;
--------------------------------------------------------------------------------
procedure p_neu_transfer_daten 
as
begin

    /* Daten für reaktivierte Depots neu laden */
    execute immediate '
        insert into todo_reaktivierte_depots 
        select depo_key
            , grdp_depotnummer
            , grdp_depotstammnummer
            , grdp_dt_instanz_pseudo_start
            , grdp_dt_instanz_pseudo_ende
        from dispo.GELOESCHTE_REAKTIVIERTE_DEPOTS
        where grdp_kz_ist_reaktiviert = ''J''
            and grdp_kz_daten_reaktiviert = ''N''
    ';
    commit;

end p_neu_transfer_daten;


procedure p_sende_guv_fopr_error_mail (instanz_id in number default null)
as
    dtladedatum date;
    nbprotokollkey number;
    stSQL varchar2(32767 char);
    nbMailBereitsVersendet number := 0;
begin
    dtladedatum := VDWH.load_gewinn_und_verlust_daten.f_get_naechstes_ladedatum (in_zieltabelle => 'FONDSPREISE'); 

    
    /** Versende Infomail! ... wenn für das ermittelte Ladedatum nicht bereits eine versendet worden ist
    */
    stSQL := '
                select count(rownum)
                from dispo.guv_abholungsprotokoll
                where gvap_tabelle = ''FONDSPREISE''
                and gvap_ladedatum = :ladedatum 
            ';
    execute immediate stSQL into nbMailBereitsVersendet using dtladedatum;
                
    if nbMailBereitsVersendet = 0 then 
        p_write_guv_abholungsprotokoll (in_tabelle => 'FONDSPREISE', in_ladedatum => dtladedatum, out_gvap_key => nbprotokollkey);
        dispo.p_versende_html_email ( in_betreff => 'GuV-Beladung: Plausibilitätscheck der VDWH-Fondspreise ergab Unstimmigkeiten!', in_text => 'Manuelle Pruefung/Korrektur notwendig');
        p_write_guv_abholungsprotokoll (in_gvap_key => nbprotokollkey, out_gvap_key => nbprotokollkey);
    end if;
    
end;

function f_ist_guv_sonstige_zu_laden (instanz_id in number default null) return number
as

    nbReturnValue number;

begin

    execute immediate '
        select case when guv_depot_infos_aktuell >= 1
                    then 0
                    else 1
                end as depot_infos_sind_zu_laden        
        from (            
            select count(*) as guv_depot_infos_aktuell
            from dispo.guv_abholungsprotokoll
                inner join (
                    select max(lplb_ladedatum) as letztes_vdwh_ladedatum
                    from dwh_repos_etl.llf_ko_Ladeblock_logisch@VDWH.VDWH_DISPO
                        inner join dwh_repos_etl.llf_pr_ladeblock@VDWH.VDWH_DISPO 
                            on lplb_lblg_id = lblg_id
                    where lblg_block_name = ''load_gvdi1dwh_tabellen - P50''
                        and lplb_statuscode = ''110''
                )          
                    on gvap_ladedatum >= letztes_vdwh_ladedatum       
            where upper(gvap_tabelle) = ''GUV_SONSTIGE''
                and gvap_endezeit is not null
        ) 
    ' into nbReturnValue;    
    p_close_db_link;
    
    return nbReturnValue;

end ;

procedure p_merge_guv_sonstige (instanz_id in number default null, in_ladedatum in date default null, in_quelltabelle in varchar2 default 'GUV_SONSTIGE', in_stZieltabelle in varchar2 default 'GUV_SONSTIGE')
as
    stSQL varchar2(32767 char);
    dtLadedatum date;
    stQuelltabelle varchar2(30 char) := in_quelltabelle;
    stZieltabelle varchar2(30 char) := in_stZieltabelle;
    nbProtokollKey number;
    nbAnzahlSaetzeDML number;
begin

    if in_ladedatum is null then
        dtLadedatum := f_get_naechstes_ladedatum (in_zieltabelle => stQuelltabelle);
    else
        dtLadedatum := in_ladedatum;
    end if;
    
    p_write_guv_abholungsprotokoll (in_tabelle => stQuelltabelle, in_ladedatum => dtLadedatum, out_gvap_key => nbProtokollKey);
    
    stSQL := '
                merge into dispo.'||stZieltabelle||' z
                using (
                        select guvs_depo_key
                                , guvs_fond_key
                                , guvs_zeit_datum
                                , guvs_beleg_nummer
                                , guvs_beleg_unternummer
                                , guvs_dokument_nummer
                                , guvs_guv_sonstige
                                , guvs_guv_nachlass
                                , guvs_kz_geloescht
                        from dwh.'||stQuelltabelle||'@VDWH.VDWH_DISPO                             
                        ) q 
                on (z.guvs_depo_key = q.guvs_depo_key
                    and z.guvs_fond_key = q.guvs_fond_key
                    and z.guvs_zeit_datum = q.guvs_zeit_datum
                    and z.guvs_beleg_nummer = q.guvs_beleg_nummer
                    and z.guvs_beleg_unternummer = q.guvs_beleg_unternummer
                    and z.guvs_dokument_nummer = q.guvs_dokument_nummer)
                when matched then update
                    set z.guvs_guv_sonstige = q.guvs_guv_sonstige
                            , z.guvs_guv_nachlass = q.guvs_guv_nachlass
                            , z.guvs_kz_geloescht = q.guvs_kz_geloescht
                when not matched then insert (z.guvs_depo_key
                                                , z.guvs_fond_key
                                                , z.guvs_zeit_datum
                                                , z.guvs_beleg_nummer
                                                , z.guvs_beleg_unternummer
                                                , z.guvs_dokument_nummer
                                                , z.guvs_guv_sonstige
                                                , z.guvs_guv_nachlass
                                                , z.guvs_kz_geloescht)
                                        values (q.guvs_depo_key
                                                , q.guvs_fond_key
                                                , q.guvs_zeit_datum
                                                , q.guvs_beleg_nummer
                                                , q.guvs_beleg_unternummer
                                                , q.guvs_dokument_nummer
                                                , q.guvs_guv_sonstige
                                                , q.guvs_guv_nachlass
                                                , q.guvs_kz_geloescht)
            ';
    execute immediate stSQL;
    nbAnzahlSaetzeDML := SQL%ROWCOUNT;
    commit;
    
    p_write_guv_abholungslog (in_prozedur => 'P_MERGE_GUV_SONSTIGE', in_ladedatum => dtLadedatum, in_meldung => 'Es wurden '||to_char(nbAnzahlSaetzeDML)||' Saetze in der Tabelle DISPO.'||stZieltabelle||' aktualsiert.');
    p_write_guv_abholungsprotokoll (in_gvap_key => nbProtokollKey, out_gvap_key => nbProtokollKey);
    
end;

    procedure p_loesche_depots (instanz_id in number default null, debug in number default 0)
    as
        stProzedur varchar2(30 char) := 'DEPOTLOESCHUNGEN';
        sqlstmt clob;
        nbAnzahlDatensaetze number;
        nbProtokollKey number;
        stMaxDISPODatum varchar2(10 char);
        stMaxVDWHDatum varchar2(10 char);        
    begin

        if debug <> 0 then 
            dbms_output.enable(1000000);
        else
            dbms_output.disable;
        end if;

        execute immediate '
            select to_char(nvl(max(gvap_ladedatum),to_date(''11.11.1111'')),''dd.mm.rrrr'') max_gvap_ladedatum
            from dispo.guv_abholungsprotokoll
            where gvap_tabelle = '''||stProzedur||'''
        ' into stMaxDISPODatum;
        dbms_output.put_line('stMaxDISPODatum: '||stMaxDISPODatum);
          
        execute immediate '
                            select to_char(max(lplf_ladedatum),''dd.mm.rrrr'')
                            from dwh_repos_etl.llf_pr_ladelauf@VDWH.VDWH_DISPO
                            where lplf_ladelauftyp = ''LADELAUF''
                            and lplf_vollstaendig = ''J''
        ' into stMaxVDWHDatum;
        dbms_output.put_line('stMaxVDWHDatum: '||stMaxVDWHDatum);

        if to_date(stMaxVDWHDatum, 'dd.mm.yyyy') > to_date(stMaxDISPODatum, 'dd.mm.yyyy') then
                
            p_write_guv_abholungsprotokoll (in_tabelle => stProzedur, in_ladedatum => to_date(stMaxVDWHDatum, 'dd.mm.rrrr'), out_gvap_key => nbProtokollKey);
            /**
                Schreibe Löschaufträge
            */
            sqlstmt := '
                        insert into vdwh.dispodb_depots_loeschauftraege (ddla_sald_depo_stammnummer, ddla_sald_depo_nummer, ddla_lagerstelle_inst_kz, ddla_eingestellt_am)
                        select substr(apde_depot_nummer,1,8) depo_stammnummer
                                , apde_depot_nummer
                                , apde_lagerstelle_inst_kz
                                , sysdate
                        from dwh_repos_etl.anon_pr_depot@VDWH.VDWH_DISPO depo
                                join (
                                        select nvl(max(gval_ladedatum),to_date(''11.11.1111'', ''dd.mm.yyyy'')) max_gval_ladedatum
                                        from dispo.guv_abholungslog
                                        where gval_prozedur = '''||stProzedur||'''
                                    ) on max_gval_ladedatum < apde_angelegt_am
                        where apde_lagerstelle_inst_kz = ''U''
                        and not exists (
                                        select 1
                                        from vdwh.dispodb_depots_loeschauftraege ddla_exists 
                                        where ddla_exists.ddla_sald_depo_stammnummer = substr(apde_depot_nummer,1,8)
                                        and ddla_exists.ddla_sald_depo_nummer = apde_depot_nummer
                                        )
                    ';
            execute immediate sqlstmt;
            nbAnzahlDatensaetze := sql%rowcount;
            commit;
            dbms_output.put_line('Es wurden '||to_char(nbAnzahlDatensaetze)||' neue Depotlöschungssätze ermittelt.');
            p_write_guv_abholungslog (in_prozedur => stProzedur, in_ladedatum => to_date(stMaxVDWHDatum, 'dd.mm.rrrr'), in_meldung => 'Es wurden '||to_char(nbAnzahlDatensaetze)||' neue Depotlöschungssätze ermittelt.');

            if nbAnzahlDatensaetze > 0 then
                
                /**
                    Führe die Depotlöschungen aus
                */
                -- 1 SALDEN
                sqlstmt := '
                            delete from dispo.salden sald
                            where exists (
                                            select 1
                                            from vdwh.dispodb_depots_loeschauftraege ddla
                                            where ddla_loeschung_ausgefuehrt_am is null
                                            and ddla_sald_depo_stammnummer = sald.sald_depo_stammnummer
                                            and ddla_sald_depo_nummer = sald.sald_depo_nummer
                                        )
                        ';
                execute immediate sqlstmt;
                nbAnzahlDatensaetze := sql%rowcount;
                commit;
                if nbAnzahlDatensaetze > 0 then
                    dbms_output.put_line('Es wurden '||to_char(nbAnzahlDatensaetze)||' aus den SALDEN gelöscht.');
                    p_write_guv_abholungslog (in_prozedur => stProzedur, in_ladedatum => to_date(stMaxVDWHDatum, 'dd.mm.rrrr'), in_meldung => 'Es wurden '||to_char(nbAnzahlDatensaetze)||' aus den SALDEN gelöscht.');
                end if;

                -- 2 GUV_DEPOT_INFORMATIONEN
                sqlstmt := '
                            delete from dispo.guv_depot_informationen gvdi
                            where exists (
                                            select 1
                                            from vdwh.dispodb_depots_loeschauftraege ddla
                                            where ddla_loeschung_ausgefuehrt_am is null
                                            and ddla_sald_depo_stammnummer = gvdi.gvdi_stammdepotnummer
                                            and ddla_sald_depo_nummer = gvdi.gvdi_depotnummer
                                        )
                        ';
                execute immediate sqlstmt;
                nbAnzahlDatensaetze := sql%rowcount;
                commit;
                if nbAnzahlDatensaetze > 0 then
                    dbms_output.put_line('Es wurden '||to_char(nbAnzahlDatensaetze)||' aus den SALDEN gelöscht.');
                    p_write_guv_abholungslog (in_prozedur => stProzedur, in_ladedatum => to_date(stMaxVDWHDatum, 'dd.mm.rrrr'), in_meldung => 'Es wurden '||to_char(nbAnzahlDatensaetze)||' aus den GUV_DEPOT_INFORMATIONEN gelöscht.');
                end if;    
                
                sqlstmt := '
                            update vdwh.dispodb_depots_loeschauftraege ddla
                            set ddla_loeschung_ausgefuehrt_am = sysdate
                            where ddla_loeschung_ausgefuehrt_am is null
                        ';
                execute immediate sqlstmt;
                commit;
                
            end if;  
            p_write_guv_abholungsprotokoll (in_gvap_key => nbProtokollKey, out_gvap_key => nbProtokollKey);        
        end if;
    end;

end;
/

WHENEVER SQLERROR EXIT SUCCESS COMMIT

SPOOL OFF