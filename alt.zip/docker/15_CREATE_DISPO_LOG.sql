SPOOL /tmp/15_create_dispo_log.log

WHENEVER SQLERROR CONTINUE NONE

--DROP TABLE container_log;

CREATE TABLE container_log
(
  ctlg_timestamp TIMESTAMP DEFAULT LOCALTIMESTAMP,
  ctlg_subject VARCHAR2(100),
  ctlg_message VARCHAR2(4000)
);

GRANT INSERT, UPDATE, DELETE, SELECT ON container_log TO VDWH;

COMMIT;

/*
INSERT INTO dispo.container_log (ctlg_subject, ctlg_message)
VALUES ('01 - Script', 'bla bla bla bla');

SELECT *
FROM dispo.container_log;
*/
 
WHENEVER SQLERROR EXIT SUCCESS COMMIT

SPOOL OFF