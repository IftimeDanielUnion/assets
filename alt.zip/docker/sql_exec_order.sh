#!/usr/bin/env bash

runsqlsys () {
  # param 1 is $1
sqlplus -S /nolog << EOF
CONNECT $1@$ORACLE_SID AS SYSDBA;
whenever sqlerror exit sql.sqlcode;
#set echo off
#set heading off
set define off
set sqlblanklines on
$2
set define on
exit;
EOF
}

runsql () {
  # param 1 is $1
sqlplus -S /nolog << EOF
CONNECT $1@$ORACLE_SID;
whenever sqlerror exit sql.sqlcode;
#set echo off
#set heading off
set define off
set sqlblanklines on
$2
set define on
exit;
EOF
}

prepare_setup_scripts () {

sed -e "s|REPLACE_DB_USER_DISPO_PWD|${DB_USER_DISPO_PWD}|g" -i "/opt/oracle/scripts/startup/sql_script/10_CREATE_USERS.sql"
sed -e "s|REPLACE_DB_USER_VDWH_PWD|${DB_USER_VDWH_PWD}|g" -i "/opt/oracle/scripts/startup/sql_script/10_CREATE_USERS.sql"

}

prepare_setup_scripts

echo "TS::$(date): Starting 10_CREATE_USERS.sql..."
runsqlsys "SYS/$ORACLE_PWD" "@/opt/oracle/scripts/startup/sql_script/10_CREATE_USERS.sql;"

echo "TS::$(date): Starting 15_CREATE_DISPO_LOG.sql..."
runsql "DISPO/$DB_USER_DISPO_PWD" "@/opt/oracle/scripts/startup/sql_script/15_CREATE_DISPO_LOG.sql;"

echo "TS::$(date): Starting 20_CREATE_DISPO_OBJECTS.sql..."
runsql "DISPO/$DB_USER_DISPO_PWD" "@/opt/oracle/scripts/startup/sql_script/20_CREATE_DISPO_OBJECTS.sql;"

echo "TS::$(date): Starting 30_CREATE_VDWH_OBJECTS.sql..."
runsql "VDWH/$DB_USER_VDWH_PWD" "@/opt/oracle/scripts/startup/sql_script/30_CREATE_VDWH_OBJECTS.sql;"

echo "TS::$(date): Starting 40_CREATE_VDWH_OBJECTS_INIT.sql..."
runsql "VDWH/$DB_USER_VDWH_PWD" "@/opt/oracle/scripts/startup/sql_script/40_CREATE_VDWH_OBJECTS_INIT.sql;"

echo "TS::$(date): DONE"