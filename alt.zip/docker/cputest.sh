#!/usr/bin/env bash

counter=0
max_counter=$1

if [ $# -ne 1 ]; then
  echo "SYNTAX: $0 <n>"
  exit 1
fi

while [ $counter -lt $max_counter ]; do
  echo "Starting process $counter"
  time awk 'BEGIN {for (i = 0; i < 100000; i++) for (j = 0; j < 10000; j++); }' &
  counter=$(( $counter + 1 ))
done
