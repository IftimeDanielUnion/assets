"U";"02.12.21 06:56:35,042607";"EE02132";"P";"3";"3";"1";"1";"select case when ich_bin='ENTWICKLUNG' then
            case when cnt_unvollst_llf=0 then
                 case when last_ladedatum< trunc(sysdate)-1 then 1 else 0 end
            else 0 end 
       else case when to_DATE(to_CHAR(to_DATE(substr(dwh_proc_contr.next_load('LADELAUF'), 1, 8), 'yyyymmdd'), 'dd.mm.yyyy')||'21:00:00', 'dd.mm.yyyy hh24:mi:ss')  <= sysdate AND cnt_unvollst_llf=0
                 then 1
            else 0 end
       end retVal
from
(select count(*) cnt_unvollst_llf from DWH_REPOS_ETL.LLF_PR_LADELAUF where nvl(lplf_vollstaendig, 'N')!='J' and lplf_ladelauftyp = 'LADELAUF'),
(select max(lplf_id), max(lplf_ladedatum) keep (dense_rank first order by lplf_id desc) last_ladedatum from DWH_REPOS_ETL.LLF_PR_LADELAUF where nvl(lplf_vollstaendig, 'N')='J' and lplf_ladelauftyp = 'LADELAUF')";"select case when ich_bin='ENTWICKLUNG' then
            case when cnt_unvollst_llf=0 then
                 case when last_ladedatum< trunc(sysdate)-2 then 1 else 0 end
            else 0 end 
       else case when to_DATE(to_CHAR(to_DATE(substr(dwh_proc_contr.next_load('LADELAUF'), 1, 8), 'yyyymmdd'), 'dd.mm.yyyy')||'21:00:00', 'dd.mm.yyyy hh24:mi:ss')  <= sysdate AND cnt_unvollst_llf=0
                 then 1
            else 0 end
       end retVal
from
(select count(*) cnt_unvollst_llf from DWH_REPOS_ETL.LLF_PR_LADELAUF where nvl(lplf_vollstaendig, 'N')!='J' and lplf_ladelauftyp = 'LADELAUF'),
(select max(lplf_id), max(lplf_ladedatum) keep (dense_rank first order by lplf_id desc) last_ladedatum from DWH_REPOS_ETL.LLF_PR_LADELAUF where nvl(lplf_vollstaendig, 'N')='J' and lplf_ladelauftyp = 'LADELAUF')"
"U";"02.12.21 06:57:06,780962";"EE02132";"P";"3";"3";"1";"1";"select case when ich_bin='ENTWICKLUNG' then
            case when cnt_unvollst_llf=0 then
                 case when last_ladedatum< trunc(sysdate)-2 then 1 else 0 end
            else 0 end 
       else case when to_DATE(to_CHAR(to_DATE(substr(dwh_proc_contr.next_load('LADELAUF'), 1, 8), 'yyyymmdd'), 'dd.mm.yyyy')||'21:00:00', 'dd.mm.yyyy hh24:mi:ss')  <= sysdate AND cnt_unvollst_llf=0
                 then 1
            else 0 end
       end retVal
from
(select count(*) cnt_unvollst_llf from DWH_REPOS_ETL.LLF_PR_LADELAUF where nvl(lplf_vollstaendig, 'N')!='J' and lplf_ladelauftyp = 'LADELAUF'),
(select max(lplf_id), max(lplf_ladedatum) keep (dense_rank first order by lplf_id desc) last_ladedatum from DWH_REPOS_ETL.LLF_PR_LADELAUF where nvl(lplf_vollstaendig, 'N')='J' and lplf_ladelauftyp = 'LADELAUF')";"select case when ich_bin='ENTWICKLUNG' then
            case when cnt_unvollst_llf=0 then
                 case when last_ladedatum< trunc(sysdate)-1 then 1 else 0 end
            else 0 end 
       else case when to_DATE(to_CHAR(to_DATE(substr(dwh_proc_contr.next_load('LADELAUF'), 1, 8), 'yyyymmdd'), 'dd.mm.yyyy')||'21:00:00', 'dd.mm.yyyy hh24:mi:ss')  <= sysdate AND cnt_unvollst_llf=0
                 then 1
            else 0 end
       end retVal
from
(select count(*) cnt_unvollst_llf from DWH_REPOS_ETL.LLF_PR_LADELAUF where nvl(lplf_vollstaendig, 'N')!='J' and lplf_ladelauftyp = 'LADELAUF'),
(select max(lplf_id), max(lplf_ladedatum) keep (dense_rank first order by lplf_id desc) last_ladedatum from DWH_REPOS_ETL.LLF_PR_LADELAUF where nvl(lplf_vollstaendig, 'N')='J' and lplf_ladelauftyp = 'LADELAUF')"
