"U";"17.12.21 14:59:30,561702";"EE02132";"P";"erwartungshaltung";"erwartungshaltung";"GSD_ABHOL_ERWARTUNGSH";"GSD_ABHOL_ERWARTUNGSH";"0";"0";"CREATE OR REPLACE procedure SAS2ORA.GSD_ABHOL_ERWARTUNGSH (forecast_tage in number default 350)
as
rcnt number;

type cursor_type is ref cursor; 
c cursor_TYPE;

zop VARCHAR2(30 CHAR);
abh_am_tag NUMBER;
UMGEBUNG_LIEFERANT VARCHAR2 (30 CHAR);
UMGEBUNG_URQUELLE VARCHAR2 (30 CHAR);
freigabe VARCHAR2 (10 char);
intervall NUMBER;

i NUMBER;

begin

/*************Routine von GSD dynamisch erstellt***************
*  FIXER Code in DWH_REPOS_ETL.GSD_KO_SOURCE_PLUGIN_PROC      *
*  ERSTELLT von Jens Thole (c) 2013                           *
***************************************************************/


/*******************************************************************************************************************************************************************************************
 erstelle zentrale BASIS-Zeit-View GSD$PROTOKALENDER_FROM_VDWH
 -------------------------------------------------------------
 Hier ist anzumerken, da� die Kolumne ZEIT_IST_WERKT";"CREATE OR REPLACE procedure SAS2ORA.GSD_ABHOL_ERWARTUNGSH (forecast_tage in number default 350)
as
rcnt number;

type cursor_type is ref cursor; 
c cursor_TYPE;

zop VARCHAR2(30 CHAR);
abh_am_tag NUMBER;
UMGEBUNG_LIEFERANT VARCHAR2 (30 CHAR);
UMGEBUNG_URQUELLE VARCHAR2 (30 CHAR);
freigabe VARCHAR2 (10 char);
intervall NUMBER;

i NUMBER;

begin

/*************Routine von GSD dynamisch erstellt***************
*  FIXER Code in DWH_REPOS_ETL.GSD_KO_SOURCE_PLUGIN_PROC      *
*  ERSTELLT von Jens Thole (c) 2013                           *
***************************************************************/


/*******************************************************************************************************************************************************************************************
 erstelle zentrale BASIS-Zeit-View GSD$PROTOKALENDER_FROM_VDWH
 -------------------------------------------------------------
 Hier ist anzumerken, da� die Kolumne ZEIT_IST_WERKT";"1";"1";"0";"0"
