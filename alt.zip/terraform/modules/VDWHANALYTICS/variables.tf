variable "arm_tenant_id" {
  type = string
}

variable "arm_subscription_id" {
  type = string
}

variable "region" {
  type = string
}

variable "workload_environment" {
  type = string
}

variable "workload_name" {
  type = string
}

variable "workload_environment_display_name" {
  type = string
}

variable "managed_resource_group_name" {
  type = string
}

variable "managed_keyvault_name" {
  type = string
}

variable "managed_keyvault_id" {
  type = string
}

variable "managed_storage_account_name" {
  type = string
}

variable "managed_storage_account_id" {
  type = string
}

variable "managed_log_analytics_name" {
  type = string
}

variable "managed_log_analytics_id" {
  type = string
}

variable "managed_virtual_network_name" {
  type = string
  default = ""
}

variable "managed_virtual_network_id" {
  type = string
  default = ""
}

variable "managed_subnet_name" {
  type = list(string)
  default = []
}

variable "managed_subnet_id" {
  type = list(string)
  default = []
}
