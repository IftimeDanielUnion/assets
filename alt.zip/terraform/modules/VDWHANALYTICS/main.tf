terraform {
  required_version = "= 0.13.5"
  backend "azurerm" {}
  required_providers {
    azurerm = {
      source = "hashicorp/azurerm"
      version = "~> 2.38.0"
    }
    random = {
      source = "hashicorp/random"
      version = "~> 3.0.0"
    }
    template = {
      source = "hashicorp/template"
      version = "~> 2.2.0"
    }
    kubernetes = {
      source = "hashicorp/kubernetes"
      version = "~> 1.13.3"
    }
    helm = {
      source = "hashicorp/helm"
      version = "~> 1.3.2"
    }
    kubectl = {
      source = "gavinbunney/kubectl"
      version = "1.9.1"
    }
  }
}

locals {
  rand_id = random_id.rand_id.hex
}

resource "random_id" "rand_id" {
  keepers = {
    seed = "40374743331728269655576791709"
  }

  byte_length = 4
}
