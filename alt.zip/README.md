# vDWH Azure PoC

For the UIT vDWH PoC, it will be evaluated to see if the analytics workload on the on-premise vDWH can be shifted to the Azure Cloud. According to the current idea, an Oracle 19 Enterprise database will be packaged in a container and deployed on an Azure Kubernetes service (AKS). AKS was chosen because it is currently the only container service on Azure that allows fine-grained hardware sizing of the execution environment. In addition, the workload to be executed has very high hardware requirements. (64 vCPU, 512GB RAM, ...)

To save costs it is a mandatory requirement that the AKS can be started and stopped at will. Recently the service offers a start/stop feature which is in preview. For the operation within Union Investment, a special network configuration is necessary, which unfortunately becomes unusable when the AKS is stopped. herefore, a dedicated Azure pipeline `manage-aks` which can start and stop the AKS using parameters has been created. The build pipeline contains some additional steps to ensure that the cluster has been stopped or started properly.

The definition of all required Azure Resources is done in [Terraform](https://www.terraform.io) configuration files and can be found in the folder `modules/VDWHANALYTICS`. Terraform is executed via [Terragrunt](https://github.com/gruntwork-io/terragrunt), which is a thin wrapper that provides extra tools for keeping the environment configurations [DRY](https://en.wikipedia.org/wiki/Don%27t_repeat_yourself) and managing remote state.

## How is the code in this repo organized?

The structure of the project is inspired by the Gruntwork Blog ["How to manage multiple versions of Terragrunt and Terraform as a team in your IaC project"](https://blog.gruntwork.io/how-to-manage-multiple-versions-of-terragrunt-and-terraform-as-a-team-in-your-iac-project-da5b59209f2d) and uses the following folder hierarchy:

```bash
ci
docker
environment
 └ test
terraform
 └ modules
  └ VDWHANALYTICS
```

Where:

- **ci**: This folder defines the individual [Azure Pipelines](https://azure.microsoft.com/de-de/services/devops/pipelines/) stages that are required to provide the Azure resources within each workload environment. By default there is an [Azure Pipeline Stage](https://docs.microsoft.com/en-us/azure/devops/pipelines/process/stages?view=azure-devops&tabs=yaml) which applies the Terraform configuration files in the `modules` directory. Additional stages can be added, for example to provide a database export in a previously provided database.

- **docker**: Includes all customizations to Oracle 19 Enterprise necessary for PoC.

- **environment**: This folder contains configurations for all VDWHANALYTICS workload environments. However, the configurations are organized into separate subfolders (e.g. `dev`, `test`, `prod`) depending on the environment.

- **terraform/modules**: The folder contains all terraform configuration files necessary to deploy the workload on Azure. The individual configuration files are aggregated in a so-called [Terraform module](https://www.terraform.io/docs/configuration/modules.html) '`VDWHANALYTICS`'.

## How to deploy the infrastructure in this repo manually?

   > **General note on deployment**:
   > Before the deployment can be executed via Terraform, the AKS must be started.
   > It is recommended to do this via the build pipeline `manage-aks`.

### Pre-requisites

1. Install the [Azure CLI](https://docs.microsoft.com/en-us/cli/azure/install-azure-cli) version 2.x or a later version.
2. Please [sign in with Azure CLI](https://docs.microsoft.com/bs-latn-ba/cli/azure/authenticate-azure-cli?view=azure-cli-latest).
3. Install [Terraform](https://www.terraform.io/) version `0.13.5` or newer and [Terragrunt](https://github.com/gruntwork-io/terragrunt) version `0.26.7` or newer.

   > **HINT**:
   > To simplify the installation and version management of Terraform or Terragrunt, the tools
     [tfenv](https://github.com/tfutils/tfenv) or [tgenv](https://github.com/cunymatthieu/tgenv) can be used. When using the PowerShell module 'UniClara', both tools are automatically installed and the current versions of Terraform/Terragrunt.
   >
   > After installing the two tools, you can change to the `environment` folder and execute the commands `tfenv install` and `tgenv  install` respectively. During installation, the tools take into account the files `.terraform-version` and `.terragrunt-version` and automatically install the required version.

### Deployment for a single workload environment

1. `cd` into the environment's folder (e.g. `cd environment/test`).
2. Run `terragrunt plan` to see the changes you're about to apply.
3. If the plan looks good, run `terragrunt apply`.

## How to deploy the infrastructure in this repo automatically?

A `git push` on the `master` branch triggers the Azure DevOps pipeline job `deploy-infrastructure`. By default, changes are applied within the Azure Workload Development Environment. Deployment within other Azure Workload Environments can also be performed by the same Azure Pipeline job. To do this, it only needs to be executed manually with a modified pipeline job parameter `workloadEnvironment`.

## Contributing

Pull requests are welcome. For major changes, please open an issue first to discuss what you would like to change.

---
***Copyright © 2021 Union IT-Services GmbH. All rights reserved.***
