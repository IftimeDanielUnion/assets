# Azure DevOps Pull Request

**Titel (separates Titelfeld):**

fix(infra): Go-Toolchain aktualisieren und PROD-Blob-Alarm-Drift abgleichen

**Beschreibung (in das PR-Beschreibungsfeld kopieren):**

## Zusammenfassung

- Terraform `1.13.4` → `1.16.7` und Terragrunt `0.92.1` → `1.2.1` (Go-Sicherheitsfix).
- Setup mit Versionsprüfung; Drift-Auswertung mit Tests korrigiert.
- `blob_capacity`-Alarm in **PROD** auf bereits vorhandene **5 GiB** abgeglichen. DEV/TEST bleiben unverändert bei 1 GiB.
- TEST-/PROD-Gate um explizite manuelle ServiceNow-Change-Prüfung ergänzt.

## Prüfung und Freigabe

- [x] Archiv/Diff und lokale Syntax-/Parser-Tests geprüft.
- [ ] Aktuelle Azure-Pläne für DEV, TEST und PROD mit der neuen Toolchain prüfen; unerwartete Änderungen stoppen.
- [ ] 5-GiB-Sollwert und ggf. Action-Group-Diff für PROD fachlich bestätigen.
- [ ] **TEST-Change:** genehmigen, durchführen und Nachweis verlinken.
- [ ] **PROD-Change:** nach TEST-Abnahme separat genehmigen und durchführen.

**Jira:** nach Erstellung verlinken  
**ServiceNow TEST:** nach Erstellung verlinken  
**ServiceNow PROD:** nach Erstellung verlinken

> Die Toolversionen gelten für sämtliche Infrastrukturpipelines im Repository. Kein automatischer ServiceNow-Check; keine Azure-Änderung durch diesen PR allein.
