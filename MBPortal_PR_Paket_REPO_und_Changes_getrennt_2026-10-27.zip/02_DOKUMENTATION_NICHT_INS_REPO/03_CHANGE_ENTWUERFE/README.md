# Releaseunterlagen: Terraform/Terragrunt und MBPortal-Drift (27.10.2026)

**Status: Entwürfe.** Weder die Jira-Story noch die beiden ServiceNow-Changes sind durch diese Dateien angelegt, genehmigt oder ausgeführt worden. Die jeweiligen Nummern, Zeitfenster, Prüfer, MR/PR und Testergebnisse sind erst nach Anlage und tatsächlicher Durchführung einzutragen.

## Vorbereitete Dokumente

| Dokument | Geltungsbereich |
| --- | --- |
| [TEST-Change](Change_TEST.md) | Werkzeugaktualisierung in TEST; keine beabsichtigte Ressourcenänderung in TEST |
| [PROD-Change](Change_PROD.md) | Werkzeugaktualisierung in PROD und deklarative Übernahme des dort bestehenden 5-GiB-Alarm-Schwellwerts |
| [Jira-Story](../02_JIRA/Jira_Ticket_Entwurf.md) | Kurze Story in Jira-Wiki-Syntax mit Akzeptanzkriterien und beiden Changes |

Die bestehende Pipeline `ci/pipeline.deploy-mbportal.yml` nutzt den gemeinsamen Stage-Baustein `ci/templates/stages.deploy-infrastructure.yml`. Dessen manuelle Freigabe-Anweisungen nennen jetzt ausdrücklich den freigegebenen, zur Stage passenden Change, PR/Commit, die Prüfung aller Plan-Units und für PROD den TEST-Nachweis. **Es wird kein automatisches ServiceNow-Gate hinzugefügt.** Die Wirksamkeit der Freigabe hängt weiterhin von den tatsächlichen Azure-DevOps-Berechtigungen und der manuellen Prüfung ab.

## Umsetzung und Referenzierung

1. Pull Request vom aktuellen `main` erstellen. Die beiden Changes und Jira-Story im Review benennen. Noch keine ID als vergeben ausgeben, solange die Datensätze nicht existieren.
2. Beide ServiceNow-Changes einzeln anlegen; zuerst TEST, dann PROD. In jedem Change den tatsächlich verantwortlichen TSO/AS und CI aus der CMDB bestätigen. Die hier enthaltenen Dokumente sind ausfüllbare Textentwürfe, keine ServiceNow-Exporte.
3. Im Jira-Ticket Verknüpfungen zu beiden Changes einfügen. In jedem Change auf die Jira-Story und den tatsächlichen PR/Commit verweisen. Im PR auf die tatsächlichen Change-Nummern rückverweisen.
4. Nach fachlichem Review und genehmigtem TEST-Change den gemeinsamen Commit in `main` bringen und nur den TEST-Stack geplant ausrollen. Das neue Tool-Pin gilt nach Merge technisch für sämtliche Infrastrukturpipelines dieses Repositories, nicht nur MBPortal.
5. TEST-Protokoll und Plan prüfen. Danach PROD-Change beantragen/freigeben und PROD ausschließlich mit aktuellem, veröffentlichtem, kontrolliertem Plan und vorhandener manuell kontrollierter Freigabe durchführen.
6. Alle Nachweise hinterlegen; keine reale Freigabe oder erfolgreichen Test allein aus der Existenz dieser Dateien ableiten.

## Unveränderte technische Anforderungen

- Terraform `1.16.7`, Terragrunt `1.2.1`, keine automatische Terraform-Provider- oder State-Migration.
- Die PROD-Alarmgrenze `blob_capacity` im MBPortal-Document-Store beträgt nach dem gelieferten Drift-Log live 5 GiB; der Code übernimmt **5 GiB nur in PROD**. TEST/DEV bleiben bei 1 GiB. Das ist kein Storage-Kapazitätslimit, sondern ein Monitor-Schwellwert.
- Eine reine Schreibungskonvention von Action-Group-IDs kann weiter einen kleinen In-place-Diff verursachen. Ohne ausdrückliche Freigabe keinen solchen Diff anwenden.
- `doPublishPlan: true` verwenden und den **gesamten Plan für `applications/mashub`** prüfen. Der Plan umfasst möglicherweise mehr als die Blob-Alarm-Ressource.
- Ein Terraform-Apply mit neuem Tool kann State-Metadaten beeinflussen. Kein unüberlegter Downgrade/Apply mit alten Werkzeugen als automatische Rollback-Strategie.
- Bei ungeplantem Add, Replace, Destroy oder Update beziehungsweise Plan-/Commit-Abweichung stoppen und den Change neu bewerten.

Quelle für die ServiceNow-Anforderungen: die bereitgestellte Checkliste *Wie Prüfen wir Changes* sowie das ältere, bereits geschlossene Referenzbeispiel `UI-CHG-0096937` (IM Action Hub, nicht für diese Änderung wiederverwenden).
