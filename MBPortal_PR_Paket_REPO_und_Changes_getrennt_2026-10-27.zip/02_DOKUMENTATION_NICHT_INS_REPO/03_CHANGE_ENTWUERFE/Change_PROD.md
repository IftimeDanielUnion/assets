# ServiceNow-Change-Entwurf: PROD

**Status: NICHT ANGELEGT.** Eine TEST-Change-Nummer und bestätigter TEST-Abschluss sind Voraussetzung für die reguläre PROD-Freigabe. Keine IDs oder Genehmigungen aus dem älteren IM-Action-Hub-Beispiel übernehmen.

| Feld | Vorschlag / erforderlicher Abgleich |
| --- | --- |
| Titel | `UIS FMD BI Marktbearbeitung - IaC Security-Update Terraform 1.16.7 / Terragrunt 1.2.1 und BlobCapacity-Drift [PROD]` |
| Stage / Workload | `PROD` / `MARKTBEARBEITUNG` |
| ServiceNow-Typ | `Normal`, technische Kategorie `Betrieb / Minor-Patch` als Vorschlag, vom Change-Management bestätigen |
| TSO / AS / CI | Für die frühere IM-AH-Änderung wurden `TSO Marktbearbeitung Produktion` und `AS Marktbearbeitung Produktion` verwendet. **Für MBPortal und diesen Change im CMDB bestätigen**, richtige betroffene CI auswählen. |
| TEST-Change | **Neu anzulegende, genehmigt abgeschlossene TEST-Change-Nummer eintragen.** |
| Jira / PR / Commit | **Nach tatsächlicher Anlage eintragen und mit Rückverweisen versehen.** |
| Zeitfenster / Freigabe | **Offen.** Vor Durchführung in ServiceNow genehmigen lassen. |
| Ansprechpartner | Tatsächliche technische, fachliche und freigebende Personen (mindestens zwei) eintragen. |

## Begründung

Die Infrastruktur nutzt laut Run 1252870 Terraform `1.13.4` und Terragrunt `0.92.1`; die neuen Releases `1.16.7` und `1.2.1` verwenden korrigierte Go-Buildversionen für CVE-2026-111943. Gleichzeitig wurde im PROD-Drift-Log des MBPortal-Document-Stores beim Metric Alert `blob_capacity` eine bereits in Azure vorhandene **5-GiB-Schwelle** festgestellt, während der alte Code 1 GiB deklarierte. Der PR übernimmt den bestehenden live gesetzten Wert als Sollzustand, ohne die Alarmierung auszuschalten. Dies ist ein **Alert-Schwellwert, keine Kapazitäts-Quota**.

**Vor Freigabe ausdrücklich bestätigen:** Die 5-GiB-Schwelle entspricht dem fachlich und betrieblich gewollten PROD-Zustand. Kein stillschweigender Wechsel zurück auf 1 GiB. Der PR aktualisiert außerdem die Drift-Auswertung; sie meldete bisher keine Stack-Zusammenfassung, obwohl die eigentlichen Drift-Codes korrekt waren.

## Implementierungsplan

**System:** Azure Subscription `S_MARKTBEARBEITUNG_PROD`, Terragrunt-Stack `environment/prod/applications/mashub`, Repository `ui-mb-infrastructure`, Pipeline `ci/pipeline.deploy-mbportal.yml`. In der Version des Repos betrifft `document-store.hcl` den MBPortal-Document-Store, Metric Alert `blob_capacity`. Konkrete Resource-Group-, Storage- und Alert-Resource-IDs aus dem **aktuellen PROD-Plan** übernehmen, keine Ressourcen-IDs aus IM-AH-Beispielen.

**Vorbedingungen:** TEST-Change ist erfolgreich abgeschlossen und mit Testergebnissen verknüpft (oder ausdrückliche genehmigte Ausnahme); PROD-Change freigegeben; PR-Merge/Commit dokumentiert; 5-GiB-Sollwert bestätigt; kein paralleler Schreibzugriff auf dieselbe Stage; Tool-Releases für den Runner erreichbar; der umfassende Plan ist reviewfähig. Ein bereits durch TEST gemergter PR bringt auch die PROD-Codeänderung nach `main`, führt jedoch **keinen genehmigten PROD-Apply** durch.

1. Tatsächlich genehmigte Change-Nummer, TEST-Change samt Nachweisen, Jira-Story, PR-/Merge-Commit und erwarteten Diff abgleichen. Vor Ausführung tatsächliche Alert-Schwelle und Action Groups aus Azure dokumentieren.
2. Pipeline `ci/pipeline.deploy-mbportal.yml` auf `main` starten: `environment: PROD`, `application: MB Portal`, `workload: MARKTBEARBEITUNG`, `doPublishPlan: true`.
3. Werkzeugsetup bestätigt Terraform `1.16.7` und Terragrunt `1.2.1`. Bei einer abweichenden Version oder Fehlern nicht fortsetzen.
4. **Alle** Units und den veröffentlichten `tfplan` im Verzeichnis `environment/prod/applications/mashub` prüfen. Erwartet: kein Update, das den BlobCapacity-Schwellwert von 5 GiB auf 1 GiB zurücksetzt. Bei unverändertem Azure-Ausgangszustand wäre für `blob_capacity` ein No-op vorgesehen. Groß-/Kleinschreibung bestehender Action-Group-IDs kann dennoch einen einmaligen In-place-Diff auslösen; ein solcher Diff ist **nicht automatisch freigegeben**.
5. Bei Add, Replace, Destroy, unerwarteten Updates, unbekannten Provider-/State-Änderungen oder Abweichungen des Commit/Plans das Gate ablehnen und den Change neu bewerten. Keine pauschale Genehmigung des kompletten Stacks anhand nur des Alert-Diffs.
6. Nur nach vollständiger Planprüfung, freigegebenem PROD-Change und manueller Bestätigung im Azure-DevOps-Approval-Gate den geprüften Plan gegebenenfalls anwenden. Bei No-op-Plan muss kein Azure-Objekt geändert werden; eine reine Validierungsdurchführung kann nach Zustimmung der Changekoordination ausreichend sein.
7. Alert-Schwelle und Action Groups mit dem freigegebenen Ausgangszustand vergleichen, bestehenden MBPortal-Smoke-Test durchführen und einen frischen Drift-Plan erstellen. Abschließende Pipeline-/Commit-/Testnachweise im PROD-Change und Jira hinterlegen.

## Risiko- und Auswirkungsanalyse

Ein Versionssprung von Terraform/Terragrunt kann abweichende Planung oder Provider-/State-Kompatibilität verursachen. Der gemeinsame Versions-Pin beeinflusst spätere Infrastrukturpipelines anderer Anwendungen. Bei einem unerwarteten Apply könnten Azure-Ressourcen geändert werden. Die 5-GiB-Schwelle soll **den bestehenden live gesetzten Wert nur deklarativ übernehmen**; dadurch ist bei unverändertem PROD-Stand keine Änderung am Alarm erforderlich. Es ist keine Downtime geplant. Verfügbarkeit, Wartezeit und tatsächlicher Service-Impact werden anhand des vollständigen Plans und der beteiligten Anwendungen im Change überprüft. Risiko/Auswirkung nicht pauschal als „kein Risiko“ deklarieren.

## Backout-Plan

**Vor Apply:** Gate ablehnen, Pipeline stoppen, Plan und Werkzeuglogs sichern; über geprüften Korrektur-PR eine kompatible, gepatchte Toolversion oder korrigierte Konfiguration bereitstellen. Alte Pläne verwerfen. Kein automatischer Downgrade auf eine möglicherweise verwundbare Toolversion.

**Nach unerwartetem Apply:** weiteren Apply verhindern; tatsächlichen Zustand von Alert, Action Groups und Terraform-State feststellen. Je nach Abweichung gezielten Korrekturplan erstellen, separat freigeben und abnehmen. Ein einfaches Git-Revert stellt Azure-State und Ressourcen **nicht** automatisch zurück. Den live bereits bestehenden 5-GiB-Sollwert nicht ohne fachliche Genehmigung überschreiben.

**Backout-Test:** Ressourcen- und Alarmzustand stimmen mit dem dokumentierten genehmigten Ausgangszustand überein; aktuelle Version und Plan aus dem freigegebenen Korrekturcommit sind nachgewiesen; keine ungewollten Apply-Änderungen; Smoke-Test erfolgreich. Ob Backout und Rollback identisch sind, nach tatsächlichem Verlauf bewerten.

## Freigaben / Testdokumentation

- **Qualitätssicherung vor dem Change:** abgeschlossener TEST-Change mit Ergebnis (oder formal genehmigte Ausnahme), bestätigter 5-GiB-Sollwert, PR-Review, neue TEST-/PROD-Plans und Provider-Abgleich.
- **Qualitätssicherung nach dem Change:** Pipeline-ID und Commit, Versionen, gesamter tfplan, Azure-Alert-Wert und Action Groups vorher/nachher, MBPortal-Smoke-Test, neuer Drift-Lauf. Keine driftfreie PROD-Umgebung allein aufgrund des PR-Merges behaupten.
- **Abnahmetest geplant/durchgeführt:** nach tatsächlich dokumentiertem TEST-Nachweis im ServiceNow-Formular pflegen; keine automatische Auswahl ohne Prüfbeleg.
- **Testdokumentation / Jira:** den tatsächlich angelegten Jira-Eintrag verlinken und mit Ergebnissen aus TEST ergänzen. Status nicht vor Durchführung auf „Erledigt“ setzen.
- **Provider-only-Checkboxen:** nur bei tatsächlich zuständigem Betriebsprovider wählen. Change-Aufgabe referenziert diesen Implementierungsplan eindeutig.
