# ServiceNow-Change-Entwurf: TEST

**Status: NICHT ANGELEGT.** Hier steht keine gültige Change-Nummer oder Genehmigung. Erst die neue ServiceNow-Nummer und die tatsächlich geprüften Referenzen ergänzen.

| Feld | Vorschlag / erforderlicher Abgleich |
| --- | --- |
| Titel | `UIS FMD BI Marktbearbeitung - IaC Security-Update Terraform 1.16.7 / Terragrunt 1.2.1 [TEST]` |
| Stage / Workload | `TEST` / `MARKTBEARBEITUNG` |
| ServiceNow-Typ | `Normal`, technische Kategorie `Betrieb / Minor-Patch` als Vorschlag, vom Change-Management bestätigen |
| TSO / AS / CI | **Im CMDB-Eintrag für Marktbearbeitung TEST nachsehen und korrekt auswählen.** Keine PROD-CI übernehmen. |
| Referenzen | Jira: **nach Anlage eintragen**; PR/Commit: **nach Anlage eintragen**; Change-Nummer: **nach Anlage eintragen** |
| Genehmigungsstatus / Zeitfenster | **Nicht beantragt und nicht genehmigt; in ServiceNow ausfüllen.** |
| Fachliche/technische Ansprechpartner | Mindestens zwei tatsächlich zuständige Personen namentlich eintragen; ein externer Kontakt ersetzt keine interne Verantwortlichkeit oder Deploymentberechtigung. |

## Begründung

Die bisherigen Azure-DevOps-Infrastrukturpipelines nutzen laut Run 1252870 Terraform `1.13.4` und Terragrunt `0.92.1`. Im Repository werden die Werkzeuge auf `1.16.7` beziehungsweise `1.2.1` aktualisiert. Die Hersteller dokumentieren für diese Releases korrigierte Go-Buildversionen im Zusammenhang mit CVE-2026-111943. Zunächst soll die Kompatibilität in TEST unter kontrollierten Bedingungen nachgewiesen werden. Das gemeinsame Setup prüft die tatsächlich gewählten Werkzeugversionen; die Ausführung beeinflusst auch spätere Pipelines anderer Anwendungen im Repository.

## Implementierungsplan

**System:** Azure Subscription `S_MARKTBEARBEITUNG_TEST`, Terragrunt-Stack `environment/test/applications/mashub`, Repository `ui-mb-infrastructure`, Pipeline `ci/pipeline.deploy-mbportal.yml`.

**Vorbedingungen:** Change in genehmigtem Zustand; PR mit aktueller Quell-/Zielbranch-Referenz und Review vorhanden; eindeutiger Commit dokumentiert; keine gleichzeitige Azure-DevOps-/GitLab-Auslieferung in derselben Stage; technische Verantwortliche und Freigeber bestimmt. Die angeforderten Toolversionen müssen aus einer zugelassenen Quelle beziehbar sein. Vor Durchführung prüfen, ob DEV bereits validiert wurde; falls nicht, die begründete Ausnahme dokumentieren und genehmigen lassen.

1. Im genehmigten Zeitfenster den überprüften PR-Commit mit dem zuletzt genehmigten Diff vergleichen; tatsächliche Change- und Jira-Referenz im PR hinterlegen. Branch/Commit-Status und die PR-Freigabe prüfen.
2. Nach genehmigtem Merge die Pipeline `ci/pipeline.deploy-mbportal.yml` auf `main` starten mit `environment: TEST`, `application: MB Portal`, `workload: MARKTBEARBEITUNG`, `doPublishPlan: true`. Keine alte Plandatei verwenden.
3. Setup-Ausgaben kontrollieren: Terraform `1.16.7` und Terragrunt `1.2.1` müssen tatsächlich ausgewählt sein. Bei Fehlern stoppen.
4. Validierung und **alle** geplanten Terragrunt-Units unter `environment/test/applications/mashub` prüfen. Das veröffentlichte `tfplan`-Artefakt und vollständige Logs mit Commit und Pipeline-Run dokumentieren. Das Ausgangs-Drift-Log vom 26.10.2026 zeigt für TEST 60 Units und Exitcode 0; dies ist kein Nachweis für den neuen Toolstand.
5. Erwartet: keine funktionale Ressourcenänderung durch den Alarm-Patch in TEST; Schwelle `blob_capacity` verbleibt bei 1 GiB. Unerwartete Adds, Replacements, Destroys oder andere Updates stoppen. Wenn ein erforderlicher Diff auftritt, **vor einem Apply** gesondert fachlich genehmigen lassen.
6. Nur wenn der gesamte Plan dem Change entspricht und die manuelle Freigabe geprüft ist, optional den genehmigten No-op-Apply ausführen. Bei einem No-op-Plan ist keine Azure-Ressourcenänderung erforderlich; der erfolgreiche Plan kann als technischer Nachweis genügen, wenn die Changekoordination dies akzeptiert.
7. Vorher-/Nachher-Zustand der betroffenen Einstellungen kontrollieren, vorhandenen MBPortal-Smoke-Test ausführen, Logs, Commit, Plan und Testergebnisse im TEST-Change und in Jira dokumentieren.

## Risiko- und Auswirkungsanalyse

Werkzeugwechsel können geändertes Terraform-/Terragrunt-Verhalten, Provider-Inkompatibilitäten, neue Plan-Diffs oder Probleme mit dem State auslösen. Die Versionspins gelten für **alle** Anwendungen, die das gemeinsame Setup verwenden. Es sind keine fachlichen Änderungen oder geplanten Ausfälle vorgesehen; ein Apply mit unvorhergesehenem Plan könnte trotzdem Ressourcen verändern. Deshalb zuerst alle Plans prüfen, bei Abweichungen abbrechen und keine Freigabe pauschal über alle Stacks erteilen. Die tatsächliche Risikoeinstufung und ein eventuell erforderliches Downtime-Fenster muss der Change-Verantwortliche vor Freigabe bestimmen.

## Backout-Plan

Falls noch **kein Apply** stattgefunden hat: weitere Pipelinefreigaben stoppen; Tool-Pins und gegebenenfalls Approval-Hinweise nur mit einem geprüften Korrektur-PR wiederherstellen beziehungsweise eine kompatible, nicht verwundbare Version wählen. Auf den alten, möglicherweise verwundbaren Stand nur nach formeller Sicherheitsfreigabe zurückgehen. Bereits erzeugte Plandateien verwerfen.

Falls bereits ein Apply gelaufen ist: zuerst tatsächlichen Azure- und State-Zustand feststellen. Ein Git-Revert allein setzt keinen Azure-State zurück. Keine ungeprüften Downgrades oder State-Rückspielungen. Notwendige Korrekturmaßnahmen separat planen und freigeben.

**Backout-Test:** Kein weiterer Apply aktiv; ausgewählte Versionen/Commit dokumentiert; frischer Plan unter freigegebenem Toolstand, keine ungewollten Ressourcenänderungen; MBPortal-Smoke-Test erfolgreich. Backout/Rollback-Gleichheit anhand der tatsächlich durchgeführten Änderung in ServiceNow bewerten.

## Freigaben / Testdokumentation

- **Qualitätssicherung vor dem Change:** DEV-Plan-/Testnachweis oder von Change-Management genehmigte begründete Abweichung, PR-Review und Tool-/Provider-Abgleich.
- **Qualitätssicherung nach dem Change:** tatsächliche Versionsausgaben, vollständiger Plan, `tfplan`, Commit, Lauf-ID, erwartete 1-GiB-Alarmgrenze, erfolgreicher Betriebs-Smoke-Test.
- **Testdokumentation:** Jira-Story und verknüpften PR sowie Pipeline-Protokolle mit realen URLs eintragen, noch keinen erfolgreichen Lauf behaupten.
- **Provider-only-Checkboxen:** Nur setzen, wenn die Definition des tatsächlichen Betriebsproviders zutrifft; nicht aus dem Entwicklerteam ableiten.
- **Change-Aufgabe:** Der Change-Implementierungsplan ist maßgeblich, oder im Task eindeutig darauf verweisen.
