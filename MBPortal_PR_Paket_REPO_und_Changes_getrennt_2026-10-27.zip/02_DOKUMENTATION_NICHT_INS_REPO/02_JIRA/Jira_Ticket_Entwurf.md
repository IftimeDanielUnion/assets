# Jira-Story: kopierbarer Entwurf in Jira-Wiki-Syntax

**Status: nicht in Jira angelegt.** Epic und Assignee nach Teamzuständigkeit festlegen. TEST-/PROD-Change-IDs nach Anlage ergänzen. Ticket bewusst kurz nach `Jira.txt`-Struktur gehalten.

**Zusammenfassung:** `ui-mb-infrastructure: Terraform/Terragrunt Security-Update und PROD-BlobCapacity-Drift`

```text
h3. Als DevOps-Verantwortlicher möchte ich die Terraform-/Terragrunt-Toolchain aktualisieren und den MBPortal-BlobCapacity-Drift in PROD bereinigen, damit die Pipeline mit den korrigierten Go-Versionen arbeitet und die Alarmgrenze deklarativ dem freigegebenen Sollzustand entspricht.

h3. Offene Punkte:
* 5 GiB als gewollte PROD-Alarmgrenze bestätigen; Provider-/State-Kompatibilität prüfen.
* TEST- und PROD-ServiceNow-Changes anlegen, genehmigen und gegenseitig verlinken.

h3. Vorbedingungen:
* PR-Review, aktuelle Pläne und berechtigte Pipelinefreigaben; TEST-Nachweis vor PROD.

h3. Anforderungen:
* Terraform 1.16.7, Terragrunt 1.2.1 mit überprüften Binärversionen.
* PROD-BlobCapacity im Code 5 GiB; DEV/TEST unverändert 1 GiB.
* Korrekte Drift-Auswertung, keine unerwarteten Azure-Ressourcenänderungen.

h3. Fehlerhandling:
* Bei Versions-, Plan- oder Freigabeabweichung abbrechen; keinen ungeprüften Apply ausführen.

h3. Server-Log/Audit-Log/Business-Log:
* PR/Commit, Change-IDs, Pipeline-Runs, Planartefakte und Testergebnisse dokumentieren.

h3. UX/UI:
* Keine UI-Änderung.

h3. Technische Hinweise
* Repository: ui-mb-infrastructure. Pipeline: ci/pipeline.deploy-mbportal.yml.
* Änderungen: environment/.terraform-version, environment/.terragrunt-version,
  environment/_apps/mashub/document-store.hcl und ci/templates/steps.setup.yml;
  zusätzlich Drift-Zusammenfassung samt Tests. TEST- und PROD-Change in den separaten Unterlagen (nicht im Repository).

h3. Feature Toggle:
* Nicht erforderlich.

h3. Akzeptanzkriterien:
* TEST erfolgreich mit dokumentiertem, genehmigtem Change und kontrolliertem Plan.
* PROD nur nach TEST-Nachweis und eigener Change-Freigabe; Alarmgrenze 5 GiB bestätigt.
* Frischer Drift-Lauf ohne ungeklärte Änderungen; PR, beide Changes und Tests verlinkt.
```
