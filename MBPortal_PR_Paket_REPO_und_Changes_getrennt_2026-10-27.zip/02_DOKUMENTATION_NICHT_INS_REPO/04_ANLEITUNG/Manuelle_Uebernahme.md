# Manuelle Übernahme in Azure Repos

1. In Azure DevOps `Marktbearbeitung` → `Repos` → `ui-mb-infrastructure` den tatsächlichen Hauptbranchstand prüfen.
2. Neuen Featurebranch aus aktuellem `main` erstellen. Keinesfalls im Hauptbranch direkt Dateien überschreiben.
3. `ui-mb-infrastructure_NUR_PR_DATEIEN_2026-10-27.zip` lokal entpacken. In Azure DevOps bei den entsprechenden Ordnern die **10 Dateien** hinzufügen/ersetzen. Die Oberfläche kann je nach Berechtigung verschiedene Uploadmöglichkeiten zeigen. Überprüfe die angezeigten Pfade, insbesondere `.terraform-version` und `.terragrunt-version`.
4. Auf jedem Upload die vollständigen relativen Pfade kontrollieren. Nur den gewünschten Branch committen.
5. Repos → Pull Requests → New pull request. Ziel `main`, Quelle Featurebranch. Titel und Beschreibung aus `01_PULL_REQUEST/AzureDevOps_PR_Beschreibung.md` kopieren. Eine PR-Beschreibung verwendet **Markdown**, nicht Jira-Wiki-Syntax.
6. Unter Files den Diff prüfen: 8 bestehende Dateien geändert und 2 Dateien ergänzt, **keine gelöschten Dateien**. Jira und ServiceNow noch nicht behaupten, bevor reale Datensätze angelegt wurden.
7. Bei TEST/PROD: Genehmigte und verlinkte Changes, aktuelle vollständige tfplans, jeweilige Umgebung und manuellen Gate-Status prüfen. Nicht auf neue Toolversionen vertrauen, bevor ein echter Azure-Plan erfolgreich gelaufen ist.

## Trennung der Dateien

- Nur Repository-Code und bestehende Operationsdocs: `01_REPOSITORY_DATEIEN/` (422 Dateien).
- Nicht committen: `02_DOKUMENTATION_NICHT_INS_REPO/` mit Jira-/Change-/PR-Entwürfen.
- Für ausschließlich geänderte Dateien die separate ZIP mit 10 Dateien verwenden.

Die `docs/changes` und `docs/jira` der vorherigen Gesamt-ZIP gehören nicht in den neuen PR. Die bereits ursprünglich vorhandene `docs/operations/drift-detection.md` dagegen bleibt im Repo.
