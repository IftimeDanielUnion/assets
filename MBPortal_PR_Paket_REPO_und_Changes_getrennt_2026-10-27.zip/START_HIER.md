# START HIER: Azure DevOps PR / ServiceNow / Jira

Diese ZIP enthaelt ZWEI klar getrennte Verzeichnisse:

1. `01_REPOSITORY_DATEIEN/` enthält die **vollständigen 422 Repository-Dateien**. Nur die Inhalte dieses Ordners gehören in `ui-mb-infrastructure`. Den Ordnernamen `01_REPOSITORY_DATEIEN` selbst NICHT als neues Verzeichnis im Git-Repo anlegen.
2. `02_DOKUMENTATION_NICHT_INS_REPO/` enthält Azure-DevOps-PR, Jira und TEST-/PROD-Change-Entwürfe. Diese Dateien bleiben AUSSERHALB des Git-Repositories und werden in den jeweiligen Systemen verwendet.

**Für manuelle Browser-Änderungen besser:** Die separate `ui-mb-infrastructure_NUR_PR_DATEIEN_2026-10-27.zip` enthält nur die **10 neuen/geänderten Repository-Dateien**, jeweils im richtigen Pfad. Entpacken, in einem neuen Branch die betroffenen Dateien überführen und andere Dateien NICHT anfassen.

**Vorsicht:** Azure-DevOps-Upload per Browser muss die relativen Unterordnerpfade erhalten. Prüfe den PR-Diff in Azure DevOps vor dem Absenden. Weder den Gesamtordner noch `.zip` als Datei im Repository committen. Dateien mit führendem Punkt (`environment/.terraform-version` und `.terragrunt-version`) dürfen nicht übersehen werden.

**Versionsänderungen gelten repo-weit.** Die Ausführung in TEST und PROD benötigt getrennte genehmigte ServiceNow-Changes, echte Pipeline-Pläne und manuelle Freigaben. Der 5-GiB-PROD-Sollwert muss fachlich bestätigt werden. **Es wurden keine Changes/Jira/PR erstellt und kein Azure-Plan/Apply ausgeführt.**

Repository-Operationsdokumentation unter `docs/operations/drift-detection.md` bleibt ausdrücklich im Repository, weil die Datei bereits im ursprünglichen Git-Export existierte. Die in der letzten Ausgabe zusätzlich angelegten `docs/changes/` und `docs/jira/` sind nun vollständig in den separaten Dokumentationsbereich verschoben.

## Reihenfolge

1. Aktuelles `main` in Azure DevOps prüfen und einen neuen Branch anlegen, z. B. `fix/toolchain-go-cve-and-prod-blobcapacity-drift`. Seit dem ZIP-Export vorgenommene Änderungen gesondert zusammenführen.
2. Nur die 10 PR-Dateien in die identischen relativen Pfade übernehmen (oder vollständigen Repository-Inhalt mit `main` vergleichen).
3. Den DIFF auf 10 fachliche Änderungen und keine entfernten Dateien prüfen. Keine generelle Massenüberschreibung von 422 Dateien.
4. Jira-Ticket und je einen TEST-/PROD-Change nach deren Entwürfen anlegen. Echte URLs beidseitig in Jira, Changes und PR verknüpfen.
5. PR erstellen: Titel und Markdown-Beschreibung stehen in `02_DOKUMENTATION_NICHT_INS_REPO/01_PULL_REQUEST/AzureDevOps_PR_Beschreibung.md`.
6. Pipelinepläne validieren; TEST erst nach Change-Freigabe, PROD erst nach TEST-Abnahme und eigener Freigabe.

Die vorhandenen Freigaben in Azure DevOps bleiben manuell; die Pipeline fragt ServiceNow nicht automatisch ab.
