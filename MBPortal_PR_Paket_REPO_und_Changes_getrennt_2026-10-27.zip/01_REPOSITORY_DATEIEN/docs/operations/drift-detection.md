# Drift Detection

Pipeline that detects planned differences between the checked-out configuration,
the Terraform state and refreshed Azure resources. Scheduled runs check TEST and
PROD; manual runs can also check DEV. Runs `terragrunt run --all -- plan
-detailed-exitcode` over the selected environments and notifies Microsoft Teams
when changes or errors are detected. A non-empty plan is not proof that every
change was made outside Terraform; configuration changes can also produce it.

## Owner

DevOps Engineers in der Marktbearbeitung. The Teams Workflow that owns the
webhook is co-owned by at least two team members so that the flow does not
become an orphan when one owner leaves.

## What it runs

- Pipeline: `ci/pipeline.drift-check.yml`
- Stage template: `ci/templates/stages.drift-check.yml`
- Summary parser: `ci/scripts/summarize-drift.py` (Python 3 standard library)
- Parser tests: `python3 -m unittest discover -s ci/tests -v`
- Notification helper: `ci/scripts/notify-teams-drift.sh`
- Schedule: `Mon-Fri 06:00 UTC` (only fires when YAML is on `main`)
- Per environment: separate stage with `dependsOn: []`, runs in parallel
- Pool: `azdo_agent_marktbearbeitung_prod` (existing self-hosted pool)
- Service connection: existing `Workload CI/CD Service Connection (S_MARKTBEARBEITUNG_<ENV>)`
- Operation: PLAN ONLY. There is no apply in this pipeline. Plan still reads Azure
  and state, acquires state locks and can execute configured hooks. Use reviewed
  branches, authorized service connections and coordinate with other deployments.

## Pipeline result mapping

| terragrunt exit code | Meaning                | Pipeline result        | Teams notification |
| -------------------- | ---------------------- | ---------------------- | ------------------ |
| 0                    | No changes anywhere    | Succeeded              | none               |
| 2                    | Drift detected         | SucceededWithIssues    | warning card       |
| 1 / other            | Plan errored           | Failed                 | attention card     |

## Setup (one-time)

These steps must be done in Azure DevOps and Microsoft Teams once before the
pipeline can be merged to `main`.

### 1. Create the Teams channel and Workflow webhook

1. Create channel `MB-Infra Drift Alerts` in the appropriate Team
2. In the channel: `…` → `Workflows` → template `Post to a channel when a webhook request is received`
3. Name the workflow `MB-Infra Drift Alerts Webhook`
4. Pick the team and channel from step 1
5. Copy the webhook URL (long URL containing `prod-…logic.azure.com`)
6. Add a co-owner from the team via the Power Automate portal so the flow does
   not become an orphan

### 2. Create the Variable Group

1. In Azure DevOps: `Pipelines` → `Library` → `+ Variable group`
2. Name: `mb-infra-drift-notifications`
3. Add variable `TEAMS_WEBHOOK_URL` with the URL from step 1
4. Mark it as a secret (the lock icon)
5. `Pipeline permissions`: grant access to the `pipeline.drift-check` pipeline

### 3. Run the manual baseline

Before merging to `main` and letting the schedule fire, run the pipeline
manually for each environment from the feature branch. The first run will very
likely surface existing differences. Decide and document the intended state:
commit an approved live setting or restore the declared setting through a reviewed
apply. Do not use broad `lifecycle.ignore_changes` rules to hide unexplained drift.
Only an explicitly approved external ownership contract justifies ignoring a field.

### 4. Merge the feature branch

After the baseline is clean, merge the PR to `main`. The schedule only fires on
`main`, so the daily check is active from that point.

## Manual triggering

From the Azure DevOps Pipelines UI: `Run pipeline`. The form lets you pick:

- `environments` - subset of `[DEV, TEST, PROD]` to check. Default: all three.
- `sendNotification` - default true. Set to false when running test/calibration
  passes to avoid spamming the channel.

## Triage runbook

When a drift notification appears in the channel:

1. Open the linked pipeline run, scroll to the failed/warning stage
2. Look at the `Plan summary` step output (per-stack `Plan: X to add ...` lines)
3. For each affected stack:
   - **Expected drift** (someone made an approved manual change):
     record the intended value in code through a PR. The reviewer must approve
     adoption of that value. Do not disable monitoring or ignore all changes to
     an alert just to make the pipeline green.
   - **Unexpected drift** (no known cause): treat as incident, identify who or
     what changed the resource, restore desired state via apply or via portal.
   - **Provider-update noise** (after an azurerm bump): expected for a few
     stacks; either accept and apply, or pin a specific provider behaviour.
4. Confirm the next scheduled run goes green again.

## False-positive calibration phase

The first 2 weeks after going live are calibration: document each finding,
confirm ownership and reconcile the intended values. Track the decisions below;
a clean report must reflect the actual plan, not a suppressed drift signal.

### Known calibrations

### 2026-10-26: MBPortal PROD document-store capacity alert

Evidence: run `1252870`, commit `9e5ae61b27e5d60e3209f5ce1049eede290a277d`.
TEST: 60 units succeeded, exit 0. PROD: 60 units succeeded, exit 2. DEV did not run
in this scheduled baseline and is not covered by those results.

The only resource plan was in `applications/mashub/document-store`:
`azurerm_monitor_metric_alert.alerts["blob_capacity"]`, 0 add / 1 change / 0 destroy.
The live threshold was 5 GiB (5368709120 bytes), whereas the configuration used
1 GiB (1073741824 bytes). The description had the same 5-to-1 GiB difference.

The prepared correction **adopts the existing PROD value of 5 GiB as intended
state**, subject to PR review. DEV and TEST stay at 1 GiB. The shared config
`environment/_apps/mashub/document-store.hcl` derives description and byte
threshold from one environment-specific value. The alert remains enabled;
severity, frequency, time window and the two existing action-group targets stay
unchanged. This is a monitoring threshold, not a Storage quota or retention change.

The original plan also rewrites the same action-group resource IDs with canonical
casing. The dynamic references to monitoring outputs are intentionally retained.
A new PROD plan may therefore still show **one in-place update** to normalize
these references. Review that exact delta, apply it through the existing approved
MBPortal deployment pipeline if needed, then run drift detection again. An
upload/merge alone is not proof of drift resolution. No lifecycle suppression,
state deletion, import or resource replacement is needed for this finding.

### 2026-10-26: Per-stack summary parsing

The original regular expressions did not extract the colored, timestamp-prefixed
PROD plan line, although Terragrunt correctly returned 2. The standalone parser
now removes ANSI escapes, retains module paths, handles terraform/tofu/engine
prefixes, de-duplicates summary lines and distinguishes no changes, changes with
no resource summary (for example output changes), and errors. The original exit
code remains authoritative; Teams notification policy and webhook are unchanged.

## Toolchain update and acceptance

The repository pins Terraform 1.16.7 and Terragrunt 1.2.1. The shared setup checks
the versions actually selected through PATH and fails before plan/apply if either
differs. The pins apply to every pipeline using `steps.setup.yml`, not just
MBPortal. No Azure subscription, state key, resource module, provider constraint
or approval rule is changed by this update.

Before merge, run the plan-only pipeline from the feature branch for DEV, TEST
and PROD and inspect all changes. Check the full drift scope as appropriate.
For PROD the desired alert threshold after this PR is still 5 GiB, not 1 GiB.
Do not reuse saved plan files generated with Terraform 1.13.4; generate new plans
with the new toolchain and use the same reviewed commit and versions for apply.

The uploaded source contains no Terraform dependency lock files. Unchanged
provider constraints do not guarantee unchanged provider selections on a fresh
init. Compare the next run against the baseline: azurerm 4.81.0, random 3.9.1,
time 0.14.2, azapi 2.13.0, modtm 0.4.0. Additional changes must be reviewed, not
accepted as part of the capacity-alert fix. Provider security is a separate check.

Local tests do not replace an authenticated Azure plan, artifact download checks,
provider initialization or environment approval. Closure requires a fresh run
without unexpected changes and, where necessary, the approved in-place apply.
