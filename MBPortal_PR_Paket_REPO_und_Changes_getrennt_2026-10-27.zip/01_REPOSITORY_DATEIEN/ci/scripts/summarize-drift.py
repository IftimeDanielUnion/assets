#!/usr/bin/env python3
"""Summarize Terragrunt plan output without executing Terraform or contacting Azure.

Supports raw plan.log and timestamped Azure DevOps logs, ANSI color, Terraform,
OpenTofu and Terragrunt's newer ``engine:`` log prefix. Only plan summaries and
bounded run statistics are emitted; resource values and secrets are not copied.
"""
from __future__ import annotations

import argparse
import re
import sys
from pathlib import Path
from typing import Iterable

ANSI = re.compile(r"\x1b\[[0-?]*[ -/]*[@-~]")
AZURE_TIMESTAMP = re.compile(r"^\d{4}-\d{2}-\d{2}T\S+\s*")
PLAN = re.compile(r"Plan: (\d+) to add, (\d+) to change, (\d+) to destroy\.")
MODULE = re.compile(r"\b(?:STDOUT|STDERR)\s+\[([^\]\r\n]+)\]")
STATS = re.compile(r"^\s*(?:Succeeded|Failed|Skipped|Excluded|Early Exits?)\s+\d+\s*$")


def summarize(lines: Iterable[str], exit_code: int) -> str:
    """Return a bounded summary; exit_code comes from the actual plan process."""
    plans: dict[tuple[str, str], None] = {}
    run_summary: list[str] = []
    statistics_left = 0
    for raw in lines:
        line = AZURE_TIMESTAMP.sub("", ANSI.sub("", raw)).strip()
        match = PLAN.search(line)
        if match:
            module = MODULE.search(line)
            scope = module.group(1) if module else "unassigned"
            plans[(scope, match.group(0))] = None
        if "Run Summary" in line:
            # Log exports may contain the final summary twice. Keep the last one.
            run_summary = [line]
            statistics_left = 6
        elif statistics_left:
            if STATS.match(line):
                run_summary.append(line)
            statistics_left -= 1

    result = [f"Terragrunt exit code: {exit_code}"]
    if plans:
        result.extend(f"[{scope}] {plan}" for scope, plan in plans)
    elif exit_code == 0:
        result.append("No changes reported (exit code 0).")
    elif exit_code == 2:
        result.append("Changes detected (exit code 2), but no per-stack Plan line was found.")
        result.append("Review the full plan-log artifact; output-only changes can also return 2.")
    else:
        result.append("Plan failed. Review the full plan-log artifact for errors.")
    if exit_code not in (0, 2) and plans:
        result.append("At least one unit failed; the listed plans do not constitute a complete result.")
    if exit_code == 0 and plans:
        result.append("Warning: Plan lines exist despite exit code 0; verify the complete log.")
    if run_summary:
        result.extend(["", *run_summary])
    return "\n".join(result) + "\n"


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--log", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--exit-code", required=True, type=int)
    args = parser.parse_args(argv)
    if args.log.resolve() == args.output.resolve():
        parser.error("--log and --output must refer to different files")
    try:
        with args.log.open(encoding="utf-8", errors="replace") as stream:
            summary = summarize(stream, args.exit_code)
        args.output.write_text(summary, encoding="utf-8")
    except OSError as exc:
        print(f"Cannot write drift summary: {exc}", file=sys.stderr)
        return 1
    # This script's status describes parsing; the pipeline separately maps the
    # original Terragrunt status to success, warning or failure.
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
