"""Offline regression tests: python3 -m unittest discover -s ci/tests -v."""
from __future__ import annotations

import importlib.util
from pathlib import Path
import tempfile
import unittest

SCRIPT = Path(__file__).resolve().parents[1] / "scripts" / "summarize-drift.py"
SPEC = importlib.util.spec_from_file_location("summarize_drift", SCRIPT)
assert SPEC is not None and SPEC.loader is not None
MODULE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(MODULE)


class DriftSummaryTests(unittest.TestCase):
    def test_ansi_timestamp_and_module(self):
        line = ("2026-10-26T06:03:40.843Z \x1b[0;90m06:03:40.843\x1b[0m "
                "STDOUT [applications/mashub/document-store] terraform: "
                "\x1b[32mPlan: 0 to add, 1 to change, 0 to destroy.\x1b[0m\n")
        text = MODULE.summarize([line], 2)
        self.assertIn("[applications/mashub/document-store] Plan: 0 to add, 1 to change, 0 to destroy.", text)
        self.assertNotIn("\x1b", text)

    def test_engine_and_tofu_prefixes(self):
        for engine in ("terraform", "tofu", "engine"):
            with self.subTest(engine=engine):
                text = MODULE.summarize([
                    f"10:00:00.001 STDOUT [applications/test] {engine}: Plan: 1 to add, 2 to change, 3 to destroy."
                ], 2)
                self.assertIn("[applications/test] Plan:", text)

    def test_duplicate_lines_are_deduplicated_per_unit(self):
        line = "STDOUT [a] terraform: Plan: 0 to add, 1 to change, 0 to destroy."
        text = MODULE.summarize([line, line, line.replace("[a]", "[b]")], 2)
        self.assertEqual(text.count("[a] Plan:"), 1)
        self.assertEqual(text.count("[b] Plan:"), 1)

    def test_no_changes(self):
        text = MODULE.summarize(["No changes. Your infrastructure matches the configuration."], 0)
        self.assertIn("No changes reported", text)
        self.assertNotIn("failed", text)

    def test_output_only_drift_is_not_hidden(self):
        text = MODULE.summarize(["Changes to Outputs:"], 2)
        self.assertIn("Changes detected", text)
        self.assertIn("output-only", text)

    def test_error_does_not_become_success(self):
        text = MODULE.summarize(["Error: authorization failed"], 1)
        self.assertIn("Plan failed", text)
        self.assertNotIn("No changes reported", text)

    def test_partial_failure_with_other_unit_plan(self):
        text = MODULE.summarize(["STDOUT [a] engine: Plan: 1 to add, 0 to change, 0 to destroy."], 1)
        self.assertIn("complete result", text)

    def test_unprefixed_line(self):
        text = MODULE.summarize(["Plan: 0 to add, 1 to change, 0 to destroy."], 2)
        self.assertIn("[unassigned]", text)

    def test_run_statistics_but_not_resource_content(self):
        text = MODULE.summarize([
            "secret = DO_NOT_COPY_THIS", "Run Summary  60 units  2m",
            "--------", "Succeeded    60", "account = DO_NOT_COPY_THIS"
        ], 0)
        self.assertIn("Succeeded    60", text)
        self.assertNotIn("DO_NOT_COPY_THIS", text)

    def test_cli_write_and_read_failure(self):
        with tempfile.TemporaryDirectory() as td:
            source, output = Path(td) / "plan.log", Path(td) / "summary.txt"
            source.write_text("STDOUT [a] terraform: Plan: 0 to add, 1 to change, 0 to destroy.")
            self.assertEqual(MODULE.main(["--log", str(source), "--output", str(output), "--exit-code", "2"]), 0)
            self.assertIn("[a] Plan:", output.read_text())
            source.unlink()
            self.assertEqual(MODULE.main(["--log", str(source), "--output", str(output), "--exit-code", "2"]), 1)

    def test_inconsistent_status_is_visible(self):
        text = MODULE.summarize(["Plan: 0 to add, 1 to change, 0 to destroy."], 0)
        self.assertIn("Warning:", text)


if __name__ == "__main__":
    unittest.main()
