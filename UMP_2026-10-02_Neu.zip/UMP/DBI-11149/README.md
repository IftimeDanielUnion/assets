# DBI-11149: SFTP-Verbindungen

**Status: Mail versendet, Bestätigung und Verbindungstest offen. Prio 1.**
Du musst die Mail nicht erneut schicken. Die anderen Tickets hängen nicht von dieser Antwort ab.

## Wofür ist das Ticket?

Die UMP muss Dateien zu mehreren Gegenstellen übertragen können. Der zuletzt konkret offene Punkt ist Lukas PROD. Das Jira umfasst aber auch weitere Verbindungen und ausdrücklich die Dokumentation der Firewall-Changes.

## Was ist erledigt?

Dein Screenshot zeigt die Mail an **Marc Hintz, hintz@msu.biz**, vom **01.10.2026 um 12:48**, mit dem Dateinamen `azure-lukas-sftp-prod.pub` als Anhang. Du hast die zusätzliche Hinterlegung, die Zugangsdaten-Zuordnung und den Server-Host-Key-Fingerabdruck angefragt.

**Nicht belegt:** ob Marc geantwortet oder den Schlüssel hinterlegt hat. Der Screenshot zeigt auch nicht den vollständigen Inhalt des tatsächlich versandten Anhangs. Der hier beiliegende Schlüssel stimmt mit dem Public Key aus dem Jira überein.

## Schritt 1: Auf die relevante Bestätigung warten

**Warum:** Eine gesendete Mail ändert noch nichts auf dem SFTP-Server. Marc muss bestätigen, dass der richtige Benutzer den Schlüssel verwenden darf.

Wenn seine Antwort schon vorliegt, nicht weiter warten. Du brauchst:
- Bestätigung „neuer Public Key zusätzlich hinterlegt“,
- Host, Benutzer, Port und geeignetes Zielverzeichnis,
- den bestätigten Server-Host-Key-Fingerabdruck.

Der Server-Host-Key ist nicht derselbe Schlüssel wie dein zugesandter Benutzer-Public-Key.

**Nur falls die Antwort ausbleibt und du nachfassen musst, im bestehenden Mailverlauf:**

> Hallo Marc, ich wollte kurz bei meiner Mail vom 01.10. zum Lukas-PROD-SFTP-Zugang nachfragen. Konntest du die zusätzliche Hinterlegung des öffentlichen Schlüssels schon prüfen? Für den nächsten Test brauche ich noch deine Bestätigung der Verbindungseinstellungen und des Server-Host-Key-Fingerabdrucks. Danke dir!

Keinen privaten Schlüssel schicken oder neue Schlüssel auf Verdacht erzeugen.

## Schritt 2: Technische Anmeldung aus der UMP prüfen

**Warum:** Ein SFTP-Test von WSL beweist nicht, dass der UMP-Server mit seiner Konfiguration funktioniert. `az login` ist außerdem kein SSH-Zugang zum UMP-Server.

Der beiliegende Diagnosecode ist eine Hilfe, keine Voraussetzung, um eine bestehende Betriebsdiagnose zu verwenden. Wenn der freigegebene Betrieb die Anmeldung bereits sicher prüfen kann, nutze diesen Weg und vermeide ein unnötiges App-Deployment nur für einen Test.

Soll der vorbereitete Diagnosebefehl genutzt werden:

```bash
bash start.sh 11149 code
```

Das kopiert zwei PHP-Dateien in einen getrennten `unioninvestment`-Worktree, noch nicht auf den Server. Review und normale UMP-Bereitstellung sind weiterhin erforderlich.

Nach der freigegebenen Bereitstellung und mit vorhandenem UMP-Serverzugang:

```bash
bash start.sh 11149 server
```

Der Starter fragt den UMP-SSH-Alias, das App-Verzeichnis mit `bin/console` und das dortige PHP ab. Der Befehl liest zunächst nur die tatsächlich verwendete MBO-Konfiguration und den Client-Key-Fingerprint, ohne Lukas zu kontaktieren.

Erst nach bestätigter Schlüsselhinterlegung und unabhängig geprüftem Host-Key:

```bash
bash start.sh 11149 connect
```

Erwartet werden erfolgreiche Anmeldung und Verzeichniszugriff. Es werden keine Dateien übertragen und keine Aufträge bearbeitet.

**Nicht `app:export:mbo` als Verbindungstest starten.** Dieser Befehl kann echte Bestellungen verarbeiten. Alte SSH-Verfahren nicht pauschal aktivieren; eine notwendige Ausnahme muss gezielt abgestimmt werden.

## Schritt 3: Den tatsächlichen Transfer mit Alex abnehmen

**Warum:** Eine Anmeldung beweist noch nicht, dass ein vollständiger freigegebener UMP-Transfer funktioniert.

Erst nach erfolgreicher technischer Anmeldung:

> Hi Alex, die technische Lukas-SFTP-Anmeldung und der Zugriff auf das Zielverzeichnis funktionieren jetzt aus der UMP-Instanz. Können wir bitte einen freigegebenen Testauftrag für den vollständigen Transfer verwenden? Ich möchte keinen produktiven Export nur zu Testzwecken anstoßen. Danke dir!

Diese Nachricht nicht vor einem erfolgreichen Verbindungstest verwenden.

## Schritt 4: Das ganze Jira abschließen, nicht nur Lukas

**Warum:** Im Akzeptanzkriterium steht ausdrücklich, die Firewall-Changes zu dokumentieren. Das Ticket nennt mehrere Ziele.

| Ziel | Im Export dokumentiert | Vor Abschluss prüfen |
|---|---|---|
| Lukas Abnahme | Erfolgreicher Test am 11.09. gemeldet. | Vorhandenen Beleg referenzieren; bei Änderungen erneut prüfen. |
| Lukas PROD | Schlüssel-/SSH-Thema offen. | Bestätigung und sicheren Transfer nachweisen. |
| Emailing | Firewall-Anpassung im Verlauf behandelt. | Aktuellen Nachweis bzw. bestätigten Reststatus von OSC aufnehmen. |
| Wertanlage / Strato | Im Verlauf wird die weitere Notwendigkeit hinterfragt. | Mit OSC/Fachseite klären: benötigt und getestet oder nachvollziehbar entfallen. |
| MOVEit | Transfer soll laut Zusatzinformation nach der Migration durch Blob-zu-Blob ersetzt werden. | Ablösung bestätigen lassen, nicht einen entfallenen Weg unnötig wiederherstellen. |

**An Alex, falls die bereits vorliegenden Restbelege fehlen:**

> Hi Alex, für den Abschluss von DBI-11149 möchte ich neben Lukas auch den Restumfang sauber dokumentieren. Gibt es aktuelle Testergebnisse für Emailing und einen bestätigten Stand, ob Wertanlage/Strato und der alte MOVEit-Weg noch benötigt werden? Bereits vorhandene Belege reichen mir; ich möchte keine erledigten Tests unnötig wiederholen. Danke dir!

Firewall-Change **UI-CHG-0094446** ist im Export genannt. Den tatsächlichen Change/Beleg sowie weitere zugehörige Freischaltungen im Jira verlinken oder ablegen. Der hier vorliegende Export ersetzt nicht die Change-Dokumentation.

## Jira-Kommentar: jetzt kopierbar

```text
Zwischenstand DBI-11149:

Die Anfrage an Marc Hintz wurde am 01.10.2026 versendet. Angefragt wurden die zusätzliche Hinterlegung des neuen öffentlichen RSA-Schlüssels unter Beibehaltung des bisherigen Schlüssels, die Bestätigung der Verbindungseinstellungen und der Server-Host-Key-Fingerabdruck.

Die Schlüsselhinterlegung und die Anmeldung aus der tatsächlichen UMP-Laufzeit sind noch nicht bestätigt. Nach Rückmeldung folgen zunächst reine Anmeldung und Verzeichnisprüfung, danach ein mit OSC abgestimmter sicherer Transfer-Test.

Für den Ticketabschluss werden außerdem die Restverbindungen bzw. bestätigten Ablösungen und die zugehörigen Firewall-Changes dokumentiert. UI-CHG-0094446 ist im bisherigen Verlauf referenziert.

Ticket bleibt offen.
```

Falls Marc inzwischen geantwortet hat, den zweiten Absatz vor dem Einfügen entsprechend aktualisieren.

## Fertig, wenn

Lukas und alle noch benötigten weiteren Wege nachvollziehbar funktionieren bzw. bestätigte Ablösungen dokumentiert sind, der sichere Transfer abgenommen ist und die Firewall-Change-Belege im Ticket stehen.

Quelle: Jira-Export DBI-11149 vom 30.09.2026 und dein Mail-Screenshot in `2139.7z`. Es wurde kein Postfach gelesen.
