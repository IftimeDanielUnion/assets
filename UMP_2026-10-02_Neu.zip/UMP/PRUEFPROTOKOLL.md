# Prüfprotokoll: Übergabe vom 02.10.2026

## 1. Verwendete Unterlagen

- `2139.7z`: dein Azure-Inventar, TEST-Uploadbeleg, Testdatei, HTTP-Prüfbericht, Konsolenlog und Screenshot der Mail an Marc.
- `ump_jiras.zip`: die vier Jira-Exporte vom 30.09.2026 zu DBI-11149, DBI-6455, DBI-7161 und PB2B-27849.
- Die im Gespräch hochgeladenen Jira-Screenshots zu DBI-12139.
- `UMP_repos.zip`: der ursprüngliche Repository-Snapshot.
- Das zuletzt bereitgestellte vollständige `UMP_Tickets.zip` als Codebasis dieses neuen Pakets.

**Keine Live-Abfrage von Jira oder des Postfachs.** Spätere Ticketkommentare/Antworten sind nur bekannt, wenn du sie bereitgestellt hast. Nicht behauptet wird, dass seit dem Export nichts passiert sei.

## 2. Was dein tatsächlicher Azure-Lauf beweist

Inventarbeginn: **02.10.2026, 08:56:49 UTC** (10:56:49 Uhr deutscher Sommerzeit).

Beleg: [inventar.json](ergebnisse/DBI-12139/20261002T085649095294Z/inventar.json)

| Umgebung | Gespeicherte Vergleiche | Separater Backend-Sollabgleich | Storage/Gateway-Bereitstellung |
|---|---|---|---|
| dev | 7 Storage-/Container- und 18 Gateway-Prüfungen erfolgreich | true | Succeeded |
| test | 7 Storage-/Container- und 18 Gateway-Prüfungen erfolgreich | true | Succeeded |
| prod | 7 Storage-/Container- und 18 Gateway-Prüfungen erfolgreich | true | Succeeded |

Damit sind **75 konkrete gespeicherte Sollwertvergleiche** erfolgreich. Es gibt in diesem Inventar keine aufgezeichneten Lesefehler. Das ist keine vollständige Terraform-Driftprüfung und kein Test jedes möglichen Inhalts.

Beobachtet in allen drei Umgebungen:
- `allowBlobPublicAccess = true`
- `publicNetworkAccess = Disabled`
- Release-Container mit `publicAccess = Blob`
- allgemeiner Container `assets` mit `publicAccess = None`
- erwartete Gateway-Zuordnung und Containerpfade

Diese Kombination bedeutet nicht „Storage für das ganze Internet geöffnet“. Anonymer Blob-Zugriff und Netzwerk-Erreichbarkeit sind getrennt. Der veröffentlichte Asset-Host muss aus dem vorgesehenen Zielnetz geprüft werden. Der direkte Storage-Netzzugang soll nicht auf Verdacht geöffnet werden.

Dein Skript hat den aktuellen lokalen Git-Checkout nicht gefunden. Die Azure-Aufrufe liefen trotzdem explizit gegen die vorgesehenen UMP-Subscriptions. Der andere Default bei `az login` hat diese Aufrufe daher nicht auf die falsche Subscription umgelenkt.

## 3. Tatsächlicher TEST-Upload und Abruf

Upload: **02.10.2026, 08:59:02 UTC**.
Abruf: **02.10.2026, 09:00:16 UTC**.

Belegordner:
`ergebnisse/DBI-12139/20261002T085855379770Z/test/dbi-12139-check-20261002T085902Z-99cb2a98bb4b/`

Darin:
- `upload.json`: Status `uploaded`, Container `uniglobal-release-1`, 8.192 Byte.
- `testdatei.txt`: unveränderte synthetische Testdatei.
- `probe-20261002T090016306962Z.json`: tatsächliches HTTP-Ergebnis.

Prüfsumme der mitgelieferten Testdatei wurde erneut lokal mit dem Uploadbeleg verglichen und stimmt:

```text
202288fa2b4e185e70c9476dba00dea617f189c1d3149433f76743d1f8b1a039
```

| Teilprüfung | Ergebnis |
|---|---|
| Vollständiger GET | HTTP 200, 8.192 Byte, Inhalt stimmt. |
| GET des Bereichs 0 bis 1023 | HTTP 206, 1.024 Byte, Teilinhalt stimmt. |
| Content-Range | `bytes 0-1023/8192` |
| Netzwerkangabe | `intern` |
| Anmeldung | Laut Prüfbericht keine Authorization-Header, SAS-Tokens oder Cookies. |
| Redirects | Vom Prüfwerkzeug nicht verfolgt. |

**Belegt ist dieser TEST-Pfad aus diesem angegebenen Netz zu diesem Zeitpunkt.**
Nicht belegt sind DEV-/PROD-Dateiabrufe, ein externes Zielnetz, ein großes reales Medium, Browser-/Template-Verhalten oder eine anschließende Bereinigung.

Im Upload liegt kein Cleanup-Beleg. Die Testdatei wird deshalb als „nicht als bereinigt dokumentiert“ geführt, nicht als garantiert heute noch vorhanden.

Ein zusätzlicher Abruf der synthetischen TEST-URL über das hier verfügbare Webwerkzeug lieferte nur „not accessible via this tool“, keinen verwertbaren HTTP-Status oder Inhalt. Das ist **kein Nachweis eines Azure-Konfigurationsfehlers** und ersetzt keinen externen Abnahmetest.

## 4. SFTP-Mail und Jira-Umfang

Der Screenshot zeigt die Mail an `hintz@msu.biz` vom **01.10.2026 um 12:48**, mit `azure-lukas-sftp-prod.pub` als Anhang. Inhaltlich wurden zusätzliche Schlüsselhinterlegung, Verbindungseinstellungen und Server-Fingerprint angefragt.

Der Public Key in diesem Paket wurde byteweise gegen das Schlüsselmaterial aus dem Jira-Kommentar vom 17.09.2026 abgeglichen. Fingerprint:

```text
SHA256:dnNfJ61wYm8HJzH+x+DLgIvcREFPbmZUXdMVjJPvXV8
```

Der tatsächlich versandte Anhang selbst wurde nicht als Datei hochgeladen. Sein Inhalt und eine spätere Serverhinterlegung sind daher nicht allein durch den Screenshot bewiesen. Keine Antwort von Marc ist im Upload enthalten.

Erneut aus dem Jira gelesen:
- DBI-11149: Akzeptanzkriterium ist unter anderem die Dokumentation der Firewall-Changes. Der Scope umfasst mehr als Lukas. Change `UI-CHG-0094446` ist genannt.
- DBI-6455: OSC meldet am 11.09. erfolgreiche OTEL-Tests, Mail-Versand für `error`/`fatal` fehlt. Am 28.09. steht „niedrigere Prio“.
- PB2B-27849: Oliver meldet am 22.09. die App-Anlage als umgesetzt und nennt die temporären Metadaten. Ein aktueller Login-Nachweis fehlt.
- DBI-7161: Die Akzeptanzkriterien umfassen tatsächliche Zustellung/Fehlerablage und Zugriff beider Anwendungen. Ein vorbereitetes Modul reicht nicht.
- DBI-12139: Im Screenshot werden Storages für dev/test/prod und öffentlich lesbare Assets gefordert; keine feste Mindestgröße oder Performance-Schwelle.

## 5. Was im neuen Ordner geändert wurde

1. Frischer eigenständiger Ordner `UMP`; kein Zusammenführen mit alten Versionen erforderlich.
2. Alle fünf Ticket-READMEs auf den belegten Arbeitsstand umgestellt, mit Zweck, Grund pro Schritt und verwendbarem Jira-Zwischenkommentar.
3. Keine erneute Mail an Marc als erster Arbeitsschritt. Antwort auswerten, sofern inzwischen vorhanden.
4. Deine verwendbaren Testbelege übernommen. Die veraltete reine Inventar-STATUS-Anweisung „jetzt neu hochladen“ wird nicht als aktuelle Anleitung mitgeliefert.
5. `fortschritt.py`: liest vorhandene Nachweise, trennt intern/extern und unterstützt das Fortsetzen nur fehlender Abrufe.
6. `bash start.sh 12139` zeigt mit den vorhandenen Belegen den Stand. Eine neue Azure-Bestandsprüfung wird ausdrücklich über `inventar` gestartet.
7. `rest` überspringt erfolgreiche Tests und verwendet vorhandene eigene Uploadbelege; kein wiederholter TEST-Upload.
8. `extern` benötigt keinen Azure-Login und führt niemals Uploads aus. Die Netzangabe muss vom tatsächlichen Teststandort stammen.
9. Im Medientest wird der Endbereich jetzt explizit als Start-/Endbyte angefragt. Nach einem ungültigen ersten Bereich wird der zweite Abruf ausgelassen. Die auswählbare Größenprüfung ist keine zusätzliche Jira-Vorgabe.

**Alle 14 vorbereiteten Repository-Dateien bleiben enthalten.** Gegenüber dem vorherigen vollständigen Paket wurde in diesem Durchgang davon nur `DBI-12139/code/live/scripts/lp_assets.py` geändert. Die übrigen Repository-Dateien sind unverändert, noch nicht durch deinen Asset-Lauf deployt oder abgenommen.

## 6. Lokal tatsächlich ausgeführte Softwareprüfungen

Ergebnis: [lokale-pruefung.json](ergebnisse/lokale-pruefung.json)

| Prüfung | Ergebnis |
|---|---|
| Python-/Workflow-Tests | **165 ausgeführt, 0 Fehler, 0 Fehlschläge, 0 übersprungen.** |
| Prüfsummen der Code-/Hilfsdateien | 29 erfolgreich. |
| Struktureller LP-Quellcodevergleich | 48 Vergleiche gegen den ursprünglichen `live`-Snapshot erfolgreich. |
| Python-Syntax | 9 Dateien erfolgreich geparst. |
| PHP-Syntax | Beide Diagnose-Dateien mit `php -l` erfolgreich geprüft. |
| Bash-Syntax | `bash -n start.sh` erfolgreich. |
| YAML-Syntax | 3 Dokumente geparst; GitLab-Referenzen dabei nicht serverseitig aufgelöst. |
| Offline-Einstiege | `status`, `12139` und `11149` erfolgreich ausgeführt. |
| Fortsetzen ohne doppelte Tests | In einem simulierten Durchlauf für dev/test/prod geprüft, anschließend erneuter Aufruf ohne zusätzliche Uploads/Abrufe. |

Die 165 Tests verwenden für Azure/HTTP/SSH simulierte Antworten und für Git temporäre lokale Repositories. Sie liefen in einem Linux-Testcontainer, nicht auf deinem Windows-/WSL2-Rechner. Das ist getrennt von deinen echten Azure-Belegen in Abschnitt 2 und 3 zu verstehen.

## 7. Nicht durchgeführt und nicht als erledigt gewertet

- Kein Terraform-/Terragrunt-Plan oder Apply.
- Keine native Terraform-/Ansible-Gesamtvalidierung in diesem Durchgang; diese Werkzeuge sind hier nicht verfügbar.
- Keine Bereitstellung des neuen PHP-Diagnosebefehls auf UMP.
- Keine echte SFTP-Anmeldung oder Dateiübertragung zu Lukas.
- Kein SAML-Login und keine neue Serverkonfiguration.
- Keine Monitoring-Testmail oder Event-Grid-End-to-End-Abnahme.
- Keine von hier ausgeführte neue Azure-Schreibaktion, kein Jira-Update und keine neue Nachricht.

**Gesamturteil:** Die von dir gelieferten Prüfungen waren erfolgreich innerhalb ihres dokumentierten Umfangs. Keines der fünf Jiras ist durch diese Unterlagen bereits vollständig abschließbar.

## Technische Primärquellen

- [Microsoft: anonymer Zugriff auf Blobs und weiterhin geltende Netzwerkregeln](https://learn.microsoft.com/en-us/azure/storage/blobs/anonymous-read-access-configure)
- [Microsoft: Storage-Netzwerkzugriff und Private Endpoints](https://learn.microsoft.com/en-us/azure/storage/common/storage-network-security-set-default-access)
- [Microsoft: Get Blob, HTTP 200/206 und Range-Anfragen](https://learn.microsoft.com/en-us/rest/api/storageservices/get-blob)
