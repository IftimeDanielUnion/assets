# PB2B-27849: temporärer SAML-Login

**Status: App-Anlage laut Jira erledigt. Aktueller Login nicht nachgewiesen.**
**Prio 4; bei blockierten Migrationstests vorziehen.** Keine Abhängigkeit zu den anderen vier Tickets.

## Wofür ist das Ticket?

Für Migrationstests wird eine temporäre UMP-App für den Login benötigt. **Oliver schreibt am 22.09. ausdrücklich, dass die App angelegt wurde.** Das Ticket ist ihm im Export zugewiesen.

Deshalb nicht noch eine App bestellen und nicht ungefragt den normalen PROD-Login ändern. Es kann sein, dass nur noch die Rückmeldung zur bereits erfolgten Integration fehlt.

## Schritt 1: Echte Restarbeit mit Oliver klären

**Warum:** Der Unterschied zwischen regulärer und temporärer Instanz muss eindeutig sein. Ein Login-Test auf der falschen Instanz ist wertlos.

**An Oliver Ehli:**

> Hi Oliver, ich schaue mir PB2B-27849 an. Laut deinem Kommentar ist die temporäre App bereits angelegt. Ist die Mellon-Anbindung inzwischen auch umgesetzt und der Login erfolgreich getestet? Falls ja, reicht mir der Testbeleg für die Abstimmung des Ticketabschlusses. Falls noch etwas fehlt, brauche ich bitte die konkrete temporäre UMP-URL und den zugehörigen Zielhost; die Entity-ID und Rücksprungadresse gleiche ich dann mit der laufenden Konfiguration ab. Blockiert das aktuell noch Migrationstests? Danke dir!

Wenn die Integration bereits erfolgreich abgenommen wurde, **keinen unnötigen Codechange erzeugen**. Mit Oliver den dokumentierten Abschluss abstimmen.

## Schritt 2: Nur bei offener Integration die Konfiguration vergleichen

**Warum:** Die im Ticket genannte Policy `B2C_1A_signin_saml_ump_tmp` muss zur bestätigten temporären Instanz passen, nicht pauschal zu jeder PROD-Instanz.

Die angegebene IdP-Metadatenquelle lautet:

```text
https://auth.user.union-investment.de/b2cunioninvestmentprod.onmicrosoft.com/B2C_1A_signin_saml_ump_tmp/samlp/metadata
```

Von der bestätigten Instanz die aktiven öffentlichen SP-Metadaten und Konfigurationszuordnung lesen. Standardpfad im vorhandenen Aufbau: `/etc/apache2/mellon/ump-app_metadata.xml`. Vor Ort prüfen, nicht blind annehmen. Keine privaten Schlüssel oder Login-Tokens kopieren.

Dafür ist euer UMP-Server-/Bastion-/Betriebszugang nötig. `az login` allein liefert ihn nicht.

## Schritt 3: Vorbereiteten Ablauf nur bei Bedarf verwenden

**Warum:** Der beiliegende Code begrenzt eine tatsächliche Änderung auf die bestätigte temporäre Instanz. Er ist nicht Pflicht, wenn der vorhandene Betriebsprozess die Änderung schon korrekt erledigt hat.

```bash
bash start.sh 27849 code
bash start.sh 27849 prepare
```

`code` legt einen getrennten `ansible-ump`-Worktree an. `prepare` fragt bestätigten Host, Entity-ID, Rücksprungadresse und eine lokale Kopie der öffentlichen SP-Metadaten ab. Es bereitet die Dateien lokal vor, noch keine Serveränderung.

Mit Ansible, bestätigtem Inventory und Serverzugang:

```bash
bash start.sh 27849 dry-run
```

**Erwartung:** Syntaxprüfung und gezielter Check zeigen die gewünschte Änderung nur für den freigegebenen Host. Der Ergebnisbericht enthält den vollständig ausgefüllten späteren Deployment-Befehl. Diesen erst nach Review/Freigabe verwenden, nicht automatisch ausführen lassen.

Die temporäre IdP-Auswahl muss auch bei künftigen regulären Konfigurationsläufen auf diesem Host erhalten bleiben. Keine globale Umstellung aller PROD-Hosts.

## Schritt 4: Wirklich anmelden

**Warum:** Gültiges XML und eine erfolgreiche Ansible-Ausgabe beweisen keinen funktionierenden SAML-Login.

Mit freigegebenem Testbenutzer den Login bis zur richtigen temporären UMP-Instanz durchführen. Den normalen Login unverändert gegenprüfen. Danach festhalten, wann die temporäre App/Sonderkonfiguration zurückgebaut werden soll.

## Jira-Kommentar: jetzt als Abklärungsstand verwendbar

```text
PB2B-27849: Abgleich des vorliegenden Ticketstands

Laut Kommentar vom 22.09.2026 ist die temporäre App angelegt. Eine erneute App-Anlage ist nicht vorgesehen.

Offen ist aus den mir vorliegenden Belegen, ob die genannte temporäre IdP-Policy bereits auf der richtigen UMP-Instanz eingebunden und der vollständige Login abgenommen wurde. Dies wird mit Oliver abgeglichen. Bei bereits vorhandenem erfolgreichem Test kann der Ticketabschluss darauf gestützt werden; andernfalls wird nur die bestätigte temporäre Instanz gezielt geprüft.

Keine Änderung am regulären PROD-Login auf Verdacht.
```

## Fertig, wenn

Oliver die korrekte App-/Instanzzuordnung und die erforderliche Login-Abnahme bestätigt hat bzw. der fehlende Test erfolgreich nachgeholt ist. Neue Ansible-Dateien sind für sich kein Abschlussbeleg.

Quelle: Jira-Export PB2B-27849, Kommentar von Oliver vom 22.09.2026. Vollständige vorbereitete Dateien unter `code/ansible-ump/`. Dein `2139.7z` enthält keinen SAML-Test.
