# UMP: neuer kompletter Arbeitsordner

**Stand: 02.10.2026.** Für Windows 11, WSL2 und VS Code. Dieser Ordner ist vollständig und braucht keine alte Paketversion.

## Deine Frage: War alles erfolgreich?

**Die von dir ausgeführten Schritte waren erfolgreich. Ein ganzes Ticket ist damit noch nicht vollständig abgenommen.**

| Was du gemacht hast | Ergebnis | Was es wirklich beweist |
|---|---|---|
| Azure-Bestandsprüfung | dev, test und prod erfolgreich | Die geprüften Storage-, Container- und Gateway-Einstellungen sind vorhanden und passen zu den eingebauten Sollwerten. |
| Kleine Datei in TEST hochgeladen | Erfolgreich, 8 KiB | Dein TEST-Upload und der Zugriff auf diesen Container funktionieren. |
| Datei aus TEST ohne Anmeldung gelesen | HTTP 200, Inhalt stimmt | Dieser Asset-Pfad ist aus deinem angegebenen internen Netz anonym lesbar. |
| Teil der Datei gelesen | HTTP 206, Inhalt stimmt | Auch der getestete Teilabruf funktioniert. |
| Mail an Marc | Im Screenshot vom 01.10.2026, 12:48 dokumentiert | Die Anfrage wurde gestellt. Schlüsselhinterlegung und Anmeldung sind noch nicht bestätigt. |

**Noch offen bei 12139:** tatsächliche Asset-Abrufe in DEV und PROD sowie die Erreichbarkeit aus den vorgesehenen Zielnetzen. Ein Firmen-/VPN-Netztest ist kein Internet-Nachweis. Ein großes echtes Medium wurde ebenfalls noch nicht geprüft.

**Zur Mail:** Nicht erneut schicken. Im Upload ist keine Antwort enthalten. Wenn noch keine Antwort gekommen ist, brauchst du Marcs Bestätigung für den nächsten Lukas-Verbindungstest. Die anderen Tickets kannst du währenddessen weiterbearbeiten.

## Frisch starten, nichts zusammenführen

Den ZIP-Inhalt in einen **neuen leeren Arbeitsort** entpacken. Der enthaltene Ordner heißt `UMP`. Den bisherigen Paketordner als Sicherung behalten; nicht über ihn kopieren und keine echten Git-Repositories löschen.

In VS Code den neuen `UMP`-Ordner öffnen, in WSL wechseln und im Terminal ausführen:

```bash
bash start.sh status
```

Das liest **nur deine übernommenen Belege**, ohne Azure-Login und ohne neue Tests. Die Testdatei, ihr Uploadbeleg und dein Prüfergebnis sind bereits enthalten. Du musst sie nicht von Hand aus dem alten Ordner zusammensuchen.

## Was du als Nächstes machst und warum

| Reihenfolge | Deine nächste Aktion | Warum? |
|---|---|---|
| 1 | [DBI-12139](DBI-12139/README.md): Zwischenkommentar ins Jira kopieren; fehlende Abrufe ergänzen. | Die Infrastrukturprüfung ist erledigt. Jetzt geht es um die tatsächliche Nutzung, nicht um eine Neuanlage. |
| Parallel | [DBI-11149](DBI-11149/README.md): auf Marcs Bestätigung warten bzw. die vorhandene Antwort auswerten. | Nur die Gegenstelle kann bestätigen, ob der Schlüssel richtig hinterlegt ist. |
| Während Wartezeiten | [DBI-6455](DBI-6455/README.md): `bash start.sh 6455`. | Prüft vorhandene Logs/Regeln. Dazu brauchst du keine Rückmeldung der abwesenden Kollegen. |
| Bei blockierten Migrationstests vorziehen | [PB2B-27849](PB2B-27849/README.md): gezielte Rückfrage an Oliver. | Die App ist laut Jira bereits angelegt. Unklar ist die bestätigte temporäre Instanz und deren Login-Abnahme. |
| Zuletzt | [DBI-7161](DBI-7161/README.md): Schnittstelle mit Sinan/OSC klären. | Ohne Empfänger, Identitäten und Nachrichtenschema wäre die Bereitstellung unvollständig. |

Das ist eine Priorisierung, keine technische Kette. 12139 und SFTP sind im vorliegenden Ticketstand Prio 1. Monitoring ist Prio 2; die anderen beiden Prio 4.

## Nur die fehlenden 12139-Tests fortsetzen

Wenn kleine Testuploads in den jeweiligen Umgebungen nach eurem Betriebsprozess erlaubt sind:

```bash
bash start.sh 12139 rest --network intern
```

Der Befehl überspringt den bereits erfolgreichen TEST-Abruf. Für fehlende Umgebungen verwendet er einen vorhandenen eigenen Testblob oder legt nach deiner ausdrücklichen Bestätigung eine neue kleine Testdatei an. **PROD braucht eine bewusste Freigabe; bei der Rückfrage kannst du jederzeit abbrechen.** Kein Terraform-Apply, keine Änderung der Netzwerkfreigaben.

Aus einem tatsächlich freigegebenen externen Testnetz kann derselbe Ordner ohne Azure-Login die vorhandenen Testdateien erneut lesen:

```bash
bash start.sh 12139 extern
```

Nicht im internen Netz als „extern“ ausführen. Keine Sicherheitssoftware/VPN-Vorgaben umgehen. Alternativ prüft ein Kollege den Zugriff aus dem vorgesehenen Kundennetz; die Nachricht dafür steht im Ticket. Ein externer Test muss nicht mit diesem Skript erfolgen.

## Was im Ordner steckt

Pro Ticket steht alles Nötige in seiner `README.md`: Zweck, bereits erledigte Arbeit, nächster Schritt, Grund dafür, erwartetes Ergebnis, Nachrichten und Jira-Kommentar.

- `code/` unter dem Ticket enthält die vollständigen vorbereiteten Repository-Dateien, keine bloßen Codeausschnitte.
- `ergebnisse/DBI-12139/` enthält deine bereits erstellten technischen Belege.
- `start.sh` ist der gemeinsame WSL-Einstieg.
- [PRUEFPROTOKOLL.md](PRUEFPROTOKOLL.md) trennt deine echten Azure-Ergebnisse von meinen lokalen Softwaretests.

**Du musst nicht alle Codeordner übernehmen.** Für 12139 ist weiterhin keine Infrastrukturänderung nachgewiesen. Für die übrigen Tickets ist der Code vorbereitet, aber nicht durch deinen 12139-Lauf deployt oder getestet.

Optional übernimmt `bash start.sh 6455 code` die Monitoring-Dateien nach Prüfung in einen separaten Git-Worktree. Drag & Drop ist nur eine alternative bewusste Codeübernahme, nicht die Installation dieses Arbeitsordners. Ganze Repositories werden hier nicht ersetzt.

## Welche Schritte gibt es noch?

| Befehl | Zweck | Verändert Azure? |
|---|---|---|
| `bash start.sh status` | Vorhandene Belege verständlich anzeigen. | Nein. |
| `bash start.sh 12139` | Zeigt mit diesem Paket den vorhandenen 12139-Stand, statt alles zu wiederholen. | Nein. |
| `bash start.sh 12139 inventar` | Azure-Bestandsprüfung bewusst neu ausführen, etwa nach einer Änderung. | Nein. |
| `bash start.sh 12139 rest --network intern` | Nur fehlende Beispielabrufe ergänzen. | Allenfalls neue kleine Testblobs, nur nach Bestätigung. |
| `bash start.sh 12139 cleanup --env test` | Eigenen unveränderten Testblob nach den Tests entfernen. | Ja, genau diesen Blob nach Bestätigung. |
| `bash start.sh 6455` | TEST-Logs und bereits vorhandene Alarmregeln lesen. | Nein. |
| `bash start.sh portal` | Direkte Ressourcenlinks zum Nachschlagen erzeugen. | Nein. |

`az login` erfolgt in WSL, nicht nur im Windows-Browser. Falls es bereits funktioniert, nichts neu einrichten. Für die Prüfskripte sind Linux-Python 3.10+ und die Linux-Azure-CLI ausreichend. Terraform, Terragrunt, PHP und Ansible brauchst du nur bei den ausdrücklich genannten jeweiligen Code-/Betriebsschritten.

## Ist irgendein Jira jetzt fertig?

**Keines der fünf Tickets ist mit den vorliegenden Belegen vollständig abschließbar.** Deshalb enthalten die Ticketdateien ehrliche, direkt nutzbare **Zwischenkommentare**, keine vorgetäuschten Abschlussmeldungen.

Die Jira-Grundlage sind die Exporte vom 30.09.2026 sowie die von dir gezeigten Screenshots zu DBI-12139. Neu sind deine Laufbelege vom 02.10. und der Mail-Screenshot vom 01.10. Es fand keine aktuelle Live-Abfrage von Jira oder deinem Postfach statt.
