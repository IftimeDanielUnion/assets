# DBI-12139: Landingpage-Assets

**Status: Infrastruktur live bestätigt, TEST-Abruf erfolgreich. Gesamt-Abnahme noch offen.**
**Prio 1. Standalone.** Keine neue Storage-Anlage erforderlich, soweit die geprüften Einstellungen zeigen.

## Wofür ist das Ticket?

Große Landingpage-Dateien sollen in Azure liegen und für die vorgesehenen Nutzer ohne Anmeldung lesbar sein. Im Ticket stehen DEV, TEST und PROD.

Dein erster Lauf hat bereits gezeigt: Der vorhandene Code ist nicht nur ein Entwurf. Die geprüften Ressourcen sind auch in Azure vorhanden.

## Was ist jetzt erledigt?

| Prüfung | Nachweis |
|---|---|
| Storage/Container/Gateway für DEV | Im Inventar vom 02.10.2026 erfolgreich. |
| Storage/Container/Gateway für TEST | Im selben Inventar erfolgreich. |
| Storage/Container/Gateway für PROD | Im selben Inventar erfolgreich. |
| TEST-Upload | Eigene synthetische Datei, 8.192 Byte, erfolgreich angelegt. |
| Anonymer TEST-Abruf | HTTP 200, Inhalt korrekt. |
| TEST-Teilabruf | HTTP 206, erste 1.024 Byte korrekt. |

Die beim Login ausgewählte andere Default-Subscription hat diese Prüfung nicht verfälscht: Die Aufrufe verwenden jeweils ausdrücklich die hinterlegte UMP-Subscription.

Die Abrufe wurden von dir als **intern** gekennzeichnet. Sie sind echte erfolgreiche Tests, aber kein Nachweis für eine Internet-Veröffentlichung.

Der aktuelle `live`-Checkout wurde in deinem Lauf nicht gefunden. Das macht den Azure-/Download-Test nicht ungültig. Es bedeutet nur: Kein vollständiger Abgleich mit deinem heutigen Git-Branch oder Terraform-State. Für eine neue Codeänderung wäre dieser Vergleich nötig, nicht für eine Wiederholung des bereits bestandenen Tests.

## Schritt 1: Ergebnis dokumentieren, nicht erneut anfangen

**Warum:** Die bisherige Arbeit soll im Jira sichtbar sein. Du musst weder neu hochladen noch eine zweite Infrastruktur anlegen.

Diesen Kommentar kannst du jetzt unverändert ins Jira kopieren:

```text
Zwischenstand DBI-12139, Prüfung vom 02.10.2026:

Die vorhandene LP-Asset-Infrastruktur wurde für DEV, TEST und PROD aus Azure gelesen. Alle geprüften Storage-, Container- und Gateway-Sollwerte stimmen; es wurden keine Infrastrukturänderungen vorgenommen.

In TEST wurde eine synthetische 8-KiB-Testdatei in uniglobal-release-1 hochgeladen. Der anschließende Abruf über die Landingpage-Asset-Domain war ohne Anmeldung erfolgreich:
- vollständiger GET: HTTP 200, Inhalt stimmt
- Range-GET: HTTP 206, Inhalt des Teilbereichs stimmt
- Teststandort: internes Netz

Damit sind Infrastruktur-Bestand und der interne anonyme TEST-Abruf bestätigt. Noch offen sind entsprechende Abrufbelege für DEV/PROD und die Abnahme der Erreichbarkeit aus den vorgesehenen Zielnetzen. Ein repräsentatives großes Medium wurde noch nicht geprüft.

Kein Ticketabschluss: Der interne Test ist kein Nachweis der öffentlichen Internet-Erreichbarkeit. Die eigene Testdatei bleibt bis zu den restlichen Abrufen bestehen; anschließend wird sie bereinigt.
```

## Schritt 2: Nur die fehlenden Umgebungen ergänzen

**Warum:** Das Ticket nennt drei Umgebungen. Ein funktionierender TEST-Link beweist den DEV- oder PROD-Link nicht.

Wenn Testuploads dort freigegeben sind, im neuen UMP-Ordner:

```bash
bash start.sh 12139 rest --network intern
```

Das Skript:
1. erkennt deinen erfolgreichen TEST-Nachweis und überspringt ihn,
2. nutzt eventuell schon vorhandene eigene Testbelege für die übrigen Umgebungen,
3. fragt vor jedem neuen 8-KiB-Upload ausdrücklich nach `UPLOAD dev` bzw. `UPLOAD prod`,
4. prüft den anonymen Voll- und Teilabruf,
5. schreibt neue Belege und eine aktualisierte Übersicht.

**Erwartetes Ergebnis:** DEV und PROD ebenfalls mit erfolgreichem Abruf. Noch keine Internet-Abnahme.

Einzeln nur DEV prüfen:

```bash
bash start.sh 12139 rest --env dev --network intern
```

**Kein PROD-Test ohne Freigabe.** Wenn du dort nicht hochladen darfst, verwende eine vorhandene freigegebene Asset-URL oder lasse den Betriebs-/Anwendungsverantwortlichen den Abruf dokumentieren. Ein fehlendes Testergebnis ist kein Anlass, die Storage-Firewall zu öffnen.

## Schritt 3: Zielnetz und externen Zugriff abnehmen

**Warum:** „Ohne Anmeldung lesbar“ und „aus dem Internet erreichbar“ sind zwei verschiedene Eigenschaften. Der Blob-Account bleibt im geprüften Aufbau netzseitig privat; die Auslieferung erfolgt über den vorgesehenen Gateway-/Veröffentlichungsweg.

**Kurzes Update an Zeljko:**

> Hi Zeljko, kurzes Update zu DBI-12139: Die vorhandene Storage-/Gateway-Konfiguration ist in dev, test und prod bestätigt. In TEST funktionieren Upload sowie Abruf ohne Anmeldung bereits, einschließlich Teilabruf. Eine neue Storage-Anlage ist nach den bisherigen Prüfungen nicht nötig. Offen sind noch die Abrufe in den übrigen Umgebungen und die Prüfung aus dem vorgesehenen Kundennetz. Sollen DEV und TEST dabei bewusst intern bleiben und nur PROD extern erreichbar sein, oder ist die öffentliche Erreichbarkeit für alle drei Umgebungen vorgesehen?

Die Frage ist nur nötig, wenn dieser Netzumfang nicht bereits verbindlich dokumentiert ist. Keine vorhandene Freigabe erneut einholen.

**Falls jemand anders den externen TEST-Abruf übernehmen soll, an Alex Köster:**

> Hi Alex, der anonyme TEST-Abruf für DBI-12139 funktioniert aus unserem internen Netz. Kannst du bitte aus eurem dafür freigegebenen externen Testnetz prüfen, ob der folgende Link ohne Anmeldung ebenfalls die kleine synthetische Testdatei liefert? Bitte kurz Testzeitpunkt, Testnetz und Ergebnis zurückmelden. Es werden keine echten Kundendaten verwendet. Danke dir!
>
> https://landing-assets.test.apps.union-investment.de/uniglobal/dbi-12139-check-20261002T085902Z-99cb2a98bb4b.txt

Die Nachricht nur verwenden, solange die eigene Datei noch vorhanden ist. Für DEV/PROD stehen die jeweiligen Links nach Schritt 2 in den neuen Uploadbelegen.

Aus einem **tatsächlich freigegebenen externen Netz** kannst du selbst mit den vorhandenen Belegen prüfen:

```bash
bash start.sh 12139 extern
```

Keine Azure-Anmeldung, kein Upload. Der Befehl liest nur bereits angelegte eigene Testdateien. Bei der Rückfrage `NETZ EXTERN` nur bestätigen, wenn das wirklich dein Teststandort ist. Die Angabe wird dokumentiert, aber nicht technisch bewiesen.

**Nicht erforderlich:** Sicherheitssoftware abschalten, Firmenregeln umgehen oder private Storage-Endpunkte öffentlich schalten. Ein externer Abruffehler muss zuerst entlang des vorgesehenen DNS-/Gateway-/Veröffentlichungswegs untersucht werden.

## Schritt 4: Ein echtes großes Medium prüfen

**Warum:** 8 KiB prüfen den Weg, aber noch kein großes Video oder anderes echtes Landingpage-Medium. Das Ticket nennt keine feste Mindestgröße und keine Performance-Schwelle.

Wenn du eine freigegebene Datei kennst:

```bash
bash start.sh 12139 medium --env test --network intern
```

Der Befehl fragt nach dem relativen Dateipfad innerhalb des Release-Containers. Er liest nur Anfang und Ende, nicht den ganzen Film. Der interne Prüfwert von 10 MiB ist eine auswählbare Stichprobengrenze, **kein zusätzliches Jira-Akzeptanzkriterium**; bei Bedarf `--min-size-mib` passend zur abgestimmten Testdatei setzen.

Die echte Landingpage im Browser ebenfalls kurz ansehen. Kein eigener neuer Medien-Upload nötig.

**Nur wenn eine Testdatei fehlt, an Alex:**

> Hi Alex, für die letzte fachliche Prüfung von DBI-12139 brauche ich noch eine vorhandene, freigegebene große Asset-URL und die zugehörige Landingpage, möglichst zuerst auf TEST. Ich prüfe nur lesend und möchte keine produktiven Inhalte verändern. Kannst du mir einen geeigneten Testfall nennen? Danke dir!

## Schritt 5: Eigene Testdateien entfernen

**Warum:** Technische Testdateien sollen nach der Abnahme nicht liegen bleiben. Deine bisherige TEST-Datei ist im Upload noch nicht als gelöscht dokumentiert.

Erst wenn alle benötigten internen/externen Abrufe damit erledigt sind:

```bash
bash start.sh 12139 cleanup --env test
```

Für neue DEV-/PROD-Testdateien jeweils die betreffende Umgebung angeben. Der Befehl prüft Testmarkierungen und ETag, verlangt eine Bestätigung und löscht nur den unveränderten eigenen Blob. Wenn jemand die Datei bereits manuell entfernt oder verändert hat, stoppt er statt beliebige Inhalte zu löschen.

## Wann ist das Ticket fertig?

Wenn für alle vereinbarten Umgebungen ein anonymer Asset-Abruf aus den vorgesehenen Zielnetzen dokumentiert ist und der fachliche Testfall akzeptiert wurde. Interne DEV-/TEST-Abweichungen vom externen PROD-Zugriff nur nach ausdrücklich bestätigtem Umfang, nicht stillschweigend.

**Jetzt noch nicht schließen.** Der oben stehende Kommentar beschreibt den echten Zwischenstand. Nach den Resttests Testzeitpunkte/Netze und Abnahme ergänzen; „Infrastruktur neu angelegt“ wäre falsch.

## Technischer Stand zum Nachschlagen

Belege: `ergebnisse/DBI-12139/20261002T085649095294Z/inventar.json` sowie der TEST-Belegordner unter `20261002T085855379770Z/test/`.

Originalcode: `live/live/{dev,test,prod}/terragrunt.stack.hcl` und `appgateway.hcl`. Die Release-Container bleiben anonym lesbar; der alte allgemeine Container `assets` bleibt privat.

Das Prüfwerkzeug liegt vollständig in `code/live/scripts/lp_assets.py`; es muss für diese Arbeit nicht ins Repo übernommen werden. Sein Medientest verwendet jetzt einen expliziten Bytebereich für das Dateiende statt eines Suffixbereichs.

Quellen: DBI-12139-Screenshots, deine Belege aus `2139.7z` und der Repository-Upload. Technische Erläuterung: [Microsoft: anonymer Blob-Zugriff](https://learn.microsoft.com/en-us/azure/storage/blobs/anonymous-read-access-configure), [Microsoft: Get Blob und Teilbereiche](https://learn.microsoft.com/en-us/rest/api/storageservices/get-blob).
