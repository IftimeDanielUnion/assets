#!/usr/bin/env python3
"""WSL-Einstieg für die fünf UMP-Tickets. Kein automatisches Deployment."""
from __future__ import annotations

import argparse
import base64
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import shlex
import shutil
import subprocess
import sys
from typing import Any
from urllib.parse import quote, urlsplit

BASE = Path(__file__).resolve().parent
RESULTS = BASE / "ergebnisse"
LOCAL = BASE / "lokal.json"  # User-owned: deliberately never included in update ZIPs.
TICKETS = {
    "DBI-12139": ("live", "LP-Assets: Azure-Bestand und anonymen Abruf prüfen"),
    "DBI-11149": ("unioninvestment", "SFTP: Schlüssel bestätigen, echte UMP-Anmeldung testen"),
    "DBI-6455": ("live", "Monitoring: Logs prüfen, Alert-Code bereitstellen, Testmail"),
    "PB2B-27849": ("ansible-ump", "SAML: temporäre Instanz bestätigen, Metadaten und Login prüfen"),
    "DBI-7161": ("catalog", "Event Grid: Schnittstellenvertrag fehlt, Modul nicht aktiviert"),
}
ALIASES = {key.split("-", 1)[1]: key for key in TICKETS}
LP_FILE = BASE / "DBI-12139/code/live/scripts/lp_assets.py"
MONITOR_QUERY = """OTelLogs
| where TimeGenerated > ago(24h)
| summarize Records = count(), Latest = max(TimeGenerated) by ServiceName, SeverityText
| order by Latest desc
| take 200"""
UUID_RE = re.compile(r"[0-9a-fA-F]{8}-(?:[0-9a-fA-F]{4}-){3}[0-9a-fA-F]{12}")


class Stop(RuntimeError):
    """Expected missing prerequisite, not a successful ticket completion."""


def load_module(name: str, path: Path) -> Any:
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise Stop(f"Datei nicht ladbar: {path}. Bitte das ganze ZIP entpacken.")
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod


def lp() -> Any:
    return load_module("ump_lp_assets", LP_FILE)


def local_config() -> dict:
    if not LOCAL.exists():
        return {}
    if LOCAL.stat().st_size > 65536:
        raise Stop("lokal.json ist unerwartet groß. Bitte die lokale Konfiguration prüfen.")
    result = json.loads(LOCAL.read_text(encoding="utf-8-sig"))
    if not isinstance(result, dict):
        raise Stop("lokal.json muss ein JSON-Objekt sein.")
    return result


def save_local(key: str, value: Any, section: str | None = None) -> None:
    config = local_config()
    if section:
        config.setdefault(section, {})[key] = value
    else:
        config[key] = value
    LOCAL.parent.mkdir(parents=True, exist_ok=True)
    temp = LOCAL.with_name(LOCAL.name + ".tmp")
    temp.write_text(json.dumps(config, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    temp.chmod(0o600)
    temp.replace(LOCAL)


def ask(label: str, default: str = "") -> str:
    if not sys.stdin.isatty():
        if default:
            return default
        raise Stop(f"Eingabe erforderlich: {label}. Im interaktiven WSL-Terminal starten.")
    answer = input(label + (f" [{default}]" if default else "") + ": ").strip()
    return answer or default


def confirm(text: str) -> None:
    if not sys.stdin.isatty() or ask(f"Zur Bestätigung exakt {text} eingeben") != text:
        raise Stop("Nicht bestätigt. Keine angeforderte Schreib-/Serveraktion gestartet.")


def user_path(value: str) -> Path:
    value = value.strip()
    if len(value) >= 2 and value[0] == value[-1] and value[0] in "\"'":
        value = value[1:-1]
    if not value or "\x00" in value or "\n" in value or "\r" in value:
        raise Stop("Bitte einen gültigen einzelnen Dateipfad eingeben.")
    if re.match(r"^[A-Za-z]:[\\/]", value):
        value = "/mnt/" + value[0].lower() + "/" + value[3:].replace("\\", "/")
    elif value.startswith("\\\\"):
        parts = value[2:].split("\\")
        if len(parts) < 3 or parts[0].lower() not in ("wsl.localhost", "wsl$"):
            raise Stop("Netzlaufwerk zuerst in WSL mounten und den Linux-Pfad angeben.")
        if parts[1].casefold() != os.environ.get("WSL_DISTRO_NAME", "").casefold():
            raise Stop("Der Pfad gehört zu einer anderen WSL-Distribution.")
        value = "/" + "/".join(parts[2:])
    return Path(os.path.expandvars(value)).expanduser().resolve()


def executable(name: str) -> str:
    path = shutil.which(name)
    if not path:
        raise Stop(f"{name} fehlt in WSL. Siehe README, Abschnitt Voraussetzungen.")
    resolved = str(Path(path).resolve())
    # Avoid Windows az.cmd/python.exe and accidental calls through interop.
    if resolved.lower().endswith((".exe", ".cmd", ".bat")) or re.match(r"^/mnt/[a-z]/", resolved):
        raise Stop(f"{name} zeigt auf ein Windows-Werkzeug ({resolved}). Linux-Version in WSL verwenden.")
    return path


def run(command: list[str], *, cwd: Path | None = None, env: dict | None = None,
        capture: bool = False, timeout: int | None = None) -> subprocess.CompletedProcess:
    print("$ " + shlex.join(command), flush=True)
    try:
        result = subprocess.run(command, cwd=cwd, env=env, capture_output=capture,
                                text=True, encoding="utf-8", errors="replace", timeout=timeout, check=False)
    except subprocess.TimeoutExpired as exc:
        raise Stop("Zeitlimit erreicht. Ergebnis der begonnenen Operation separat prüfen.") from exc
    if result.returncode:
        message = (result.stderr or result.stdout or "").strip() if capture else ""
        raise Stop(f"Befehl fehlgeschlagen (Exit {result.returncode}). " + message[:5000])
    return result


def ensure_login() -> None:
    az = executable("az")
    result = subprocess.run([az, "account", "show", "--only-show-errors", "--output", "none"],
                            capture_output=True, text=True, timeout=40, check=False)
    if result.returncode:
        if not sys.stdin.isatty():
            raise Stop("Keine nutzbare Azure-Anmeldung in WSL. Zuerst az login ausführen.")
        answer = ask("Azure-Anmeldung in WSL fehlt. az login jetzt starten? j/n", "j")
        if answer.lower() not in ("j", "ja"):
            raise Stop("Azure-Prüfung noch nicht gestartet.")
        run([az, "login", "--output", "none"])
    print("Azure-Abfragen verwenden jeweils die ausdrückliche Subscription aus dem Repo-Snapshot.")


def new_run(ticket: str) -> Path:
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
    folder = RESULTS / ticket / stamp
    folder.mkdir(parents=True, exist_ok=False)
    return folder


def report(folder: Path, ticket: str, heading: str, lines: list[str]) -> None:
    text = f"# {ticket}: {heading}\n\nStand (UTC): {datetime.now(timezone.utc).isoformat(timespec='seconds')}\n\n"
    text += "\n".join(lines) + "\n\nKein Nachweis einer vollständigen Jira-Abnahme. Kein Infrastruktur-Deployment durch den Starter.\n"
    path = folder / "STATUS.md"
    path.write_text(text, encoding="utf-8")
    print("\n" + text + "\nErgebnis zum Öffnen in VS Code: " + str(path))


def portal_link(resource_id: str) -> str:
    return "https://portal.azure.com/#resource" + quote(resource_id, safe="/-._") + "/overview"


def monitoring_target(env: str) -> dict:
    cfg = lp().env_config(env)
    name, group = f"log-ump-{env}", f"rg-monitoring-{env}"
    rid = f"/subscriptions/{cfg['subscription_id']}/resourceGroups/{group}/providers/Microsoft.OperationalInsights/workspaces/{name}"
    return {"name": name, "resource_group": group, "id": rid, "subscription_id": cfg["subscription_id"]}


def create_portal_map() -> Path:
    tool = lp()
    text = ["# Azure-Portal: direkte Ressourcenlinks", "", "Namen stammen aus dem Upload, nicht aus einer Live-Bestätigung.", ""]
    for env, cfg in tool.load_config()["environments"].items():
        gateway = f"/subscriptions/{cfg['subscription_id']}/resourceGroups/{cfg['gateway_resource_group']}/providers/Microsoft.Network/applicationGateways/{cfg['gateway']}"
        text.extend([f"## {env}", "", f"[LP-Storage]({portal_link(tool.account_id(cfg))}) | "
                     f"[Gateway]({portal_link(gateway)}) | [Log Analytics]({portal_link(monitoring_target(env)['id'])})", ""])
    text += ["Portal-Anmeldung und CLI-Anmeldung sind getrennte Arbeitswege. Für CLI-Aufrufe az login in WSL verwenden.",
             "Private Blobs brauchen auch im Portal einen funktionierenden Daten-Netzwerkweg und Datenrechte.",
             "Nicht wegen einer fehlgeschlagenen Portal-Anzeige Firewall oder Public Network Access öffnen."]
    RESULTS.mkdir(parents=True, exist_ok=True)
    path = RESULTS / "PORTAL.md"
    path.write_text("\n".join(text) + "\n", encoding="utf-8")
    return path


def looks_like_repo(path: Path, name: str) -> bool:
    markers = {"live": "live/root.hcl", "catalog": "modules/log-and-monitor/main.tf",
               "ansible-ump": "host_vars/ump-app", "unioninvestment": "htdocs/src"}
    return path.is_dir() and (path / markers[name]).exists()


def find_repo(name: str, explicit: str | None = None, required: bool = True) -> Path | None:
    if explicit:
        path = user_path(explicit)
        if not looks_like_repo(path, name):
            raise Stop(f"Kein passender {name}-Repository-Stamm: {path}")
        save_local(name, str(path), "repos")
        return path
    saved = local_config().get("repos", {}).get(name)
    if saved and looks_like_repo(Path(saved), name):
        return Path(saved).resolve()
    roots = [Path.cwd(), BASE.parent, BASE.parent.parent, Path.home() / "repos",
             Path.home() / "src", Path.home() / "projects", Path.home() / "work"]
    candidates: set[Path] = set()
    for root in roots:
        for relative in (Path(name), Path("UMP_repos/UMP_legacy") / name,
                         Path("UMP_legacy") / name):
            path = (root / relative).resolve()
            if looks_like_repo(path, name) and not path.is_relative_to(BASE):
                candidates.add(path)
        if root.name == name and looks_like_repo(root, name) and not root.is_relative_to(BASE):
            candidates.add(root.resolve())
    if len(candidates) == 1:
        path = next(iter(candidates))
        print(f"Repository gefunden: {path}")
        return path
    if not required:
        return None
    if candidates:
        print("Mehrere mögliche Repositories: " + ", ".join(str(p) for p in sorted(candidates)))
    value = ask(f"Pfad zu deinem {name}-Repository (Linux- oder Windows-Pfad)")
    return find_repo(name, value, True)


def code(ticket: str, args: argparse.Namespace) -> int:
    """Use a separate local worktree; never switch the user's current branch."""
    helper = load_module("ump_importer", BASE / "uebernehmen.py")
    manifest = json.loads((BASE / "paket.json").read_text(encoding="utf-8"))
    saved = local_config().get("worktrees", {}).get(ticket)
    target = Path(saved).resolve() if saved else Path.home() / "ump-worktrees" / ticket / TICKETS[ticket][0]
    branch = "feat/" + ticket + "-ump-checkpoint"
    executable("git")
    if target.exists():
        if not (target / ".git").exists():
            raise Stop(f"Ziel existiert, ist aber kein verwalteter Git-Worktree: {target}")
        if helper.git(target, "branch", "--show-current") != branch:
            raise Stop(f"Unerwarteter Branch im Ticket-Worktree: {target}. Nicht automatisch umschalten.")
    else:
        source = find_repo(TICKETS[ticket][0], args.repo)
        assert source is not None
        if Path(helper.git(source, "rev-parse", "--show-toplevel")).resolve() != source:
            raise Stop("Bitte exakt den Git-Repository-Stamm wählen.")
        if helper.git(source, "status", "--porcelain"):
            raise Stop("Dein Quell-Checkout enthält ungesicherte Änderungen. Erst sichern/committen; kein automatisches Stash.")
        helper.inspect(ticket, source, manifest)  # Reject newer files before making any worktree.
        if helper.git(source, "branch", "--list", branch):
            raise Stop(f"Branch {branch} existiert bereits. Bestehenden Arbeitsstand prüfen, nicht neu überschreiben.")
        target.parent.mkdir(parents=True, exist_ok=True)
        run([executable("git"), "-C", str(source), "worktree", "add", "-b", branch, str(target), "HEAD"])
        save_local(ticket, str(target), "worktrees")
        save_local(TICKETS[ticket][0], str(source), "repos")
    changes = helper.inspect(ticket, target, manifest)
    helper.apply(target, ticket, changes)
    print(f"\nTicket-Worktree: {target}\nOriginal-Checkout unverändert. Kein Commit/Push/Deployment.\nÖffnen: code {shlex.quote(str(target))}")
    print("Jetzt git status und git diff prüfen. Neue Dateien werden in git diff ohne Staging noch nicht angezeigt.")
    return 0


def latest_receipt(args: argparse.Namespace) -> Path:
    tool = lp()
    if args.receipt:
        path = user_path(args.receipt)
        tool.read_receipt(path)
        return path
    candidates = []
    for path in (RESULTS / "DBI-12139").glob("**/upload.json"):
        try:
            data, _ = tool.read_receipt(path)
        except (OSError, ValueError, tool.TaskError):
            continue
        if data.get("status") in ("current_test_blob_deleted", "upload_pending", "upload_failed_or_unconfirmed"):
            continue
        if args.env and data["environment"] != args.env:
            continue
        candidates.append(path)
    if not candidates:
        raise Stop("Kein eigener Testupload-Beleg gefunden. Zuerst 12139 upload, oder --receipt mit dem vorhandenen Beleg angeben.")
    candidates.sort(key=lambda p: p.stat().st_mtime_ns, reverse=True)
    path = candidates[0]
    data, _ = tool.read_receipt(path)
    print(f"Verwende letzten eigenen Beleg: {data['environment']} / {data['campaign']} / {path}")
    return path


def asset_check(args: argparse.Namespace) -> int:
    ensure_login()
    tool, folder = lp(), new_run("DBI-12139")
    source = find_repo("live", args.repo, required=False)
    lines = []
    if source:
        rc = tool.source_check(argparse.Namespace(repo=source, output=folder / "quellcode.json"))
        lines.append("Quellcodeabgleich: " + ("passt zum Snapshot" if rc == 0 else "Abweichungen, siehe quellcode.json"))
    else:
        lines.append("Aktueller Git-Checkout nicht automatisch gefunden. Codeabgleich ausgelassen; optional --repo angeben.")
    rc = tool.inventory(argparse.Namespace(env=args.env or "all", output=folder / "inventar.json"))
    data = json.loads((folder / "inventar.json").read_text())
    lines += ["", "| Umgebung | Inventarergebnis |", "|---|---|"]
    for env, entry in data["environments"].items():
        failures = [c["check"] for c in entry.get("checks", []) + entry.get("gateway_checks", []) if not c["passed"]]
        errors = entry.get("errors", [])
        if errors:
            value = "Lesefehler, kein Nachweis fehlender Ressourcen"
        elif failures or not entry.get("gateway_backend_matches_expected_storage", False):
            value = "Abweichungen: " + "; ".join(failures or ["Gateway-Backend"])
        else:
            value = "Gelesene Sollwerte passen; Asset-Abruf steht aus"
        lines.append(f"| {env} | {value.replace('|', '/')} |")
    lines += ["", "Details stehen in inventar.json. Keine Blob-Datei wurde hochgeladen.",
              "Nächster Schritt: bei passenden Werten `bash start.sh 12139 upload`, dann `bash start.sh 12139 probe`.",
              "Für Upload/Blob-Zugriff sind zusätzlich Datenrechte, VPN/Route und DNS erforderlich. az login allein genügt nicht.",
              "Ein Test aus WSL mit Firmen-VPN ist kein Nachweis öffentlicher Internet-Erreichbarkeit."]
    report(folder, "DBI-12139", "Azure-Inventar, keine Live-Abnahme", lines)
    return rc


def assets(action: str, args: argparse.Namespace) -> int:
    if action in ("stand", "rest", "extern") or (action == "check" and any((RESULTS / "DBI-12139").glob("**/inventar.json"))):
        progress = load_module("ump_progress", BASE / "fortschritt.py")
        if action in ("check", "stand"):
            return progress.summary(sys.modules[__name__], args.campaign)
        return progress.remaining(sys.modules[__name__], args, external_only=action == "extern")
    if action in ("check", "inventar", "inventory"):
        return asset_check(args)
    tool = lp()
    env = args.env or "test"
    if env == "all":
        raise Stop("Upload/Medientest immer für genau eine Umgebung durchführen, nicht all.")
    if action == "upload":
        ensure_login()
        return tool.upload_test(argparse.Namespace(env=env, campaign=args.campaign,
                                                   output_dir=new_run("DBI-12139")))
    if action in ("probe", "cleanup"):
        receipt = latest_receipt(args)
        if action == "cleanup":
            ensure_login()
            return tool.cleanup(argparse.Namespace(receipt=receipt))
        network = args.network or ask("Netz dieses Abrufs: intern / extern / unbekannt", "unbekannt")
        if network not in ("intern", "extern", "unbekannt"):
            raise Stop("Netz muss intern, extern oder unbekannt sein.")
        return tool.probe(argparse.Namespace(receipt=receipt, endpoint=args.endpoint, origin=None,
                                             network=network, output=receipt.with_name("probe-" + datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ") + ".json")))
    if action == "medium":
        blob = args.blob or ask("Freigegebener großer Blob: relativer Pfad im Release-Container, keine URL")
        network = args.network or ask("Netz dieses Abrufs: intern / extern / unbekannt", "unbekannt")
        if network not in ("intern", "extern", "unbekannt"):
            raise Stop("Netz muss intern, extern oder unbekannt sein.")
        return tool.probe_media(argparse.Namespace(env=env, campaign=args.campaign, blob=blob,
                           network=network, min_size_mib=args.min_size_mib, output=new_run("DBI-12139") / "medientest.json"))
    raise Stop("12139 kennt stand, inventar, rest, extern, upload, probe, medium, cleanup, code.")


def arm_pages(tool: Any, url: str, subscription: str) -> list[dict]:
    rows, seen = [], set()
    while url:
        parsed = urlsplit(url)
        if url in seen or parsed.scheme != "https" or parsed.netloc != "management.azure.com":
            raise Stop("Unerwarteter ARM-Folgelink; kein Wechsel auf fremde Endpunkte.")
        seen.add(url)
        page = tool.az_json(["rest", "--method", "get", "--url", url, "--subscription", subscription])
        rows.extend(page.get("value", []))
        url = page.get("nextLink")
    return rows


def log_rows(data: dict) -> list[dict]:
    if data.get("error"):
        raise Stop("Log Analytics liefert einen Fehler oder Teilergebnisfehler: " + str(data["error"])[:2000])
    tables = [table for table in data.get("tables", []) if table.get("name") == "PrimaryResult"]
    if len(tables) != 1:
        raise Stop("Kein eindeutiges PrimaryResult in der Log-Antwort.")
    table = tables[0]
    names = [column["name"] for column in table.get("columns", [])]
    if not {"ServiceName", "SeverityText", "Records", "Latest"}.issubset(names):
        raise Stop("Unerwartete Ergebnisspalten der OTEL-Prüfung.")
    return [dict(zip(names, row, strict=True)) for row in table.get("rows", [])]


def monitoring(args: argparse.Namespace) -> int:
    ensure_login()
    tool, folder = lp(), new_run("DBI-6455")
    envs = ["dev", "test", "prod"] if args.env == "all" else [args.env or "test"]
    result, lines, failed = {}, [], False
    for env in envs:
        target = monitoring_target(env)
        item: dict = {"expected_workspace": target, "errors": []}
        result[env] = item
        lines.append("## " + env)
        lines.append(f"[Workspace im Portal]({portal_link(target['id'])})")
        try:
            workspace = tool.az_json(["monitor", "log-analytics", "workspace", "show", "--subscription", target["subscription_id"],
                                      "--resource-group", target["resource_group"], "--workspace-name", target["name"]])
            if workspace.get("id", "").casefold() != target["id"].casefold():
                raise Stop("Falscher Workspace zurückgeliefert, kein automatischer Wechsel.")
            cid = workspace.get("customerId", "")
            if not UUID_RE.fullmatch(cid):
                raise Stop("Workspace Customer ID fehlt oder ist ungültig.")
            query = tool.az_json(["rest", "--method", "post", "--url", f"https://api.loganalytics.azure.com/v1/workspaces/{cid}/query",
                         "--resource", "https://api.loganalytics.io", "--subscription", target["subscription_id"],
                         "--body", json.dumps({"query": MONITOR_QUERY, "timespan": "P1D"})])
            item["logs"] = log_rows(query)
            lines.append(f"Logabfrage ausgeführt: {len(item['logs'])} Service-/Severity-Gruppen in den letzten 24 Stunden (max. 200).")
            if not item["logs"]:
                lines.append("Keine Daten in dieser Abfrage. Erst Logeingang/Berechtigungen prüfen, nicht als erfolgreiche Alarmierung bewerten.")
                failed = True
        except (tool.TaskError, Stop) as exc:
            item["errors"].append(str(exc)); failed = True
            lines.append("Logabfrage nicht bestätigt. Grund steht in details.json.")
        try:
            url = f"https://management.azure.com/subscriptions/{target['subscription_id']}/providers/Microsoft.Insights/scheduledQueryRules?api-version=2021-08-01"
            all_rules = arm_pages(tool, url, target["subscription_id"])
            appi = target["id"].split("/providers/")[0] + "/providers/Microsoft.Insights/components/" + target["name"] + "-appi"
            relevant = {target["id"].casefold(), appi.casefold()}
            item["related_rules"] = [rule for rule in all_rules if relevant.intersection(
                scope.casefold() for scope in (rule.get("properties", {}).get("scopes") or []))]
            lines.append(f"Bestehende Regeln mit direktem Workspace-/App-Insights-Scope: {len(item['related_rules'])}. Vor Neuanlage auf doppelte Alarmierung prüfen.")
        except (tool.TaskError, Stop) as exc:
            item["errors"].append("Regelbestand: " + str(exc)); failed = True
            lines.append("Regelbestand nicht vollständig gelesen; keine Aussage über fehlende Alarme.")
        lines.append("")
    tool.save_json(folder / "details.json", result)
    (folder / "abfrage.kql").write_text(MONITOR_QUERY + "\n", encoding="utf-8")
    lines += ["Keine Regel erstellt, keine Mail versendet. Auch eine erfolgreiche Logabfrage ist noch kein Alarmtest.",
              "Nächster Schritt: `bash start.sh 6455 code`, dann Review/Plan/Deployment über die bestehende GitLab-Pipeline.",
              "az login authentifiziert nicht den GitLab-Terraform-State. Dafür keine Azure-Schlüssel oder Tokens in Dateien kopieren."]
    report(folder, "DBI-6455", "Log- und Regelbestand", lines)
    return 2 if failed else 0


def sftp_command(target: str, directory: str, php: str, connect: bool) -> list[str]:
    if not re.fullmatch(r"(?:[A-Za-z0-9_][A-Za-z0-9_.-]*@)?[A-Za-z0-9_][A-Za-z0-9_.-]*", target):
        raise Stop("Bitte einen einzelnen bestätigten SSH-Alias oder user@host eingeben, keine Optionen.")
    if not directory.startswith("/") or any(c in directory + php for c in "\r\n\x00"):
        raise Stop("Der Remote-App-Pfad muss absolut und einzeilig sein.")
    if not php or (php != "php" and not php.startswith("/")):
        raise Stop("PHP entweder als php oder als bestätigten absoluten Serverpfad angeben.")
    parts = ["sudo", "-u", "www-data", php, "bin/console", "app:diagnostics:mbo-sftp"]
    if connect:
        parts.append("--connect")
    remote = "cd -- " + shlex.quote(directory) + " && " + shlex.join(parts)
    return ["ssh", "-t", "-o", "StrictHostKeyChecking=yes", "-o", "ConnectTimeout=15", "--", target, remote]


def sftp(action: str, args: argparse.Namespace) -> int:
    key = BASE / "DBI-11149/azure-lukas-sftp-prod.pub"
    fields = key.read_text(encoding="utf-8").split()
    fingerprint = "SHA256:" + base64.b64encode(hashlib.sha256(base64.b64decode(fields[1], validate=True)).digest()).decode().rstrip("=")
    if fields[0] != "ssh-rsa" or fingerprint != "SHA256:dnNfJ61wYm8HJzH+x+DLgIvcREFPbmZUXdMVjJPvXV8":
        raise Stop("Beiliegender Public Key stimmt nicht zum Ticketfingerabdruck.")
    if action == "check":
        print(f"Öffentlicher Schlüssel geprüft: {fingerprint}\nAnhang: {key}\nDie Anfrage an Marc wurde laut deinem Screenshot am 01.10.2026 versendet. Nicht erneut senden.\nIm Upload ist keine Antwort enthalten. Sobald seine Bestätigung vorliegt: DBI-11149/README.md.\nKein Server kontaktiert; Schlüsselhinterlegung und SFTP-Anmeldung sind damit nicht bestätigt.")
        return 0
    if action not in ("server", "connect"):
        raise Stop("11149 kennt check, code, server, connect.")
    executable("ssh")
    cfg = local_config().get("sftp", {})
    target = args.host or ask("Bestätigter SSH-Alias der UMP-Instanz, nicht Lukas", cfg.get("host", ""))
    directory = args.app_dir or ask("Absolutes App-Verzeichnis AUF der UMP-Instanz, das bin/console enthält", cfg.get("directory", ""))
    php = args.php or ask("PHP der UMP-Instanz, Version gemäß Repo 8.5", cfg.get("php", "php"))
    command = sftp_command(target, directory, php, action == "connect")
    print("Ausführung auf der UMP-Instanz, nicht auf deinem Laptop:\n" + shlex.join(command))
    if action == "connect":
        print("Nur nach bestätigtem Lukas-Public-Key und unabhängig geprüftem Server-Host-Key im App-known_hosts.")
    confirm("VERBINDEN " + target)
    save_local("sftp", {"host": target, "directory": directory, "php": php})
    run(command)
    print("Diagnose beendet. Kein Export gestartet; Anwendungstest bleibt gesondert abzustimmen.")
    return 0


def ticket_worktree(ticket: str) -> Path:
    saved = local_config().get("worktrees", {}).get(ticket)
    if not saved or not Path(saved).is_dir():
        raise Stop(f"Zuerst bash start.sh {ticket.split('-')[1]} code ausführen.")
    return Path(saved).resolve()


def saml(action: str, args: argparse.Namespace) -> int:
    if action == "check":
        print("Noch offen: Oliver muss Zielhost, URL, Entity-ID und ACS der temporären Instanz bestätigen.\nNachricht: PB2B-27849/README.md\nVorbereitung: 27849 code, danach 27849 prepare. Noch kein Server kontaktiert.")
        return 0
    repo = ticket_worktree("PB2B-27849")
    if str(repo).startswith("/mnt/"):
        raise Stop("Ansible-Worktree im WSL-Dateisystem verwenden, z.B. ~/ump-worktrees, nicht /mnt/c.")
    cfg = local_config().get("saml", {})
    if action == "prepare":
        executable("openssl")
        host = args.host or ask("Von Oliver bestätigter einzelner Ansible-Inventarhost", cfg.get("host", ""))
        entity = args.entity_id or ask("Von Oliver bestätigte SAML-Entity-ID", cfg.get("entity", ""))
        acs = args.acs_url or ask("Von Oliver bestätigte ACS-/Rücksprungadresse", cfg.get("acs", ""))
        sp = user_path(args.sp_metadata or ask("Lokale XML-Kopie der aktiven SP-Metadaten, KEIN privater Schlüssel", cfg.get("sp", "")))
        folder = new_run("PB2B-27849")
        values = folder / "temp-saml-vars.json"
        run([sys.executable, str(repo / "scripts/prepare_temporary_saml.py"), "prepare", "--repo", str(repo),
             "--host", host, "--entity-id", entity, "--acs-url", acs, "--sp-metadata", str(sp), "--output", str(values)], cwd=repo)
        save_local("saml", {"host": host, "entity": entity, "acs": acs, "sp": str(sp), "vars": str(values), "inventory": cfg.get("inventory", "")})
        report(folder, "PB2B-27849", "Metadaten lokal vorbereitet", ["Nur lokale Dateien vorbereitet. Kein Login getestet und keine Serverkonfiguration geändert.",
                "Nächster Schritt: `bash start.sh 27849 dry-run`, mit ausdrücklich bestätigtem Inventory."])
        return 0
    if action != "dry-run":
        raise Stop("27849 kennt check, code, prepare, dry-run. Tatsächliches Deployment über euren freigegebenen Weg.")
    exe = executable("ansible-playbook")
    if not cfg.get("vars") or not Path(cfg["vars"]).is_file():
        raise Stop("Zuerst 27849 prepare erfolgreich ausführen.")
    inventory = user_path(args.inventory or ask("Bestätigtes Inventory, nicht der local.yml-Default", cfg.get("inventory", "")))
    if not inventory.exists():
        raise Stop("Inventory existiert nicht.")
    values = json.loads(Path(cfg["vars"]).read_text())
    target = values["temporary_ump_host"]
    confirm("CHECK " + target)
    cfg["inventory"] = str(inventory); save_local("saml", cfg)
    env = dict(os.environ, ANSIBLE_CONFIG=str(repo / "ansible.cfg"), ANSIBLE_HOST_KEY_CHECKING="True")
    cmd = [exe, "-i", str(inventory), str(repo / "playbooks/configuration/mellon-temporary.yml"),
           "--extra-vars", "@" + cfg["vars"], "--extra-vars", "temporary_ump_approved=true"]
    run(cmd + ["--syntax-check"], cwd=repo, env=env)
    run(cmd + ["--check", "--diff"], cwd=repo, env=env)
    folder = new_run("PB2B-27849")
    report(folder, "PB2B-27849", "Ansible-Check beendet, noch nicht deployt", [
        "Syntax- und Check-Aufruf beendet. Ansible liest die Zielkonfiguration und kann temporäre Prüfhilfen übertragen; keine produktive Metadatenübernahme angefordert.",
        "Nach inhaltlichem Review und Freigabe denselben Befehl ohne --check/--diff verwenden:", "```bash", "cd -- " + shlex.quote(str(repo)),
        shlex.join(["env", "ANSIBLE_CONFIG=" + str(repo / "ansible.cfg"), "ANSIBLE_HOST_KEY_CHECKING=True", *cmd]), "```",
        "Anschließend echter Login und Rückbauabstimmung. SSH-Host-Key-Prüfung bleibt aktiviert."])
    return 0


def doctor() -> int:
    print("Umgebung: " + (os.environ.get("WSL_DISTRO_NAME", "Linux (hier nicht als WSL erkannt)")))
    print("Python: " + sys.version.split()[0] + " | " + sys.executable)
    for name in ("az", "git", "ssh", "openssl", "terraform", "terragrunt", "ansible-playbook", "php"):
        try:
            path = executable(name)
            print(f"OK {name}: {path}")
        except Stop as exc:
            print(str(exc))
    print("Für 12139 check: Python und Linux-Azure-CLI. Terraform/PHP/Ansible sind dafür nicht nötig.")
    print("Für Infra bleibt der Repo-Stand maßgeblich: Terraform 1.13.4, Terragrunt 1.1.6. Keine automatische Aktualisierung.")
    print("Keine Installation und keine Anmeldung automatisch durch setup. Portal-Links: " + str(create_portal_map()))
    return 0


def menu() -> str:
    print("UMP-Tickets in WSL. Standardaktionen verändern keine Azure-Infrastruktur.\n")
    for key, (_, title) in TICKETS.items():
        print(key.split("-")[1] + "  " + title)
    print("setup  Werkzeuge prüfen    portal  Ressourcenlinks    status  Letzte Ergebnisse\n")
    return ask("Ticketnummer/Aktion", "12139")


def parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description=__doc__, epilog="Beispiel: bash start.sh 12139 oder bash start.sh 6455 code")
    p.add_argument("ticket", nargs="?", default="menu")
    p.add_argument("action", nargs="?", default="check")
    p.add_argument("--env", choices=["dev", "test", "prod", "all"])
    p.add_argument("--repo", help="Repository-Stamm, einmalig speicherbar")
    p.add_argument("--campaign", choices=["uniglobal", "ve", "zukunft"], default="uniglobal")
    p.add_argument("--network", choices=["intern", "extern", "unbekannt"])
    p.add_argument("--endpoint", choices=["asset-domain", "blob-intern"], default="asset-domain")
    p.add_argument("--receipt")
    p.add_argument("--blob")
    p.add_argument("--min-size-mib", type=int, choices=range(1, 102401), default=10, metavar="MIB", help="Nur gewählte Medienstichprobe, keine Jira-Vorgabe")
    p.add_argument("--host")
    p.add_argument("--app-dir")
    p.add_argument("--php")
    p.add_argument("--entity-id")
    p.add_argument("--acs-url")
    p.add_argument("--sp-metadata")
    p.add_argument("--inventory")
    return p


def main() -> int:
    args = parser().parse_args()
    try:
        if not sys.platform.startswith("linux"):
            raise Stop("Im WSL-Terminal starten, nicht mit Windows-Python.")
        key = menu() if args.ticket == "menu" and sys.stdin.isatty() else args.ticket
        if key == "menu":
            parser().print_help(); return 0
        if key == "setup":
            return doctor()
        if key == "login":
            run([executable("az"), "login", "--output", "none"]); return 0
        if key == "portal":
            print(create_portal_map()); return 0
        if key == "status":
            progress = load_module("ump_progress", BASE / "fortschritt.py")
            return progress.summary(sys.modules[__name__])
        if key == "tests":
            run([sys.executable, str(BASE / "pruefen.py")]); return 0
        ticket = ALIASES.get(key, key.upper())
        if ticket not in TICKETS:
            raise Stop("Unbekanntes Ticket. 12139, 11149, 6455, 27849 oder 7161 verwenden.")
        if args.action == "code":
            return code(ticket, args)
        if args.action == "validate" and ticket in ("DBI-6455", "DBI-7161"):
            executable("terraform")
            run([sys.executable, str(BASE / "pruefen.py"), "--terraform", "--ticket", ticket]); return 0
        if ticket == "DBI-12139":
            return assets(args.action, args)
        if ticket == "DBI-6455" and args.action == "check":
            return monitoring(args)
        if ticket == "DBI-11149":
            return sftp(args.action, args)
        if ticket == "PB2B-27849":
            return saml(args.action, args)
        if ticket == "DBI-7161" and args.action == "check":
            print("Modul vorbereitet, nicht in Live-Stack aktiviert.\nOffen: Event-Schema, UMP-URL, Identitäten, Netzwerkfreigabe und App-Verantwortliche.\nNachrichten: DBI-7161/README.md\nCode isoliert übernehmen: bash start.sh 7161 code\nNative Modulprüfung: bash start.sh 7161 validate")
            return 0
        raise Stop("Unbekannte Aktion. Siehe Ticket-README oder --help.")
    except (Stop, OSError, ValueError, KeyError, subprocess.SubprocessError) as exc:
        print("\nSTOPP: " + str(exc), file=sys.stderr)
        return 2
    except KeyboardInterrupt:
        print("\nAbgebrochen. Bereits erfolgte lokale Änderungen/Testuploads sind nicht automatisch zurückgenommen.", file=sys.stderr)
        return 130
    except RuntimeError as exc:
        # Ticket subtools use their own explicit RuntimeError-derived TaskError.
        print("\nPRÜFUNG GESTOPPT: " + str(exc), file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
