# DBI-6455: Fehlermails aus dem Monitoring

**Status: Code vorbereitet. Keine Ausführung oder Mail-Abnahme in deinem neuen Upload belegt.**
**Prio 2. Standalone.** Während der Rückmeldungen zu SFTP/Assets kannst du hier weiterarbeiten.

## Wofür ist das Ticket?

Die Anwendungen sollen bei `error` oder `fatal` eine Benachrichtigung an `ui-team@os-cillation.de` auslösen. Laut Jira-Kommentar vom 11.09. wurde die OpenTelemetry-Anbindung bereits von OSC getestet; offen ist vor allem der E-Mail-Versand.

Dein 12139-Skript hat weder Monitoring eingerichtet noch eine Testmail versendet.

## Schritt 1: Vorhandene Logs und Alarmregeln lesen

**Warum:** Wir müssen wissen, ob aktuelle Fehlermeldungen ankommen und ob jemand die gewünschte Regel inzwischen schon eingerichtet hat. Sonst entstehen doppelte Alarme.

```bash
bash start.sh 6455
```

Liest standardmäßig TEST und schreibt `STATUS.md` sowie technische Details unter `ergebnisse/DBI-6455/`. Keine Regel wird erstellt, keine Mail verschickt.

**Erwartung:** aktuelle Logs mit `ServiceName`/`SeverityText`, nachvollziehbarer Regelbestand. Leere Logs oder ein Rechtefehler sind kein erfolgreicher Test. Der automatisierte Regelscan findet direkte Workspace-/Application-Insights-Zuordnungen, nicht garantiert jede mögliche Cross-Workspace-Regel.

Portal-Alternative: `bash start.sh portal`, TEST-Workspace öffnen und dort Logs/Alert-Regeln ansehen.

## Schritt 2: Nur die wirklich fehlende Alarmierung ergänzen

**Warum:** Es gibt bereits die Monitoring-Infrastruktur. Wir ergänzen die fehlende Funktion statt alles neu aufzusetzen.

Nur wenn noch keine passende Regel existiert:

```bash
bash start.sh 6455 code
```

Erstellt nach Prüfung einen getrennten `live`-Worktree mit sechs vollständigen Dateien: Alert-Modul, Terragrunt-Unit, drei Stackdateien und CI-Anpassung. Dein ursprünglicher Checkout bleibt unverändert. Bei neueren abweichenden Repository-Dateien wird gestoppt.

TEST ist im vorbereiteten Code zur Aktivierung vorgesehen, DEV/PROD bleiben zunächst deaktiviert. Ein deaktivierter Alarm ist noch keine funktionierende Benachrichtigung.

## Schritt 3: Änderungen prüfen und regulär bereitstellen

**Warum:** Ein erzeugter Codeordner ändert noch nichts in Azure. Außerdem muss der echte Plan zeigen, dass keine unerwarteten bestehenden Ressourcen verändert werden.

Wenn Terraform in WSL vorhanden ist:

```bash
bash start.sh 6455 validate
```

Das lädt Provider in ein temporäres Verzeichnis und validiert nur das Modul, ohne Backend und ohne Apply. Die Repository-Versionen sind maßgeblich, im Upload Terraform 1.13.4 und Terragrunt 1.1.6.

Danach den Worktree in VS Code öffnen, `git status` und Änderungen prüfen, regulär committen/pushen und euren Review-/Plan-/Freigabeprozess nutzen. Nicht den ganzen Stack unbesehen anwenden. Ein echter Plan benötigt euren GitLab-State- und Katalogzugriff; `az login` allein reicht dafür nicht.

**Ein validiertes Modul ist noch kein bestandener vollständiger Terragrunt-Plan.** Bereits bestehende manuell angelegte Regeln zuerst abgleichen, nicht mit einer zweiten Regel überbauen.

## Schritt 4: Echte E-Mail testen

**Warum:** Erst die empfangene Alarmmail beweist den gewünschten Ablauf.

**An Alex Köster:**

> Hi Alex, ich bearbeite bei DBI-6455 die noch offene Mail-Alarmierung. Ich prüfe zuerst die vorhandenen TEST-Logs und Alarmregeln. Nach der freigegebenen Bereitstellung würde ich mit dir gern einen kontrollierten Fehler auslösen und den Eingang bei `ui-team@os-cillation.de` bestätigen. Welchen sicheren Testfall können wir dafür nehmen? Danke dir!

Erwartung: kontrollierter Fehler erscheint im Log, richtige Regel löst aus, Mail erreicht den Verteiler. Die vorbereitete Regel gruppiert nach `ServiceName`, wertet jede Minute ein Fünf-Minuten-Fenster aus und ist zustandsbehaftet. Es ist nicht „eine neue Mail je Logzeile“. Der Wunsch nach `ServiceName` im individuellen Betreff muss anhand der tatsächlichen Mail mit OSC abgenommen werden, er ist nicht pauschal zugesichert.

## Schritt 5: Vereinbarte weitere Umgebungen aktivieren

**Warum:** Ein TEST-Erfolg ist noch kein PROD-Erfolg. Im Jira-Verlauf wird auch die produktive Nutzung genannt.

Nach erfolgreichem TEST und Freigabe den jeweiligen `exception-alerts`-Block aktivieren und kontrolliert bereitstellen. Nicht OTEL oder die vorhandene Monitoring-Unit ersetzen. Den Betriebsumfang mit OSC bestätigen; zunächst deaktivierte PROD-Regeln nicht als fertig zählen.

## Jira-Kommentar: aktueller, noch offener Stand

```text
Zwischenstand DBI-6455:

Der Repository-Code für die ergänzende Mail-Alarmierung ist vorbereitet. Grundlage ist der Jira-Stand, nach dem OSC die OpenTelemetry-Anbindung bereits getestet hat und der Mail-Versand für error/fatal noch fehlt.

Eine aktuelle Prüfung der eingehenden Logs, der vorhandenen Alert-Regeln und eine End-to-End-Mail-Abnahme sind durch die bisher vorliegenden Ausführungsbelege nicht nachgewiesen. Der DBI-12139-Lauf betrifft ausschließlich die Landingpage-Assets.

Nächste Schritte: TEST-Logs/Regeln prüfen, erforderliche Änderungen validieren und freigegeben bereitstellen, kontrollierten Fehler mit OSC testen und Mail-Eingang bestätigen. Anschließend die vereinbarten weiteren Umgebungen freigeben.

Ticket bleibt offen.
```

## Fertig, wenn

Die gewünschten Umgebungen alarmieren nach dem vereinbarten Verhalten, OSC den Mail-Eingang bestätigt hat und Test/Plan/Freigabe dokumentiert sind. Nicht schon nach `validate` oder einem Terraform-Apply schließen.

Quelle: Jira DBI-6455, besonders Kommentare vom 27.08., 11.09. und 28.09.2026. Vollständiger Code liegt unter `code/live/`.
