# DBI-7161: ProductHub -> Event Grid -> UMP

**Status: Infrastrukturentwurf vorbereitet, noch keine freigegebene oder getestete Gesamtintegration.**
**Prio 4.** Die anderen Tickets müssen technisch nicht erst fertig sein, aber die Schnittstellenangaben sind echte Voraussetzungen.

## Wofür ist das Ticket?

Der ProductHub soll Ereignisse an Azure schicken. Azure soll sie zuverlässig an die UMP zustellen. Dauerhaft nicht zustellbare Ereignisse sollen in einer gesonderten Fehlerablage landen.

Der LP-Asset-Storage aus DBI-12139 ist **nicht** diese Fehlerablage. Ein bestandener Blob-Asset-Test erledigt Event Grid nicht mit.

## Schritt 1: Die wenigen wirklich fehlenden Angaben beschaffen

**Warum:** Ein Topic ohne erreichbaren Empfänger und passende Berechtigungen erfüllt die Akzeptanzkriterien nicht.

**An Sinan Balcin:**

> Hi Sinan, ich bereite DBI-7161 vor. Der Azure-Infrastrukturentwurf ist vorhanden, aber noch nicht eingebunden. Für die korrekte Umsetzung brauche ich bitte das aktuelle Konzept mit einer Beispielnachricht, der UMP-Empfänger-URL und der ersten Zielumgebung. Kannst du auch die vorgesehenen Identitäten, die freizugebenden Publisher-Netze und die Verantwortlichen für ProductHub-Sender und UMP-Empfänger bestätigen? Die im Ticket genannten B2C-Scopes möchte ich vor der Bereitstellung mit der tatsächlichen Authentifizierung abgleichen. Danke dir!

Die im Ticket genannten Konzeptanhänge und der verlinkte `eventhub`-Quellcode sind im vorliegenden Upload nicht enthalten. Nicht auf einen abwesenden Kollegen warten, wenn Sinan/OSC die aktuellen Angaben liefern können.

**Nur für noch unbekannte Anwendungsteile an Alex Köster:**

> Hi Alex, gibt es für DBI-7161 bereits einen ProductHub-Sender und einen UMP-Webhook in einem anderen Branch? Falls noch nicht, wer übernimmt diese beiden Anwendungsteile? Für die Abnahme brauche ich außerdem das Event-Schema und das erwartete Verhalten bei wiederholter Zustellung. Danke dir!

## Schritt 2: Den vorbereiteten Code prüfen

**Warum:** Damit lässt sich die Infrastruktur zügig fertigstellen, sobald der Vertrag geklärt ist. Sie ist noch kein freigegebener fertiger Dienst.

Optional vorbereiten:

```bash
bash start.sh 7161 code
```

Übernimmt die beiden vollständigen `catalog`-Dateien in einen getrennten Worktree. Noch keine Live-Stack-Einbindung und keine Azure-Änderung.

Bei passender lokaler Terraform-Version:

```bash
bash start.sh 7161 validate
```

Nur isolierte native Modulprüfung, ohne State/Plan/Apply. Wenn Terraform lokal fehlt, eure vorhandene CI verwenden.

## Schritt 3: Erst mit bestätigten Angaben integrieren

**Warum:** Der aktuelle Entwurf enthält Annahmen zu Identitäten, Webhook-Schutz, Netz und Fehlerablage. Diese dürfen nicht stillschweigend die Ticketvorgaben ersetzen.

Topic, Senderberechtigung, Event Subscription, UMP-Zustellung und Dead-Letter-Speicher gemeinsam anschließen. Der Guard `approved_for_deployment = false` ist Absicht. Nicht ohne fachlich/technisch bestätigte Eingaben einfach auf `true` stellen.

Die B2C-Scopes aus dem Ticket sind noch keine nachgewiesene funktionierende native Event-Grid-Authentifizierung. Die beiden Strecken getrennt klären: ProductHub zu Event Grid und Event Grid zu UMP. Der im Kommentar verlinkte Event-Hubs-Code ist nicht automatisch die richtige Event-Grid-Vorlage.

## Schritt 4: Den ganzen Weg testen

**Warum:** Die Akzeptanzkriterien verlangen tatsächliche Zustellung und funktionierende Fehlerablage, nicht nur sichtbare Azure-Ressourcen.

Erwartet werden:
- echtes Ereignis wird vom ProductHub gesendet und von UMP fachlich richtig verarbeitet,
- unberechtigter Zugriff wird abgewiesen,
- dauerhaft fehlerhafte Zustellung landet nach dem vorgesehenen Retry-/TTL-Verhalten in der Fehlerablage,
- wiederholte Zustellung erzeugt keine doppelte fachliche Wirkung.

Ein HTTP-200-Platzhalter ohne fachliche Verarbeitung reicht nicht.

## Jira-Kommentar: aktueller Vorbereitungsstand

```text
Zwischenstand DBI-7161:

Ein Infrastrukturentwurf für Event Grid, Senderberechtigung, Webhook-Zustellung und Dead-Letter-Ablage ist vorbereitet, aber noch nicht in einen Live-Stack eingebunden oder bereitgestellt.

Vor der Integration fehlen der bestätigte Schnittstellenvertrag, Zielumgebung, Empfänger-URL, Identitäten/Auth-Konzept, Netzfreigaben und die Zuständigkeiten für Publisher und UMP-Empfänger. Insbesondere müssen die im Ticket genannten B2C-Scopes mit der vorgesehenen tatsächlichen Event-Grid-Authentifizierung abgeglichen werden.

Die Prüfung von DBI-12139 betrifft einen anderen Storage-Zweck und ist kein Test dieser Integration. Nach Klärung folgen native Validierung, Plan/Freigabe und gemeinsame End-to-End-/Fehlerfalltests.

Ticket bleibt offen.
```

## Fertig, wenn

Alle Akzeptanzkriterien mit dem echten ProductHub-/UMP-Ablauf belegt sind, einschließlich Fehlerablage. Ein vorbereitetes Modul oder erfolgreiches `validate` reicht nicht.

Quelle: Jira DBI-7161 vom 30.09.2026. Vollständiger Entwurf unter `code/catalog/`. Im neuen Laufupload gibt es keine Event-Grid-Ausführung.
