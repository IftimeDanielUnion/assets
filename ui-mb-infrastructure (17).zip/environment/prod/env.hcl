locals {
  backend_container_name       = "terraform-state"
  backend_storage_account_name = "sawde3af87e25f0be60c"
  backend_resource_group_name  = "rg-marktbearbeitung-prod-managed-resources"

  workload        = "MARKTBEARBEITUNG"
  environment     = "prod"
  subscription_id = "a6c520e0-a1af-4c4c-82f0-8482ff82ecd8"

  tags = {
    environment = local.environment
  }
}

inputs = {
  location                     = "swedencentral"
  vnet_name                    = "vnet-marktbearbeitung-prod-swc-01"
  vnet_resource_group_name     = "rg-marktbearbeitung-prod-networking"
  vnet_subnet_name             = "default"
  vnet_subnet_name_appgw       = "appgw"
  vnet_subnet_name_functionapp = "functionapp"

  # Defender is active for the whole subscription
  integrate_defender_for_storage = {
    endpoint_resource_id = "/subscriptions/${local.subscription_id}/providers/Microsoft.Security/datascanners/storageDataScanner"
    endpoint_tenant_id   = "2eb07b91-f9f8-437b-a89e-59f55e565c11"
  }
}
