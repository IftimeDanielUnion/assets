include "root" {
  path           = find_in_parent_folders("root.hcl")
  merge_strategy = "deep"
}

include "app" {
  path           = "${get_terragrunt_dir()}/../../../../_apps/beratungsunterstuetzung/frontend.hcl"
  merge_strategy = "deep"
}

inputs = {
  # TODO > Need to clarify concrete url for beratungsunterstützung
  #static_web_app_custom_domain         = "beratungsunterstuetzung.test.union-investment.de"
}
