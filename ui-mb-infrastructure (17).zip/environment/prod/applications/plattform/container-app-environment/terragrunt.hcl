include "root" {
  path           = find_in_parent_folders("root.hcl")
  merge_strategy = "deep"
}

include "app" {
  path           = "${get_terragrunt_dir()}/../../../../_apps/plattform/container-app-environment.hcl"
  merge_strategy = "deep"
}

inputs = {
  container_subnet_id = "/subscriptions/a6c520e0-a1af-4c4c-82f0-8482ff82ecd8/resourceGroups/rg-marktbearbeitung-prod-networking/providers/Microsoft.Network/virtualNetworks/vnet-marktbearbeitung-prod-swc-01/subnets/containerapp"
}
