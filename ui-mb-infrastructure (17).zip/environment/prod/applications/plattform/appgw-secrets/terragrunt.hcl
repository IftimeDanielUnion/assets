include "root" {
  path           = find_in_parent_folders("root.hcl")
  merge_strategy = "deep"
}

include "app" {
  path           = "${get_terragrunt_dir()}/../../../../_apps/plattform/appgw-secrets.hcl"
  merge_strategy = "deep"
  expose         = true
}

inputs = {}
