# Omit merge_strategy, there is nothing to merge here.
include "root" {
  path = find_in_parent_folders("root.hcl")
}

include "app" {
  path = "${get_terragrunt_dir()}/../../../../_apps/mashub/rbac-on-bb-keyvaults.hcl"
}

# Do _not_ use this to assign roles to resources created by terraform. Those roles shall be assigned within the resource itself.
# Only use this for 'external' resources like Buildng Blocks
inputs = {
  role_assignments = {
    uai_secrets_user_aadb2c = {
      scope                = "/subscriptions/a6c520e0-a1af-4c4c-82f0-8482ff82ecd8/resourceGroups/RG-M-KEYVAULT-mbp4aadb2c/providers/Microsoft.KeyVault/vaults/kv-mbp4aadb2c-hxbatmmb"
      role_definition_name = "Key Vault Secrets User"
      principal_id         = dependency.identity.outputs.principal_id
      description          = "User Assigned Identity has permission to access the KeyVault"
    }
  }
}
