include "root" {
  path = find_in_parent_folders("root.hcl")
}

include "app" {
  path = "${get_terragrunt_dir()}/../../../../_apps/mashub/rbac-datenprodukt-identity.hcl"
}

# Role assignments for external resources (Building Blocks) in PROD environment
inputs = {
  role_assignments = {
    # aadb2c KeyVault access - PROD environment
    datenprodukt_identity_aadb2c_secrets_user = {
      scope                = "/subscriptions/a6c520e0-a1af-4c4c-82f0-8482ff82ecd8/resourceGroups/RG-M-KEYVAULT-mbp4aadb2c/providers/Microsoft.KeyVault/vaults/kv-mbp4aadb2c-hxbatmmb"
      role_definition_name = "Key Vault Secrets User"
      principal_id         = dependency.datenprodukt_identity.outputs.principal_id
      description          = "Datenprodukt Identity has permission to access the aadb2c KeyVault"
    }
  }
}
