include "root" {
  path           = find_in_parent_folders("root.hcl")
  merge_strategy = "deep"
}

include "app" {
  path           = "${get_terragrunt_dir()}/../../../../_apps/mashub/monitoring.hcl"
  merge_strategy = "deep"
}

inputs = {
  integrate_application_insights = true
  secret_alerts = {
    concentrix = {
      action_group_map_key = "incidents"
      key_vault = {
        id = "/subscriptions/a6c520e0-a1af-4c4c-82f0-8482ff82ecd8/resourceGroups/RG-M-KEYVAULT-mbp4aadb2c/providers/Microsoft.KeyVault/vaults/kv-mbp4aadb2c-hxbatmmb"
      }
      secret = {
        name = "Concentrix"
        key  = "aadb2c-sp-mbportalConcentrixclt-secret"
      }
      sop = {
        url = "https://confluence.apps.union-investment.de/spaces/CISTAB/pages/225545166"
      }
    }
    finco = {
      action_group_map_key = "incidents"
      key_vault = {
        id = "/subscriptions/a6c520e0-a1af-4c4c-82f0-8482ff82ecd8/resourceGroups/RG-M-KEYVAULT-mbp4aadb2c/providers/Microsoft.KeyVault/vaults/kv-mbp4aadb2c-hxbatmmb"
      }
      secret = {
        name = "Finco"
        key  = "aadb2c-sp-mbportalFINCOclt-secret"
      }
      sop = {
        url = "https://confluence.apps.union-investment.de/spaces/CISTAB/pages/225549345"
      }
    }
  }
}
