include "root" {
  path           = find_in_parent_folders("root.hcl")
  merge_strategy = "deep"
}

dependency "monitoring" {
  config_path = "${get_terragrunt_dir()}/../monitoring"
}

include "app" {
  path           = "${get_terragrunt_dir()}/../../../../_apps/im-action-hub/functionapp.hcl"
  merge_strategy = "deep"
}

inputs = {
  # PROD: Premium SKU für Production, 1 Instanzen für HA
  instance_count = 1
  sku_name       = "P1v3"

  # PROD Azure AD Authentication Settings
  # Service Principal: IM-Action-Hub (PROD) aus marktbearbeitung.yml
  # KeyVault für Credentials: kv-17cdd303c9bb2e255af9
  auth_settings = {
    client_id              = "74c0d589-a374-42ab-b42f-caaec92392f4"
    tenant_auth_endpoint   = "https://login.microsoftonline.com/2eb07b91-f9f8-437b-a89e-59f55e565c11/v2.0"
    allowed_audiences      = ["74c0d589-a374-42ab-b42f-caaec92392f4"]
    allowed_applications   = ["292abf06-6e8b-402d-9e51-7ffd85218ba4", "04b07795-8ddb-461a-bbee-02f9e1bf7b46"] #impulsmanager-prod and azure-cli-client
    require_authentication = true
    unauthenticated_action = "Return401"
    excluded_paths         = ["/api/q/health"]
  }
}

# Nur IM Action Hub in dieser Umgebung: Versions-Tag nicht durch IaC entfernen.
# Freigabevoraussetzung: Zuständigkeit für den extern gepflegten Tag ist bestätigt.
# Bewusst kein globales ignore_changes im gemeinsam genutzten Function-App-Modul.
# Bei Moduländerungen die unten vollständig erhaltene ignore_changes-Liste abgleichen.
generate "im_action_hub_version_tag_lifecycle" {
  path      = "im_action_hub_version_tag_override.tf"
  if_exists = "overwrite_terragrunt"
  contents  = <<-EOF
    # Ergänzt die bestehende Lifecycle-Liste ausschließlich um tags["version"].
    # Terraform ersetzt die Liste, daher müssen die vorhandenen Einträge erhalten bleiben.
    resource "azurerm_linux_function_app" "main" {
      lifecycle {
        ignore_changes = [
          app_settings,
          sticky_settings,
          tags["hidden-link: /app-insights-resource-id"],
          tags["hidden-link: /app-insights-conn-string"],
          tags["hidden-link: /app-insights-instrumentation-key"],
          tags["version"]
        ]
      }
    }
  EOF
}
