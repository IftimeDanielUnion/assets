include "root" {
  path           = find_in_parent_folders("root.hcl")
  merge_strategy = "deep"
}

include "app" {
  path           = "${get_terragrunt_dir()}/../../../../_apps/marktbearbeitung/bff-api.hcl"
  merge_strategy = "deep"
}

inputs = {
  instance_count = 1
  sku_name       = "P1v3"

  auth_settings = {
    client_id = "a4626616-b636-401b-a2ae-c02a78edfb93"
    tenant_auth_endpoint = "https://auth.user.union-investment.de/b2cunioninvestmentprod.onmicrosoft.com/B2C_1A_SIGNIN/v2.0/.well-known/openid-configuration"

    allowed_audiences = [
      "a4626616-b636-401b-a2ae-c02a78edfb93", # BFF Prod
      "803c1bad-bc22-46a2-b592-40033524a762", # SPA MB Prod
      "184b0184-4c3f-431c-9ca9-d09d4ab26061", # SPA BU Prod
      "2c705131-66fa-44cb-aba2-0bed97c5fe29" # Portalrahmen Prod
    ]
    allowed_applications = [
      "a4626616-b636-401b-a2ae-c02a78edfb93", # BFF Prod
      "803c1bad-bc22-46a2-b592-40033524a762", # SPA MB Prod
      "184b0184-4c3f-431c-9ca9-d09d4ab26061", # SPA BU Prod
      "2c705131-66fa-44cb-aba2-0bed97c5fe29" # Portalrahmen Prod
    ]

    # UI-CHG-0091618: Azure App Service Health Check muss Easy Auth umgehen,
    # damit der Plattform-Ping den anonymen Quarkus-Health-Endpunkt erreicht.
    excluded_paths = ["/api/q/health"]
  }
}
