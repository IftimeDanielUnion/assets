include "root" {
  path           = find_in_parent_folders("root.hcl")
  merge_strategy = "deep"
}

include "app" {
  path           = "${get_terragrunt_dir()}/../../../../_apps/marktbearbeitung/dms-metadata.hcl"
  merge_strategy = "deep"
}

inputs = {
  account_replication_type = "ZRS"

  role_assignments = {
    bb_func_dms_contributor = {
      principal_id               = "0d82db5a-8059-463d-b36e-15e98da65db6"
      role_definition_id_or_name = "Storage Table Data Contributor"
      description                = "System Assigned Identity of fa-mb-prod-dms-api-dstcikff has permissions to access the Table Storage"
    }
    bb_func_dms_tf_contributor = {
      principal_id               = "51efb70a-fde7-4d97-95cb-bad28e7c3856"
      role_definition_id_or_name = "Storage Table Data Contributor"
      description                = "System Assigned Identity of func-mb-prod-dms-api-svwjt4qh has permissions to access the Table Storage"
    }
  }
}
