include "root" {
  path           = find_in_parent_folders("root.hcl")
  merge_strategy = "deep"
}

include "app" {
  path           = "${get_terragrunt_dir()}/../../../../_apps/marktbearbeitung/keyvault.hcl"
  merge_strategy = "deep"
}

inputs = {
  role_assignments = {
    bb_func_bff_secrets_user = {
      principal_id         = "1738c22f-ae2e-452d-912d-13e92113516e"
      role_definition_name = "Key Vault Secrets User"
      description          = "System Assigned Identity of fa-mb-prod-bff-api-rlxtxaye has permission to access the Key Vault"
    }
    bb_func_bff_tf_secrets_user = {
      principal_id         = "963e693a-05b8-49f0-9213-3db07125001f"
      role_definition_name = "Key Vault Secrets User"
      description          = "System Assigned Identity of func-mb-prod-bff-api-gkweznzx has permission to access the Key Vault"
    }
    bb_func_dms_secrets_user = {
      principal_id         = "0d82db5a-8059-463d-b36e-15e98da65db6"
      role_definition_name = "Key Vault Secrets User"
      description          = "System Assigned Identity of fa-mb-prod-dms-api-dstcikff has permission to access the Key Vault"
    }
    bb_func_dms_tf_secrets_user = {
      principal_id         = "51efb70a-fde7-4d97-95cb-bad28e7c3856"
      role_definition_name = "Key Vault Secrets User"
      description          = "System Assigned Identity of func-mb-prod-dms-api-svwjt4qh has permission to access the Key Vault"
    }
  }
}
