include "root" {
  path           = find_in_parent_folders("root.hcl")
  merge_strategy = "deep"
}

include "app" {
  path           = "${get_terragrunt_dir()}/../../../../_apps/verbundintegration/backup-vault.hcl"
  merge_strategy = "deep"
}

inputs = {
  # PROD-specific overrides if needed
}
