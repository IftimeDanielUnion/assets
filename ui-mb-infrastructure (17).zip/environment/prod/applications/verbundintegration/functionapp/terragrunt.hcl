include "root" {
  path           = find_in_parent_folders("root.hcl")
  merge_strategy = "deep"
}

dependency "monitoring" {
  config_path = "${get_terragrunt_dir()}/../monitoring"
}

include "app" {
  path           = "${get_terragrunt_dir()}/../../../../_apps/verbundintegration/functionapp.hcl"
  merge_strategy = "deep"
}

inputs = {
  instance_count = 1
  sku_name       = "P1v3"

  # UI-CHG-0091618: Plattform-Health-Check analog zu DEV und TEST aktivieren.
  # /api/health/live ist der reine Liveness-Endpunkt und enthaelt keine
  # Abhaengigkeitspruefung, die eine gesunde Instanz unnoetig aus dem Pool nimmt.
  health_check = {
    eviction_time_in_min = 5
    path                 = "/api/health/live"
    monitoring_alert = {
      actions = concat(
        [{
          action_group_id = dependency.monitoring.outputs.action_groups["incidents"].resource_id
        }],
        contains(keys(dependency.monitoring.outputs.action_groups), "tab") ? [{
          action_group_id = dependency.monitoring.outputs.action_groups["tab"].resource_id
        }] : []
      )
      resource_group_name = dependency.monitoring.outputs.resource_group
    }
  }

  # PROD-specific Azure AD Authentication Settings
  # App Registration: VBST
  auth_settings = {
    client_id                        = "51b01ed4-e51a-43ee-92d0-673291a3690e"
    tenant_auth_endpoint             = "https://login.microsoftonline.com/2eb07b91-f9f8-437b-a89e-59f55e565c11/v2.0/.well-known/openid-configuration"
    allowed_audiences                = ["51b01ed4-e51a-43ee-92d0-673291a3690e"]
    allowed_applications             = [
        "51b01ed4-e51a-43ee-92d0-673291a3690e",
        "ca8bc05f-d735-4e3b-b0c0-679ef87d97b4" # VBST Dashboard (PROD)
    ]

    # UI-CHG-0091618: Health-Endpunkte von Easy Auth ausnehmen, damit der
    # App-Service-Health-Check die Function ohne Token erreicht.
    excluded_paths = ["/api/health/live", "/api/health/ready", "/api/health/healthz"]
  }
}
