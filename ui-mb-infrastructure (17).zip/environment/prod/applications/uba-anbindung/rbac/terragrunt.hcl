include "root" {
  path           = find_in_parent_folders("root.hcl")
  merge_strategy = "deep"
}

include "app" {
  path           = "${get_terragrunt_dir()}/../../../../_apps/uba-anbindung/rbac.hcl"
  merge_strategy = "deep"
}

inputs = {
  role_assignments = {
    container_app_acr_access = {
      scope = "/subscriptions/a6c520e0-a1af-4c4c-82f0-8482ff82ecd8/resourceGroups/RG-M-ACR-cr-mb-prod/providers/Microsoft.ContainerRegistry/registries/crcrmbprodesgshpnp"
    }
  }
}
