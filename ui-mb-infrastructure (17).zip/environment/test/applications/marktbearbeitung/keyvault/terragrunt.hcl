include "root" {
  path           = find_in_parent_folders("root.hcl")
  merge_strategy = "deep"
}

include "app" {
  path           = "${get_terragrunt_dir()}/../../../../_apps/marktbearbeitung/keyvault.hcl"
  merge_strategy = "deep"
}

inputs = {
  role_assignments = {
    bb_func_bff_secrets_user = {
      principal_id         = "f6b7ab45-5d95-475e-a9d5-e99386c9db42"
      role_definition_name = "Key Vault Secrets User"
      description          = "System Assigned Identity of fa-mb-test-bff-api-njrsgdjx has permission to access the Key Vault"
    }
    bb_func_bff_tf_secrets_user = {
      principal_id         = "d2c315c3-2fe0-4873-a7c4-319b47e240e5"
      role_definition_name = "Key Vault Secrets User"
      description          = "System Assigned Identity of func-mb-test-bff-api-nb33y6hm has permission to access the Key Vault"
    }
    bb_func_dms_secrets_user = {
      principal_id         = "aa87c091-9f0e-49d9-b23f-8dd572670c4f"
      role_definition_name = "Key Vault Secrets User"
      description          = "System Assigned Identity of fa-mb-test-dms-api-hxcenhpt has permission to access the Key Vault"
    }
    bb_func_dms_tf_secrets_user = {
      principal_id         = "4f475aa1-ffa5-448f-8405-71a87253dd09"
      role_definition_name = "Key Vault Secrets User"
      description          = "System Assigned Identity of func-mb-test-dms-api-mr2adrc4 has permission to access the Key Vault"
    }
  }
}
