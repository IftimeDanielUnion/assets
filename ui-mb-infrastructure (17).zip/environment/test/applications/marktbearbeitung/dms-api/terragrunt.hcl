include "root" {
  path           = find_in_parent_folders("root.hcl")
  merge_strategy = "deep"
}

include "app" {
  path           = "${get_terragrunt_dir()}/../../../../_apps/marktbearbeitung/dms-api.hcl"
  merge_strategy = "deep"
}

inputs = {
  instance_count = 1
  sku_name       = "B2"

  auth_settings = {
    client_id = "98d9d8de-6113-4570-bd4e-04ce29fd5a97"
    tenant_auth_endpoint = "https://auth-test.user.union-investment.de/b2cunioninvestmenttest.onmicrosoft.com/B2C_1A_SIGNIN/v2.0/.well-known/openid-configuration"

    allowed_audiences = [
      "98d9d8de-6113-4570-bd4e-04ce29fd5a97", # DMS Test
      "4afaa250-2196-4dc5-955c-040e722fde31", # BFF Test
      "6d76e1c7-74cc-4e63-9600-c31895449862", # SPA MB Test
      "608cf051-66dc-4f30-968f-ffbbfdb8bd21", # SPA BU Test
      "24457482-9108-409b-ae4d-fd41dd4e9134", # Portalrahmen Test
      "1c929317-e3be-4fb2-8585-27c0b346d199" # ProductHub Test
    ]
    allowed_applications = [
      "98d9d8de-6113-4570-bd4e-04ce29fd5a97", # DMS Test
      "4afaa250-2196-4dc5-955c-040e722fde31", # BFF Test
      "6d76e1c7-74cc-4e63-9600-c31895449862", # SPA MB Test
      "608cf051-66dc-4f30-968f-ffbbfdb8bd21", # SPA BU Test
      "24457482-9108-409b-ae4d-fd41dd4e9134", # Portalrahmen Test
      "1c929317-e3be-4fb2-8585-27c0b346d199" # ProductHub Test
    ]

    # UI-CHG-0091618: Azure App Service Health Check muss Easy Auth umgehen,
    # damit der Plattform-Ping den anonymen Quarkus-Health-Endpunkt erreicht.
    excluded_paths = ["/api/q/health"]
  }
}
