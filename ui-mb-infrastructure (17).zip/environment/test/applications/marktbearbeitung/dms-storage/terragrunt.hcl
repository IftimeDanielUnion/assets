include "root" {
  path           = find_in_parent_folders("root.hcl")
  merge_strategy = "deep"
}

include "app" {
  path           = "${get_terragrunt_dir()}/../../../../_apps/marktbearbeitung/dms-storage.hcl"
  merge_strategy = "deep"
}

inputs = {
  account_replication_type = "ZRS"

  role_assignments = {
    bb_func_dms_owner = {
      principal_id               = "aa87c091-9f0e-49d9-b23f-8dd572670c4f"
      role_definition_id_or_name = "Storage Blob Data Owner"
      description                = "System Assigned Identity of fa-mb-test-dms-api-hxcenhpt has owner permissions at the Blob Storage"
    }
    bb_func_dms_tf_owner = {
      principal_id               = "4f475aa1-ffa5-448f-8405-71a87253dd09"
      role_definition_id_or_name = "Storage Blob Data Owner"
      description                = "System Assigned Identity of func-mb-test-dms-api-mr2adrc4 has owner permissions at the Blob Storage"
    }
  }
}
