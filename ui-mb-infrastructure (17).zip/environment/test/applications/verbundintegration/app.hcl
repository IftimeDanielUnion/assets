locals {
  tags = {
    application = "Verbundintegration"
  }
}
inputs = {
  app_name = "vbi"
}
