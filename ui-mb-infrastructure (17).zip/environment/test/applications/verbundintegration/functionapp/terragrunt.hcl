include "root" {
  path           = find_in_parent_folders("root.hcl")
  merge_strategy = "deep"
}

dependency "monitoring" {
  config_path = "${get_terragrunt_dir()}/../monitoring"
}

include "app" {
  path           = "${get_terragrunt_dir()}/../../../../_apps/verbundintegration/functionapp.hcl"
  merge_strategy = "deep"
}

inputs = {
  instance_count = 1
  sku_name       = "P1v3"

  # UI-CHG-0091618 Hotfix: Plattform-Health-Check fuer VBST TEST aktivieren.
  # Der App Service pingt /api/health/live und stellt die HealthCheckStatus-Metrik bereit.
  health_check = {
    eviction_time_in_min = 5
    path                 = "/api/health/live"

    monitoring_alert = {
      actions = concat(
        [{
          action_group_id = dependency.monitoring.outputs.action_groups["incidents"].resource_id
        }],
        contains(keys(dependency.monitoring.outputs.action_groups), "tab") ? [{
          action_group_id = dependency.monitoring.outputs.action_groups["tab"].resource_id
        }] : []
      )

      resource_group_name = dependency.monitoring.outputs.resource_group
    }
  }

  # TEST-specific Azure AD Authentication Settings
  # App Registration: VBST (ABN)
  auth_settings = {
    client_id            = "b6241ac1-8094-4610-98c7-3eb1038698c9"
    tenant_auth_endpoint = "https://login.microsoftonline.com/2eb07b91-f9f8-437b-a89e-59f55e565c11/v2.0/.well-known/openid-configuration"
    allowed_audiences    = ["b6241ac1-8094-4610-98c7-3eb1038698c9"]

    allowed_applications = [
      "b6241ac1-8094-4610-98c7-3eb1038698c9",
      "7f99f9eb-33a9-466c-8858-fe0e60174b4a" # VBST Dashboard (TEST)
    ]

    # UI-CHG-0091618 Hotfix: Health-Endpunkte von Easy Auth ausnehmen.
    # Sonst beantwortet App Service Authentication die anonymen Plattform-Pings mit HTTP 401.
    excluded_paths = [
      "/api/health/live",
      "/api/health/ready",
      "/api/health/healthz"
    ]
  }
}
