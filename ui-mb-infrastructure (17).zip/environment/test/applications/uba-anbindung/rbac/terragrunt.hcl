include "root" {
  path           = find_in_parent_folders("root.hcl")
  merge_strategy = "deep"
}

include "app" {
  path           = "${get_terragrunt_dir()}/../../../../_apps/uba-anbindung/rbac.hcl"
  merge_strategy = "deep"
}

inputs = {
  role_assignments = {
    container_app_acr_access = {
      scope = "/subscriptions/d98221c3-b24d-4770-a9a3-3716667d7353/resourceGroups/RG-M-ACR-cr-mb-test/providers/Microsoft.ContainerRegistry/registries/crcrmbtestsykuuemm"
    }
  }
}
