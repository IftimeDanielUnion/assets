locals {
  tags = {
    application = "MB-Portal"
  }
}
inputs = {
  app_name = "mashub"
}
