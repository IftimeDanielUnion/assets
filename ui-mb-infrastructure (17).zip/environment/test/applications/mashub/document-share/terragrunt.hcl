include "root" {
  path           = find_in_parent_folders("root.hcl")
  merge_strategy = "deep"
}

include "app" {
  path           = "${get_terragrunt_dir()}/../../../../_apps/mashub/document-share.hcl"
  merge_strategy = "deep"
}

# NOTE: account_replication_type (LRS -> ZRS) darf NICHT via Terraform geändert werden,
# da dies ein ForceNew auf dem Storage Account auslöst (Account wird gelöscht und neu erstellt = Datenverlust).
# ZRS-Migration muss über Azure Live Migration erfolgen:
#   az storage account update --name <name> --resource-group <rg> --sku Standard_ZRS
inputs = {
  vnet_subnet_name = "privateendpoints"
}
