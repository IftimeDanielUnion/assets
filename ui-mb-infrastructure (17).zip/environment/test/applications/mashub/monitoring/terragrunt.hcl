include "root" {
  path           = find_in_parent_folders("root.hcl")
  merge_strategy = "deep"
}

include "app" {
  path           = "${get_terragrunt_dir()}/../../../../_apps/mashub/monitoring.hcl"
  merge_strategy = "deep"
}

inputs = {
  integrate_application_insights = true
  scheduled_log_alerts = {
    concentrix_no_feedback_24h = {
      enabled = false
    }
  }
  secret_alerts = {
    concentrix = {
      action_group_map_key = "incidents"
      key_vault = {
        id = "/subscriptions/d98221c3-b24d-4770-a9a3-3716667d7353/resourceGroups/RG-M-KEYVAULT-mbp4aadb2c/providers/Microsoft.KeyVault/vaults/kv-mbp4aadb2c-fckygjhr"
      }
      secret = {
        name = "Concentrix"
        key = "aadb2c-sp-mbportalConcentrixclt-secret"
      }
      sop = {
        url = "https://confluence.apps.union-investment.de/spaces/CISTAB/pages/225545166"
      }
    }
    finco = {
      action_group_map_key = "incidents"
      key_vault = {
        id = "/subscriptions/d98221c3-b24d-4770-a9a3-3716667d7353/resourceGroups/RG-M-KEYVAULT-mbp4aadb2c/providers/Microsoft.KeyVault/vaults/kv-mbp4aadb2c-fckygjhr"
      }
      secret = {
        name = "Finco"
        key = "aadb2c-sp-mbportalFINCOclt-secret"
      }
      sop = {
        url = "https://confluence.apps.union-investment.de/spaces/CISTAB/pages/225549345"
      }
    }
  }
}
