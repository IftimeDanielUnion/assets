# Omit merge_strategy, there is nothing to merge here.
include "root" {
  path = find_in_parent_folders("root.hcl")
}

include "app" {
  path = "${get_terragrunt_dir()}/../../../../_apps/mashub/rbac-on-bb-keyvaults.hcl"
}

# Do _not_ use this to assign roles to resources created by terraform. Those roles shall be assigned within the resource itself.
# Only use this for 'external' resources like Buildng Blocks
inputs = {
  role_assignments = {
    uai_secrets_user_aadb2c = {
      scope                = "/subscriptions/d98221c3-b24d-4770-a9a3-3716667d7353/resourceGroups/RG-M-KEYVAULT-mbp4aadb2c/providers/Microsoft.KeyVault/vaults/kv-mbp4aadb2c-fckygjhr"
      role_definition_name = "Key Vault Secrets User"
      principal_id         = dependency.identity.outputs.principal_id
      description          = "User Assigned Identity has permission to access the KeyVault"
    }
    uai_secrets_user_moveit = {
      scope                = "/subscriptions/d98221c3-b24d-4770-a9a3-3716667d7353/resourceGroups/RG-M-KEYVAULT-mbp4moveit/providers/Microsoft.KeyVault/vaults/kv-mbp4moveit-kbhgtofx"
      role_definition_name = "Key Vault Secrets User"
      principal_id         = dependency.identity.outputs.principal_id
      description          = "User Assigned Identity has permission to access the KeyVault"
    }
  }
}
