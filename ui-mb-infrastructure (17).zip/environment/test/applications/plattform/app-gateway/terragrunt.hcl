include "root" {
  path           = find_in_parent_folders("root.hcl")
  merge_strategy = "deep"
}

include "app" {
  path           = "${get_terragrunt_dir()}/../../../../_apps/plattform/app-gateway.hcl"
  expose         = true
  merge_strategy = "deep"
}

## TEST environment specific dependency
## This is intentionally NOT part of the global config, until resources are rolled out to all environments.
dependency "vbst_frontend" {
  config_path = "${get_terragrunt_dir()}/../../verbundintegration/frontend"
}
dependency "mbportal_dashboard_frontend" {
  config_path = "${get_terragrunt_dir()}/../../mashub/datenprodukt-frontend"
}

locals {
  # Define the App Gateway and the static settings.
  # As the App Gateway was created outside this terraform, these values have to be taken from the existing Gateway.
  # For flexibility and environment specific setups, only the static information is maintained in the 'app' global-settings.
  appgw_name             = "appgw-5ace9d9ccee0389b"
  appgw_resource_group   = "rg-marktbearbeitung-test-networking-appgateways"
  private_ip_value       = "172.28.9.202"
  gw_ip_config_name      = "${local.appgw_name}${include.app.locals.gw_ip_config_suffix}"
  public_ip_config_name  = "${local.appgw_name}${include.app.locals.public_ip_config_suffix}"
  private_ip_config_name = "${local.appgw_name}${include.app.locals.private_ip_config_suffix}"
  public_ip_address_name = "${local.appgw_name}${include.app.locals.public_ip_address_suffix}"

  https_port_name = "port_https"

  # App specific: "IW Marktbearbeitung"
  mb_config = {
    # Environment specifics
    listener_host_name = "iw-marktbearbeitung.test.union-investment.de"
    listener_ip_config = local.public_ip_config_name

    # Settings are independent of environment
    listener     = "mb-public-https-listener"
    routing_rule = "mb-path-based-routing-rule"

    backend_pool_frontend     = "mb-frontend-backend-pool"
    backend_settings_frontend = "mb-frontend-https-backend-setting"

    backend_pool_dms_storage     = "mb-dms-storage-backend-pool"
    backend_settings_dms_storage = "mb-dms-storage-https-backend-setting"
    health_probe_dms_storage     = "mb-dms-storage-health-probe"

    ssl_certificate = {
      # This info is used to create a ssl certificate with a name of ${ssl_certificate.name} and a key_vault_secret_id like "https://${dependency.certificates_vault.outputs.uri}/secrets/${ssl_certificate.secret_name}"
      name        = "mb-certificate"
      secret_name = "iw-marktbearbeitung-certificate"
    }

  }
  # App specific: "IW Beratungsunterstützung"
  bu_config = {
    listener_host_name = "iw-beratungsunterstuetzung.test.union-investment.de"
    listener_ip_config = local.public_ip_config_name

    # Settings are independent of environment
    listener     = "bu-public-https-listener"
    routing_rule = "bu-basic-routing-rule"

    backend_pool_frontend     = "bu-frontend-backend-pool"
    backend_settings_frontend = "bu-frontend-https-backend-setting"

    ssl_certificate = {
      # This info is used to create a ssl certificate with a name of ${ssl_certificate.name} and a key_vault_secret_id like "https://${dependency.certificates_vault.outputs.uri}/secrets/${ssl_certificate.secret_name}"
      name        = "bu-certificate"
      secret_name = "iw-beratungsunterstuetzung-certificate"
    }
  }
  # App specific: "MB Portal"
  mbportal_config = {
    # Environment specifics
    listener_host_name = "marketing.test.union-investment.de"
    listener_ip_config = local.private_ip_config_name

    # Settings are independent of environment
    listener         = "mbportal-public-https-listener"
    routing_rule     = "mbportal-path-based-routing-rule"
    routing_redirect = "mbportal-path-based-routing-rule-admin-redirect"

    backend_pool_salesportal     = "mbportal-salesportal-backend-pool"
    backend_settings_salesportal = "mbportal-salesportal-backend-setting"

    backend_pool_salesportal_admin     = "mbportal-salesportaladmin-backend-pool"
    backend_settings_salesportal_admin = "mbportal-salesportaladmin-backend-setting"

    # This info is used to create a ssl certificate with a name of ${ssl_certificate.name} and a key_vault_secret_id like "https://${dependency.certificates_vault.outputs.uri}/secrets/${ssl_certificate.secret_name}"
    ssl_certificate = {
      name        = "mbportal-certificate"
      secret_name = "marketing-certificate"
    }
  }

  # App specific: "VBST Verbundschnittstelle"
  vbst_config = {
    # Environment specifics
    listener_host_name = "vbst-dashboard.test.apps.union-investment.de"
    listener_ip_config = local.private_ip_config_name

    # Settings are independent of environment
    listener     = "vbst-private-https-listener"
    routing_rule = "vbst-basic-routing-rule"

    backend_pool_frontend     = "vbst-backend-pool"
    backend_settings_frontend = "vbst-backend-setting"

    # This info is used to create a ssl certificate with a name of ${ssl_certificate.name} and a key_vault_secret_id like "https://${dependency.certificates_vault.outputs.uri}/secrets/${ssl_certificate.secret_name}"
    ssl_certificate = {
      name        = "vbst_certificate"
      secret_name = "vbst-dashboard-apps-certificate"
    }
  }

  # App specific: "MB-Portal Reporting Dashboard (Datenprodukt)"
  mbportal_dashboard_config = {
    # Environment specifics
    listener_host_name = "mb-portal-dashboard.test.apps.union-investment.de"
    listener_ip_config = local.private_ip_config_name

    # Settings are independent of environment
    listener     = "mbportal-dashboard-private-https-listener"
    routing_rule = "mbportal-dashboard-basic-routing-rule"

    backend_pool_frontend     = "mbportal-dashboard-backend-pool"
    backend_settings_frontend = "mbportal-dashboard-backend-setting"

    # This info is used to create a ssl certificate with a name of ${ssl_certificate.name} and a key_vault_secret_id like "https://${dependency.certificates_vault.outputs.uri}/secrets/${ssl_certificate.secret_name}"
    ssl_certificate = {
      name        = "mbportal_dashboard_certificate"
      secret_name = "mb-portal-dashboard-apps-certificate"
    }
  }


  # App specific: "UBA Ruecklieferung"
  uba_config = {
    # Environment specifics
    listener_host_name = "uba-ruecklieferung.test.union-investment.de"
    listener_ip_config = local.public_ip_config_name

    # Settings are independent of environment
    listener     = "uba-public-https-listener"
    routing_rule = "uba-path-based-routing-rule"

    backend_pool_frontend     = "uba-storage-backend-pool"
    backend_settings_frontend = "uba-storage-https-backend-setting"

    health_probe_uba_storage     = "uba-storage-health-probe"

    ssl_certificate = {
      # This info is used to create a ssl certificate with a name of ${ssl_certificate.name} and a key_vault_secret_id like "https://${dependency.certificates_vault.outputs.uri}/secrets/${ssl_certificate.secret_name}"
      name        = "uba-certificate"
      secret_name = "uba-ruecklieferung-certificate"
    }
  }
}

inputs = {
  ## See 'app' global-settings for additional inputs

  # Custom Rewrite Rule Sets with frontend-specific CSP policies
  custom_rewrite_rule_sets = {
    "mb-security-headers" = {
      csp_connect_src_urls = [
        "https://auth-test.user.union-investment.de",
        "https://zfdr.test.api.union-investment.de",
        "https://uiapimf5c41c8714ee.azure-api.net",
        "https://internal.developer.test.union-investment.de",
        "https://internal.api.test.union-investment.de",
        "https://iw-marktbearbeitung.test.union-investment.de",
        "https://celum-icons.fe.union-investment.de",
        "data:"
      ]
      csp_font_src_urls = [
        "https://global-resources.fe.union-investment.de"
      ]

      # Allow images hosted in the public Marktbearbeitung DMS storage for the test environment.  
      # Without this entry, thumbnail images served from the mbdmspublictest storage account are
      # blocked by the Content-Security-Policy.
      csp_img_src_urls = [
        "https://mbdmspublictest.blob.core.windows.net"
      ]
    }
    "bu-security-headers" = {
      csp_connect_src_urls = [
        "https://auth-test.user.union-investment.de",
        "https://zfdr.test.api.union-investment.de",
        "https://uiapimf5c41c8714ee.azure-api.net",
        "https://internal.developer.test.union-investment.de",
        "https://internal.api.test.union-investment.de",
        "https://iw-beratungsunterstuetzung.test.union-investment.de",
        "https://celum-icons.fe.union-investment.de",
        "data:"
      ]
      csp_font_src_urls = [
        "https://global-resources.fe.union-investment.de"
      ]
    }
    "mbportal-security-headers" = {
      csp_connect_src_urls = [
        "https://auth-test.user.union-investment.de",
        "https://zfdr.test.api.union-investment.de",
        "https://uiapimf5c41c8714ee.azure-api.net",
        "https://internal.developer.test.union-investment.de",
        "https://internal.api.test.union-investment.de",
        "https://marketing.test.union-investment.de",
        "https://celum-icons.fe.union-investment.de",
        "data:"
      ]
      csp_font_src_urls = [
        "https://global-resources.fe.union-investment.de"
      ]
    }
    "vbst-dashboard-security-headers" = {
      csp_connect_src_urls = [
        "https://auth-test.user.union-investment.de",
        "https://zfdr.test.api.union-investment.de",
        "https://uiapimf5c41c8714ee.azure-api.net",
        "https://internal.developer.test.union-investment.de",
        "https://internal.api.test.union-investment.de",
        "https://vbst-dashboard.test.apps.union-investment.de",
        "https://login.microsoftonline.com",
        "https://celum-icons.fe.union-investment.de",
        "data:"
      ]
      csp_font_src_urls = [
        "https://global-resources.fe.union-investment.de"
      ]
      csp_style_src_urls = [
        "https://global-resources.fe.union-investment.de"
      ]
    }
    "mbportal-dashboard-security-headers" = {
      csp_connect_src_urls = [
        "https://auth-test.user.union-investment.de",
        "https://zfdr.test.api.union-investment.de",
        "https://uiapimf5c41c8714ee.azure-api.net",
        "https://internal.developer.test.union-investment.de",
        "https://internal.api.test.union-investment.de",
        "https://mb-portal-dashboard.test.apps.union-investment.de",
        "https://login.microsoftonline.com",
        "https://celum-icons.fe.union-investment.de",
        "https://app.powerbi.com",
        "data:"
      ]
      csp_font_src_urls = [
        "https://global-resources.fe.union-investment.de"
      ]
      csp_style_src_urls = [
        "https://global-resources.fe.union-investment.de"
      ]
      csp_frame_src_urls = [
        "https://app.powerbi.com"
      ]
    }
    "uba-storage-security-headers" = {
      csp_connect_src_urls = [
        "data:"
      ]
      csp_font_src_urls = [
      ]
      csp_style_src_urls = [
      ]
      csp_frame_src_urls = [
      ]
    }
  }

  app_gateway_properties = {
    name                                  = local.appgw_name
    resource_group                        = local.appgw_resource_group
    gateway_ip_configuration_name         = local.gw_ip_config_name
    frontend_public_ip_configuration_name = local.public_ip_config_name
    user_assigned_resource_ids            = [dependency.managed_identity.outputs.resource_id]
  }

  public_ip_address = {
    name           = local.public_ip_address_name
    resource_group = local.appgw_resource_group
  }

  frontend_ip_configuration_private = {
    name                          = local.private_ip_config_name
    private_ip_address            = local.private_ip_value
    private_ip_address_allocation = "Static"
  }

  frontend_ports = {
    https = {
      name = local.https_port_name
      port = 443
    }
  }

  private_subdomain = {
    name = "gateway"
    zone = {
      name                = "marktbearbeitung.test.azure.union-investment.de"
      resource_group_name = "rg-marktbearbeitung-test-managed-resources"
    }
  }

  ## --- Application Specifics ---
  ##
  ## "IW Marktbearbeitung" (short 'mb')
  ## "IW Beratungsunterstützung" (short 'bu')
  ## "MB Portal" (short 'mbportal')
  ## "VBST Verbundschnittstelle" (short 'vbst')
  ## "MB Portal Dashboard" (short 'mbportal-dashboard')
  ## "UBA Anbindung" (short 'uba')
  #
  http_listeners = {
    mb_public_https_listener = {
      name                           = local.mb_config.listener
      frontend_port_name             = local.https_port_name
      frontend_ip_configuration_name = local.public_ip_config_name
      require_sni                    = true
      host_name                      = local.mb_config.listener_host_name
      ssl_certificate_name           = local.mb_config.ssl_certificate.name
    }

    bu_public_https_listener = {
      name                           = local.bu_config.listener
      frontend_port_name             = local.https_port_name
      frontend_ip_configuration_name = local.public_ip_config_name
      require_sni                    = true
      host_name                      = local.bu_config.listener_host_name
      ssl_certificate_name           = local.bu_config.ssl_certificate.name
    }

    mbportal_public_https_listener = {
      name                           = local.mbportal_config.listener
      frontend_port_name             = local.https_port_name
      frontend_ip_configuration_name = local.public_ip_config_name
      require_sni                    = true
      host_name                      = local.mbportal_config.listener_host_name
      ssl_certificate_name           = local.mbportal_config.ssl_certificate.name
    }

    vbst_private_https_listener = {
      name                           = local.vbst_config.listener
      frontend_port_name             = local.https_port_name
      frontend_ip_configuration_name = local.private_ip_config_name
      require_sni                    = true
      host_name                      = local.vbst_config.listener_host_name
      ssl_certificate_name           = local.vbst_config.ssl_certificate.name
    }

    mbportal_dashboard_public_https_listener = {
      name                           = local.mbportal_dashboard_config.listener
      frontend_port_name             = local.https_port_name
      frontend_ip_configuration_name = local.private_ip_config_name
      require_sni                    = true
      host_name                      = local.mbportal_dashboard_config.listener_host_name
      ssl_certificate_name           = local.mbportal_dashboard_config.ssl_certificate.name
    }

    uba_public_https_listener = {
      name                           = local.uba_config.listener
      frontend_port_name             = local.https_port_name
      frontend_ip_configuration_name = local.public_ip_config_name
      require_sni                    = true
      host_name                      = local.uba_config.listener_host_name
      ssl_certificate_name           = local.uba_config.ssl_certificate.name
    }
  }

  backend_address_pools = {
    mb_frontend = {
      name  = local.mb_config.backend_pool_frontend
      fqdns = [dependency.mb_frontend.outputs.default_host_name]
    }
    mb_dms_storage = {
      name  = local.mb_config.backend_pool_dms_storage
      fqdns = [dependency.mb_dmsstorage.outputs.blob_host_name]
    }

    bu_frontend = {
      name  = local.bu_config.backend_pool_frontend
      fqdns = [dependency.bu_frontend.outputs.default_host_name]
    }

    mbportal_salesportal = {
      name  = local.mbportal_config.backend_pool_salesportal
      fqdns = [dependency.mbportal_salesportal.outputs.default_host_name]
    }
    mbportal_salesportal_admin = {
      name  = local.mbportal_config.backend_pool_salesportal_admin
      fqdns = [dependency.mbportal_salesportal_admin.outputs.default_host_name]
    }
    vbst_frontend = {
      name  = local.vbst_config.backend_pool_frontend
      fqdns = [dependency.vbst_frontend.outputs.default_host_name]
    }
    mbportal_dashboard_frontend = {
      name  = local.mbportal_dashboard_config.backend_pool_frontend
      fqdns = [dependency.mbportal_dashboard_frontend.outputs.default_host_name]
    }
    uba_storage = {
      name  = local.uba_config.backend_pool_frontend
      fqdns = [dependency.uba_storage.outputs.blob_host_name]
    }
  }

  backend_http_settings = {
    mb_frontend = {
      cookie_based_affinity               = "Disabled"
      name                                = local.mb_config.backend_settings_frontend
      port                                = 443
      protocol                            = "Https"
      request_timeout                     = 20
      pick_host_name_from_backend_address = true
    }
    mb_dms_storage = {
      cookie_based_affinity               = "Disabled"
      name                                = local.mb_config.backend_settings_dms_storage
      port                                = 443
      protocol                            = "Https"
      path                                = "/"
      request_timeout                     = 20
      pick_host_name_from_backend_address = true
      probe_name                          = local.mb_config.health_probe_dms_storage
    }

    bu_frontend = {
      cookie_based_affinity               = "Disabled"
      name                                = local.bu_config.backend_settings_frontend
      port                                = 443
      protocol                            = "Https"
      request_timeout                     = 20
      pick_host_name_from_backend_address = true
    }

    mbportal_salesportal = {
      cookie_based_affinity               = "Disabled"
      name                                = local.mbportal_config.backend_settings_salesportal
      port                                = 443
      protocol                            = "Https"
      request_timeout                     = 20
      pick_host_name_from_backend_address = true
    }
    mbportal_salesportal_admin = {
      cookie_based_affinity               = "Disabled"
      name                                = local.mbportal_config.backend_settings_salesportal_admin
      port                                = 443
      protocol                            = "Https"
      request_timeout                     = 20
      pick_host_name_from_backend_address = true
    }

    vbst_frontend = {
      cookie_based_affinity               = "Disabled"
      name                                = local.vbst_config.backend_settings_frontend
      port                                = 443
      protocol                            = "Https"
      request_timeout                     = 20
      pick_host_name_from_backend_address = true
    }
    mbportal_dashboard_frontend = {
      cookie_based_affinity               = "Disabled"
      name                                = local.mbportal_dashboard_config.backend_settings_frontend
      port                                = 443
      protocol                            = "Https"
      request_timeout                     = 20
      pick_host_name_from_backend_address = true
    }
    uba_storage = {
      cookie_based_affinity               = "Disabled"
      name                                = local.uba_config.backend_settings_frontend
      port                                = 443
      protocol                            = "Https"
      path                                = "/"
      request_timeout                     = 20
      pick_host_name_from_backend_address = true
      probe_name                          = local.uba_config.health_probe_uba_storage
    }
  }

  request_routing_rules = {
    mb_path_based = {
      name               = local.mb_config.routing_rule
      rule_type          = "PathBasedRouting"
      url_path_map_name  = local.mb_config.routing_rule
      http_listener_name = local.mb_config.listener

      priority = 10
    }

    bu_basic = {
      name                       = local.bu_config.routing_rule
      rule_type                  = "Basic"
      http_listener_name         = local.bu_config.listener
      backend_address_pool_name  = local.bu_config.backend_pool_frontend
      backend_http_settings_name = local.bu_config.backend_settings_frontend
      rewrite_rule_set_name      = "bu-security-headers"

      priority = 20
    }

    mbportal_path_based = {
      name               = local.mbportal_config.routing_rule
      rule_type          = "PathBasedRouting"
      url_path_map_name  = local.mbportal_config.routing_rule
      http_listener_name = local.mbportal_config.listener

      priority = 30
    }

    vbst_basic = {
      name                       = local.vbst_config.routing_rule
      rule_type                  = "Basic"
      http_listener_name         = local.vbst_config.listener
      backend_address_pool_name  = local.vbst_config.backend_pool_frontend
      backend_http_settings_name = local.vbst_config.backend_settings_frontend
      rewrite_rule_set_name      = "vbst-dashboard-security-headers"

      priority = 40
    }

    mbportal_dashboard_basic = {
      name                       = local.mbportal_dashboard_config.routing_rule
      rule_type                  = "Basic"
      http_listener_name         = local.mbportal_dashboard_config.listener
      backend_address_pool_name  = local.mbportal_dashboard_config.backend_pool_frontend
      backend_http_settings_name = local.mbportal_dashboard_config.backend_settings_frontend
      rewrite_rule_set_name      = "mbportal-dashboard-security-headers"

      priority = 50
    }

    uba_basic = {
      name                       = local.uba_config.routing_rule
      rule_type                  = "Basic"
      http_listener_name         = local.uba_config.listener
      backend_address_pool_name  = local.uba_config.backend_pool_frontend
      backend_http_settings_name = local.uba_config.backend_settings_frontend
      rewrite_rule_set_name      = "uba-storage-security-headers"

      priority = 60
    }
  }

  redirect_configuration = {
    mbportal_redirect = {
      name                 = local.mbportal_config.routing_redirect
      include_path         = false
      include_query_string = false

      redirect_type = "Permanent"
      target_url    = "https://${local.mbportal_config.listener_host_name}/admin/"
    }
  }

  url_path_map_configurations = {
    mb_path_based = {
      name = local.mb_config.routing_rule

      default_backend_address_pool_name  = local.mb_config.backend_pool_frontend
      default_backend_http_settings_name = local.mb_config.backend_settings_frontend
      default_rewrite_rule_set_name      = "mb-security-headers"

      path_rules = {
        mb_dms_storage = {
          name                       = "mb-dms-storage"
          paths                      = ["/dms/blob/*"]
          backend_address_pool_name  = local.mb_config.backend_pool_dms_storage
          backend_http_settings_name = local.mb_config.backend_settings_dms_storage
        }
      }
    }

    mbportal_path_based = {
      name = local.mbportal_config.routing_rule

      default_backend_address_pool_name  = local.mbportal_config.backend_pool_salesportal
      default_backend_http_settings_name = local.mbportal_config.backend_settings_salesportal
      default_rewrite_rule_set_name      = "mbportal-security-headers"

      path_rules = {
        # Redirect /admin -> /admin/ (no rewrite rule set possible for redirects)
        mbportal_salesportal_admin-redirect = {
          name                        = "admin-redirect"
          paths                       = ["/admin"]
          redirect_configuration_name = local.mbportal_config.routing_redirect
        }
        # Admin frontend at /admin/* (explicitly set rewrite rule set)
        mbportal_salesportal_admin-path = {
          name                       = "admin-path"
          paths                      = ["/admin/*"]
          backend_address_pool_name  = local.mbportal_config.backend_pool_salesportal_admin
          backend_http_settings_name = local.mbportal_config.backend_settings_salesportal_admin
          rewrite_rule_set_name      = "mbportal-security-headers"
        }

      }
    }
  }

  probe_configurations = {
    mb_dms_storage = {
      name                                      = local.mb_config.health_probe_dms_storage
      interval                                  = 30
      timeout                                   = 30
      unhealthy_threshold                       = 3
      protocol                                  = "Https"
      path                                      = "/"
      pick_host_name_from_backend_http_settings = true
      match = {
        status_code = ["200-400"]
      }
    }
    uba_storage = {
      name                                      = local.uba_config.health_probe_uba_storage
      interval                                  = 30
      timeout                                   = 30
      unhealthy_threshold                       = 3
      protocol                                  = "Https"
      path                                      = "/"
      pick_host_name_from_backend_http_settings = true
      match = {
        status_code = ["200-400"]
      }
    }
  }

  ssl_certificates = {
    mb_https_certificate = {
      name                = local.mb_config.ssl_certificate.name
      key_vault_secret_id = "${dependency.certificates_vault.outputs.uri}secrets/${local.mb_config.ssl_certificate.secret_name}"
    }
    bu_https_certificate = {
      name                = local.bu_config.ssl_certificate.name
      key_vault_secret_id = "${dependency.certificates_vault.outputs.uri}secrets/${local.bu_config.ssl_certificate.secret_name}"
    }
    mbportal_https_certificate = {
      name                = local.mbportal_config.ssl_certificate.name
      key_vault_secret_id = "${dependency.certificates_vault.outputs.uri}secrets/${local.mbportal_config.ssl_certificate.secret_name}"
    }
    vbst_https_certificate = {
      name                = local.vbst_config.ssl_certificate.name
      key_vault_secret_id = "${dependency.certificates_vault.outputs.uri}secrets/${local.vbst_config.ssl_certificate.secret_name}"
    }
    mbportal_dashboard_https_certificate = {
      name                = local.mbportal_dashboard_config.ssl_certificate.name
      key_vault_secret_id = "${dependency.certificates_vault.outputs.uri}secrets/${local.mbportal_dashboard_config.ssl_certificate.secret_name}"
    }
    uba_https_certificate = {
      name                = local.uba_config.ssl_certificate.name
      key_vault_secret_id = "${dependency.certificates_vault.outputs.uri}secrets/${local.uba_config.ssl_certificate.secret_name}"
    }
  }

}
