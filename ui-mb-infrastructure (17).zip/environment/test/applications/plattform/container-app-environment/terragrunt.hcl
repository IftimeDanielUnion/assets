include "root" {
  path           = find_in_parent_folders("root.hcl")
  merge_strategy = "deep"
}

include "app" {
  path           = "${get_terragrunt_dir()}/../../../../_apps/plattform/container-app-environment.hcl"
  merge_strategy = "deep"
}

inputs = {
  container_subnet_id = "/subscriptions/d98221c3-b24d-4770-a9a3-3716667d7353/resourceGroups/rg-marktbearbeitung-test-networking/providers/Microsoft.Network/virtualNetworks/vnet-marktbearbeitung-test-swc-01/subnets/containerapp"
}
