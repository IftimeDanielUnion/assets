locals {
  backend_container_name       = "terraform-state"
  backend_storage_account_name = "sawd345ade3fb4f39a5a"
  backend_resource_group_name  = "rg-marktbearbeitung-test-managed-resources"

  workload        = "MARKTBEARBEITUNG"
  environment     = "test"
  subscription_id = "d98221c3-b24d-4770-a9a3-3716667d7353"

  tags = {
    environment = local.environment
  }
}

inputs = {
  location                     = "swedencentral"
  vnet_name                    = "vnet-marktbearbeitung-test-swc-01"
  vnet_resource_group_name     = "rg-marktbearbeitung-test-networking"
  vnet_subnet_name             = "default"
  vnet_subnet_name_appgw       = "appgw"
  vnet_subnet_name_functionapp = "functionapp"

  # Defender is active for the whole subscription
  integrate_defender_for_storage = {
    endpoint_resource_id = "/subscriptions/${local.subscription_id}/providers/Microsoft.Security/datascanners/storageDataScanner"
    endpoint_tenant_id   = "2eb07b91-f9f8-437b-a89e-59f55e565c11"
  }
}
