terraform {
  source = "../../../../../modules//functionapp"
}

dependency "monitoring" {
  config_path = "${get_terragrunt_dir()}/../monitoring"
  mock_outputs = {
    resource_id = "/subscriptions/12345678-1234-9876-4563-123456789012/resourceGroups/example-resource-group/providers/Microsoft.OperationalInsights/workspaces/workspaceValue"
    application_insights = {
      connection_string = "string-sample"
    }
  }
}

dependency "datenprodukt_identity" {
  config_path = "${get_terragrunt_dir()}/../datenprodukt-identity"
  mock_outputs = {
    resource_id = "/subscriptions/12345678-1234-9876-4563-123456789012/resourceGroups/example-resource-group/providers/Microsoft.ManagedIdentity/userAssignedIdentities/identityValue"
  }
}

locals {
  environment_vars = read_terragrunt_config(find_in_parent_folders("env.hcl"))
  env              = local.environment_vars.locals.environment
}

inputs = {
  component_name = "datenprodukt-api"
  instance_count = 1
  sku_name       = "B2"
  runtime = {
    stack   = "java"
    version = "17"
  }

  alerts = {
    resource_group_name = dependency.monitoring.outputs.resource_group
    metric_alerts = {
      cpu = {
        name        = "TAB - Function CPU Usage (%scope_name%) S_MARKTBEARBEITUNG_${upper(local.env)}"
        description = "CPU Auslastung des Function servers %scope_name% ist in den letzten 15 Minuten 80% oder höher."
        enabled     = true
        frequency   = "PT5M"
        severity    = 2
        window_size = "PT15M"
        criteria = [{
          metric_namespace = "Microsoft.Web/serverFarms"
          metric_name      = "CpuPercentage"
          aggregation      = "Average"
          operator         = "GreaterThan"
          threshold        = 80
        }]
        actions = concat(
          [{
            action_group_id = dependency.monitoring.outputs.action_groups["incidents"].resource_id
          }],
          contains(["test", "prod"], local.env) ? [{
            action_group_id = dependency.monitoring.outputs.action_groups["tab"].resource_id
          }] : []
        )
      }
    }
  }
  cors = {
    allowed_origins = ["https://portal.azure.com"]
  }

  discovery_key = "func-datenprodukt-api"

  health_check = {
    eviction_time_in_min = 3
    path                 = "/api/q/health"
    monitoring_alert = {
      actions = concat(
        [{
          action_group_id = dependency.monitoring.outputs.action_groups["incidents"].resource_id
        }],
        contains(["test", "prod"], local.env) ? [{
          action_group_id = dependency.monitoring.outputs.action_groups["tab"].resource_id
        }] : []
      )
      resource_group_name = dependency.monitoring.outputs.resource_group
    }
  }

  logging = {
    application_insights_connection_string = dependency.monitoring.outputs.application_insights.connection_string
  }

  storage_account = {
    private_endpoints = ["blob", "table"]
  }

  user_assigned_resource_ids = [dependency.datenprodukt_identity.outputs.resource_id]
}
