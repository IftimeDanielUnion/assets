terraform {
  source = "../../../../../modules//log-and-monitor"
}

locals {
  environment_vars = read_terragrunt_config(find_in_parent_folders("env.hcl"))

  env = local.environment_vars.locals.environment
}

inputs = {
  component_name                 = "monitoring"
  integrate_application_insights = true

  action_groups = merge(
    {
      incidents = {
        short_name = "mbportal-inc"
        tags = {
          monitoring : "incidents"
        }
        email_receiver = [{
          name          = "Monitoring: New Incident"
          email_address = "monitoring_mbportal+${local.env}@union-investment.de"
        }]
      }
    },
    contains(["test", "prod"], local.env) ? {
      tab = {
        short_name = "TAB-Mail"
        tags = {
          monitoring : "tab"
        }
        email_receiver = [{
          name          = "Monitoring: TAB Mail"
          email_address = "cis-tab@union-investment.de"
        }]
      }
    } : {}
  )

  external_endpoint_check = {
    name                 = "TAB - availability (%scope_name%) in S_MARKTBEARBEITUNG_${upper(local.env)}"
    description          = "Der Endpunkt %scope_name% war innerhalb der letzten 5 Minuten nicht erreichbar."
    action_group_map_key = "incidents"
    frequency            = "PT5M"
    severity             = 2
    window_size          = "PT5M"
    endpoints = [{
      name = "PBM"
      url  = "union-investment.stage.pbm.sh"
    }]
  }

  scheduled_log_alerts = {
    error_logs = {
      name                 = "TAB - Error logs S_MARKTBEARBEITUNG_${upper(local.env)}"
      description          = "Error logs oder Exceptions sind in den letzten 15 Minuten aufgetreten."
      action_group_map_key = "incidents"
      enabled              = true
      evaluation_frequency = "PT15M"
      severity             = 1
      window_duration      = "PT15M"
      criteria = [{
        query                   = <<-QUERY
            exceptions
            | extend message = outerMessage
            | where type != "com.azure.storage.blob.implementation.models.BlobStorageExceptionInternal"
            | where message !has "databasechangeloglock\" does not exist"
            | union traces
            | extend applicationName = tostring(customDimensions.applicationName)
            | extend bankTenant=tostring(customDimensions.bankTenant)
            | extend bankCode=tostring(customDimensions.bankCode)
            | extend functionName=tostring(customDimensions.functionName)
            | extend channelName=tostring(customDimensions.channelName)
            | extend requestedHttpMethod=tostring(customDimensions.requestedHttpMethod)
            | extend requestedHttpPath=tostring(customDimensions.requestedHttpPath)
            | where severityLevel == 3 or tostring(severityLevel) == @''
            | project-reorder timestamp,itemType,message,applicationName,bankTenant,bankCode,functionName,channelName,requestedHttpMethod,requestedHttpPath
          QUERY
        time_aggregation_method = "Count"
        threshold               = 0
        operator                = "GreaterThan"
        dimension = [{
          name     = "applicationName"
          operator = "Include"
          values   = ["*"]
        }]
      }]
    }
    concentrix_no_feedback_24h = {
      name                 = "TAB - Keine Concentrix Rückmeldung seit 24h S_MARKTBEARBEITUNG_${upper(local.env)}"
      description          = "Seit 24 Stunden (an Werktagen) keine Rückmeldung von Concentrix zu laufenden Aufträgen erhalten."
      action_group_map_key = "incidents"
      enabled              = true
      evaluation_frequency = "P1D"
      severity             = 2
      window_duration      = "P1D"
      criteria = [{
        query                   = <<-QUERY
            let berlinNow = datetime_utc_to_local(now(), 'Europe/Berlin');
            let dow       = dayofweek(berlinNow);
            let isWeekday = dow between (1d .. 5d);
            let lookback  = iif(dow == 1d, 72h, 24h);
            let events =
                traces
                | extend applicationName = tostring(customDimensions.applicationName),
                         loggerName      = tostring(customDimensions.LoggerName)
                | where timestamp > ago(lookback)
                | where applicationName == "mbportal-backend"
                  and loggerName == "BusinessAuditLogger"
                  and message has_cs "gibt es ein Update von Concentrix";
            let eventCount = toscalar(events | summarize count());
            print LogCount = iif(isWeekday, eventCount, 999), IsWeekday = isWeekday
            | project LogCount
          QUERY
        time_aggregation_method = "Total"
        metric_measure_column   = "LogCount"
        threshold               = 1
        operator                = "LessThan"
        dimension               = []
      }]
    }
  }

  log_analytics_alerts = {
    failed_postgres_cron = {
      name                 = "TAB - Failed Postgres-Cron-Logs S_MARKTBEARBEITUNG_${upper(local.env)}"
      description          = "Ein Postgres-Cron-Job ist in den letzten 60 Minuten fehlgeschlagen."
      action_group_map_key = "incidents"
      enabled              = true
      evaluation_frequency = "PT1H"
      severity             = 1
      window_duration      = "PT1H"
      criteria = [{
        query                   = <<-QUERY
            AzureDiagnostics
            | where Message contains "CRON_ALERT"
            | where Category == "PostgreSQLLogs"
            | project TimeGenerated, Message, LogicalServerName_s, context_s, errorLevel_s
          QUERY
        time_aggregation_method = "Count"
        threshold               = 0
        operator                = "GreaterThan"
      }]
    }
  }

  alert_processing_rules = {
    # Neujahr 2026
    german_holiday_neujahr_2026 = {
      name        = "Suppress-Concentrix-Alert-Neujahr-2026"
      description = "Suppresses the Concentrix feedback alert on Neujahr (01.01.2026)"
      enabled     = true
      condition = {
        alert_rule_name = {
          operator = "Contains"
          values   = ["Keine Concentrix Rückmeldung seit 24h"]
        }
      }
      schedule = {
        effective_from  = "2026-01-01T00:00:00"
        effective_until = "2026-01-01T23:59:59"
        time_zone       = "W. Europe Standard Time"
      }
    }
    # Karfreitag 2026
    german_holiday_karfreitag_2026 = {
      name        = "Suppress-Concentrix-Alert-Karfreitag-2026"
      description = "Suppresses the Concentrix feedback alert on Karfreitag (03.04.2026)"
      enabled     = true
      condition = {
        alert_rule_name = {
          operator = "Contains"
          values   = ["Keine Concentrix Rückmeldung seit 24h"]
        }
      }
      schedule = {
        effective_from  = "2026-04-03T00:00:00"
        effective_until = "2026-04-03T23:59:59"
        time_zone       = "W. Europe Standard Time"
      }
    }
    # Ostermontag 2026
    german_holiday_ostermontag_2026 = {
      name        = "Suppress-Concentrix-Alert-Ostermontag-2026"
      description = "Suppresses the Concentrix feedback alert on Ostermontag (06.04.2026)"
      enabled     = true
      condition = {
        alert_rule_name = {
          operator = "Contains"
          values   = ["Keine Concentrix Rückmeldung seit 24h"]
        }
      }
      schedule = {
        effective_from  = "2026-04-06T00:00:00"
        effective_until = "2026-04-06T23:59:59"
        time_zone       = "W. Europe Standard Time"
      }
    }
    # Tag der Arbeit 2026
    german_holiday_tag_der_arbeit_2026 = {
      name        = "Suppress-Concentrix-Alert-Tag-der-Arbeit-2026"
      description = "Suppresses the Concentrix feedback alert on Tag der Arbeit (01.05.2026)"
      enabled     = true
      condition = {
        alert_rule_name = {
          operator = "Contains"
          values   = ["Keine Concentrix Rückmeldung seit 24h"]
        }
      }
      schedule = {
        effective_from  = "2026-05-01T00:00:00"
        effective_until = "2026-05-01T23:59:59"
        time_zone       = "W. Europe Standard Time"
      }
    }
    # Christi Himmelfahrt 2026
    german_holiday_christi_himmelfahrt_2026 = {
      name        = "Suppress-Concentrix-Alert-Christi-Himmelfahrt-2026"
      description = "Suppresses the Concentrix feedback alert on Christi Himmelfahrt (14.05.2026)"
      enabled     = true
      condition = {
        alert_rule_name = {
          operator = "Contains"
          values   = ["Keine Concentrix Rückmeldung seit 24h"]
        }
      }
      schedule = {
        effective_from  = "2026-05-14T00:00:00"
        effective_until = "2026-05-14T23:59:59"
        time_zone       = "W. Europe Standard Time"
      }
    }
    # Pfingstmontag 2026
    german_holiday_pfingstmontag_2026 = {
      name        = "Suppress-Concentrix-Alert-Pfingstmontag-2026"
      description = "Suppresses the Concentrix feedback alert on Pfingstmontag (25.05.2026)"
      enabled     = true
      condition = {
        alert_rule_name = {
          operator = "Contains"
          values   = ["Keine Concentrix Rückmeldung seit 24h"]
        }
      }
      schedule = {
        effective_from  = "2026-05-25T00:00:00"
        effective_until = "2026-05-25T23:59:59"
        time_zone       = "W. Europe Standard Time"
      }
    }
    # Tag der Deutschen Einheit 2026
    german_holiday_tag_der_deutschen_einheit_2026 = {
      name        = "Suppress-Concentrix-Alert-Tag-der-Deutschen-Einheit-2026"
      description = "Suppresses the Concentrix feedback alert on Tag der Deutschen Einheit (03.10.2026)"
      enabled     = true
      condition = {
        alert_rule_name = {
          operator = "Contains"
          values   = ["Keine Concentrix Rückmeldung seit 24h"]
        }
      }
      schedule = {
        effective_from  = "2026-10-03T00:00:00"
        effective_until = "2026-10-03T23:59:59"
        time_zone       = "W. Europe Standard Time"
      }
    }
    # 1. Weihnachtsfeiertag 2026
    german_holiday_weihnachten_1_2026 = {
      name        = "Suppress-Concentrix-Alert-1-Weihnachtsfeiertag-2026"
      description = "Suppresses the Concentrix feedback alert on 1. Weihnachtsfeiertag (25.12.2026)"
      enabled     = true
      condition = {
        alert_rule_name = {
          operator = "Contains"
          values   = ["Keine Concentrix Rückmeldung seit 24h"]
        }
      }
      schedule = {
        effective_from  = "2026-12-25T00:00:00"
        effective_until = "2026-12-25T23:59:59"
        time_zone       = "W. Europe Standard Time"
      }
    }
    # 2. Weihnachtsfeiertag 2026
    german_holiday_weihnachten_2_2026 = {
      name        = "Suppress-Concentrix-Alert-2-Weihnachtsfeiertag-2026"
      description = "Suppresses the Concentrix feedback alert on 2. Weihnachtsfeiertag (26.12.2026)"
      enabled     = true
      condition = {
        alert_rule_name = {
          operator = "Contains"
          values   = ["Keine Concentrix Rückmeldung seit 24h"]
        }
      }
      schedule = {
        effective_from  = "2026-12-26T00:00:00"
        effective_until = "2026-12-26T23:59:59"
        time_zone       = "W. Europe Standard Time"
      }
    }
  }

  tags = {
    component = "Logging and Monitoring"
  }
}
