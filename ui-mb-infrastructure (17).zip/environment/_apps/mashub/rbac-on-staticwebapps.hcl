# RBAC on Static Web App Key Vaults
# This assigns the System Assigned Identity of each Static Web App to its associated Key Vault
# Separated from the staticwebapp module to avoid circular dependencies with dynamic identity blocks

terraform {
  source = "../../../../../modules//rbac-assignment"
}

dependency "datenprodukt_frontend" {
  config_path = "${get_terragrunt_dir()}/../datenprodukt-frontend"
  mock_outputs = {
    principal_id = "12345678-1234-1234-1234-123456789012"
    key_vault_id = "/subscriptions/12345678-1234-9876-4563-123456789012/resourceGroups/example-resource-group/providers/Microsoft.KeyVault/vaults/kv-example"
  }
  mock_outputs_allowed_terraform_commands = ["validate", "plan"]
  mock_outputs_merge_strategy_with_state  = "shallow"
}

dependency "sales_portal" {
  config_path = "${get_terragrunt_dir()}/../sales-portal"
  mock_outputs = {
    principal_id = "12345678-1234-1234-1234-123456789012"
    key_vault_id = "/subscriptions/12345678-1234-9876-4563-123456789012/resourceGroups/example-resource-group/providers/Microsoft.KeyVault/vaults/kv-example"
  }
  mock_outputs_allowed_terraform_commands = ["validate", "plan"]
  mock_outputs_merge_strategy_with_state  = "shallow"
}

dependency "sales_portal_admin" {
  config_path = "${get_terragrunt_dir()}/../sales-portal-admin"
  mock_outputs = {
    principal_id = "12345678-1234-1234-1234-123456789012"
    key_vault_id = "/subscriptions/12345678-1234-9876-4563-123456789012/resourceGroups/example-resource-group/providers/Microsoft.KeyVault/vaults/kv-example"
  }
  mock_outputs_allowed_terraform_commands = ["validate", "plan"]
  mock_outputs_merge_strategy_with_state  = "shallow"
}

inputs = {
  role_assignments = {
    datenprodukt_frontend_kv_access = {
      scope                = dependency.datenprodukt_frontend.outputs.key_vault_id
      role_definition_name = "Key Vault Secrets User"
      principal_id         = dependency.datenprodukt_frontend.outputs.principal_id
      principal_type       = "ServicePrincipal"
      description          = "Datenprodukt Frontend Static Web App has permission to read secrets from its KeyVault"
    }
    sales_portal_kv_access = {
      scope                = dependency.sales_portal.outputs.key_vault_id
      role_definition_name = "Key Vault Secrets User"
      principal_id         = dependency.sales_portal.outputs.principal_id
      principal_type       = "ServicePrincipal"
      description          = "Sales Portal Static Web App has permission to read secrets from its KeyVault"
    }
    sales_portal_admin_kv_access = {
      scope                = dependency.sales_portal_admin.outputs.key_vault_id
      role_definition_name = "Key Vault Secrets User"
      principal_id         = dependency.sales_portal_admin.outputs.principal_id
      principal_type       = "ServicePrincipal"
      description          = "Sales Portal Admin Static Web App has permission to read secrets from its KeyVault"
    }
  }
}
