terraform {
  source = "../../../../../modules//servicebus"
}

dependency "identity" {
  config_path = "${get_terragrunt_dir()}/../identity"
  mock_outputs = {
    resource_id  = "/subscriptions/12345678-1234-9876-4563-123456789012/resourceGroups/example-resource-group/providers/Microsoft.ManagedIdentity/userAssignedIdentities/identityValue"
    principal_id = "12345678-1234-1234-1234-123456789012"
  }
}

dependency "datenprodukt_identity" {
  config_path = "${get_terragrunt_dir()}/../datenprodukt-identity"
  mock_outputs = {
    resource_id  = "/subscriptions/12345678-1234-9876-4563-123456789012/resourceGroups/example-resource-group/providers/Microsoft.ManagedIdentity/userAssignedIdentities/identityValue"
    principal_id = "12345678-1234-1234-1234-123456789012"
  }
}

dependency "monitoring" {
  config_path = "${get_terragrunt_dir()}/../monitoring"

  mock_outputs = {
    resource_id = "/subscriptions/12345678-1234-9876-4563-123456789012/resourceGroups/example-resource-group/providers/Microsoft.OperationalInsights/workspaces/workspaceValue"
  }
}

locals {
  environment_vars = read_terragrunt_config(find_in_parent_folders("env.hcl"))

  env = local.environment_vars.locals.environment
}

inputs = {
  component_name = "servicebus"

  alerts = {
    resource_group_name = dependency.monitoring.outputs.resource_group

    metric_alerts = {
      dlq = {
        name        = "TAB - DLQ messages in S_MARKTBEARBEITUNG_${upper(local.env)}"
        description = "Dead-lettered messages im Service Bus > 0 (letzte 60 Minuten)"
        severity    = 2
        enabled     = true
        frequency   = "PT5M" # Abfrageintervall
        window_size = "PT1H" # Betrachtungszeitraum

        criteria = [{
          metric_namespace = "Microsoft.ServiceBus/namespaces"
          metric_name      = "deadletteredMessages"
          aggregation      = "Average"
          operator         = "GreaterThan"
          threshold        = 0
          dimension = [{
            name     = "EntityName" # berücksichtigt jede Queue / Subscription
            operator = "Include"
            values   = ["*"]
          }]
        }]

        actions = concat(
          [{
            action_group_id = dependency.monitoring.outputs.action_groups["incidents"].resource_id
          }],
          contains(["test", "prod"], local.env) ? [{
            action_group_id = dependency.monitoring.outputs.action_groups["tab"].resource_id
          }] : []
        )
      }
    }
  }

  diagnostic_settings = {
    logs = {
      name                           = "service-bus-all-logs"
      log_groups                     = ["allLogs"]
      metric_categories              = []
      log_analytics_destination_type = "Dedicated"
      workspace_resource_id          = dependency.monitoring.outputs.resource_id
    }
  }

  role_assignments = {
    uai_owner = {
      principal_id         = dependency.identity.outputs.principal_id
      role_definition_name = "Azure Service Bus Data Owner"
      description          = "User Assigned Identity has Owner Role on Service Bus"
    }
    datenprodukt_identity_owner = {
      principal_id         = dependency.datenprodukt_identity.outputs.principal_id
      role_definition_name = "Azure Service Bus Data Owner"
      description          = "Datenprodukt Identity has Owner Role on Service Bus"
    }
  }
}
