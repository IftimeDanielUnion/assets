terraform {
  source = "../../../../../modules//staticwebapp"
}

inputs = {
  component_name = "sales-portal"

  static_web_app_location = "westeurope"
}
