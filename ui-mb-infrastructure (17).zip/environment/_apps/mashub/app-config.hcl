terraform {
  source = "../../../../../modules//appconfiguration"
}

dependency "monitoring" {
  config_path = "${get_terragrunt_dir()}/../monitoring"

  mock_outputs = {
    resource_id = "/subscriptions/12345678-1234-9876-4563-123456789012/resourceGroups/example-resource-group/providers/Microsoft.OperationalInsights/workspaces/workspaceValue"
  }
}

dependency "identity" {
  config_path = "${get_terragrunt_dir()}/../identity"
  mock_outputs = {
    resource_id  = "/subscriptions/12345678-1234-9876-4563-123456789012/resourceGroups/example-resource-group/providers/Microsoft.ManagedIdentity/userAssignedIdentities/identityValue"
    principal_id = "12345678-1234-1234-1234-123456789012"
  }
}

dependency "datenprodukt_identity" {
  config_path = "${get_terragrunt_dir()}/../datenprodukt-identity"
  mock_outputs = {
    resource_id  = "/subscriptions/12345678-1234-9876-4563-123456789012/resourceGroups/example-resource-group/providers/Microsoft.ManagedIdentity/userAssignedIdentities/identityValue"
    principal_id = "12345678-1234-1234-1234-123456789012"
  }
}

inputs = {
  component_name = "appconfig"

  diagnostic_settings = {
    logs = {
      name                  = "app-config-all-logs"
      log_groups            = ["allLogs"]
      metric_categories     = []
      workspace_resource_id = dependency.monitoring.outputs.resource_id
    }
  }

  role_assignments = {
    uai_contributor = {
      principal_id         = dependency.identity.outputs.principal_id
      role_definition_name = "App Configuration Data Reader"
      description          = "User Assigned Identity has read access to the App Configuration"
    }
    datenprodukt_identity_reader = {
      principal_id         = dependency.datenprodukt_identity.outputs.principal_id
      role_definition_name = "App Configuration Data Reader"
      description          = "Datenprodukt Identity has read access to the App Configuration"
    }
  }
}
