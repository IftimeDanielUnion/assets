# Key Vault for supplying Entra Id Secrets

terraform {
  source = "../../../../../modules//keyvault"
}

dependency "identity" {
  config_path = "${get_terragrunt_dir()}/../identity"
  mock_outputs = {
    resource_id  = "/subscriptions/12345678-1234-9876-4563-123456789012/resourceGroups/example-resource-group/providers/Microsoft.ManagedIdentity/userAssignedIdentities/identityValue"
    principal_id = "12345678-1234-1234-1234-123456789012"
  }
}

dependency "datenprodukt-identity" {
  config_path = "${get_terragrunt_dir()}/../datenprodukt-identity"
  mock_outputs = {
    resource_id  = "/subscriptions/12345678-1234-9876-4563-123456789012/resourceGroups/example-resource-group/providers/Microsoft.ManagedIdentity/userAssignedIdentities/identityValue"
    principal_id = "12345678-1234-1234-1234-123456789012"
  }
}

dependency "monitoring" {
  config_path = "${get_terragrunt_dir()}/../monitoring"

  mock_outputs = {
    resource_id = "/subscriptions/12345678-1234-9876-4563-123456789012/resourceGroups/example-resource-group/providers/Microsoft.OperationalInsights/workspaces/workspaceValue"
  }
}

inputs = {
  component_name = "secrets-entra-id"

  diagnostic_settings = {
    logs = {
      name                           = "kv-all-logs"
      log_groups                     = ["allLogs"]
      log_analytics_destination_type = "Dedicated"
      workspace_resource_id          = dependency.monitoring.outputs.resource_id
    }
  }

  role_assignments = {
    uai_secrets_user = {
      role_definition_name = "Key Vault Secrets User"
      principal_id         = dependency.identity.outputs.principal_id
      description          = "User Assigned Identity has permission to access the KeyVault"
    }
    uai_secrets_datenprodukt_user = {
      role_definition_name = "Key Vault Secrets User"
      principal_id         = dependency.datenprodukt-identity.outputs.principal_id
      description          = "User Assigned Identity has permission to access the KeyVault"
    }
  }

  tags = {
    component = "Entra ID Secrets"
    purpose   = "app-internal use"
  }

}
