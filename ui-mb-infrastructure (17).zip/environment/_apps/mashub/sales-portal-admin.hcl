terraform {
  source = "../../../../../modules//staticwebapp"
}

inputs = {
  component_name = "sales-portal-admin"

  static_web_app_location = "westeurope"
}
