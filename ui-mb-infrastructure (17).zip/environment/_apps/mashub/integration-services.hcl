terraform {
  source = "../../../../../modules//functions"
}

dependency "monitoring" {
  config_path = "${get_terragrunt_dir()}/../monitoring"
  mock_outputs = {
    resource_id = "/subscriptions/12345678-1234-9876-4563-123456789012/resourceGroups/example-resource-group/providers/Microsoft.OperationalInsights/workspaces/workspaceValue"
    application_insights = {
      connection_string = "string-sample"
    }
  }
}

dependency "identity" {
  config_path = "${get_terragrunt_dir()}/../identity"
  mock_outputs = {
    resource_id = "/subscriptions/12345678-1234-9876-4563-123456789012/resourceGroups/example-resource-group/providers/Microsoft.ManagedIdentity/userAssignedIdentities/identityValue"
  }
}

locals {
  environment_vars = read_terragrunt_config(find_in_parent_folders("env.hcl"))

  env = local.environment_vars.locals.environment
}

inputs = {
  component_name = "integration-services"
  runtime = {
    stack   = "java"
    version = "17"
  }

  alerts = {
    resource_group_name = dependency.monitoring.outputs.resource_group
    metric_alerts = {
      cpu = {
        name        = "TAB - Function CPU Usage (%scope_name%) S_MARKTBEARBEITUNG_${upper(local.env)}"
        description = "CPU Auslastung des Function servers %scope_name% ist in den letzten 15 Minuten 80% oder höher."
        enabled     = true
        frequency   = "PT5M" # Abfrageintervall
        severity    = 2
        window_size = "PT15M" # Betrachtungszeitraum
        criteria = [{
          metric_namespace = "Microsoft.Web/serverFarms"
          metric_name      = "CpuPercentage"
          aggregation      = "Average"
          operator         = "GreaterThan"
          threshold        = 80
        }]
        actions = concat(
          [{
            action_group_id = dependency.monitoring.outputs.action_groups["incidents"].resource_id
          }],
          contains(["test", "prod"], local.env) ? [{
            action_group_id = dependency.monitoring.outputs.action_groups["tab"].resource_id
          }] : []
        )
      }
    }
  }
  cors = {
    allowed_origins = ["https://portal.azure.com"]
  }
  functions = {
    eazi = {
      name          = "eazi-integration"
      discovery_key = "func-eazi-integration"
    }
    ump = {
      name          = "ump-integration"
      discovery_key = "func-ump-integration"
    }
    pbm = {
      name          = "pbm-integration"
      discovery_key = "func-pbm-integration"
    }
    finco = {
      name          = "finco-integration"
      discovery_key = "func-finco-integration"
    }
  }
  health_check = {
    eviction_time_in_min = 3
    path                 = "/api/q/health"
    monitoring_alert = {
      actions = concat(
        [{
          action_group_id = dependency.monitoring.outputs.action_groups["incidents"].resource_id
        }],
        contains(["test", "prod"], local.env) ? [{
          action_group_id = dependency.monitoring.outputs.action_groups["tab"].resource_id
        }] : []
      )# This group is defined in _apps/mashub/monitoring.hcl
      resource_group_name = dependency.monitoring.outputs.resource_group
    }
  }
  logging = {
    application_insights_connection_string = dependency.monitoring.outputs.application_insights.connection_string
  }
  storage_account = {
    private_endpoints = ["blob", "table"]
  }
  tags = {
    component = "Integration Services"
  }
  user_assigned_resource_ids = [dependency.identity.outputs.resource_id]
}
