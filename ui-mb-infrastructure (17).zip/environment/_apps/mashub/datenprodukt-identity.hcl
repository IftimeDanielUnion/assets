terraform {
  source = "../../../../../modules//user-managed-identity"
}

inputs = {
  component_name = "datenprodukt-identity"
}
