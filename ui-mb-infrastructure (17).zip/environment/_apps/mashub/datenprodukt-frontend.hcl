terraform {
  source = "../../../../../modules//staticwebapp"
}

inputs = {
  component_name = "datenprodukt-fe" # Gekürzt von "datenprodukt-frontend"

  static_web_app_location = "westeurope"
}
