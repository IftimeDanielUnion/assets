terraform {
  source = "../../../../../modules//postgresql"
}

dependency "monitoring" {
  config_path = "${get_terragrunt_dir()}/../monitoring"

  mock_outputs = {
    resource_id = "/subscriptions/12345678-1234-9876-4563-123456789012/resourceGroups/example-resource-group/providers/Microsoft.OperationalInsights/workspaces/workspaceValue"
  }
}

dependency "backup_vault" {
  config_path = "${get_terragrunt_dir()}/../backup-vault"

  mock_outputs = {
    vault_id                    = "/subscriptions/12345678-1234-9876-4563-123456789012/resourceGroups/example-resource-group/providers/Microsoft.DataProtection/backupVaults/vaultValue"
    backup_policy_id            = "/subscriptions/12345678-1234-9876-4563-123456789012/resourceGroups/example-resource-group/providers/Microsoft.DataProtection/backupVaults/vaultValue/backupPolicies/policyValue"
    vault_identity_principal_id = "12345678-1234-1234-1234-123456789012"
  }
}

locals {
  environment_vars = read_terragrunt_config(find_in_parent_folders("env.hcl"))
  env              = local.environment_vars.locals.environment
}

inputs = {
  component_name = "database"

  sku_settings = {
    name    = "Standard_D2ds_v5"
    tier    = "GeneralPurpose"
    storage = 32
  }

  # PostgreSQL Flexible Server has built-in daily backups (independent of Azure Backup Vault)
  # Azure Backup Vault provides additional weekly backups for long-term retention
  retention_days = 14 # Daily automated backups retention

  # you can add more parameters and override these in the enviroment-specific inputs.
  server_parameters = {
    "azure.extensions" = "pg_cron" # this must be a comma separated list of all extensions
  }

  # Backup configuration - now handled internally by the module
  backup_vault_id           = dependency.backup_vault.outputs.vault_id
  backup_policy_id          = dependency.backup_vault.outputs.backup_policy_id
  backup_vault_principal_id = dependency.backup_vault.outputs.vault_identity_principal_id

  alerts = {
    resource_group_name = dependency.monitoring.outputs.resource_group

    metric_alerts = {
      cpu_usage = {
        name        = "TAB - Postgres CPU Usage S_MARKTBEARBEITUNG_${upper(local.env)}"
        description = "CPU Auslastung der Postgres DB ist in den letzten 15 Minuten 80% oder höher."
        severity    = 2
        enabled     = true
        frequency   = "PT5M"  # Abfrageintervall
        window_size = "PT15M" # Betrachtungszeitraum

        criteria = [{
          metric_namespace = "Microsoft.DBforPostgreSQL/flexibleServers"
          metric_name      = "cpu_percent"
          aggregation      = "Average"
          operator         = "GreaterThan"
          threshold        = 80
        }]

        actions = concat(
          [{
            action_group_id = dependency.monitoring.outputs.action_groups["incidents"].resource_id
          }],
          contains(["test", "prod"], local.env) ? [{
            action_group_id = dependency.monitoring.outputs.action_groups["tab"].resource_id
          }] : []
        )
      },
      autogrowth = {
        name        = "TAB - Postgres Autogrowth S_MARKTBEARBEITUNG_${upper(local.env)}"
        description = "Festplattenspeicher der Postgres DB ist zu 79% gefüllt. Autogrowth findet ab 80% statt (automatische Vergrößerung des Festplattenspeichers). Überprüfen, ob Datenzuwachs plausibel und gerechtfertigt. Kosten im Blick behalten."
        severity    = 2
        enabled     = true
        frequency   = "PT5M" # Abfrageintervall
        window_size = "PT1H" # Betrachtungszeitraum

        criteria = [{
          metric_namespace = "Microsoft.DBforPostgreSQL/flexibleServers"
          metric_name      = "storage_percent"
          aggregation      = "Maximum"
          operator         = "GreaterThan"
          threshold        = 79
        }]

        actions = concat(
          [{
            action_group_id = dependency.monitoring.outputs.action_groups["incidents"].resource_id
          }],
          contains(["test", "prod"], local.env) ? [{
            action_group_id = dependency.monitoring.outputs.action_groups["tab"].resource_id
          }] : []
        )
      }
      cpu_percent = {
        name        = "TAB - Postgres CPU Percentage S_MARKTBEARBEITUNG_${upper(local.env)}"
        description = "Die CPU Auslastung der Postgres DB ist in der letzten Stunde über 90%"
        severity    = 2
        enabled     = true
        frequency   = "PT1M" # Abfrageintervall
        window_size = "PT1H" # Betrachtungszeitraum

        criteria = [{
          metric_namespace = "Microsoft.DBforPostgreSQL/flexibleServers"
          metric_name      = "cpu_percent"
          aggregation      = "Average"
          operator         = "GreaterThan"
          threshold        = 90
        }]

        actions = concat(
          [{
            action_group_id = dependency.monitoring.outputs.action_groups["incidents"].resource_id
          }],
          contains(["test", "prod"], local.env) ? [{
            action_group_id = dependency.monitoring.outputs.action_groups["tab"].resource_id
          }] : []
        )
      },
      storage_percent = {
        name        = "TAB - Postgres High Disk Usage S_MARKTBEARBEITUNG_${upper(local.env)}"
        description = "Die Festplattennutzung der Postgres DB ist in den letzten 15 Minuten 90% oder höher."
        severity    = 1
        enabled     = true
        frequency   = "PT1M"  # Abfrageintervall
        window_size = "PT15M" # Betrachtungszeitraum

        criteria = [{
          metric_namespace = "Microsoft.DBforPostgreSQL/flexibleServers"
          metric_name      = "storage_percent"
          aggregation      = "Average"
          operator         = "GreaterThan"
          threshold        = 90
        }]

        actions = concat(
          [{
            action_group_id = dependency.monitoring.outputs.action_groups["incidents"].resource_id
          }],
          contains(["test", "prod"], local.env) ? [{
            action_group_id = dependency.monitoring.outputs.action_groups["tab"].resource_id
          }] : []
        )
      },
      disk_iops_consumed_percentage = {
        name        = "TAB - Postgres High IOPS Consumption Percentage S_MARKTBEARBEITUNG_${upper(local.env)}"
        description = "Der IOPS-Verbrauch der Postgres DB ist in den letzten 5 Minuten über 95%"
        severity    = 2
        enabled     = true
        frequency   = "PT1M" # Abfrageintervall
        window_size = "PT5M" # Betrachtungszeitraum

        criteria = [{
          metric_namespace = "Microsoft.DBforPostgreSQL/flexibleServers"
          metric_name      = "disk_iops_consumed_percentage"
          aggregation      = "Average"
          operator         = "GreaterThan"
          threshold        = 95
        }]

        actions = concat(
          [{
            action_group_id = dependency.monitoring.outputs.action_groups["incidents"].resource_id
          }],
          contains(["test", "prod"], local.env) ? [{
            action_group_id = dependency.monitoring.outputs.action_groups["tab"].resource_id
          }] : []
        )
      },
      memory_percent = {
        name        = "TAB - Postgres High Memory Load S_MARKTBEARBEITUNG_${upper(local.env)}"
        description = "Die Speichernutzung der Postgres DB ist in der letzten Stunden über 90%"
        severity    = 2
        enabled     = true
        frequency   = "PT1M" # Abfrageintervall
        window_size = "PT1H" # Betrachtungszeitraum

        criteria = [{
          metric_namespace = "Microsoft.DBforPostgreSQL/flexibleServers"
          metric_name      = "memory_percent"
          aggregation      = "Average"
          operator         = "GreaterThan"
          threshold        = 90
        }]

        actions = concat(
          [{
            action_group_id = dependency.monitoring.outputs.action_groups["incidents"].resource_id
          }],
          contains(["test", "prod"], local.env) ? [{
            action_group_id = dependency.monitoring.outputs.action_groups["tab"].resource_id
          }] : []
        )
      },
      is_db_alive = {
        name        = "TAB - Postgres not alive S_MARKTBEARBEITUNG_${upper(local.env)}"
        description = "Die Datenbank Postgres scheint ausgefallen zu sein"
        severity    = 1
        enabled     = true
        frequency   = "PT1M" # Abfrageintervall
        window_size = "PT5M" # Betrachtungszeitraum

        criteria = [{
          metric_namespace = "Microsoft.DBforPostgreSQL/flexibleServers"
          metric_name      = "is_db_alive"
          aggregation      = "Average"
          operator         = "LessThan"
          threshold        = 1
        }]

        actions = concat(
          [{
            action_group_id = dependency.monitoring.outputs.action_groups["incidents"].resource_id
          }],
          contains(["test", "prod"], local.env) ? [{
            action_group_id = dependency.monitoring.outputs.action_groups["tab"].resource_id
          }] : []
        )
      },
    }
  }

  diagnostic_settings = {
    db_logs = {
      name                  = "database-all-logs"
      log_groups            = ["allLogs"]
      metric_categories     = []
      workspace_resource_id = dependency.monitoring.outputs.resource_id
    }
  }
}
