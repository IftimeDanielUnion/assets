terraform {
  source = "../../../../../modules//blob-storage"
}

dependency "identity" {
  config_path = "${get_terragrunt_dir()}/../identity"
  mock_outputs = {
    resource_id  = "/subscriptions/12345678-1234-9876-4563-123456789012/resourceGroups/example-resource-group/providers/Microsoft.ManagedIdentity/userAssignedIdentities/identityValue"
    principal_id = "12345678-1234-1234-1234-123456789012"
  }
}

dependency "datenprodukt_identity" {
  config_path = "${get_terragrunt_dir()}/../datenprodukt-identity"
  mock_outputs = {
    resource_id  = "/subscriptions/12345678-1234-9876-4563-123456789012/resourceGroups/example-resource-group/providers/Microsoft.ManagedIdentity/userAssignedIdentities/identityValue"
    principal_id = "12345678-1234-1234-1234-123456789012"
  }
}

dependency "monitoring" {
  config_path = "${get_terragrunt_dir()}/../monitoring"

  mock_outputs = {
    resource_id = "/subscriptions/12345678-1234-9876-4563-123456789012/resourceGroups/example-resource-group/providers/Microsoft.OperationalInsights/workspaces/workspaceValue"
  }
}

dependency "backup_vault" {
  config_path = "${get_terragrunt_dir()}/../backup-vault"

  mock_outputs = {
    vault_id                    = "/subscriptions/12345678-1234-9876-4563-123456789012/resourceGroups/example-resource-group/providers/Microsoft.DataProtection/backupVaults/vaultValue"
    vault_identity_principal_id = "12345678-1234-1234-1234-123456789012"
  }
}

locals {
  environment_vars = read_terragrunt_config(find_in_parent_folders("env.hcl"))
  env              = local.environment_vars.locals.environment
}

inputs = {
  component_name = "doc-store" #i.e. document-store (too long for storage account)

  # Enable Azure Backup for TEST and PROD
  enable_azure_backup                   = contains(["test", "prod"], local.env)
  backup_vault_id                       = contains(["test", "prod"], local.env) ? dependency.backup_vault.outputs.vault_id : null
  backup_vault_principal_id             = contains(["test", "prod"], local.env) ? dependency.backup_vault.outputs.vault_identity_principal_id : null
  backup_policy_blob_retention_duration = "P14D" # 14 days retention

  alerts = {
    resource_group_name = dependency.monitoring.outputs.resource_group

    metric_alerts = {
      blob_capacity = {
        name        = "TAB - blob storage capacity (%scope_name%) in S_MARKTBEARBEITUNG_${upper(local.env)}"
        description = "Genutzter Storage Account Blob Speicher %scope_name% hat 1 GiB überschritten. Auf Plausibilität überprüfen und ggf. Threshold erhöhen."
        severity    = 3
        enabled     = true
        frequency   = "PT1H" # Abfrageintervall
        window_size = "PT1H" # Betrachtungszeitraum

        criteria = [{
          metric_name = "BlobCapacity"
          aggregation = "Average"
          operator    = "GreaterThan"
          threshold   = 1073741824
        }]

        actions = concat(
          [{
            action_group_id = dependency.monitoring.outputs.action_groups["incidents"].resource_id
          }],
          contains(["test", "prod"], local.env) ? [{
            action_group_id = dependency.monitoring.outputs.action_groups["tab"].resource_id
          }] : []
        )
      }
    }
  }

  containers = {
    documents = {
      public_access = "None"
      name          = "resources"
    }
    upload = {
      public_access = "None"
      name          = "service-package-resources"
    }
    eazi-docs = {
      public_access = "None"
      name          = "eazi-documents"
    }
    dialogeinwilligung-docs = {
      public_access = "None"
      name          = "dialogeinwilligung-documents"
    }
  }

  role_assignments = {
    uai_owner = {
      principal_id               = dependency.identity.outputs.principal_id
      role_definition_id_or_name = "Storage Blob Data Owner"
      description                = "User Assigned Identity has Owner Role to access Index-Tags (written by Defender)"
    }
    datenprodukt_identity_owner = {
      principal_id               = dependency.datenprodukt_identity.outputs.principal_id
      role_definition_id_or_name = "Storage Blob Data Owner"
      description                = "Datenprodukt Identity has Owner Role to access storage account"
    }
  }

  # Backup-Features aktiviert für Datensicherheit
  # - Versioning: Ermöglicht Wiederherstellung früherer Versionen
  # - Change Feed: Audit-Trail für alle Änderungen
  # - Soft Delete: 14 Tage Retention für gelöschte Blobs und Container
  # - Point-in-Time Restore: Wiederherstellung zu einem bestimmten Zeitpunkt
  # - Azure Backup: Zusätzliche Backup-Ebene mit 14 Tagen Retention (TEST/PROD)
  #
  # WICHTIG: Feste Werte für alle Environments verwenden!
  # Azure erlaubt keine gleichzeitige Änderung von delete_retention und restore_policy
  # wenn dabei die Constraint "delete > restore" temporär verletzt würde.
  blob_properties = {
    versioning_enabled  = true
    change_feed_enabled = true

    # Feste Werte - NICHT environment-abhängig machen!
    # delete_retention MUSS > restore_policy sein
    delete_retention_policy = {
      days = 15
    }

    container_delete_retention_policy = {
      days = 14
    }

    restore_policy = {
      days = 14
    }
  }

  storage_management_policy_rule = {
    delete_blobs = {
      enabled = true
      name    = "delete-eazi-documents"
      actions = {
        base_blob = {
          delete_after_days_since_modification_greater_than = 42
        }
      }
      filters = {
        blob_types   = ["blockBlob"]
        prefix_match = ["eazi-documents/"]
      }
    }
    delete_dialogeinwilligung_blobs = {
      enabled = true
      name    = "delete-dialogeinwilligung-documents"
      actions = {
        base_blob = {
          delete_after_days_since_modification_greater_than = 84
        }
      }
      filters = {
        blob_types   = ["blockBlob"]
        prefix_match = ["dialogeinwilligung-documents/"]
      }
    }
  }

}
