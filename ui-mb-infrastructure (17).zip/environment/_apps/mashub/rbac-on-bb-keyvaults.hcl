# RBAC on Building Block KeyVault Resources
# This does _not_ create any resource but only assign roles to existing resources
# There is no proper sense in a global config of this, therefore _inputs_ shall be given in env-dependent files

terraform {
  source = "../../../../../modules//rbac-assignment"
}

dependency "identity" {
  config_path = "${get_terragrunt_dir()}/../identity"
  mock_outputs = {
    resource_id  = "/subscriptions/12345678-1234-9876-4563-123456789012/resourceGroups/example-resource-group/providers/Microsoft.ManagedIdentity/userAssignedIdentities/identityValue"
    principal_id = "12345678-1234-1234-1234-123456789012"
  }
}
