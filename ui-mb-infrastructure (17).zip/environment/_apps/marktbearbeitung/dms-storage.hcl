terraform {
  source = "../../../../../modules//blob-storage"
}

inputs = {
  component_name             = "dms-storage"
  allow_anonymous_containers = true
  use_with_app_gateway       = true # a network rule allows access to only the app gateway subnet
  shared_access_key_enabled  = true

  containers = {
    anonymous_thumbnail = {
      public_access = "Blob"
      name          = "thumbnails"
    }
    private_materials = {
      public_access = "None"
      name          = "materials"
    }
  }

  # Backup-Features aktiviert für Datensicherheit
  # - Versioning: Ermöglicht Wiederherstellung früherer Versionen
  # - Change Feed: Audit-Trail für alle Änderungen
  # - Soft Delete: 14 Tage Retention für gelöschte Blobs und Container
  # - Point-in-Time Restore: Wiederherstellung zu einem bestimmten Zeitpunkt
  blob_properties = {
    versioning_enabled  = true
    change_feed_enabled = true

    delete_retention_policy = {
      days = 14
    }

    container_delete_retention_policy = {
      days = 14
    }

    restore_policy = {
      days = 13 # Muss kleiner sein als delete_retention_policy
    }
  }
}
