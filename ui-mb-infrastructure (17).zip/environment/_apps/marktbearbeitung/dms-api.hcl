terraform {
  source = "../../../../../modules//functionapp"
}

dependency "monitoring" {
  config_path = "${get_terragrunt_dir()}/../monitoring"

  mock_outputs = {
    resource_id = "/subscriptions/12345678-1234-9876-4563-123456789012/resourceGroups/example-resource-group/providers/Microsoft.OperationalInsights/workspaces/workspaceValue"
    application_insights = {
      connection_string = "string-sample"
    }
  }
}

inputs = {
  component_name = "dms-api"

  discovery_key = "func-dms-api"
  logging = {
    application_insights_connection_string = dependency.monitoring.outputs.application_insights.connection_string
  }
  runtime = {
    stack   = "java"
    version = "21"
  }

  # UI-CHG-0091618: Plattform-Health-Check fuer die Java Function App.
  # Der Pfad entspricht dem etablierten Quarkus-Health-Muster der anderen
  # Java Function Apps in diesem Repository. Das Alerting bleibt unveraendert.
  health_check = {
    eviction_time_in_min = 3
    path                 = "/api/q/health"
  }
  storage_account = {
    private_endpoints = ["blob", "table"]
  }
}