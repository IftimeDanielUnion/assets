terraform {
  source = "../../../../../modules//log-and-monitor"
}

inputs = {
  component_name = "monitoring"
  integrate_application_insights = true
  action_group_map_key = "incidents"

  tags = {
    component = "Logging and Monitoring"
  }
}
