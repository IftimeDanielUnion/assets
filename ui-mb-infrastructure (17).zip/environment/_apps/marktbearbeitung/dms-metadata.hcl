terraform {
  source = "../../../../../modules//table-storage"
}

inputs = {
  component_name = "dms-metadata"
  tables = {
    thumbnails = {
      name = "ThumbnailMetadata"
    }
    materials = {
      name = "DocumentMetadata"
    }
  }
}
