terraform {
  source = "../../../../../modules//staticwebapp"
}

inputs = {
  component_name = "frontend"

  static_web_app_location = "westeurope" # Service itself is not available in swedencentral.
}
