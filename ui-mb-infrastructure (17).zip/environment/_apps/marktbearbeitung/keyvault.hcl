terraform {
  source = "../../../../../modules//keyvault"
}

dependency "monitoring" {
  config_path = "${get_terragrunt_dir()}/../monitoring"

  mock_outputs = {
    resource_id = "/subscriptions/12345678-1234-9876-4563-123456789012/resourceGroups/example-resource-group/providers/Microsoft.OperationalInsights/workspaces/workspaceValue"
  }
}

inputs = {
  component_name = "shared-secrets"
  diagnostic_settings = {
    logs = {
      name                           = "kv-audit-logs"
      log_groups                     = ["audit"]
      log_analytics_destination_type = "Dedicated"
      metric_categories              = []
      workspace_resource_id          = dependency.monitoring.outputs.resource_id
    }
  }
  tags = {
    component = "Internal Secrets"
    purpose   = "app-internal use"
  }
}
