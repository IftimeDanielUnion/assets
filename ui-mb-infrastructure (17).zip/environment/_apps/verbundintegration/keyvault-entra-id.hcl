# Key Vault für die von den Entra-Kollegen bereitgestellten Client-ID/Client-Secret
# der truuco-proxy- und vbst-Entra-Applikationen.
# Schreibrechte für die Entra-Kollegen werden separat über einen CIS Change
# "RBAC Self-Service: Gruppen Freischaltung" plus anschließendes Role Assignment
# ("Key Vault Secrets Officer") ergänzt -- bewusst NICHT hier hinterlegt.

terraform {
  source = "../../../../../modules//keyvault"
}

dependency "identity" {
  config_path = "${get_terragrunt_dir()}/../identity"

  mock_outputs = {
    resource_id  = "/subscriptions/12345678-1234-9876-4563-123456789012/resourceGroups/example-resource-group/providers/Microsoft.ManagedIdentity/userAssignedIdentities/identityValue"
    principal_id = "12345678-1234-1234-1234-123456789012"
  }
  mock_outputs_merge_strategy_with_state = "shallow"
}

# DBI-9169: Function-Backend (vbst) benötigt Lesezugriff auf diesen KeyVault.
# An der Function hängen zwei Managed Identities (System-Assigned + UAI).
# DefaultAzureCredential wählt im Zweifel die System-Assigned Identity --
# daher braucht auch sie hier eine Rolle, damit der Zugriff ohne explizite
# AZURE_CLIENT_ID-Konfiguration im Backend funktioniert.
# Symmetrisch zur Lösung in keyvault-internal.hcl. Möglich, weil dieser KV
# NEU angelegt wird (Pipeline-SP hat Anlegerechte und damit auch Rechte zum
# Setzen von Role Assignments -- im Gegensatz zum bestehenden keyvault-internal).
dependency "functionapp" {
  config_path = "${get_terragrunt_dir()}/../functionapp"

  mock_outputs = {
    system_assigned_principal_id = "12345678-1234-1234-1234-123456789012"
  }
  mock_outputs_merge_strategy_with_state = "shallow"
}

dependency "monitoring" {
  config_path = "${get_terragrunt_dir()}/../monitoring"

  mock_outputs = {
    resource_id = "/subscriptions/12345678-1234-9876-4563-123456789012/resourceGroups/example-resource-group/providers/Microsoft.OperationalInsights/workspaces/workspaceValue"
  }
  mock_outputs_merge_strategy_with_state = "shallow"
}

inputs = {
  component_name = "secrets-entra-id"

  # Das in env.hcl konfigurierte default-Subnet (172.28.14.128/26) hat keine
  # freien IPs mehr fuer neue Private Endpoints. Da dieser KV neu angelegt wird,
  # legen wir ihn direkt im dafuer vorgesehenen privateendpoints-Subnet an
  # (gleiches Muster wie im-action-hub und mashub).
  # Bestehende PEs (keyvault-internal, functionapp Storage) bleiben unangetastet
  # in default, weil ein subnet_id-Wechsel ein force-new auf azurerm_private_endpoint
  # ausloesen wuerde.
  vnet_subnet_name_privateendpoints = "privateendpoints"

  diagnostic_settings = {
    logs = {
      name                           = "kv-all-logs"
      log_groups                     = ["allLogs"]
      metric_categories              = []
      log_analytics_destination_type = "Dedicated"
      workspace_resource_id          = dependency.monitoring.outputs.resource_id
    }
  }

  # Self-Service-fähige Rolle (siehe "Role Assignment für Azure Workloads"):
  # "Key Vault Secrets User" wird hier für BEIDE an der Function hängenden
  # Identities gesetzt. So funktioniert der Zugriff unabhängig davon, welche
  # Identity DefaultAzureCredential im Backend tatsächlich auswählt (DBI-9169).
  role_assignments = {
    uai_secrets_user = {
      role_definition_name = "Key Vault Secrets User"
      principal_id         = dependency.identity.outputs.principal_id
      description          = "User Assigned Identity has permission to read secrets from the Entra ID KeyVault"
    }
    func_secrets_user = {
      role_definition_name = "Key Vault Secrets User"
      principal_id         = dependency.functionapp.outputs.system_assigned_principal_id
      description          = "System Assigned Identity of vbst Function App has permission to read secrets from the Entra ID KeyVault (DBI-9169)"
    }
  }

  tags = {
    component = "Entra ID Secrets"
    purpose   = "app-internal use"
  }
}
