terraform {
  source = "../../../../../modules//keyvault"
}

dependency "functionapp" {
  config_path = "${get_terragrunt_dir()}/../functionapp"

  mock_outputs = {
    system_assigned_principal_id = "12345678-1234-1234-1234-123456789012"
  }
}

dependency "monitoring" {
  config_path = "${get_terragrunt_dir()}/../monitoring"

  mock_outputs = {
    resource_id = "/subscriptions/12345678-1234-9876-4563-123456789012/resourceGroups/example-resource-group/providers/Microsoft.OperationalInsights/workspaces/workspaceValue"
  }
}

inputs = {
  component_name = "secrets-internal"

  diagnostic_settings = {
    logs = {
      name                           = "kv-all-logs"
      log_groups                     = ["allLogs"]
      metric_categories              = []
      log_analytics_destination_type = "Dedicated"
      workspace_resource_id          = dependency.monitoring.outputs.resource_id
    }
  }

  # Nur die System-Assigned Identity der Function bekommt Lesezugriff.
  #
  # Hinweis: Eine zusätzliche Rolle für die User Assigned Identity wurde bewusst
  # entfernt -- der Pipeline-Service-Principal hat in TEST/PROD nur Contributor
  # auf existierenden KVs und kann dort keine neuen Role Assignments anlegen
  # (Microsoft.Authorization/roleAssignments/write fehlt).
  #
  # Beim spaeteren Backend-Umstieg auf die UAI gibt es zwei Wege:
  #  1. Backend-Code waehlt pro KV explizit die Identity (system-assigned fuer
  #     keyvault-internal, UAI fuer keyvault-entra-id) via
  #     ManagedIdentityCredentialBuilder().clientId(...). Dann bleibt diese
  #     Datei unveraendert.
  #  2. CIS-Change, der dem Pipeline-SP "User Access Administrator" auf den
  #     bestehenden KV gibt; danach kann hier eine UAI-Rolle ergaenzt werden.
  role_assignments = {
    func_secrets_user = {
      role_definition_name = "Key Vault Secrets User"
      principal_id         = dependency.functionapp.outputs.system_assigned_principal_id
      description          = "Identity of Function App has permission to access the KeyVault"
    }
  }

  tags = {
    component = "Internal Secrets"
    purpose   = "app-internal use"
  }
}
