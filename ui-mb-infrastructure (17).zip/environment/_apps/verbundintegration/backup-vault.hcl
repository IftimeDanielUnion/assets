terraform {
  source = "../../../../../modules//backup-vault"
}

dependency "monitoring" {
  config_path = "${get_terragrunt_dir()}/../monitoring"

  mock_outputs = {
    resource_id = "/subscriptions/12345678-1234-9876-4563-123456789012/resourceGroups/example-resource-group/providers/Microsoft.OperationalInsights/workspaces/workspaceValue"
  }
}

# Note: Azure Data Protection Backup Vault only supports System Assigned Identity
# The plattform backup identity is managed separately via manual RBAC assignments

locals {
  environment_vars = read_terragrunt_config(find_in_parent_folders("env.hcl"))
  env              = local.environment_vars.locals.environment

  # Environment-specific backup configurations
  # NOTE: Azure PostgreSQL Flexible Server with zone redundancy (high availability)
  # only supports weekly backups due to compliance restrictions.
  # See: https://learn.microsoft.com/en-us/azure/postgresql/flexible-server/concepts-backup-restore
  backup_config = {
    dev = {
      schedule_interval = "R/2024-01-01T02:00:00+00:00/P1W" # Weekly on Sundays at 2 AM
      retention_days    = 14
      redundancy        = "LocallyRedundant"
    }
    test = {
      schedule_interval = "R/2024-01-01T02:00:00+00:00/P1W" # Weekly on Sundays at 2 AM (changed from daily due to zone redundancy)
      retention_days    = 14
      redundancy        = "ZoneRedundant" # ZRS for redundancy testing
    }
    prod = {
      schedule_interval = "R/2024-01-01T02:00:00+00:00/P1W" # Weekly on Sundays at 2 AM (changed from daily due to zone redundancy)
      retention_days    = 14
      redundancy        = "GeoRedundant" # Cross-region for PROD
    }
  }

  # Generate backup vault name pattern for monitoring queries
  # Pattern varies by environment: dev/prod use 'vbst', test uses 'vbi'
  backup_vault_name_pattern = local.env == "test" ? "bv-vbi-${local.env}-backup-vault" : "bv-vbst-${local.env}-backup-vault"
}

inputs = {
  component_name = "backup-vault"

  # Note: Backup Vault uses System Assigned Identity (only supported type)
  # RBAC for plattform backup identity is managed via manual Change Requests

  # Environment-specific backup settings
  backup_schedule_interval = local.backup_config[local.env].schedule_interval
  retention_days           = local.backup_config[local.env].retention_days
  backup_vault_redundancy  = local.backup_config[local.env].redundancy

  # Soft delete for PROD only
  soft_delete_enabled = local.env == "prod" ? true : false

  # Private endpoint disabled for now
  enable_private_endpoint = false

  # Monitoring integration
  diagnostic_settings = {
    logs = {
      name                           = "backup-vault-all-logs"
      log_groups                     = ["allLogs"]
      log_analytics_destination_type = "Dedicated"
      workspace_resource_id          = dependency.monitoring.outputs.resource_id
    }
  }

  # Backup Vault Monitoring and Alerting
  alerts = {
    resource_group_name = dependency.monitoring.outputs.resource_group

    log_analytics_alerts = {
      backup_job_failures = {
        name                  = "TAB - Backup Job Failures (%scope_name%) S_VERBUNDINTEGRATION_${upper(local.env)}"
        description           = "Backup jobs for %scope_name% have failed in the last 2 days."
        enabled               = true
        evaluation_frequency  = "P1D" # Check once per day
        severity              = 1     # Critical
        window_duration       = "P2D" # Look back 2 days (maximum allowed)
        workspace_resource_id = dependency.monitoring.outputs.resource_id

        criteria = [{
          query                   = <<-QUERY
            AddonAzureBackupJobs
            | where JobOperation == "Backup"
            | where VaultName contains "${local.backup_vault_name_pattern}"
            | where JobStatus == "Failed"
            | where TimeGenerated > ago(2d)
            | summarize FailedJobs = count()
          QUERY
          time_aggregation_method = "Total"
          metric_measure_column   = "FailedJobs"
          threshold               = 0
          operator                = "GreaterThan"
        }]

        # TAB-Action-Group (cis-tab) ist in monitoring.hcl vorerst auskommentiert.
        # Guard via keys(): die TAB-Referenz greift automatisch wieder, sobald die
        # Gruppe dort einkommentiert wird (test/prod). Fehlt der "tab"-Key, bleibt es
        # bei incidents – KEIN "Invalid index"-Fehler mehr.
        actions = concat(
          [{
            action_group_id = dependency.monitoring.outputs.action_groups["incidents"].resource_id
          }],
          contains(keys(dependency.monitoring.outputs.action_groups), "tab") ? [{
            action_group_id = dependency.monitoring.outputs.action_groups["tab"].resource_id
          }] : []
        )
      }

      backup_job_duration = {
        name                  = "TAB - Long Running Backup Jobs (%scope_name%) S_VERBUNDINTEGRATION_${upper(local.env)}"
        description           = "Backup jobs for %scope_name% are taking longer than expected (>4 hours)."
        enabled               = true
        evaluation_frequency  = "P1D" # Check once per day
        severity              = 2     # Warning
        window_duration       = "P2D" # Look back 2 days (maximum allowed)
        workspace_resource_id = dependency.monitoring.outputs.resource_id

        criteria = [{
          query                   = <<-QUERY
            AddonAzureBackupJobs
            | where JobOperation == "Backup"
            | where VaultName contains "${local.backup_vault_name_pattern}"
            | where TimeGenerated > ago(2d)
            | where isnotempty(JobDurationInSecs)
            | extend DurationHours = todouble(JobDurationInSecs) / 3600
            | where DurationHours > 4
            | summarize LongRunningJobs = count()
          QUERY
          time_aggregation_method = "Total"
          metric_measure_column   = "LongRunningJobs"
          threshold               = 0
          operator                = "GreaterThan"
        }]

        # TAB-Action-Group (cis-tab) ist in monitoring.hcl vorerst auskommentiert.
        # Guard via keys(): die TAB-Referenz greift automatisch wieder, sobald die
        # Gruppe dort einkommentiert wird (test/prod). Fehlt der "tab"-Key, bleibt es
        # bei incidents – KEIN "Invalid index"-Fehler mehr.
        actions = concat(
          [{
            action_group_id = dependency.monitoring.outputs.action_groups["incidents"].resource_id
          }],
          contains(keys(dependency.monitoring.outputs.action_groups), "tab") ? [{
            action_group_id = dependency.monitoring.outputs.action_groups["tab"].resource_id
          }] : []
        )
      }

      missing_backup_jobs = {
        name                  = "TAB - Missing Backup Jobs (%scope_name%) S_VERBUNDINTEGRATION_${upper(local.env)}"
        description           = "Expected weekly backup jobs for %scope_name% have not run in the expected timeframe (>7 days)."
        enabled               = true
        evaluation_frequency  = "P1D" # Check once per day
        severity              = 1     # Critical
        window_duration       = "P2D" # Look back 2 days (maximum allowed)
        workspace_resource_id = dependency.monitoring.outputs.resource_id

        criteria = [{
          query                   = <<-QUERY
            let ExpectedInterval = 7d;
            let evalTime = now();
            let Lookback = 90d;
            let LastBackup = toscalar(
              AddonAzureBackupJobs
              | where JobOperation == "Backup"
              | where VaultName contains "${local.backup_vault_name_pattern}"
              | where TimeGenerated between (evalTime - Lookback .. evalTime)
              | summarize max(TimeGenerated)
            );
            print
              TimeGenerated = evalTime,
              MissingJobs = iif(isnull(LastBackup) or (evalTime - LastBackup) > ExpectedInterval, 1, 0)
          QUERY
          time_aggregation_method = "Total"
          metric_measure_column   = "MissingJobs"
          threshold               = 0
          operator                = "GreaterThan"
        }]

        # TAB-Action-Group (cis-tab) ist in monitoring.hcl vorerst auskommentiert.
        # Guard via keys(): die TAB-Referenz greift automatisch wieder, sobald die
        # Gruppe dort einkommentiert wird (test/prod). Fehlt der "tab"-Key, bleibt es
        # bei incidents – KEIN "Invalid index"-Fehler mehr.
        actions = concat(
          [{
            action_group_id = dependency.monitoring.outputs.action_groups["incidents"].resource_id
          }],
          contains(keys(dependency.monitoring.outputs.action_groups), "tab") ? [{
            action_group_id = dependency.monitoring.outputs.action_groups["tab"].resource_id
          }] : []
        )
      }
    }
  }

  tags = {
    component = "Backup Vault"
    purpose   = "PostgreSQL Database Backup"
  }
}
