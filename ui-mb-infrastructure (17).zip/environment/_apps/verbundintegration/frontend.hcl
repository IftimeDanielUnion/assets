terraform {
  source = "../../../../../modules//staticwebapp"
}

inputs = {
  component_name = "fe" # gekürzt von frontend

  static_web_app_location = "westeurope"
}
