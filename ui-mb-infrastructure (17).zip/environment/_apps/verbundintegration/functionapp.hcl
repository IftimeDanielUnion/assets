terraform {
  source = "../../../../../modules//functionapp"
}

dependency "monitoring" {
  config_path = "${get_terragrunt_dir()}/../monitoring"

  mock_outputs = {
    resource_id    = "/subscriptions/12345678-1234-9876-4563-123456789012/resourceGroups/example-resource-group/providers/Microsoft.OperationalInsights/workspaces/workspaceValue"
    resource_group = "example-resource-group"
    application_insights = {
      connection_string = "string-sample"
    }
    action_groups = {
      incidents = {
        resource_id = "/subscriptions/12345678-1234-9876-4563-123456789012/resourceGroups/example-resource-group/providers/Microsoft.Insights/actionGroups/groupValue"
      }
    }
  }
}

dependency "identity" {
  config_path = "${get_terragrunt_dir()}/../identity"

  mock_outputs = {
    resource_id  = "/subscriptions/12345678-1234-9876-4563-123456789012/resourceGroups/example-resource-group/providers/Microsoft.ManagedIdentity/userAssignedIdentities/identityValue"
    principal_id = "12345678-1234-1234-1234-123456789012"
  }
  mock_outputs_merge_strategy_with_state = "shallow"
}

locals {
  environment_vars = read_terragrunt_config(find_in_parent_folders("env.hcl"))
  env              = local.environment_vars.locals.environment

  # Für dev werden KEINE Alerts angelegt – Alerting nur in test und prod
  # (identisch zu monitoring.hcl / database.hcl aus DBI-6755).
  create_alerts = contains(["test", "prod"], local.env)
}

inputs = {
  component_name = "integration-logic"

  runtime = {
    stack   = "java"
    version = "17"
  }
  discovery_key = "func-integration-logic"
  logging = {
    application_insights_connection_string = dependency.monitoring.outputs.application_insights.connection_string
  }
  storage_account = {
    private_endpoints = ["blob", "table", "queue"]
  }

  # DBI-6762: Allgemeine Metriken (CPU, RAM) des App Service Plans der Function App
  # (Muster analog zu _apps/mashub/integration-services.hcl)
  # In dev leer -> keine Metric-Alert-Regeln.
  alerts = {
    resource_group_name = dependency.monitoring.outputs.resource_group

    metric_alerts = local.create_alerts ? {
      ## Was:   Feuert bei anhaltend >=80% CPU auf dem App Service Plan der Function (15 min).
      ## Wie:   Plattform-Metrik CpuPercentage auf Microsoft.Web/serverFarms, Average.
      ## Beleg: Muster identisch zu _apps/mashub/integration-services.hcl (produktiv bewaehrt).
      cpu = {
        name        = "TAB - Function CPU Usage (%scope_name%) S_MARKTBEARBEITUNG_${upper(local.env)}"
        description = "CPU Auslastung des Function servers %scope_name% ist in den letzten 15 Minuten 80% oder höher."
        enabled     = true
        frequency   = "PT5M"  # Abfrageintervall
        severity    = 2
        window_size = "PT15M" # Betrachtungszeitraum
        criteria = [{
          metric_namespace = "Microsoft.Web/serverFarms"
          metric_name      = "CpuPercentage"
          aggregation      = "Average"
          operator         = "GreaterThan"
          threshold        = 80
        }]
        # TAB-Action-Group (cis-tab) ist in monitoring.hcl vorerst auskommentiert.
        # Guard via keys(): greift automatisch wieder, sobald die Gruppe dort
        # einkommentiert wird – kein "Invalid index" bei fehlender Gruppe.
        actions = concat(
          [{
            action_group_id = dependency.monitoring.outputs.action_groups["incidents"].resource_id
          }],
          contains(keys(dependency.monitoring.outputs.action_groups), "tab") ? [{
            action_group_id = dependency.monitoring.outputs.action_groups["tab"].resource_id
          }] : []
        )
      }

      ## Was:   Feuert bei anhaltend >=85% RAM auf dem App Service Plan (15 min).
      ## Wie:   Plattform-Metrik MemoryPercentage auf Microsoft.Web/serverFarms, Average.
      ## Beleg: Ergaenzt die JVM-Heap-Thematik: ohne explizites -Xmx nimmt sich jede JVM ~25% des sichtbaren RAM.
      memory = {
        name        = "TAB - Function Memory Usage (%scope_name%) S_MARKTBEARBEITUNG_${upper(local.env)}"
        description = "RAM Auslastung des Function servers %scope_name% ist in den letzten 15 Minuten 85% oder höher."
        enabled     = true
        frequency   = "PT5M"
        severity    = 2
        window_size = "PT15M"
        criteria = [{
          metric_namespace = "Microsoft.Web/serverFarms"
          metric_name      = "MemoryPercentage"
          aggregation      = "Average"
          operator         = "GreaterThan"
          threshold        = 85
        }]
        actions = concat(
          [{
            action_group_id = dependency.monitoring.outputs.action_groups["incidents"].resource_id
          }],
          contains(keys(dependency.monitoring.outputs.action_groups), "tab") ? [{
            action_group_id = dependency.monitoring.outputs.action_groups["tab"].resource_id
          }] : []
        )
      }
    } : {}
  }

  # Zusätzlich zur bestehenden System-Assigned Identity wird eine User Assigned
  # Identity angehängt (identisches Muster wie im-action-hub/mashub). Die bestehende
  # System-Assigned Identity bleibt dabei erhalten (das functionapp-Modul setzt dann
  # type = "SystemAssigned, UserAssigned"), Rollenzuweisungen darauf (z.B. auf
  # keyvault-internal) bleiben gültig.
  #
  # HINWEIS Backend: Sobald mehrere Managed Identities an die Function angehängt
  # sind, muss der DefaultAzureCredential explizit wissen, welche Identity er
  # verwenden soll, z.B. über das App-Setting AZURE_CLIENT_ID (Client-ID der UAI)
  # oder durch explizite Verwendung von ManagedIdentityCredentialBuilder().clientId(...)
  # im Java-Code. Siehe VbstKeyVault.java.
  user_assigned_resource_ids = [dependency.identity.outputs.resource_id]

  # Azure AD Authentication Settings werden umgebungsspezifisch in den jeweiligen
  # environment/{dev,test,prod}/applications/verbundintegration/functionapp/terragrunt.hcl definiert
}
