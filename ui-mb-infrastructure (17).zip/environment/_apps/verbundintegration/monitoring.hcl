terraform {
  source = "../../../../../modules//log-and-monitor"
}

locals {
  environment_vars = read_terragrunt_config(find_in_parent_folders("env.hcl"))
  env              = local.environment_vars.locals.environment

  # Für dev werden KEINE Alerts angelegt – Alerting nur in test und prod.
  # Die Monitoring-Komponente selbst (Application Insights, Action Group) bleibt
  # in dev bestehen, damit die Function App weiterhin ihre AI-Connection bekommt.
  create_alerts = contains(["test", "prod"], local.env)
}

inputs = {
  component_name                 = "monitoring"
  integrate_application_insights = true
  action_group_map_key = "incidents"
  # Action Groups für Benachrichtigungen
  action_groups = merge(
    {
      incidents = {
        short_name = "vbst-inc"
        tags = {
          monitoring = "incidents"
        }
        email_receiver = [{
          name          = "VBST Monitoring: New Incident"
          email_address = "monitoring_vbst+${local.env}@union-investment.de"
        }]
      }
    },
    # --- TAB (cis-tab) VORERST DEAKTIVIERT ---
    # Analog zu mashub wird die TAB-Action-Group nur in test/prod ergänzt.
    # Erst aktivieren, wenn ALLE Monitoring-Branches implementiert sind und alle
    # Alerts sauber feuern. ZUM AKTIVIEREN GENÜGT das Einkommentieren des folgenden
    # Blocks: alle Consumer (database.hcl, functionapp.hcl, backup-vault.hcl) hängen
    # die TAB-Gruppe dann automatisch an (Guard via keys(...action_groups)), kein
    # manuelles Nachziehen nötig.
    # contains(["test", "prod"], local.env) ? {
    #   tab = {
    #     short_name = "TAB-Mail"
    #     tags = {
    #       monitoring = "tab"
    #     }
    #     email_receiver = [{
    #       name          = "VBST Monitoring: New Incident"
    #       email_address = "cis-tab@union-investment.de"
    #     }]
    #   }
    # } : {},
    {}
  )

  # Scheduled Log Alerts für Function App Monitoring (Application Insights)
  # In dev leer -> es werden keine Alert-Regeln angelegt.
  scheduled_log_alerts = { for alert_name, alert in {
    checkAnlassStatusChange_execution_alert = {
      name                 = "TAB - Function checkAnlassStatusChange - No Execution Alert S_MARKTBEARBEITUNG_${upper(local.env)}"
      description          = "Die Funktion checkAnlassStatusChange wurde in der letzten Stunde nicht ausgeführt. Dies könnte auf ein Problem mit dem Timer Trigger hinweisen."
      action_group_map_key = "incidents"
      enabled              = true
      auto_mitigation_enabled = true
      evaluation_frequency = "PT15M" # Alle 15 Minuten prüfen
      severity             = 2       # Warning
      window_duration      = "PT1H"  # Betrachtungszeitraum: 1 Stunde

      criteria = [{
        query                   = <<-QUERY
            requests
            | where timestamp > ago(1h)
            | where name == "checkAnlassStatusChange"
            | where cloud_RoleName contains "integration-logic"
            | summarize ExecutionCount = count()
          QUERY
        time_aggregation_method = "Total"
        metric_measure_column   = "ExecutionCount"
        threshold               = 1
        operator                = "LessThan"
      }]
    }

    ## DBI-6755: Datenbankfehler aus Anwendungssicht (fehlgeschlagene DB-Dependencies)
    ## Was:   Feuert bei >5 fehlgeschlagenen DB-Zugriffen der Anwendung in 15 min.
    ## Wie:   App-Insights 'dependencies' (OTel-JDBC): jeder Postgres-Call landet dort mit success-Flag; gezählt wird countif-frei via where success==false.
    ## Beleg: Filter trifft real: type=='postgresql' mit Target psql-*.postgres.database.azure.com in PROD-Telemetrie nachgewiesen.
    db_dependency_failures_alert = {
      name                 = "TAB - VBST DB Dependency Failures S_MARKTBEARBEITUNG_${upper(local.env)}"
      description          = "Gehäufte fehlgeschlagene Datenbank-Aufrufe (SQL-/Connection-Exceptions) der vbst Function App auf die PostgreSQL-Datenbank in den letzten 15 Minuten."
      action_group_map_key = "incidents"
      enabled              = true
      evaluation_frequency = "PT5M"
      severity             = 2
      window_duration      = "PT15M"

      criteria = [{
        query                   = <<-QUERY
            dependencies
            | where cloud_RoleName contains "integration-logic" or cloud_RoleName == "verbundintegration-backend"
            // OTel-JDBC-Dependency, type "postgresql", target "psql-vbst-<env>-database-*.postgres.database.azure.com | vbidb"
            | where type == "postgresql" or target contains "postgres.database.azure.com"
            | where success == false
            | summarize FailedCalls = count()
          QUERY
        time_aggregation_method = "Total"
        metric_measure_column   = "FailedCalls"
        threshold               = 5 # PLATZHALTER: Schwellwert nach Beobachtung in DEV/TEST justieren
        operator                = "GreaterThan"
      }]
    }

    ## DBI-6762: Error Logs / Exceptions der Function App
    ## (Query-Muster analog zum etablierten mbportal-Alert "TAB - Error logs").
    ## Telemetrie-Zuordnung (TEST+PROD verifiziert, 07/2026): requests+traces laufen
    ## unter dem Host-RoleName (func-*-integration-logic-*), dependencies unter
    ## "verbundintegration-backend" (OTel), exceptions unter beiden.
    ## Was:   Feuert bei >3 echten Fehlern (Exceptions + Error-Traces) in 15 min.
    ## Wie:   exceptions UNION traces(sev>=3); Stackframes ('at ...') und bekanntes Vert.x-Rauschen sind excludiert, damit ein Fehler = ~1 Zeile statt ~10.
    ## Beleg: Baseline C1/C3: ungefiltert waeren 52% aller Fenster rot (Dauerfeuer); nach Filterung bleiben ~4-7 echte Fehler/Tag.
    function_error_logs_alert = {
      name                 = "TAB - VBST Error Logs S_MARKTBEARBEITUNG_${upper(local.env)}"
      description          = "Gehäufte Error Logs oder Exceptions in der vbst Function App in den letzten 15 Minuten (über dem Grundrauschen)."
      action_group_map_key = "incidents"
      enabled              = true
      evaluation_frequency = "PT5M"
      severity             = 2
      window_duration      = "PT15M"

      criteria = [{
        query                   = <<-QUERY
            exceptions
            | union (traces | where severityLevel >= 3)
            | where cloud_RoleName contains "integration-logic" or cloud_RoleName == "verbundintegration-backend"
            // Rauschfilter (Baseline C3, 07/2026): Stackframe-Zeilen ("at ...") blähen
            // jeden Fehler ~10x auf; "Connection was closed" ist bekanntes Vert.x-Rauschen
            // (~60/Tag, korreliert mit Truuco-Resets und wird dort separat alertiert).
            // FP-Fix 07/2026: exceptions tragen den Text in outerMessage (message ist
            // dort leer) – ohne coalesce rutschten HttpClosedExceptions am Filter vorbei.
            | extend message = coalesce(message, outerMessage, "")
            // Analyse 07/2026: die HttpClosedException stammt aus fehlgeschlagenen
            // Telemetrie-Posts an *.in.applicationinsights.azure.com (AI-Ingest), NICHT
            // aus dem Business-API internal.api (das zur Alarmzeit fehlerfrei war).
            // Reines Telemetrie-Pfad-Rauschen -> typbasiert ausschliessen, robuster als
            // reines Text-Matching (greift auch bei abweichendem Meldungstext).
            | extend exType = coalesce(column_ifexists("type", ""), column_ifexists("innermostType", ""))
            | where exType != "io.vertx.core.http.HttpClosedException"
            | where message !startswith "at "
            | where message !has "Connection was closed"
            // FP-Fix 07/2026: fachlicher Normalfall – Delivery wartet auf laufende Jobs
            // ("Found N job(s) ready or running"); Log-Text enthaelt "Error", ist aber keiner.
            | where message !has "Wait until all jobs are done"
            | summarize ErrorCount = count()
          QUERY
        time_aggregation_method = "Total"
        metric_measure_column   = "ErrorCount"
        # PLATZHALTER: Nach den Rauschfiltern oben bleiben laut Baseline (C3, 7d)
        # nur ~4-7 echte Fehlermeldungen pro Tag. Schwelle 3/15min meldet damit
        # jede Häufung, ohne bei Einzelfehlern zu feuern.
        threshold               = 3
        operator                = "GreaterThan"
      }]
    }

    ## DBI-6762: Timer Trigger laufen nicht im erwarteten Zeitfenster.
    ## Sampling ist app-seitig bereits deaktiviert (host.json samplingSettings.isEnabled=false),
    ## damit sind Ausführungszählungen über requests verlässlich.
    ## checkAnlassStatusChange (10-Minuten-Trigger) ist oben bereits abgedeckt.
    ## Was:   Feuert, wenn der 1-Minuten-Timer checkAnlassCompletion 30 min lang nicht lief.
    ## Wie:   Functions-Host schreibt jede Timer-Ausfuehrung als 'requests'-Eintrag (name=@FunctionName); summarize count() liefert auch auf leerer Menge eine 0-Zeile, LessThan 1 greift.
    ## Beleg: Name code-verifiziert (@FunctionName); Baseline C2: max. Luecke 5 min (PROD) / 11 min (TEST) - Fenster 30 min hat Puffer.
    timer_checkAnlassCompletion_alert = {
      name                 = "TAB - Function checkAnlassCompletion - No Execution Alert S_MARKTBEARBEITUNG_${upper(local.env)}"
      description          = "Die Funktion checkAnlassCompletion (1-Minuten-Timer) wurde in den letzten 30 Minuten nicht ausgeführt."
      action_group_map_key = "incidents"
      enabled              = true
      auto_mitigation_enabled = true
      evaluation_frequency = "PT15M"
      severity             = 2
      window_duration      = "PT30M"

      criteria = [{
        query                   = <<-QUERY
            requests
            | where name == "checkAnlassCompletion"
            | where cloud_RoleName contains "integration-logic" or cloud_RoleName == "verbundintegration-backend"
            | summarize ExecutionCount = count()
          QUERY
        time_aggregation_method = "Total"
        metric_measure_column   = "ExecutionCount"
        threshold               = 1
        operator                = "LessThan"
      }]
    }

    ## Was:   Feuert, wenn der 10-Minuten-Timer checkForNewDelivery 1 h lang nicht lief.
    ## Wie:   Wie oben: requests-Zaehlung des Hosts, LessThan-1-Muster (identisch zum produktiven checkAnlassStatusChange-Alert).
    ## Beleg: Name code-verifiziert; Baseline C2: max. Luecke 30 min (PROD) / 20 min (TEST) < 1-h-Fenster.
    timer_checkForNewDelivery_alert = {
      name                 = "TAB - Function checkForNewDelivery - No Execution Alert S_MARKTBEARBEITUNG_${upper(local.env)}"
      description          = "Die Funktion checkForNewDelivery (10-Minuten-Timer) wurde in der letzten Stunde nicht ausgeführt."
      action_group_map_key = "incidents"
      enabled              = true
      auto_mitigation_enabled = true
      evaluation_frequency = "PT15M"
      severity             = 2
      window_duration      = "PT1H"

      criteria = [{
        query                   = <<-QUERY
            requests
            | where name == "checkForNewDelivery"
            | where cloud_RoleName contains "integration-logic" or cloud_RoleName == "verbundintegration-backend"
            | summarize ExecutionCount = count()
          QUERY
        time_aggregation_method = "Total"
        metric_measure_column   = "ExecutionCount"
        threshold               = 1
        operator                = "LessThan"
      }]
    }

    ## Was:   Feuert, wenn der 10-Minuten-Timer checkZielgruppenStatus 1 h lang nicht lief.
    ## Wie:   Wie oben: requests-Zaehlung des Hosts, LessThan-1-Muster.
    ## Beleg: Name code-verifiziert; Baseline C2: max. Luecke 20 min in beiden Envs < 1-h-Fenster.
    timer_checkZielgruppenStatus_alert = {
      name                 = "TAB - Function checkZielgruppenStatus - No Execution Alert S_MARKTBEARBEITUNG_${upper(local.env)}"
      description          = "Die Funktion checkZielgruppenStatus (10-Minuten-Timer) wurde in der letzten Stunde nicht ausgeführt."
      action_group_map_key = "incidents"
      enabled              = true
      auto_mitigation_enabled = true
      evaluation_frequency = "PT15M"
      severity             = 2
      window_duration      = "PT1H"

      criteria = [{
        query                   = <<-QUERY
            requests
            | where name == "checkZielgruppenStatus"
            | where cloud_RoleName contains "integration-logic" or cloud_RoleName == "verbundintegration-backend"
            | summarize ExecutionCount = count()
          QUERY
        time_aggregation_method = "Total"
        metric_measure_column   = "ExecutionCount"
        threshold               = 1
        operator                = "LessThan"
      }]
    }

    ## Was:   Feuert, wenn der 30-Minuten-Timer syncImpulsrueckmeldungen 2 h lang nicht lief.
    ## Wie:   Wie oben: requests-Zaehlung des Hosts, LessThan-1-Muster.
    ## Beleg: Name code-verifiziert; Baseline C2: max. Luecke exakt 30 min in beiden Envs < 2-h-Fenster.
    timer_syncImpulsrueckmeldungen_alert = {
      name                 = "TAB - Function syncImpulsrueckmeldungen - No Execution Alert S_MARKTBEARBEITUNG_${upper(local.env)}"
      description          = "Die Funktion syncImpulsrueckmeldungen (30-Minuten-Timer) wurde in den letzten 2 Stunden nicht ausgeführt."
      action_group_map_key = "incidents"
      enabled              = true
      auto_mitigation_enabled = true
      evaluation_frequency = "PT30M"
      severity             = 2
      window_duration      = "PT2H"

      criteria = [{
        query                   = <<-QUERY
            requests
            | where name == "syncImpulsrueckmeldungen"
            | where cloud_RoleName contains "integration-logic" or cloud_RoleName == "verbundintegration-backend"
            | summarize ExecutionCount = count()
          QUERY
        time_aggregation_method = "Total"
        metric_measure_column   = "ExecutionCount"
        threshold               = 1
        operator                = "LessThan"
      }]
    }

    ## Nachjustierung: autoCloseExpiredCustomers laeuft taeglich um 00:05 UTC.
    ## Was:   Feuert zustandsbehaftet, wenn der erwartete Tageslauf nach einem 2-h-Puffer fehlt.
    ## Wie:   Bis 02:05 UTC wird der vorherige Tageslauf bewertet, danach der aktuelle Tageslauf.
    ##        Dadurch bleibt ein bestehender Ausfall ueber Mitternacht aktiv und erzeugt keine stuendliche Mailserie.
    ## Beleg: Das bisherige rollende 24-h-Fenster war fuer einen exakt taeglichen Timer zu knapp.
    timer_autoCloseExpiredCustomers_alert = {
      name                     = "TAB - Function autoCloseExpiredCustomers - No Execution Alert S_MARKTBEARBEITUNG_${upper(local.env)}"
      description              = "Die Funktion autoCloseExpiredCustomers (taeglich 00:05 UTC) wurde nach einem 2-Stunden-Puffer nicht ausgefuehrt."
      action_group_map_key     = "incidents"
      enabled                  = true
      auto_mitigation_enabled = true
      evaluation_frequency     = "PT1H"
      severity                 = 2
      window_duration          = "P2D"

      criteria = [{
        query                   = <<-QUERY
            let currentDayStartUtc = startofday(now());
            let currentRunCheckDueUtc = currentDayStartUtc + 2h + 5m;
            let expectedRunWindowStartUtc = iff(
              now() >= currentRunCheckDueUtc,
              currentDayStartUtc,
              currentDayStartUtc - 1d
            );
            requests
            | where timestamp >= expectedRunWindowStartUtc
            | where name == "autoCloseExpiredCustomers"
            | where cloud_RoleName contains "integration-logic" or cloud_RoleName == "verbundintegration-backend"
            | summarize ExecutionCount = count()
          QUERY
        time_aggregation_method = "Total"
        metric_measure_column   = "ExecutionCount"
        threshold               = 1
        operator                = "LessThan"
      }]
    }

    ## DBI-9677: Nachrichten in Poison Queues.
    ## Jede Poison Queue hat eine dedizierte Consumer-Function (Suffix "Poison") –
    ## eine Ausführung bedeutet: mindestens eine Nachricht ist in der Poison Queue gelandet.
    ## Abgedeckt: sendanlasstosolid-poison, sendanlassupdatetosolid-poison,
    ## createzielgruppe-poison, updatezielgruppe-poison, autocloseexpiredcustomers-poison,
    ## checkzielgruppenstatusconsumer-poison, analyseimpulsrueckmeldungenconsumer-poison.
    ## Korrelation: traces enthalten "invocationId=... functionName=..." (LoggingAdapter).
    ## Historie (D1, 30d) belegt den Alert-Wert: u.a. ~1.760 createZielgruppe-Poison-
    ## Nachrichten am 02./03.06.2026 in PROD sowie wiederkehrende sendAnlass*-Poison in TEST.
    ## Was:   Feuert bei jeder Nachricht, die in einer Poison Queue landet; Dimension 'name' benennt die betroffene Queue.
    ## Wie:   Jede *-poison-Queue hat eine eigene Consumer-Function (Suffix 'Poison') - deren requests-Ausfuehrung IST der Nachweis der Poison-Nachricht.
    ## Beleg: 7 Poison-Functions decken exakt die 7 Poison-Queues (code-verifiziert); Historie D1: haette u.a. den 1.760er-Vorfall am 02./03.06. gemeldet.
    poison_queue_messages_alert = {
      name                 = "TAB - VBST Poison Queue Messages S_MARKTBEARBEITUNG_${upper(local.env)}"
      description          = "Mindestens eine Nachricht ist in einer Poison Queue der vbst Function App gelandet. Die Dimension 'name' zeigt die betroffene Poison-Consumer-Function (= Queue)."
      action_group_map_key = "incidents"
      enabled              = true
      evaluation_frequency = "PT5M"
      severity             = 1
      window_duration      = "PT15M"

      criteria = [{
        query                   = <<-QUERY
            requests
            | where cloud_RoleName contains "integration-logic" or cloud_RoleName == "verbundintegration-backend"
            | where name endswith "Poison"
            | summarize PoisonMessages = count() by name
          QUERY
        time_aggregation_method = "Total"
        metric_measure_column   = "PoisonMessages"
        threshold               = 0
        operator                = "GreaterThan"
        dimension = [{
          name     = "name"
          operator = "Include"
          values   = ["*"]
        }]
      }]
    }

    ## DBI-9677: Gehäuft fehlschlagende Queue-Verarbeitung (Verarbeitungsstau).
    ## Baseline (D2, 7d): max 2 (PROD) bzw. 4 (TEST) Fehler pro 30-min-Fenster –
    ## der TEST-4er war ein echter sendAnlassUpdateToSolid-Vorfall mit Poison-Folge,
    ## genau das soll der Alert melden. host.json maxDequeueCount=100.
    ## Was:   Feuert bei >3 fehlgeschlagenen Queue-Trigger-Ausfuehrungen in 30 min (Frueh-Indikator fuer Stau/Poison).
    ## Wie:   requests der 11 Queue-Consumer (Namen code-verifiziert) mit success==false; Dimension 'name' zeigt die betroffene Function.
    ## Beleg: Baseline D2: Normalbetrieb max 2/Fenster; der einzige TEST-Ausschlag (4) war ein echter Vorfall mit Poison-Folge - genau das Zielbild.
    queue_processing_failures_alert = {
      name                 = "TAB - VBST Queue Processing Failures S_MARKTBEARBEITUNG_${upper(local.env)}"
      description          = "Gehäufte fehlgeschlagene Ausführungen von Queue-Trigger-Functions in den letzten 30 Minuten (Nachrichten werden wiederholt requeued und nicht abgebaut)."
      action_group_map_key = "incidents"
      enabled              = true
      evaluation_frequency = "PT15M"
      severity             = 2
      window_duration      = "PT30M"

      criteria = [{
        query                   = <<-QUERY
            requests
            | where cloud_RoleName contains "integration-logic" or cloud_RoleName == "verbundintegration-backend"
            | where name in ("sendAnlassToSolid", "sendAnlassUpdateToSolid",
                             "checkCreateAnlass", "checkUpdateAnlass",
                             "checkCreateZielgruppe", "checkUpdateZielgruppe",
                             "createZielgruppe", "updateZielgruppe",
                             "autoCloseExpiredCustomersConsumer",
                             "checkZielgruppenStatusConsumer",
                             "analyseImpulsrueckmeldungenConsumer")
            | where success == false
            | summarize FailedExecutions = count() by name
          QUERY
        time_aggregation_method = "Total"
        metric_measure_column   = "FailedExecutions"
        threshold               = 3 # PLATZHALTER: Baseline max 2 (PROD) / 4 (TEST) pro 30 min
        operator                = "GreaterThan"
        dimension = [{
          name     = "name"
          operator = "Include"
          values   = ["*"]
        }]
      }]
    }

    ## DBI-9678: Externe Abhängigkeit Truuco (HTTP via truuco-proxy, TRUUCO_BASE_URL).
    ## Baseline (E1, 7d): PROD 49.7k Aufrufe, 5,8% Fehlerquote (~4,3 Fehler/15min
    ## Grundrauschen), p95 3,1s, p99 6,1s, Client-Timeout 30s (max_ms=30002 bestätigt).
    ## ACHTUNG TEST: aktuell 82% Fehlerquote (52.948/64.428) – Failures- und
    ## Latency-Alert stehen dort dauerhaft an, bis die Truuco-ABN-Anbindung
    ## repariert ist (separates Ticket empfohlen).
    ## Was:   Feuert bei >25 fehlgeschlagenen Truuco-Aufrufen in 15 min.
    ## Wie:   dependencies (OTel-HTTP): Truuco laeuft ueber den truuco-proxy, erkennbar am Target internal.api + Pfad /vbp/integration/.
    ## Beleg: Filter in PROD-Telemetrie nachgewiesen; Baseline E1: Grundrauschen Ø4,3 Fehler/15min (5,8%) - Schwelle meldet nur Ausbrueche.
    truuco_failures_alert = {
      name                 = "TAB - VBST Truuco Failures S_MARKTBEARBEITUNG_${upper(local.env)}"
      description          = "Gehäufte fehlgeschlagene Truuco-Aufrufe der vbst Function App in den letzten 15 Minuten."
      action_group_map_key = "incidents"
      // TEST ist bewusst deaktiviert: dort ist die Truuco-ABN-Anbindung aktuell nicht belastbar.
      // PROD bleibt aktiv. Damit wird der bekannte TEST-Drift (false -> true) nicht mehr zurückgedreht.
      enabled              = local.env != "test"
      evaluation_frequency = "PT5M"
      severity             = 2
      window_duration      = "PT15M"

      criteria = [{
        query                   = <<-QUERY
            dependencies
            | where cloud_RoleName contains "integration-logic" or cloud_RoleName == "verbundintegration-backend"
            // Truuco läuft via truuco-proxy als HTTP-Dependency gegen internal.api.union-investment.de
            // mit Pfaden /pc/vbp/integration/v1/... (PROD-verifiziert, 07/2026)
            | where target contains "internal.api" and name contains "/vbp/integration/"
            | where success == false
            | summarize FailedCalls = count()
          QUERY
        time_aggregation_method = "Total"
        metric_measure_column   = "FailedCalls"
        threshold               = 25 # PLATZHALTER: ~5x PROD-Grundrauschen (Ø 4,3/15min), meldet nur echte Ausbrüche
        operator                = "GreaterThan"
      }]
    }

    ## Was:   Feuert bei >3 Truuco-Aufrufen ueber 30 s in 15 min (Timeout-Welle).
    ## Wie:   dependencies.duration (ms) gegen die 30s-Grenze; gleiche Truuco-Erkennung wie oben.
    ## Beleg: Client-Timeout=30s per Baseline bestaetigt (max_ms=30002); PROD-p99=6,1s -> Treffer sind echte Timeouts, kein Rauschen.
    truuco_timeouts_alert = {
      name                 = "TAB - VBST Truuco Timeouts S_MARKTBEARBEITUNG_${upper(local.env)}"
      description          = "Mehrere Truuco-Aufrufe liefen länger als 30 Sekunden (Timeout-Verdacht)."
      action_group_map_key = "incidents"
      enabled              = true
      evaluation_frequency = "PT5M"
      severity             = 2
      window_duration      = "PT15M"

      criteria = [{
        query                   = <<-QUERY
            dependencies
            | where cloud_RoleName contains "integration-logic" or cloud_RoleName == "verbundintegration-backend"
            // Truuco läuft via truuco-proxy als HTTP-Dependency gegen internal.api.union-investment.de
            // mit Pfaden /pc/vbp/integration/v1/... (PROD-verifiziert, 07/2026)
            | where target contains "internal.api" and name contains "/vbp/integration/"
            | where duration > 30000 // Client-Timeout = 30s (Baseline E1: max_ms=30002 bestätigt)
            | summarize SlowCalls = count()
          QUERY
        time_aggregation_method = "Total"
        metric_measure_column   = "SlowCalls"
        threshold               = 3 # Baseline E1: >30s-Aufrufe in PROD selten (p99=6,1s) – feuert nur bei echten Timeout-Wellen
        operator                = "GreaterThan"
      }]
    }

    ## Was:   Feuert, wenn die Truuco-Durchschnittslatenz 30 min lang ueber 10 s liegt.
    ## Wie:   avg(duration) ueber alle Truuco-Dependencies im Fenster; Average-Aggregation der Measure-Spalte.
    ## Beleg: Baseline E1: PROD-p95=3,1s - ein 10s-Schnitt ueber 30 min ist zweifelsfrei eine Stoerung. ACHTUNG TEST: aktuell 82% Fehlerquote -> steht dort an.
    truuco_latency_alert = {
      name                 = "TAB - VBST Truuco Latency S_MARKTBEARBEITUNG_${upper(local.env)}"
      description          = "Die durchschnittliche Latenz der Truuco-Aufrufe lag in den letzten 30 Minuten über dem Schwellwert."
      action_group_map_key = "incidents"
      enabled              = true
      evaluation_frequency = "PT15M"
      severity             = 3
      window_duration      = "PT30M"

      criteria = [{
        query                   = <<-QUERY
            dependencies
            | where cloud_RoleName contains "integration-logic" or cloud_RoleName == "verbundintegration-backend"
            // Truuco läuft via truuco-proxy als HTTP-Dependency gegen internal.api.union-investment.de
            // mit Pfaden /pc/vbp/integration/v1/... (PROD-verifiziert, 07/2026)
            | where target contains "internal.api" and name contains "/vbp/integration/"
            | summarize AvgDurationMs = avg(duration)
          QUERY
        time_aggregation_method = "Average"
        metric_measure_column   = "AvgDurationMs"
        threshold               = 10000 # Baseline E1: PROD-Schnitt weit darunter (p95=3,1s) – 10s-Schnitt über 30min = echte Störung
        operator                = "GreaterThan"
      }]
    }

    ## DBI-9678: Externe Abhängigkeit vDWH (zweite JDBC-Datasource, Oracle, Port 15001)
    ## Was:   Feuert bei >3 fehlgeschlagenen vDWH-Zugriffen in 15 min (Lieferungsabfragen).
    ## Wie:   dependencies (OTel-JDBC, zweite Datasource): type=='SQL' mit vdwh*-Servicenamen im Target.
    ## Beleg: Filter in TEST+PROD nachgewiesen (vdwha1a/vdwhp1a:15001, je >250 Aufrufe, 0 Fehler in 7d).
    vdwh_failures_alert = {
      name                 = "TAB - VBST vDWH Failures S_MARKTBEARBEITUNG_${upper(local.env)}"
      description          = "Gehäufte fehlgeschlagene vDWH-Datenbankzugriffe (Lieferungsabfragen) der vbst Function App in den letzten 15 Minuten."
      action_group_map_key = "incidents"
      enabled              = true
      evaluation_frequency = "PT5M"
      severity             = 2
      window_duration      = "PT15M"

      criteria = [{
        query                   = <<-QUERY
            dependencies
            | where cloud_RoleName contains "integration-logic" or cloud_RoleName == "verbundintegration-backend"
            // vDWH = Oracle-JDBC-Dependency, type "SQL", target z.B. "10.250.251.91:15001 | vdwhp1a"
            // (TEST+PROD verifiziert: vdwha1a bzw. vdwhp1a auf Port 15001, je 0 Fehler in 7d)
            | where type == "SQL" and target contains "vdwh"
            | where success == false
            | summarize FailedCalls = count()
          QUERY
        time_aggregation_method = "Total"
        metric_measure_column   = "FailedCalls"
        threshold               = 3 # PLATZHALTER
        operator                = "GreaterThan"
      }]
    }

    ## DBI-9679: Health-Endpunkte melden DOWN (HTTP 5xx auf /api/health/*).
    ## Differenzierung über die Dimension 'name':
    ##   liveness  -> Anwendung lebt nicht
    ##   readyness -> Anwendung nicht bereit
    ##   healthz   -> mindestens eine Abhängigkeit (database, vdwh, blobstorage, queue, vbstkeyvault, truuco) nicht verfügbar
    ## Was:   Feuert, sobald ein Health-Endpunkt HTTP>=500 liefert; Dimension 'name' unterscheidet liveness/readyness/healthz (=welche Ebene down ist).
    ## Wie:   requests der drei anonymen Health-Functions; healthz aggregiert die Abhaengigkeiten (database, vdwh, blobstorage, queue, vbstkeyvault, truuco) und antwortet 503 bei DOWN.
    ## Beleg: Routen+AuthLevel code-verifiziert; erreichbar erst durch die excluded_paths/health_check-Fixes dieses Branches (vorher 401 vor der Function).
    health_endpoint_down_alert = {
      name                 = "TAB - VBST Health Endpoint DOWN S_MARKTBEARBEITUNG_${upper(local.env)}"
      description          = "Ein Health-Endpunkt der vbst Function App hat mit HTTP >= 500 geantwortet (Status DOWN). Dimension 'name' unterscheidet liveness/readyness/healthz."
      action_group_map_key = "incidents"
      enabled              = true
      evaluation_frequency = "PT5M"
      severity             = 1
      window_duration      = "PT15M"

      criteria = [{
        query                   = <<-QUERY
            requests
            | where cloud_RoleName contains "integration-logic" or cloud_RoleName == "verbundintegration-backend"
            | where name in ("liveness", "readyness", "healthz")
            | where toint(resultCode) >= 500
            | summarize DownResponses = count() by name
          QUERY
        time_aggregation_method = "Total"
        metric_measure_column   = "DownResponses"
        threshold               = 0
        operator                = "GreaterThan"
        dimension = [{
          name     = "name"
          operator = "Include"
          values   = ["*"]
        }]
      }]
    }

    ## DBI-9679: Ausbleibende Health-Check-Requests.
    ## Der App-Service-Health-Check pingt /api/health/live minütlich (siehe functionapp.hcl,
    ## health_check.path). Bleiben diese Requests aus, ist die Anwendung bzw. der Host tot.
    ## Hinweis: Externe Standard-Web-Tests sind nicht möglich, da die Function App mit
    ## public_network_access_enabled = false betrieben wird (siehe modules/functionapp).
    ## Was:   Feuert, wenn 30 min lang keine liveness-Pings ankommen (Anwendung/Host tot oder Ping-Kette gebrochen).
    ## Wie:   Der App-Service-Health-Check pingt /api/health/live minuetlich (site_config, dieser Branch) -> jeder Ping ist ein requests-Eintrag; LessThan-1 auf die Zaehlung.
    ## Beleg: Genau der Mechanismus, an dem der deaktivierte imhub-Alert scheiterte (kein Ping + falscher Name) - hier: Ping konfiguriert, Name 'liveness' code-verifiziert.
    health_liveness_missing_alert = {
      name                 = "TAB - VBST Liveness Pings Missing S_MARKTBEARBEITUNG_${upper(local.env)}"
      description          = "In den letzten 30 Minuten sind keine Health-Check-Requests auf /api/health/live eingegangen – die Anwendung ist vermutlich nicht erreichbar."
      action_group_map_key = "incidents"
      enabled              = true
      auto_mitigation_enabled = true
      evaluation_frequency = "PT5M"
      severity             = 1
      window_duration      = "PT30M"

      criteria = [{
        query                   = <<-QUERY
            requests
            | where cloud_RoleName contains "integration-logic" or cloud_RoleName == "verbundintegration-backend"
            | where name == "liveness"
            | summarize PingCount = count()
          QUERY
        time_aggregation_method = "Total"
        metric_measure_column   = "PingCount"
        threshold               = 1
        operator                = "LessThan"
      }]
    }

    ## DBI-9229: Fachliches Monitoring – Zielgruppen.
    ## Die Queries matchen auf die Log-Texte des Backends (LoggingAdapter, traces enthalten
    ## "invocationId=... functionName=... <Meldung>" inkl. vbpAnlassId und Dateiname der Lieferung).
    ## Was:   Feuert bei mindestens einer fehlgeschlagenen Zielgruppenlieferung/-update in 1 h; die Log-Zeile traegt vbpAnlassId+Dateiname der Lieferung.
    ## Wie:   traces-Match auf das exakte Backend-Literal ('Zielgruppe with vbpAnlassId: ... failed!'), geschrieben vom LoggingAdapter (inkl. invocationId/functionName zur Korrelation).
    ## Beleg: Literal woertlich code-verifiziert. Schwelle 0 (fachlich Markus Scholl): jeder Fehlschlag ist relevant; die frueheren 218 Treffer/30d waren ueberwiegend ein inzwischen in PROD gefixter Update-Bug.
    zielgruppen_delivery_failed_alert = {
      name                 = "TAB - VBST Zielgruppenlieferung fehlgeschlagen S_MARKTBEARBEITUNG_${upper(local.env)}"
      description          = "Eine Zielgruppenlieferung bzw. ein Update wurde als fehlgeschlagen markiert. Die Log-Meldung enthält vbpAnlassId und Dateiname der betroffenen Lieferung."
      action_group_map_key = "incidents"
      enabled              = true
      evaluation_frequency = "PT15M"
      severity             = 2
      window_duration      = "PT1H"

      criteria = [{
        query                   = <<-QUERY
            traces
            | where cloud_RoleName contains "integration-logic" or cloud_RoleName == "verbundintegration-backend"
            | where message contains "Zielgruppe with vbpAnlassId:" and message contains "failed!"
            | summarize FailedDeliveries = count()
          QUERY
        time_aggregation_method = "Total"
        metric_measure_column   = "FailedDeliveries"
        # Fachlich (Markus Scholl, PR 21.07.2026): jeder Fehlschlag soll sichtbar sein –
        # ein Fehlschlag bedeutet, dass Daten/Kunden nicht uebermittelt werden konnten.
        # Der fruehere Baseline-Wert (218 Treffer/30d) war groesstenteils ein inzwischen
        # in PROD gefixter Update-Bug (viele fehlgeschlagene Update-Lieferungen) und daher
        # nicht mehr repraesentativ. Aggregiert ueber das Fenster, Schwelle 0 -> jeder
        # Fehlschlag alarmiert.
        threshold               = 0
        operator                = "GreaterThan"
      }]
    }

    ## DBI-9229: Lieferung ohne valide Kunden (ersetzt frueheren "invalide Kundendaten"-Alert)
    ## Was:   Feuert, wenn in einer Zielgruppenlieferung KEIN Kunde valide war (Lieferung faktisch leer).
    ## Wie:   traces-Log "No valid customers found in delivery for massnahmenVariantId <id>"; Schwelle > 0,
    ##        jeder Fall ist relevant und umgeht zugleich das window_duration-Problem (ein Treffer alarmiert).
    ## Beleg: Fachlich (Markus Scholl, PR 21.07.2026): separater Alert auf einzelne invalide Kunden nicht
    ##        sinnvoll (10-Min-Polling, 1 Lieferung/Lauf -> Schwelle 10 praktisch nie erreichbar); dass
    ##        einzelne invalide Kunden im Log stehen, reicht laut Fachbereich. Aussagekraeftig ist der Fall
    ##        "gar kein Kunde valide" -> genau dieser Alert.
    zielgruppen_no_valid_customers_alert = {
      name                 = "TAB - VBST Lieferung ohne valide Kunden S_MARKTBEARBEITUNG_${upper(local.env)}"
      description          = "In einer Zielgruppenlieferung war kein Kunde valide (Log 'No valid customers found in delivery for massnahmenVariantId ...') – die Lieferung enthält keine übermittelbaren Kunden."
      action_group_map_key = "incidents"
      enabled              = true
      evaluation_frequency = "PT15M"
      severity             = 3
      window_duration      = "PT1H"

      criteria = [{
        query                   = <<-QUERY
            traces
            | where cloud_RoleName contains "integration-logic" or cloud_RoleName == "verbundintegration-backend"
            | where message has "No valid customers found in delivery for massnahmenVariantId"
            | summarize NoValidCustomers = count()
          QUERY
        time_aggregation_method = "Total"
        metric_measure_column   = "NoValidCustomers"
        threshold               = 0
        operator                = "GreaterThan"
      }]
    }

    ## Was:   Feuert bei jedem nicht wiederherstellbar invaliden Zielgruppen-Job (Lieferung unverarbeitbar).
    ## Wie:   traces-Match auf 'Job was invalid and it was not recoverable!'.
    ## Beleg: Literal code-verifiziert; Baseline G1: 0 Treffer/30d -> seltenes, aber immer meldewuerdiges Ereignis (Schwelle 0).
    zielgruppen_job_invalid_alert = {
      name                 = "TAB - VBST Zielgruppen-Job invalide S_MARKTBEARBEITUNG_${upper(local.env)}"
      description          = "Ein Zielgruppen-Job war invalide und nicht wiederherstellbar (Lieferung konnte nicht verarbeitet werden)."
      action_group_map_key = "incidents"
      enabled              = true
      evaluation_frequency = "PT15M"
      severity             = 2
      window_duration      = "PT30M"

      criteria = [{
        query                   = <<-QUERY
            traces
            | where cloud_RoleName contains "integration-logic" or cloud_RoleName == "verbundintegration-backend"
            | where message contains "Job was invalid and it was not recoverable!"
            | summarize InvalidJobs = count()
          QUERY
        time_aggregation_method = "Total"
        metric_measure_column   = "InvalidJobs"
        threshold               = 0
        operator                = "GreaterThan"
      }]
    }

    ## DBI-9229: SOLID-Synchronisation (deckt create, update und Poison-Pfad ab).
    ## Baseline (G1, 30d): seltene, heftige Ausbrüche (PROD: 719 an nur 4 Tagen,
    ## max 505/Tag; TEST: 2.314 an 10 Tagen) – Schwelle >0 ist gewollt, der Sev1-Alert
    ## steht während eines echten Sync-Ausfalls dauerhaft an.
    ## Was:   Feuert bei jeder fehlgeschlagenen SOLID-Synchronisation (create/update/Poison-Pfad), inkl. betroffener vbpAnlassId.
    ## Wie:   traces-Match auf 'synchronisation failed with anlass id' - der gemeinsame Kern beider Backend-Meldungen (create+update).
    ## Beleg: Literal code-verifiziert; Baseline G1: seltene, heftige Ausbrueche (max 505/Tag PROD) - Sev1 steht waehrend eines echten Ausfalls an, gewollt.
    solid_sync_failed_alert = {
      name                 = "TAB - VBST SOLID-Synchronisation fehlgeschlagen S_MARKTBEARBEITUNG_${upper(local.env)}"
      description          = "Ein Anlass (create/update) konnte nicht zu SOLID synchronisiert werden. Die Log-Meldung enthält die betroffene vbpAnlassId."
      action_group_map_key = "incidents"
      enabled              = true
      evaluation_frequency = "PT5M"
      severity             = 1
      window_duration      = "PT15M"

      criteria = [{
        query                   = <<-QUERY
            traces
            | where cloud_RoleName contains "integration-logic" or cloud_RoleName == "verbundintegration-backend"
            | where message contains "synchronisation failed with anlass id"
            | summarize FailedSyncs = count()
          QUERY
        time_aggregation_method = "Total"
        metric_measure_column   = "FailedSyncs"
        threshold               = 0
        operator                = "GreaterThan"
      }]
    }

    ## DBI-9229: Keine Zielgruppenlieferung am erwarteten Liefertag (Dienstag)
    ## Was:   Feuert, wenn der wöchentliche Dienstags-Lieferlauf ausgeblieben ist.
    ## Wie:   Die vDWH liefert ~1x/Woche, normalerweise dienstags (fachlich bestätigt). Geprüft wird
    ##        MITTWOCHS ab 12:00 Berlin-Zeit mit einem 48h-Fenster: das deckt den ganzen Dienstag ab
    ##        und bleibt innerhalb der 2-Tage-Grenze von Scheduled-Query-Alerts. An allen anderen
    ##        Tagen/Zeiten wird der Zähler auf 999 gesetzt (iff-Gate), sodass nur ein tatsächlich
    ##        ausgefallener Dienstagslauf alarmiert. Berlin-Zeit via datetime_utc_to_local (analog zum
    ##        Concentrix-Muster in mashub), damit die Tag-/Stundengrenzen korrekt liegen.
    ## Beleg: Fachliche Klärung 07/2026: Liefertag = Dienstag. Die früher als "Wochenend-Lücken"
    ##        gedeutete Baseline (14/31 Tage ohne Lieferung) ist der normale Wochenrhythmus – daher
    ##        KEIN tägliches Gate, sondern die gezielte Prüfung des Dienstags am Folgetag. Hinweis:
    ##        Defer-/Wait-Logs am Dienstag (Truuco noch nicht bereit, Prozess läuft) sind laut Fachbereich
    ##        normal und kein Fehler; dieser Alert prüft ausschließlich das Ausbleiben der Lieferung.
    zielgruppen_no_delivery_alert = {
      name                 = "TAB - VBST Keine Zielgruppenlieferung S_MARKTBEARBEITUNG_${upper(local.env)}"
      description          = "Der wöchentliche Zielgruppen-Lieferlauf (erwartet dienstags) ist ausgeblieben: im Dienstag-Fenster wurde keine Lieferung (create/update) verarbeitet."
      action_group_map_key = "incidents"
      enabled              = true
      auto_mitigation_enabled = true
      evaluation_frequency = "PT1H"
      severity             = 3
      window_duration      = "P2D"

      criteria = [{
        query                   = <<-QUERY
            // Erwarteter Liefertag: Dienstag. Prüfung am Mittwoch ab 12:00 (Berlin) mit 48h-Fenster,
            // das Dienstag abdeckt und in der 2-Tage-Grenze bleibt. Sonst Zähler = 999 -> kein Alarm.
            let jetztBerlin = datetime_utc_to_local(now(), "Europe/Berlin");
            let istPrueftag = dayofweek(jetztBerlin) == 3d and hourofday(jetztBerlin) >= 12;
            requests
            | where cloud_RoleName contains "integration-logic" or cloud_RoleName == "verbundintegration-backend"
            | where name in ("createZielgruppe", "updateZielgruppe")
            | summarize Deliveries = count()
            | extend Deliveries = iff(istPrueftag, Deliveries, tolong(999))
          QUERY
        time_aggregation_method = "Total"
        metric_measure_column   = "Deliveries"
        threshold               = 1
        operator                = "LessThan"
      }]
    }

    ## DBI-9229: Hohe Fehlerquote bei der Zielgruppenverarbeitung
    ## Was:   Feuert, wenn die Fehlerquote der Zielgruppen-Verarbeitung 1 h lang ueber 20% liegt.
    ## Wie:   requests der 4 Zielgruppen-Functions; Failed/Total als berechnete Spalte (iff faengt Division durch 0 ab, leere Stunde = 0%), Average-Aggregation.
    ## Beleg: Functionsnamen code-verifiziert; Quote statt Absolutzahl macht den Alert lastunabhaengig - fachliche 20% mit Christoph bestaetigen.
    zielgruppen_failure_rate_alert = {
      name                 = "TAB - VBST Zielgruppen Fehlerquote S_MARKTBEARBEITUNG_${upper(local.env)}"
      description          = "Die Fehlerquote der Zielgruppen-Verarbeitung lag in der letzten Stunde über dem Schwellwert."
      action_group_map_key = "incidents"
      enabled              = true
      evaluation_frequency = "PT15M"
      severity             = 2
      window_duration      = "PT1H"

      criteria = [{
        query                   = <<-QUERY
            requests
            | where cloud_RoleName contains "integration-logic" or cloud_RoleName == "verbundintegration-backend"
            | where name in ("createZielgruppe", "updateZielgruppe",
                             "checkCreateZielgruppe", "checkUpdateZielgruppe")
            | summarize Total = count(), Failed = countif(success == false)
            | extend FailureRatePct = iff(Total == 0, 0.0, todouble(Failed) * 100.0 / Total)
          QUERY
        time_aggregation_method = "Average"
        metric_measure_column   = "FailureRatePct"
        threshold               = 20 # PLATZHALTER: fachlich abstimmen, was als "hohe Fehlerquote" gilt
        operator                = "GreaterThan"
      }]
    }
  } : alert_name => alert if local.create_alerts }

  # DBI-6755: Alerts auf den PostgreSQL-Diagnoselogs im Log Analytics Workspace
  # Hinweis: Diagnostic Settings der DB laufen im AzureDiagnostics-Modus
  # (das postgresql-Modul setzt keinen resource-specific Destination Type).
  # In dev leer -> keine Log-Alert-Regeln.
  log_analytics_alerts = local.create_alerts ? {
    ## Was:   Feuert bei jedem FATAL/PANIC-Eintrag in den PostgreSQL-Serverlogs (DB abgestürzt/Recovery/nicht verbindbar).
    ## Wie:   LAW-Tabelle 'AzureDiagnostics' (Diagnostic Setting allLogs, AzureDiagnostics-Modus); errorLevel_s ist die native PG-Loglevel-Spalte.
    ## Beleg: Baseline B1: PROD hatte in 7d genau 1x FATAL - der Alert hätte exakt diesen einen echten Vorfall gemeldet.
    postgres_fatal_panic_alert = {
      name                 = "TAB - VBST Postgres FATAL-PANIC Logs S_MARKTBEARBEITUNG_${upper(local.env)}"
      description          = "In den PostgreSQL-Serverlogs sind FATAL- oder PANIC-Einträge aufgetreten (z.B. Absturz, Recovery, kein Verbindungsaufbau möglich)."
      action_group_map_key = "incidents"
      enabled              = true
      evaluation_frequency = "PT5M"
      severity             = 1 # Error – DB potenziell nicht funktionsfähig
      window_duration      = "PT15M"

      criteria = [{
        query                   = <<-QUERY
            AzureDiagnostics
            | where ResourceProvider == "MICROSOFT.DBFORPOSTGRESQL"
            | where Category == "PostgreSQLLogs"
            | where errorLevel_s in ("FATAL", "PANIC")
            // FP-Fix 07/2026: Entra-Token-Renewal ist Normalverhalten (Verbindung mit
            // abgelaufenem Token -> FATAL "access token has expired" -> Refresh -> Reconnect).
            // Gezielter Exclude statt Threshold-Anhebung: ein echter Einzel-Crash
            // (1x FATAL) soll weiterhin sofort alarmieren.
            | where Message !has "The access token has expired"
            | summarize CriticalLogCount = count()
          QUERY
        time_aggregation_method = "Total"
        metric_measure_column   = "CriticalLogCount"
        threshold               = 0
        operator                = "GreaterThan"
      }]
    }

    ## Was:   Feuert bei >10 Connection-/Auth-Fehlern (SQLSTATE-Klassen 08/28) in 30 min.
    ## Wie:   sqlerrcode_s traegt den SQLSTATE; die ersten 2 Zeichen sind die Fehlerklasse (08=Connection Exception, 28=Invalid Authorization).
    ##        Der erwartete Entra-Token-Renewal wird gezielt ausgefiltert; echte Connection-/Auth-Fehler bleiben sichtbar.
    ## Beleg: Baseline B2: 8 (TEST) bzw. 22+1 (PROD) Treffer pro Woche verteilt - Schwelle reisst nur bei echten Ausbruechen.
    postgres_connection_auth_errors_alert = {
      name                 = "TAB - VBST Postgres Connection-Auth Errors S_MARKTBEARBEITUNG_${upper(local.env)}"
      description          = "Gehäufte Connection- (SQLSTATE-Klasse 08) oder Authentifizierungsfehler (Klasse 28) in den PostgreSQL-Serverlogs; erwarteter Entra-Token-Renewal ist ausgeschlossen."
      action_group_map_key = "incidents"
      enabled              = true
      evaluation_frequency = "PT15M"
      severity             = 2
      window_duration      = "PT30M"

      criteria = [{
        query                   = <<-QUERY
            AzureDiagnostics
            | where ResourceProvider == "MICROSOFT.DBFORPOSTGRESQL"
            | where Category == "PostgreSQLLogs"
            | where sqlerrcode_s startswith "08" or sqlerrcode_s startswith "28"
            // Erwartetes Normalverhalten beim Entra-Token-Renewal:
            // abgelaufenes Token -> Refresh -> Reconnect. Der gleiche Exclude
            // wird bereits beim FATAL/PANIC-Alert verwendet.
            | where Message !has "The access token has expired"
            | summarize ErrorCount = count()
          QUERY
        time_aggregation_method = "Total"
        metric_measure_column   = "ErrorCount"
        threshold               = 10
        operator                = "GreaterThan"
      }]
    }
  } : {}
}
