terraform {
  source = "../../../../../modules//keyvault"
}

# -----------------------------------------------------------------------------
# DBI-9172 -- CIS-managed cross-subscription Role Assignments
# -----------------------------------------------------------------------------
# Das APIM (in subscription S_APIMANAGEMENT_*) konsumiert Truuco-Secrets aus
# diesem KeyVault via Named Values mit "Client identity: System assigned".
# Dafuer braucht die APIM-SystemAssigned-Identity die Rolle "Key Vault Secrets
# User" auf diesem KV.
#
# Diese Role Assignments werden NICHT via Terraform managed, sondern per
# CIS-Bestellung ("RBAC assignment" im Service-Katalog). Gruende:
#
#   1) Cross-Subscription RBAC ist laut Confluence "Erlaubte Role Assignments
#      fuer Azure Workloads" nicht self-service-faehig -- nur Identities aus
#      DERSELBEN Subscription duerfen self-service vergeben werden.
#      APIM liegt in S_APIMANAGEMENT_*, dieser KV in MARKTBEARBEITUNG_*.
#
#   2) Der Pipeline-Service-Principal hat in TEST/PROD nur "Contributor" auf
#      bestehenden KVs und kann selbst kein Microsoft.Authorization/
#      roleAssignments/write ausfuehren (siehe Kommentar in
#      keyvault-internal.hcl).
#
# Aktuell bestellte Assignments (Stand DBI-9172):
#   DEV  : APIM uiapimf5c41c8714ee
#          principal_id = d2f189cb-814b-4d25-ae88-1b6552f464a0
#          role         = "Key Vault Secrets User"
#   TEST : APIM uiapim125ce218d1e3
#          principal_id = 44fd1bdb-45fe-4fc8-9351-0b05bd28f794
#          role         = "Key Vault Secrets User"
#   PROD : APIM uiapim2b80e30deb7e
#          principal_id = 53c9b7c3-50e1-4a8d-b45b-aa10ed1882b9
#          role         = "Key Vault Secrets User"
#
# WICHTIG: Bei einem APIM-Rebuild (z.B. nach APIM-Notfalltest, vgl.
# UI-CHG-0075395 vom 03.02.2026 in DEV) aendert sich die SystemAssigned
# principal_id der APIM-Instanz. Konsequenz: das obige Role Assignment zeigt
# auf eine nicht mehr existierende Identity und APIM Named Values gehen auf
# "Failure - Caller is not authorized". In diesem Fall fuer die betroffene
# Stage erneut eine CIS-Bestellung aufmachen mit der neuen principal_id.
#
# Mittelfristig (separates Backlog-Item, nicht Teil DBI-9172):
#   - Mit APIM-Team pruefen, ob die APIM-Instanzen auf eine User-Assigned
#     Identity (UAI) umgestellt werden koennen. Eine UAI ueberlebt einen
#     APIM-Rebuild -- damit waere das Identity-Stabilitaetsproblem geloest.
#   - Optional auf unserer Seite: stabilen KV-Namen via Variable
#     key_vault_name setzen, damit auch ein KV-Rebuild bei uns die APIM
#     Named-Value-URLs nicht bricht.
#
# Hinweis zu Access Policy vs. RBAC:
# Wir bleiben bei RBAC (rbac_authorization_enabled = true im
# modules/keyvault). Ein Wechsel auf Access Policy wuerde das Problem oben
# NICHT loesen (Access Policies referenzieren ebenfalls konkrete Object IDs)
# und gilt bei Microsoft als Legacy-Pfad.
# -----------------------------------------------------------------------------

dependency "monitoring" {
  config_path = "${get_terragrunt_dir()}/../monitoring"

  mock_outputs = {
    resource_id = "/subscriptions/12345678-1234-9876-4563-123456789012/resourceGroups/example-resource-group/providers/Microsoft.OperationalInsights/workspaces/workspaceValue"
  }
}

inputs = {
  component_name = "secrets-apim"
  tags = {
    component = "External Secrets API Management"
    purpose   = "use with APIM"
  }

  diagnostic_settings = {
    logs = {
      name                           = "kv-all-logs"
      log_groups                     = ["allLogs"]
      metric_categories              = []
      log_analytics_destination_type = "Dedicated"
      workspace_resource_id          = dependency.monitoring.outputs.resource_id
    }
  }
}
