terraform {
  source = "../../../../../modules//postgresql"
}

dependency "monitoring" {
  config_path = "${get_terragrunt_dir()}/../monitoring"

  mock_outputs = {
    resource_id    = "/subscriptions/12345678-1234-9876-4563-123456789012/resourceGroups/example-resource-group/providers/Microsoft.OperationalInsights/workspaces/workspaceValue"
    resource_group = "example-resource-group"
    action_groups = {
      incidents = {
        resource_id = "/subscriptions/12345678-1234-9876-4563-123456789012/resourceGroups/example-resource-group/providers/Microsoft.Insights/actionGroups/groupValue"
      }
      tab = {
        resource_id = "/subscriptions/12345678-1234-9876-4563-123456789012/resourceGroups/example-resource-group/providers/Microsoft.Insights/actionGroups/groupValue"
      }
    }
  }
}

dependency "backup_vault" {
  config_path = "${get_terragrunt_dir()}/../backup-vault"

  mock_outputs = {
    vault_id                    = "/subscriptions/12345678-1234-9876-4563-123456789012/resourceGroups/example-resource-group/providers/Microsoft.DataProtection/backupVaults/vaultValue"
    backup_policy_id            = "/subscriptions/12345678-1234-9876-4563-123456789012/resourceGroups/example-resource-group/providers/Microsoft.DataProtection/backupVaults/vaultValue/backupPolicies/policyValue"
    vault_identity_principal_id = "12345678-1234-1234-1234-123456789012"
  }
}

locals {
  environment_vars = read_terragrunt_config(find_in_parent_folders("env.hcl"))
  env              = local.environment_vars.locals.environment

  # Für dev werden KEINE Alerts angelegt – Alerting nur in test und prod.
  create_alerts = contains(["test", "prod"], local.env)
}

inputs = {
  component_name = "database"

  sku_settings = {
    name    = "Standard_D2s_v3"
    tier    = "GeneralPurpose"
    storage = 32
  }

  # PostgreSQL Flexible Server has built-in daily backups (independent of Azure Backup Vault)
  # Retention: 7-35 days (configured per environment)
  # Azure Backup Vault provides additional weekly backups for long-term retention
  retention_days = 14 # Daily automated backups retention

  server_admins = {
    ee09cf6 = {
      user_principal_name      = "ee09cf6@union-investment.de" // Iftime, Daniel (UIT/ADMIN)
      user_principal_object_id = "836603c0-15e7-4ee7-a6e7-a3e463c8ad96"
    }
  }

  # Backup configuration - now handled internally by the module
  backup_vault_id           = dependency.backup_vault.outputs.vault_id
  backup_policy_id          = dependency.backup_vault.outputs.backup_policy_id
  backup_vault_principal_id = dependency.backup_vault.outputs.vault_identity_principal_id

  diagnostic_settings = {
    db_logs = {
      name                           = "database-all-logs"
      log_groups                     = ["allLogs"]
      metric_categories              = []
      log_analytics_destination_type = "Dedicated"
      workspace_resource_id          = dependency.monitoring.outputs.resource_id
    }
  }

  # DBI-6755: Metric Alerts auf dem PostgreSQL Flexible Server
  # (Muster analog zu _apps/mashub/database.hcl)
  # In dev leer -> keine Metric-Alert-Regeln.
  alerts = {
    resource_group_name = dependency.monitoring.outputs.resource_group

    metric_alerts = local.create_alerts ? {
      ## Was:   Feuert, wenn die DB nicht mehr als 'alive' meldet (Sev1: Totalausfall).
      ## Wie:   Plattform-Metrik is_db_alive des Flexible Servers (1=ok); Average<1 ueber 5 min.
      ## Beleg: Native Azure-Verfuegbarkeitsmetrik - kein App-Pfad noetig, greift auch wenn die Anwendung selbst tot ist.
      is_db_alive = {
        name        = "TAB - Postgres DB not alive S_MARKTBEARBEITUNG_${upper(local.env)}"
        description = "Die PostgreSQL-Datenbank %scope_name% ist nicht erreichbar (is_db_alive < 1)."
        enabled     = true
        frequency   = "PT1M"
        severity    = 1
        window_size = "PT5M"
        criteria = [{
          metric_namespace = "Microsoft.DBforPostgreSQL/flexibleServers"
          metric_name      = "is_db_alive"
          aggregation      = "Average"
          operator         = "LessThan"
          threshold        = 1
        }]
        # TAB-Action-Group (cis-tab) ist in monitoring.hcl vorerst auskommentiert.
        # Guard via keys(): greift automatisch wieder, sobald die Gruppe dort
        # einkommentiert wird (test/prod). Fehlt der "tab"-Key, bleibt es bei
        # incidents – KEIN "Invalid index"-Fehler durch fehlende Gruppe.
        actions = concat(
          [{
            action_group_id = dependency.monitoring.outputs.action_groups["incidents"].resource_id
          }],
          contains(keys(dependency.monitoring.outputs.action_groups), "tab") ? [{
            action_group_id = dependency.monitoring.outputs.action_groups["tab"].resource_id
          }] : []
        )
      }

      ## Was:   Feuert bei anhaltend >=80% CPU auf dem DB-Server (15 min).
      ## Wie:   Plattform-Metrik cpu_percent, Average-Aggregation.
      ## Beleg: Muster identisch zum produktiven mashub-DB-Alerting.
      cpu_usage = {
        name        = "TAB - Postgres CPU Usage S_MARKTBEARBEITUNG_${upper(local.env)}"
        description = "CPU Auslastung der Postgres DB %scope_name% ist in den letzten 15 Minuten 80% oder höher."
        enabled     = true
        frequency   = "PT5M"
        severity    = 2
        window_size = "PT15M"
        criteria = [{
          metric_namespace = "Microsoft.DBforPostgreSQL/flexibleServers"
          metric_name      = "cpu_percent"
          aggregation      = "Average"
          operator         = "GreaterThan"
          threshold        = 80
        }]
        # TAB-Action-Group (cis-tab) ist in monitoring.hcl vorerst auskommentiert.
        # Guard via keys(): greift automatisch wieder, sobald die Gruppe dort
        # einkommentiert wird (test/prod). Fehlt der "tab"-Key, bleibt es bei
        # incidents – KEIN "Invalid index"-Fehler durch fehlende Gruppe.
        actions = concat(
          [{
            action_group_id = dependency.monitoring.outputs.action_groups["incidents"].resource_id
          }],
          contains(keys(dependency.monitoring.outputs.action_groups), "tab") ? [{
            action_group_id = dependency.monitoring.outputs.action_groups["tab"].resource_id
          }] : []
        )
      }

      ## Was:   Feuert bei anhaltend >=85% RAM auf dem DB-Server (15 min).
      ## Wie:   Plattform-Metrik memory_percent, Average-Aggregation.
      ## Beleg: Muster identisch zum produktiven mashub-DB-Alerting.
      memory_usage = {
        name        = "TAB - Postgres Memory Usage S_MARKTBEARBEITUNG_${upper(local.env)}"
        description = "RAM Auslastung der Postgres DB %scope_name% ist in den letzten 15 Minuten 85% oder höher."
        enabled     = true
        frequency   = "PT5M"
        severity    = 2
        window_size = "PT15M"
        criteria = [{
          metric_namespace = "Microsoft.DBforPostgreSQL/flexibleServers"
          metric_name      = "memory_percent"
          aggregation      = "Average"
          operator         = "GreaterThan"
          threshold        = 85
        }]
        # TAB-Action-Group (cis-tab) ist in monitoring.hcl vorerst auskommentiert.
        # Guard via keys(): greift automatisch wieder, sobald die Gruppe dort
        # einkommentiert wird (test/prod). Fehlt der "tab"-Key, bleibt es bei
        # incidents – KEIN "Invalid index"-Fehler durch fehlende Gruppe.
        actions = concat(
          [{
            action_group_id = dependency.monitoring.outputs.action_groups["incidents"].resource_id
          }],
          contains(keys(dependency.monitoring.outputs.action_groups), "tab") ? [{
            action_group_id = dependency.monitoring.outputs.action_groups["tab"].resource_id
          }] : []
        )
      }

      ## Was:   Feuert bei >=80% Storage-Fuellstand (Vorwarnung vor Voll-Lauf, DB wird sonst read-only).
      ## Wie:   Plattform-Metrik storage_percent, Average ueber 30 min.
      ## Beleg: Macht den offenen VBST-Rollout-Punkt 'DB aufruesten' messbar sichtbar.
      storage_usage = {
        name        = "TAB - Postgres Storage Usage S_MARKTBEARBEITUNG_${upper(local.env)}"
        description = "Storage Auslastung der Postgres DB %scope_name% ist 80% oder höher. Ggf. Storage aufrüsten (offener Punkt VBST-Rollout, DBI-6755)."
        enabled     = true
        frequency   = "PT15M"
        severity    = 2
        window_size = "PT30M"
        criteria = [{
          metric_namespace = "Microsoft.DBforPostgreSQL/flexibleServers"
          metric_name      = "storage_percent"
          aggregation      = "Average"
          operator         = "GreaterThan"
          threshold        = 80
        }]
        # TAB-Action-Group (cis-tab) ist in monitoring.hcl vorerst auskommentiert.
        # Guard via keys(): greift automatisch wieder, sobald die Gruppe dort
        # einkommentiert wird (test/prod). Fehlt der "tab"-Key, bleibt es bei
        # incidents – KEIN "Invalid index"-Fehler durch fehlende Gruppe.
        actions = concat(
          [{
            action_group_id = dependency.monitoring.outputs.action_groups["incidents"].resource_id
          }],
          contains(keys(dependency.monitoring.outputs.action_groups), "tab") ? [{
            action_group_id = dependency.monitoring.outputs.action_groups["tab"].resource_id
          }] : []
        )
      }

      ## Was:   Feuert bei anhaltend hohen IOPS (Sev3: Kapazitaets-Hinweis).
      ## Wie:   Plattform-Metrik iops, Average ueber 15 min.
      ## Beleg: Schwelle PLATZHALTER am SKU-/Disk-Limit ausrichten.
      io_usage = {
        name        = "TAB - Postgres IOPS S_MARKTBEARBEITUNG_${upper(local.env)}"
        description = "IOPS der Postgres DB %scope_name% liegen anhaltend über dem Schwellwert."
        enabled     = true
        frequency   = "PT5M"
        severity    = 3
        window_size = "PT15M"
        criteria = [{
          metric_namespace = "Microsoft.DBforPostgreSQL/flexibleServers"
          metric_name      = "iops"
          aggregation      = "Average"
          operator         = "GreaterThan"
          threshold        = 500 # PLATZHALTER: am IOPS-Limit der SKU/Disk ausrichten
        }]
        # TAB-Action-Group (cis-tab) ist in monitoring.hcl vorerst auskommentiert.
        # Guard via keys(): greift automatisch wieder, sobald die Gruppe dort
        # einkommentiert wird (test/prod). Fehlt der "tab"-Key, bleibt es bei
        # incidents – KEIN "Invalid index"-Fehler durch fehlende Gruppe.
        actions = concat(
          [{
            action_group_id = dependency.monitoring.outputs.action_groups["incidents"].resource_id
          }],
          contains(keys(dependency.monitoring.outputs.action_groups), "tab") ? [{
            action_group_id = dependency.monitoring.outputs.action_groups["tab"].resource_id
          }] : []
        )
      }

      ## Was:   Feuert bei auffaellig vielen aktiven DB-Verbindungen (Pool-Leck/Instanz-Wildwuchs).
      ## Wie:   Plattform-Metrik active_connections; Bezugsgroesse: JDBC-Pool max 40 pro Function-Instanz.
      ## Beleg: Schwelle PLATZHALTER an Instanzanzahl x Poolgroesse + Puffer ausrichten.
      connection_count = {
        name        = "TAB - Postgres Active Connections S_MARKTBEARBEITUNG_${upper(local.env)}"
        description = "Anzahl aktiver Verbindungen der Postgres DB %scope_name% ist auffällig hoch (JDBC-Pool: max 40 pro Function-Instanz)."
        enabled     = true
        frequency   = "PT5M"
        severity    = 3
        window_size = "PT15M"
        criteria = [{
          metric_namespace = "Microsoft.DBforPostgreSQL/flexibleServers"
          metric_name      = "active_connections"
          aggregation      = "Average"
          operator         = "GreaterThan"
          threshold        = 50 # an Instanzanzahl x Poolgröße + Puffer ausrichten
        }]
        # TAB-Action-Group (cis-tab) ist in monitoring.hcl vorerst auskommentiert.
        # Guard via keys(): greift automatisch wieder, sobald die Gruppe dort
        # einkommentiert wird (test/prod). Fehlt der "tab"-Key, bleibt es bei
        # incidents – KEIN "Invalid index"-Fehler durch fehlende Gruppe.
        actions = concat(
          [{
            action_group_id = dependency.monitoring.outputs.action_groups["incidents"].resource_id
          }],
          contains(keys(dependency.monitoring.outputs.action_groups), "tab") ? [{
            action_group_id = dependency.monitoring.outputs.action_groups["tab"].resource_id
          }] : []
        )
      }

      ## Was:   Feuert bei >5 fehlgeschlagenen Verbindungsversuchen in 15 min.
      ## Wie:   Plattform-Metrik connections_failed, Total-Aggregation.
      ## Beleg: Ergaenzt den SQLSTATE-Log-Alert um die Server-Sicht (greift auch bei Fehlern vor dem Logging).
      failed_connections = {
        name        = "TAB - Postgres Failed Connections S_MARKTBEARBEITUNG_${upper(local.env)}"
        description = "Gehäufte fehlgeschlagene Verbindungsversuche zur Postgres DB %scope_name% in den letzten 15 Minuten."
        enabled     = true
        frequency   = "PT5M"
        severity    = 2
        window_size = "PT15M"
        criteria = [{
          metric_namespace = "Microsoft.DBforPostgreSQL/flexibleServers"
          metric_name      = "connections_failed"
          aggregation      = "Total"
          operator         = "GreaterThan"
          threshold        = 5 # PLATZHALTER: Schwellwert nach Beobachtung justieren
        }]
        # TAB-Action-Group (cis-tab) ist in monitoring.hcl vorerst auskommentiert.
        # Guard via keys(): greift automatisch wieder, sobald die Gruppe dort
        # einkommentiert wird (test/prod). Fehlt der "tab"-Key, bleibt es bei
        # incidents – KEIN "Invalid index"-Fehler durch fehlende Gruppe.
        actions = concat(
          [{
            action_group_id = dependency.monitoring.outputs.action_groups["incidents"].resource_id
          }],
          contains(keys(dependency.monitoring.outputs.action_groups), "tab") ? [{
            action_group_id = dependency.monitoring.outputs.action_groups["tab"].resource_id
          }] : []
        )
      }

      ## Was:   Feuert bei jedem Deadlock in der DB.
      ## Wie:   Plattform-Metrik deadlocks, Total>0 im 15-min-Fenster.
      ## Beleg: Deadlocks sind im Normalbetrieb 0 - jeder Treffer ist analysewuerdig.
      deadlocks = {
        name        = "TAB - Postgres Deadlocks S_MARKTBEARBEITUNG_${upper(local.env)}"
        description = "Deadlocks in der Postgres DB %scope_name% aufgetreten."
        enabled     = true
        frequency   = "PT5M"
        severity    = 2
        window_size = "PT15M"
        criteria = [{
          metric_namespace = "Microsoft.DBforPostgreSQL/flexibleServers"
          metric_name      = "deadlocks"
          aggregation      = "Total"
          operator         = "GreaterThan"
          threshold        = 0
        }]
        # TAB-Action-Group (cis-tab) ist in monitoring.hcl vorerst auskommentiert.
        # Guard via keys(): greift automatisch wieder, sobald die Gruppe dort
        # einkommentiert wird (test/prod). Fehlt der "tab"-Key, bleibt es bei
        # incidents – KEIN "Invalid index"-Fehler durch fehlende Gruppe.
        actions = concat(
          [{
            action_group_id = dependency.monitoring.outputs.action_groups["incidents"].resource_id
          }],
          contains(keys(dependency.monitoring.outputs.action_groups), "tab") ? [{
            action_group_id = dependency.monitoring.outputs.action_groups["tab"].resource_id
          }] : []
        )
      }
    } : {}
  }
}
