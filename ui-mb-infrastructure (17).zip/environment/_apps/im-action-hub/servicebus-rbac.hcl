terraform {
  source = "../../../../../modules//rbac-assignment"
}

dependency "identity" {
  config_path = "${get_terragrunt_dir()}/../identity"

  mock_outputs = {
    principal_id = "12345678-1234-1234-1234-123456789012"
  }
  mock_outputs_merge_strategy_with_state = "shallow"
}

locals {
  environment_vars = read_terragrunt_config(find_in_parent_folders("env.hcl"))
  env              = local.environment_vars.locals.environment

  # Service Bus Resource IDs pro Umgebung (MB-Portal Service Bus)
  service_bus_ids = {
    dev  = "/subscriptions/6289fbfa-0b84-4f9e-8250-684455e9bb1a/resourceGroups/rg-mbportal-dev-servicebus/providers/Microsoft.ServiceBus/namespaces/sb-9d866816937705aff5c4"
    test = "/subscriptions/d98221c3-b24d-4770-a9a3-3716667d7353/resourceGroups/rg-mashub-test-servicebus/providers/Microsoft.ServiceBus/namespaces/sb-98ca7cc87eb873df7b24"
    prod = "/subscriptions/a6c520e0-a1af-4c4c-82f0-8482ff82ecd8/resourceGroups/rg-mbportal-prod-servicebus/providers/Microsoft.ServiceBus/namespaces/sb-729f60557f8f967dcff9"
  }
}

inputs = {
  # Self-Service RBAC Role Assignment für Service Bus
  # Azure Service Bus Data Owner für Queue-Erstellung
  role_assignments = {
    servicebus_owner = {
      scope                = local.service_bus_ids[local.env]
      principal_id         = dependency.identity.outputs.principal_id
      role_definition_name = "Azure Service Bus Data Owner"
      description          = "IM-Hub User Assigned Identity kann Queues erstellen und Nachrichten senden/empfangen"
    }
  }
}
