terraform {
  source = "../../../../../modules//user-managed-identity"
}

inputs = {
  component_name = "identity"
}
