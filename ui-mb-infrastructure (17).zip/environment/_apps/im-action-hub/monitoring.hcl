terraform {
  source = "../../../../../modules//log-and-monitor"
}

locals {
  environment_vars = read_terragrunt_config(find_in_parent_folders("env.hcl"))
  env              = local.environment_vars.locals.environment
}

inputs = {
  component_name                 = "monitoring"
  integrate_application_insights = true
  action_group_map_key           = "incidents"

  # Action Groups für Benachrichtigungen (gleiche wie VBST)
  action_groups = merge(
    {
      incidents = {
        short_name = "imhub-inc"
        tags = {
          monitoring = "incidents"
        }
        email_receiver = [{
          name          = "VBST Monitoring: New Incident"
          email_address = "monitoring_vbst+${local.env}@union-investment.de"
        }]
      }
    },
    contains(["test", "prod"], local.env) ? {
      tab = {
        short_name = "TAB-Mail"
        tags = {
          monitoring = "tab"
        }
        email_receiver = [{
          name          = "VBST Monitoring: New Incident"
          email_address = "cis-tab@union-investment.de"
        }]
      }
    } : {}
  )

  # Scheduled Log Alerts für Function App Monitoring (Application Insights)
  scheduled_log_alerts = {
    imhub_health_execution_alert = {
      name                 = "TAB - Function IM-Hub Health - No Execution Alert S_MARKTBEARBEITUNG_${upper(local.env)}"
      description          = "Die IM-Hub Function wurde in der letzten Stunde nicht ausgeführt. Dies könnte auf ein Problem mit der Function App hinweisen."
      action_group_map_key = "incidents"
      # Temporarily disable the execution alert to prevent the TAB alert from firing continuously
      # Setting enabled to false ensures no alert will be generated while the underlying issue is investigated
      enabled              = false
      evaluation_frequency = "PT15M" # Alle 15 Minuten prüfen
      severity             = 2       # Warning
      window_duration      = "PT1H"  # Betrachtungszeitraum: 1 Stunde

      criteria = [{
        query                   = <<-QUERY
          requests
          | where timestamp > ago(1h)
          | where name == "health" or name contains "health/live"
          | where cloud_RoleName contains "im-action-hub"
          | summarize ExecutionCount = count()
        QUERY
        time_aggregation_method = "Total"
        metric_measure_column   = "ExecutionCount"
        threshold               = 1
        operator                = "LessThan"
      }]
    }
  }
}
