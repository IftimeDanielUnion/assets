terraform {
  source = "../../../../../modules//keyvault"
}

dependency "functionapp" {
  config_path = "${get_terragrunt_dir()}/../functionapp"

  mock_outputs = {
    system_assigned_principal_id = "12345678-1234-1234-1234-123456789012"
  }
  mock_outputs_merge_strategy_with_state = "shallow"
}

dependency "identity" {
  config_path = "${get_terragrunt_dir()}/../identity"

  mock_outputs = {
    principal_id = "12345678-1234-1234-1234-123456789012"
  }
  mock_outputs_merge_strategy_with_state = "shallow"
}

dependency "monitoring" {
  config_path = "${get_terragrunt_dir()}/../monitoring"

  mock_outputs = {
    resource_id = "/subscriptions/12345678-1234-9876-4563-123456789012/resourceGroups/example-resource-group/providers/Microsoft.OperationalInsights/workspaces/workspaceValue"
  }
  mock_outputs_merge_strategy_with_state = "shallow"
}

inputs = {
  component_name = "secrets-internal"

  # IM-Hub spezifisch: Neues Subnet für Private Endpoints (UI-CHG-XXXXXX)
  # Nur IM-Hub nutzt das neue Subnet, bestehende Apps bleiben im default Subnet
  vnet_subnet_name_privateendpoints = "privateendpoints"

  diagnostic_settings = {
    logs = {
      name                           = "kv-all-logs"
      log_groups                     = ["allLogs"]
      metric_categories              = []
      log_analytics_destination_type = "Dedicated"
      workspace_resource_id          = dependency.monitoring.outputs.resource_id
    }
  }

  # Self-Service RBAC Rollen (laut PDF "Role Assignment für Azure Workloads")
  # Diese kann der CI/CD Service Principal vergeben
  role_assignments = {
    func_secrets_user = {
      role_definition_name = "Key Vault Secrets User"
      principal_id         = dependency.functionapp.outputs.system_assigned_principal_id
      description          = "Function App System Identity has permission to access KeyVault secrets"
    }
    uai_secrets_user = {
      role_definition_name = "Key Vault Secrets User"
      principal_id         = dependency.identity.outputs.principal_id
      description          = "User Assigned Identity has permission to access KeyVault secrets"
    }
  }

  tags = {
    component = "Internal Secrets"
    purpose   = "app-internal use"
  }
}
