terraform {
  source = "../../../../../modules//postgresql-database"
}

locals {
  environment_vars = read_terragrunt_config(find_in_parent_folders("env.hcl"))
  env              = local.environment_vars.locals.environment

  # PostgreSQL Server Details pro Umgebung (VBST PostgreSQL Server)
  postgres_servers = {
    dev = {
      name                = "psql-vbst-dev-database-jjqnmfuk"
      resource_group_name = "rg-vbst-dev-database"
    }
    test = {
      name                = "psql-vbi-test-database-xm363ycp"
      resource_group_name = "rg-vbi-test-database"
    }
    prod = {
      name                = "psql-vbst-prod-database-quza6or6"
      resource_group_name = "rg-vbst-prod-database"
    }
  }
}

inputs = {
  server_name                = local.postgres_servers[local.env].name
  server_resource_group_name = local.postgres_servers[local.env].resource_group_name
  database_name              = "imactionhub"
  charset                    = "UTF8"
  collation                  = "en_US.utf8"
}
