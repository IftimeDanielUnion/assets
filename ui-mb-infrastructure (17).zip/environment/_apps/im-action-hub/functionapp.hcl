terraform {
  source = "../../../../../modules//functionapp"
}

dependency "monitoring" {
  config_path = "${get_terragrunt_dir()}/../monitoring"

  mock_outputs = {
    resource_id    = "/subscriptions/12345678-1234-9876-4563-123456789012/resourceGroups/example-resource-group/providers/Microsoft.OperationalInsights/workspaces/workspaceValue"
    resource_group = "example-resource-group"
    application_insights = {
      connection_string = "InstrumentationKey=00000000-0000-0000-0000-000000000000"
    }
    action_groups = {
      incidents = {
        resource_id = "/subscriptions/12345678-1234-9876-4563-123456789012/resourceGroups/example-resource-group/providers/Microsoft.Insights/actionGroups/incidents"
      }
      tab = {
        resource_id = "/subscriptions/12345678-1234-9876-4563-123456789012/resourceGroups/example-resource-group/providers/Microsoft.Insights/actionGroups/tab"
      }
    }
  }
  mock_outputs_merge_strategy_with_state = "shallow"
}

dependency "identity" {
  config_path = "${get_terragrunt_dir()}/../identity"

  mock_outputs = {
    resource_id  = "/subscriptions/12345678-1234-9876-4563-123456789012/resourceGroups/example-resource-group/providers/Microsoft.ManagedIdentity/userAssignedIdentities/identityValue"
    principal_id = "12345678-1234-1234-1234-123456789012"
  }
  mock_outputs_merge_strategy_with_state = "shallow"
}

locals {
  environment_vars = read_terragrunt_config(find_in_parent_folders("env.hcl"))
  env              = local.environment_vars.locals.environment
}

inputs = {
  component_name = "im-action-hub"

  # IM-Hub spezifisch: Neues Subnet für Private Endpoints (UI-CHG-XXXXXX)
  # Nur IM-Hub nutzt das neue Subnet, bestehende Apps bleiben im default Subnet
  vnet_subnet_name_privateendpoints = "privateendpoints"

  # Java 21 LTS - aktuellste LTS Version (September 2023)
  # Vorteile: Virtual Threads, Pattern Matching, Record Patterns, bessere Performance
  runtime = {
    stack   = "java"
    version = "21"
  }

  discovery_key = "func-im-action-hub"

  logging = {
    application_insights_connection_string = dependency.monitoring.outputs.application_insights.connection_string
  }

  storage_account = {
    private_endpoints = ["blob", "table", "queue"]
  }

  cors = {
    allowed_origins = ["https://portal.azure.com"]
  }

  # CPU Alerts wie bei anderen Production Apps (mashub, datenprodukt-api, etc.)
  alerts = {
    resource_group_name = dependency.monitoring.outputs.resource_group
    metric_alerts = {
      cpu = {
        name        = "TAB - Function CPU Usage (%scope_name%) S_MARKTBEARBEITUNG_${upper(local.env)}"
        description = "CPU Auslastung des Function servers %scope_name% ist in den letzten 15 Minuten 80% oder höher."
        enabled     = true
        frequency   = "PT5M" # Abfrageintervall
        severity    = 2
        window_size = "PT15M" # Betrachtungszeitraum
        criteria = [{
          metric_namespace = "Microsoft.Web/serverFarms"
          metric_name      = "CpuPercentage"
          aggregation      = "Average"
          operator         = "GreaterThan"
          threshold        = 80
        }]
        actions = concat(
          [{
            action_group_id = dependency.monitoring.outputs.action_groups["incidents"].resource_id
          }],
          contains(["test", "prod"], local.env) ? [{
            action_group_id = dependency.monitoring.outputs.action_groups["tab"].resource_id
          }] : []
        )
      }
    }
  }

  # Health Check - eviction_time auf 3 Minuten reduziert (wie andere Apps)
  health_check = {
    eviction_time_in_min = 3
    path                 = "/api/q/health"
    monitoring_alert = {
      actions = concat(
        [{
          action_group_id = dependency.monitoring.outputs.action_groups["incidents"].resource_id
        }],
        contains(["test", "prod"], local.env) ? [{
          action_group_id = dependency.monitoring.outputs.action_groups["tab"].resource_id
        }] : []
      )
      resource_group_name = dependency.monitoring.outputs.resource_group
    }
  }

  user_assigned_resource_ids = [dependency.identity.outputs.resource_id]

  # Azure AD Authentication Settings werden umgebungsspezifisch in den jeweiligen
  # environment/{dev,test,prod}/applications/im-action-hub/functionapp/terragrunt.hcl definiert
}
