terraform {
  source = "../../../../../modules//keyvault"
}

dependency "monitoring" {
  config_path = "${get_terragrunt_dir()}/../monitoring"

  mock_outputs = {
    resource_id = "/subscriptions/12345678-1234-9876-4563-123456789012/resourceGroups/example-resource-group/providers/Microsoft.OperationalInsights/workspaces/workspaceValue"
  }
}

dependency "identity" {
  config_path = "${get_terragrunt_dir()}/../identity"
  mock_outputs = {
    resource_id  = "/subscriptions/12345678-1234-9876-4563-123456789012/resourceGroups/example-resource-group/providers/Microsoft.ManagedIdentity/userAssignedIdentities/identityValue"
    principal_id = "12345678-1234-1234-1234-123456789012"
  }
}

inputs = {
  component_name = "secrets-external"

  role_assignments = {
    secrets_user = {
      role_definition_name = "Key Vault Secrets User"
      principal_id         = dependency.identity.outputs.principal_id
      description          = "User Assigned Identity has permission to access the KeyVault"
    }
  }

  tags = {
    component = "External Secrets"
    purpose   = "EntraID Secret deployment"
  }
}
