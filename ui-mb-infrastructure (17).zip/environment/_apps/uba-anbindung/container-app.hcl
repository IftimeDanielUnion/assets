terraform {
  source = "../../../../../modules//container-app"
}

dependency "container_environment" {
  config_path = "${get_terragrunt_dir()}/../../plattform/container-app-environment"
}

dependency "identity" {
  config_path = "${get_terragrunt_dir()}/../identity"

  mock_outputs = {
    resource_id  = "/subscriptions/12345678-1234-9876-4563-123456789012/resourceGroups/example-resource-group/providers/Microsoft.ManagedIdentity/userAssignedIdentities/identityValue"
    principal_id = "12345678-1234-1234-1234-123456789012"
  }
  mock_outputs_merge_strategy_with_state = "shallow"
}

locals {
  environment_vars = read_terragrunt_config(find_in_parent_folders("env.hcl"))
  env              = local.environment_vars.locals.environment
}

inputs = {
  cpu = 1
  memory = "2Gi"
  container_app_environment_id = dependency.container_environment.outputs.environment_id
  user_assigned_resource_ids = [dependency.identity.outputs.resource_id]
  registry_identity = dependency.identity.outputs.resource_id
  target_port = 8080
  liveness_probe = {
    port = 8080
    transport = "TCP"
  }
  readiness_probe = {
    port = 8080
    transport = "TCP"
  }
  startup_probe = {
    port = 8080
    transport = "TCP"
  }
}
