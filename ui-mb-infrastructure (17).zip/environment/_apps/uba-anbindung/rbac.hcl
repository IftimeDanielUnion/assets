# RBAC on Static Web App Key Vaults
# This assigns the System Assigned Identity of each Static Web App to its associated Key Vault
# Separated from the staticwebapp module to avoid circular dependencies with dynamic identity blocks

terraform {
  source = "../../../../../modules//rbac-assignment"
}

dependency "identity" {
  config_path = "${get_terragrunt_dir()}/../identity"
  mock_outputs = {
    resource_id  = "/subscriptions/12345678-1234-9876-4563-123456789012/resourceGroups/example-resource-group/providers/Microsoft.ManagedIdentity/userAssignedIdentities/identityValue"
    principal_id = "12345678-1234-1234-1234-123456789012"
  }
}

inputs = {
  role_assignments = {
    container_app_acr_access = {
      role_definition_name = "AcrPull"
      principal_id         = dependency.identity.outputs.principal_id
      description          = "UBA Container App has permission to pull images from the ACR"
    }
  }
}
