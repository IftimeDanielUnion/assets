terraform {
  source = "../../../../../modules//app-gateway"
}

## Define dependencies to Plattform-internal resources.
dependency "managed_identity" {
  config_path = "${get_terragrunt_dir()}/../identity"

  mock_outputs = {
    resource_id = "/subscriptions/12345678-1234-9876-4563-123456789012/resourceGroups/example-resource-group/providers/Microsoft.ManagedIdentity/userAssignedIdentities/identityValue"
  }
}

dependency "certificates_vault" {
  config_path = "${get_terragrunt_dir()}/../appgw-secrets"

  mock_outputs = {
    resource_id = "/subscriptions/12345678-1234-9876-4563-123456789012/resourceGroups/example-resource-group/providers/Microsoft.KeyVault/vaults/vaultValue"
  }
}

dependency "monitoring" {
  config_path = "${get_terragrunt_dir()}/../monitoring"

  mock_outputs = {
    resource_id = "/subscriptions/12345678-1234-9876-4563-123456789012/resourceGroups/example-resource-group/providers/Microsoft.OperationalInsights/workspaces/workspaceValue"
  }
}

## Define dependencies to backend resources
## Only add resources here, if they are already rolled out to all environments
dependency "bu_frontend" {
  config_path = "${get_terragrunt_dir()}/../../beratungsunterstuetzung/frontend"
}

dependency "mb_frontend" {
  config_path = "${get_terragrunt_dir()}/../../marktbearbeitung/frontend"
}
dependency "mb_dmsstorage" {
  config_path = "${get_terragrunt_dir()}/../../marktbearbeitung/dms-storage"

}
dependency "mbportal_salesportal" {
  config_path = "${get_terragrunt_dir()}/../../mashub/sales-portal"
}
dependency "mbportal_salesportal_admin" {
  config_path = "${get_terragrunt_dir()}/../../mashub/sales-portal-admin"
}
dependency "vbst_frontend" {
  config_path = "${get_terragrunt_dir()}/../../verbundintegration/frontend"
}
dependency "mbportal_dashboard_frontend" {
  config_path = "${get_terragrunt_dir()}/../../mashub/datenprodukt-frontend"
}
dependency "uba_storage" {
  config_path = "${get_terragrunt_dir()}/../../uba-anbindung/storage"
}

locals {
  # These reflect the basic App Gateway setup, as provided by the Building Block. They are not part of individual configuration, but given static values.
  gw_ip_config_suffix      = "-gw-ipconf"
  public_ip_config_suffix  = "-public-ipconf"
  private_ip_config_suffix = "-private-ipconf"
  public_ip_address_suffix = "-pip"
}

inputs = {
  component_name = "appgw-waf"

  diagnostic_settings = {
    logs = {
      name                           = "plattform monitoring"
      log_groups                     = ["allLogs"]
      log_analytics_destination_type = "Dedicated"
      workspace_resource_id          = dependency.monitoring.outputs.resource_id
    }
  }
}
