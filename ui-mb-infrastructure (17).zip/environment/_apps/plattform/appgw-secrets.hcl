terraform {
  source = "../../../../../modules//keyvault"
}

dependency "identity" {
  config_path = "${get_terragrunt_dir()}/../identity"

  mock_outputs = {
    resource_id = "/subscriptions/12345678-1234-9876-4563-123456789012/resourceGroups/example-resource-group/providers/Microsoft.ManagedIdentity/userAssignedIdentities/identityValue"
  }
}
dependency "monitoring" {
  config_path = "${get_terragrunt_dir()}/../monitoring"

  mock_outputs = {
    resource_id = "/subscriptions/12345678-1234-9876-4563-123456789012/resourceGroups/example-resource-group/providers/Microsoft.OperationalInsights/workspaces/workspaceValue"
  }
}

inputs = {
  component_name       = "appgw-secrets"
  use_with_app_gateway = true
  tags = {
    component = "Internal Secrets"
    purpose   = "app-internal use"
  }

  diagnostic_settings = {
    logs = {
      name                           = "kv-all-logs"
      log_groups                     = ["allLogs"]
      log_analytics_destination_type = "Dedicated"
      workspace_resource_id          = dependency.monitoring.outputs.resource_id
    }
  }

  role_assignments = {
    uai_certificate_user = {
      role_definition_name = "Key Vault Certificate User"
      principal_id         = dependency.identity.outputs.principal_id
      description          = "User Assigned Identity has permission to access certificates and secrets in the KeyVault"
    }
  }
}
