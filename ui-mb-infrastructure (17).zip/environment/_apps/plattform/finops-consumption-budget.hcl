terraform {
  source = "../../../../../modules//finops"
}

locals {
  environment_vars = read_terragrunt_config(find_in_parent_folders("env.hcl"))
  env              = local.environment_vars.locals.environment

  # Environment-specific budget amounts
  annual_budget_amounts = {
    dev  = 50000
    test = 50000
    prod = 50000
  }

  monthly_budget_amounts = {
    dev  = 4166
    test = 4166
    prod = 4166
  }

  # Environment-specific notification emails
  notification_emails = {
    dev  = ["finops-marktbearbeitung@union-investment.de", "daniel.iftime@union-investment.de"]
    test = ["finops-marktbearbeitung@union-investment.de", "daniel.iftime@union-investment.de"]
    prod = ["finops-marktbearbeitung@union-investment.de", "daniel.iftime@union-investment.de"]
  }
}

inputs = {
  budget_name_prefix    = "budget-marktbearbeitung-${local.env}"
  monthly_budget_amount = local.monthly_budget_amounts[local.env]
  annual_budget_amount  = local.annual_budget_amounts[local.env]
  monthly_start_date    = "2025-11-01"
  annual_start_date     = "2025-01-01"
  end_date              = null

  # Alert thresholds
  notification_thresholds = [
    {
      threshold      = 80
      operator       = "GreaterThan"
      threshold_type = "Forecasted" # Alert when forecasted to exceed 80%
    },
    {
      threshold      = 90
      operator       = "GreaterThan"
      threshold_type = "Forecasted" # Alert when forecasted to exceed 90%
    },
    {
      threshold      = 100
      operator       = "GreaterThan"
      threshold_type = "Actual" # Alert when actually exceeds 100%
    },
    {
      threshold      = 110
      operator       = "GreaterThan"
      threshold_type = "Actual" # Critical alert at 110%
    }
  ]

  notification_emails = local.notification_emails[local.env]

  # Optional: Filter by specific resource groups or tags
  # filter_resource_groups = ["rg-marktbearbeitung-${local.env}-*"]
  # filter_tags = {
  #   environment = [local.env]
  #   cost_center = ["MARKTBEARBEITUNG"]
  # }
}
