terraform {
  source = "../../../../../modules//log-and-monitor"
}

locals {
  environment_vars = read_terragrunt_config(find_in_parent_folders("env.hcl"))

  env = local.environment_vars.locals.environment
}

inputs = {
  component_name = "monitoring"
    action_groups = merge(
    {
      security = {
        short_name = "mbportal-sec"
        tags = {
          monitoring : "security"
        }
        email_receiver = [{
          name          = "Monitoring: send to mailing-list security-marktbearbeitung"
          email_address = "Security-Marktbearbeitung@union-investment.de"
        }]
      }
    }
  )

  action_group_map_key = "security"
  activity_log_alerts = {
    policy_assignment_create_alert = {
      name            = "policy-assignment-create-alert S_MARKTBEARBEITUNG_${upper(local.env)}"
      description     = "Alert on create or update of policy assignments"
      category        = "Policy"
      operation_name  = "Microsoft.Authorization/policyAssignments/write"
    },
    policy_assignment_delete_alert = {
      name            = "policy-assignment-delete-alert S_MARKTBEARBEITUNG_${upper(local.env)}"
      description     = "Alert on delete of policy assignments"
      category        = "Policy"
      operation_name  = "Microsoft.Authorization/policyAssignments/delete"
    },
    nsg_create_update_alert = {
      name            = "nsg-create-update-alert S_MARKTBEARBEITUNG_${upper(local.env)}"
      description     = "Alert on create or update of NSGs"
      category        = "Administrative"
      operation_name  = "Microsoft.Network/networkSecurityGroups/write"
    },
    nsg_delete_alert = {
      name            = "nsg-delete-alert S_MARKTBEARBEITUNG_${upper(local.env)}"
      description     = "Alert on delete of NSGs"
      category        = "Administrative"
      operation_name  = "Microsoft.Network/networkSecurityGroups/delete"
    },
    security_solution_create_update_alert = {
      name            = "security-solution-create-update-alert S_MARKTBEARBEITUNG_${upper(local.env)}"
      description     = "Alert on create or update of Security Solutions"
      category        = "Administrative"
      operation_name  = "Microsoft.Security/securitySolutions/write"
    },
    security_solution_delete_alert = {
      name            = "security-solution-delete-alert S_MARKTBEARBEITUNG_${upper(local.env)}"
      description     = "Alert on delete of Security Solutions"
      category        = "Administrative"
      operation_name  = "Microsoft.Security/securitySolutions/delete"
    },
    sql_fw_create_update_alert = {
      name            = "sql-fw-create-update-alert S_MARKTBEARBEITUNG_${upper(local.env)}"
      description     = "Alert on create or update of SQL Server Firewall Rule"
      category        = "Administrative"
      operation_name  = "Microsoft.Sql/servers/firewallRules/write"
    },
    sql_fw_delete_alert = {
      name            = "sql-fw-delete-alert S_MARKTBEARBEITUNG_${upper(local.env)}"
      description     = "Alert on delete of SQL Server Firewall Rule"
      category        = "Administrative"
      operation_name  = "Microsoft.Sql/servers/firewallRules/delete"
    },
    pubip_create_update_alert = {
      name            = "pubip-create-update-alert S_MARKTBEARBEITUNG_${upper(local.env)}"
      description     = "Alert on create or update of Public IP Addresses"
      category        = "Administrative"
      operation_name  = "Microsoft.Network/publicIPAddresses/write"
    },
    pubip_delete_alert = {
      name            = "pubip-delete-alert S_MARKTBEARBEITUNG_${upper(local.env)}"
      description     = "Alert on delete of Public IP Addresses"
      category        = "Administrative"
      operation_name  = "Microsoft.Network/publicIPAddresses/delete"
    }
  }
}
