terraform {
  source = "../../../../../modules//user-managed-identity"
}

inputs = {
  component_name = "backup-identity"

  tags = {
    component = "Backup Operations"
    purpose   = "PostgreSQL Backup Management for Mashub and Verbundintegration"
    scope     = "Cross-Application"
  }
}
