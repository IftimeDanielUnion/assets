include "root" {
  path           = find_in_parent_folders("root.hcl")
  merge_strategy = "deep"
}

include "app" {
  path           = "${get_terragrunt_dir()}/../../../../_apps/marktbearbeitung/frontend.hcl"
  merge_strategy = "deep"
}

inputs = {
  static_web_app_custom_domain = "iw-marktbearbeitung.dev.union-investment.de"
}
