include "root" {
  path           = find_in_parent_folders("root.hcl")
  merge_strategy = "deep"
}

include "app" {
  path           = "${get_terragrunt_dir()}/../../../../_apps/marktbearbeitung/bff-api.hcl"
  merge_strategy = "deep"
}

inputs = {
  instance_count = 1
  sku_name       = "B2"

  auth_settings = {
    client_id = "65344d51-ab63-4dd3-ae48-f2d64026264d"
    tenant_auth_endpoint = "https://auth-dev.user.union-investment.de/b2cunioninvestmentdev.onmicrosoft.com/B2C_1A_SIGNIN/v2.0/.well-known/openid-configuration"

    allowed_audiences = [
      "65344d51-ab63-4dd3-ae48-f2d64026264d", # BFF Dev
      "8dc81ec5-016c-4fde-9ed4-018575d61e21", # SPA MB Dev
      "d32e75b9-53be-49da-a535-f1ee6ffa8130", # SPA BU Dev
      "091c0ca5-38e2-41b5-9676-5ff68f5aa8ff" # Portalrahmen Dev
    ]
    allowed_applications = [
      "65344d51-ab63-4dd3-ae48-f2d64026264d", # BFF Dev
      "8dc81ec5-016c-4fde-9ed4-018575d61e21", # SPA MB Dev
      "d32e75b9-53be-49da-a535-f1ee6ffa8130", # SPA BU Dev
      "091c0ca5-38e2-41b5-9676-5ff68f5aa8ff" # Portalrahmen Dev
    ]

    # UI-CHG-0091618: Azure App Service Health Check muss Easy Auth umgehen,
    # damit der Plattform-Ping den anonymen Quarkus-Health-Endpunkt erreicht.
    excluded_paths = ["/api/q/health"]
  }
}

