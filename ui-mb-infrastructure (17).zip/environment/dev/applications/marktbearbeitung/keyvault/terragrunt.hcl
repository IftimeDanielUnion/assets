include "root" {
  path           = find_in_parent_folders("root.hcl")
  merge_strategy = "deep"
}

include "app" {
  path           = "${get_terragrunt_dir()}/../../../../_apps/marktbearbeitung/keyvault.hcl"
  merge_strategy = "deep"
}

inputs = {
  role_assignments = {
    bb_func_bff_secrets_user = {
      principal_id         = "ac273264-76a9-4fed-b324-7c8b3224de01"
      role_definition_name = "Key Vault Secrets User"
      description          = "System Assigned Identity of fa-mb-bff-api-tlcyoqwd has permission to access the Key Vault"
    }
    bb_func_bff_tf_secrets_user = {
      principal_id         = "3cd4a378-4c16-4f12-9a72-8707411b6b09"
      role_definition_name = "Key Vault Secrets User"
      description          = "System Assigned Identity of func-mb-dev-bff-api-nvyi0gqu has permission to access the Key Vault"
    }
    bb_func_dms_secrets_user = {
      principal_id         = "11ef0e24-519b-4a74-96bd-0c37a5626549"
      role_definition_name = "Key Vault Secrets User"
      description          = "System Assigned Identity of fa-mb-dms-api-jlsaxycr has permission to access the Key Vault"
    }
    bb_func_dms_tf_secrets_user = {
      principal_id         = "2228a482-03ad-4382-ad4b-0066b2b93c9d"
      role_definition_name = "Key Vault Secrets User"
      description          = "System Assigned Identity of func-mb-dev-dms-api-umi9q124 has permission to access the Key Vault"
    }
  }
  soft_delete_retention_days = 7
}
