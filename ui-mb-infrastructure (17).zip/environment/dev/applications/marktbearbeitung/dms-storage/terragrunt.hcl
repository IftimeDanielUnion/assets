include "root" {
  path           = find_in_parent_folders("root.hcl")
  merge_strategy = "deep"
}

include "app" {
  path           = "${get_terragrunt_dir()}/../../../../_apps/marktbearbeitung/dms-storage.hcl"
  merge_strategy = "deep"
}

inputs = {
  role_assignments = {
    bb_func_dms_owner = {
      principal_id               = "11ef0e24-519b-4a74-96bd-0c37a5626549"
      role_definition_id_or_name = "Storage Blob Data Owner"
      description                = "System Assigned Identity of fa-mb-dms-api-jlsaxycr has owner permissions at the Blob Storage"
    }
    bb_func_dms_tf_owner = {
      principal_id               = "2228a482-03ad-4382-ad4b-0066b2b93c9d"
      role_definition_id_or_name = "Storage Blob Data Owner"
      description                = "System Assigned Identity of func-mb-dev-dms-api-umi9q124 has owner permissions at the Blob Storage"
    }
  }
}
