locals {
  tags = {
    application = "IW Marktbearbeitung"
  }
}
inputs = {
  app_name = "mb"
}
