include "root" {
  path = find_in_parent_folders("root.hcl")
}

include "app" {
  path = "${get_terragrunt_dir()}/../../../../_apps/mashub/rbac-on-staticwebapps.hcl"
}
