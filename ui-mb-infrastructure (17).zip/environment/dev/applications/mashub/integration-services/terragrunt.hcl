include "root" {
  path           = find_in_parent_folders("root.hcl")
  merge_strategy = "deep"
}

include "app" {
  path           = "${get_terragrunt_dir()}/../../../../_apps/mashub/integration-services.hcl"
  merge_strategy = "deep"
}

inputs = {
  service_plan = {
    sku_name       = "B2"
    instance_count = 1
  }
}
