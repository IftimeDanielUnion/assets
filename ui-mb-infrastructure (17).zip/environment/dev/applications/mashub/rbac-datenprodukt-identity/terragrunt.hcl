include "root" {
  path = find_in_parent_folders("root.hcl")
}

include "app" {
  path = "${get_terragrunt_dir()}/../../../../_apps/mashub/rbac-datenprodukt-identity.hcl"
}

# Role assignments for external resources (Building Blocks) in DEV environment
inputs = {
  role_assignments = {
    # aadb2c KeyVault access - DEV environment
    datenprodukt_identity_aadb2c_secrets_user = {
      scope                = "/subscriptions/6289fbfa-0b84-4f9e-8250-684455e9bb1a/resourceGroups/RG-M-KEYVAULT-mbp4aadb2c/providers/Microsoft.KeyVault/vaults/kv-mbp4aadb2c-djuwmyrf"
      role_definition_name = "Key Vault Secrets User"
      principal_id         = dependency.datenprodukt_identity.outputs.principal_id
      description          = "Datenprodukt Identity has permission to access the aadb2c KeyVault"
    }
  }
}
