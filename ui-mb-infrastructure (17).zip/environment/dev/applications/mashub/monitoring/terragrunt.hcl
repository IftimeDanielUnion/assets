include "root" {
  path           = find_in_parent_folders("root.hcl")
  merge_strategy = "deep"
}

include "app" {
  path           = "${get_terragrunt_dir()}/../../../../_apps/mashub/monitoring.hcl"
  merge_strategy = "deep"
}

inputs = {
  scheduled_log_alerts = {
    concentrix_no_feedback_24h = {
      enabled = false
    }
  }
  secret_alerts = {
    concentrix = {
      action_group_map_key = "incidents"
      key_vault = {
        id = "/subscriptions/6289fbfa-0b84-4f9e-8250-684455e9bb1a/resourceGroups/RG-M-KEYVAULT-mbp4aadb2c/providers/Microsoft.KeyVault/vaults/kv-mbp4aadb2c-djuwmyrf"
      }
      secret = {
        name = "Concentrix"
        key = "aadb2c-sp-mbportalConcentrixclt-secret"
      }
      sop = {
        url = "https://confluence.apps.union-investment.de/spaces/CISTAB/pages/225545166"
      }
    }
    finco = {
      action_group_map_key = "incidents"
      key_vault = {
        id = "/subscriptions/6289fbfa-0b84-4f9e-8250-684455e9bb1a/resourceGroups/RG-M-KEYVAULT-mbp4aadb2c/providers/Microsoft.KeyVault/vaults/kv-mbp4aadb2c-djuwmyrf"
      }
      secret = {
        name = "Finco"
        key = "aadb2c-sp-mbportalFINCOclt-secret"
      }
      sop = {
        url = "https://confluence.apps.union-investment.de/spaces/CISTAB/pages/225549345"
      }
    }
  }
}
