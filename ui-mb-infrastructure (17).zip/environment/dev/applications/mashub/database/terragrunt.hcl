include "root" {
  path           = find_in_parent_folders("root.hcl")
  merge_strategy = "deep"
}

include "app" {
  path           = "${get_terragrunt_dir()}/../../../../_apps/mashub/database.hcl"
  merge_strategy = "deep"
}

inputs = {
  server_admins = {
    ee09cf6 = {
      user_principal_name      = "ee09cf6@union-investment.de" // Iftime, Daniel (UIT/ADMIN)
      user_principal_object_id = "836603c0-15e7-4ee7-a6e7-a3e463c8ad96"
    }
  }
  server_parameters = {
    "max_prepared_transactions" = "859"
  }
}
