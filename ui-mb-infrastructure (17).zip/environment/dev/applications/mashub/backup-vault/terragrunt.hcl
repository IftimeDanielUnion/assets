include "root" {
  path           = find_in_parent_folders("root.hcl")
  merge_strategy = "deep"
}

include "app" {
  path           = "${get_terragrunt_dir()}/../../../../_apps/mashub/backup-vault.hcl"
  merge_strategy = "deep"
}

inputs = {
  # DEV-specific overrides if needed
}
