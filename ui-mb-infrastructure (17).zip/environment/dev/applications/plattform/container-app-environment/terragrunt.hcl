include "root" {
  path           = find_in_parent_folders("root.hcl")
  merge_strategy = "deep"
}

include "app" {
  path           = "${get_terragrunt_dir()}/../../../../_apps/plattform/container-app-environment.hcl"
  merge_strategy = "deep"
}

inputs = {
  container_subnet_id = "/subscriptions/6289fbfa-0b84-4f9e-8250-684455e9bb1a/resourceGroups/rg-marktbearbeitung-dev-networking/providers/Microsoft.Network/virtualNetworks/vnet-marktbearbeitung-dev-swc-01/subnets/containerapp"
}
