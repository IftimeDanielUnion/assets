locals {
  tags = {
    application = "Plattform Commons"
  }
}
inputs = {
  app_name = "plattform"
}
