include "root" {
  path           = find_in_parent_folders("root.hcl")
  merge_strategy = "deep"
}

dependency "monitoring" {
  config_path = "${get_terragrunt_dir()}/../monitoring"
}

include "app" {
  path           = "${get_terragrunt_dir()}/../../../../_apps/im-action-hub/functionapp.hcl"
  merge_strategy = "deep"
}

inputs = {
  # DEV: Basic SKU für Entwicklung, 1 Instanz
  instance_count = 1
  sku_name       = "B2"

  # DEV Azure AD Authentication Settings
  # Service Principal: IM-Action-Hub (DEV) aus marktbearbeitung.yml
  # KeyVault für Credentials: kv-21d79b9b0ff404b6dcba
  auth_settings = {
    client_id                  = "cef76042-a499-4602-8e13-7fdc0934f7ff"
    tenant_auth_endpoint       = "https://login.microsoftonline.com/2eb07b91-f9f8-437b-a89e-59f55e565c11/v2.0"
    allowed_audiences          = ["cef76042-a499-4602-8e13-7fdc0934f7ff"]
    allowed_applications       = ["506b92f5-ada0-45e0-864c-89b47b3a57c6", "04b07795-8ddb-461a-bbee-02f9e1bf7b46"] #impulsmanager-dev and azure-cli-client
    require_authentication     = true
    unauthenticated_action     = "Return401"
    excluded_paths             = ["/api/q/health"]
  }
}
