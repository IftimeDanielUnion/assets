locals {
  tags = {
    application = "IM Action Hub (Impulsmanager)"
  }
}

inputs = {
  app_name = "im-action-hub"
}
