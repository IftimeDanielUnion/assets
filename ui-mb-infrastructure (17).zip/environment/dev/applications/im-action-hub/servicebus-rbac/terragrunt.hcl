include "root" {
  path           = find_in_parent_folders("root.hcl")
  merge_strategy = "deep"
}

include "app" {
  path           = "${get_terragrunt_dir()}/../../../../_apps/im-action-hub/servicebus-rbac.hcl"
  merge_strategy = "deep"
}
