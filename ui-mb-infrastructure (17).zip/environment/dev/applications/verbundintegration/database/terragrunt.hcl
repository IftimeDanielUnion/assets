include "root" {
  path           = find_in_parent_folders("root.hcl")
  merge_strategy = "deep"
}

include "app" {
  path           = "${get_terragrunt_dir()}/../../../../_apps/verbundintegration/database.hcl"
  merge_strategy = "deep"
}

inputs = {
  sku_settings = {
    name = "Standard_B1ms"
    tier = "Burstable"
  }
}
