include "root" {
  path           = find_in_parent_folders("root.hcl")
  merge_strategy = "deep"
}

dependency "monitoring" {
  config_path = "${get_terragrunt_dir()}/../monitoring"
}

include "app" {
  path           = "${get_terragrunt_dir()}/../../../../_apps/verbundintegration/functionapp.hcl"
  merge_strategy = "deep"
}

inputs = {
  instance_count = 1
  sku_name       = "B2"

  health_check = {
    eviction_time_in_min = 5
    path                 = "/api/health/live"
    monitoring_alert = {
      actions = [(
        {
          action_group_id = dependency.monitoring.outputs.action_groups["incidents"].resource_id
        }
      )] # This group is defined in _apps/verbundintegration/monitoring.hcl
      resource_group_name = dependency.monitoring.outputs.resource_group
    }
  }

  # DEV-specific Azure AD Authentication Settings
  # App Registration: VBST (DEV)
  auth_settings = {
    client_id            = "d396935a-8c1f-4c3a-992c-c326545f982d"
    tenant_auth_endpoint = "https://login.microsoftonline.com/2eb07b91-f9f8-437b-a89e-59f55e565c11/v2.0/.well-known/openid-configuration"
    allowed_audiences    = ["d396935a-8c1f-4c3a-992c-c326545f982d"]
    allowed_applications = [
      "d396935a-8c1f-4c3a-992c-c326545f982d",
      "1fcbfe9d-45df-40ff-994e-68e7f0d7c13a" # VBST Dashboard (DEV)
    ]

    # UI-CHG-0091618: Health-Endpunkte von Easy Auth ausnehmen. Ohne die Ausnahme
    # wird der Plattform-Health-Check vor Erreichen der Function mit 401 beendet.
    excluded_paths = ["/api/health/live", "/api/health/ready", "/api/health/healthz"]
  }
}
