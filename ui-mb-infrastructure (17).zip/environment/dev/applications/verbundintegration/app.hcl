locals {
  tags = {
    application = "Verbundschnittstelle TRUUCO"
  }
}
inputs = {
  app_name = "vbst"
}
