locals {
  tags = {
    application = "UBA Anbindung"
  }
}
inputs = {
  app_name = "uba"
  vnet_subnet_name = "privateendpoints"
}
