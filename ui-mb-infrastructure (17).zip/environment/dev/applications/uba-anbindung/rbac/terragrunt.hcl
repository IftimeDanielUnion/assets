include "root" {
  path           = find_in_parent_folders("root.hcl")
  merge_strategy = "deep"
}

include "app" {
  path           = "${get_terragrunt_dir()}/../../../../_apps/uba-anbindung/rbac.hcl"
  merge_strategy = "deep"
}

inputs = {
  role_assignments = {
    container_app_acr_access = {
      scope = "/subscriptions/6289fbfa-0b84-4f9e-8250-684455e9bb1a/resourceGroups/RG-M-ACR-cr-mb-dev/providers/Microsoft.ContainerRegistry/registries/crcrmbdevajdlcmno"
    }
  }
}
