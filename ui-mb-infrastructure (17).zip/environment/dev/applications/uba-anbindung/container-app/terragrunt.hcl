include "root" {
  path           = find_in_parent_folders("root.hcl")
  merge_strategy = "deep"
}

include "app" {
  path           = "${get_terragrunt_dir()}/../../../../_apps/uba-anbindung/container-app.hcl"
  merge_strategy = "deep"
}

inputs = {
  image = "crcrmbdevajdlcmno.azurecr.io/marktbearbeitungsplattform/team-mandalorian/uba-anbindung:0.1.0"
  registry_server = "crcrmbdevajdlcmno.azurecr.io"
}
