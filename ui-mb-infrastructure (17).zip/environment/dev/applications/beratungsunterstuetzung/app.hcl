locals {
  tags = {
    application = "IW Beratungsunterstützung"
  }
}
inputs = {
  app_name = "bu"
}
