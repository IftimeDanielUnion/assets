locals {
  backend_container_name       = "terraform-state"
  backend_storage_account_name = "sawd514852ab080b6472"
  backend_resource_group_name  = "rg-marktbearbeitung-dev-managed-resources"

  workload        = "MARKTBEARBEITUNG"
  environment     = "dev"
  subscription_id = "6289fbfa-0b84-4f9e-8250-684455e9bb1a"

  tags = {
    environment = local.environment
  }
}

inputs = {
  location                          = "swedencentral"
  vnet_name                         = "vnet-marktbearbeitung-dev-swc-01"
  vnet_resource_group_name          = "rg-marktbearbeitung-dev-networking"
  vnet_subnet_name                  = "default"
  # vnet_subnet_name_privateendpoints wird NICHT global gesetzt!
  # Stattdessen wird es app-spezifisch in den jeweiligen App-Templates definiert,
  # damit bestehende Apps (VBST, Mashub, etc.) im default Subnet bleiben.
  vnet_subnet_name_appgw            = "AppGatewaySubnet"
  vnet_subnet_name_functionapp      = "functionapp"

  # Defender is active for the whole subscription
  integrate_defender_for_storage = {
    endpoint_resource_id = "/subscriptions/${local.subscription_id}/providers/Microsoft.Security/datascanners/storageDataScanner"
    endpoint_tenant_id   = "2eb07b91-f9f8-437b-a89e-59f55e565c11"
  }
}
