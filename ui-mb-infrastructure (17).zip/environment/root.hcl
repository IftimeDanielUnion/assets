locals {
  # Load environment- and app-level variables
  environment_vars = read_terragrunt_config(find_in_parent_folders("env.hcl"))
  app_vars         = read_terragrunt_config(find_in_parent_folders("app.hcl"))

  workload_name        = local.environment_vars.locals.workload
  workload_environment = local.environment_vars.locals.environment
  subscription_id      = local.environment_vars.locals.subscription_id

  tags = merge(
    {
      # Deployment metadata
      deployment_type = "terraform"

      # Cost allocation tags
      workload    = local.workload_name
      environment = local.workload_environment
      cost_center = "MARKTBEARBEITUNG"

    },
    try(local.environment_vars.locals.tags, {}),
    try(local.app_vars.locals.tags, {})
  )
}

# Generate an AzureRM provider block
generate "provider" {
  path      = "provider.tf"
  if_exists = "overwrite_terragrunt"
  contents  = <<EOF
terraform {
  required_version = "~> 1.13"
  required_providers {
    azurerm = {
      source = "hashicorp/azurerm"
      version = "~>4.64"
    }
  }
}

provider "azurerm" {
  storage_use_azuread = true
  subscription_id = "${local.subscription_id}"
  features {
    resource_group {
      prevent_deletion_if_contains_resources = false
    }
  }
}
EOF
}

remote_state {
  backend = "azurerm"
  generate = {
    path      = "backend.tf"
    if_exists = "overwrite"
  }
  config = {
    subscription_id      = "${local.subscription_id}"
    key                  = "${path_relative_to_include()}/terraform.tfstate"
    resource_group_name  = local.environment_vars.locals.backend_resource_group_name
    storage_account_name = local.environment_vars.locals.backend_storage_account_name
    container_name       = local.environment_vars.locals.backend_container_name
  }
}

inputs = merge(
  local.environment_vars.inputs,
  local.app_vars.inputs,
  {
    workload_name        = local.workload_name
    workload_environment = local.workload_environment
    subscription_id      = local.subscription_id
    tags                 = local.tags
  }
)
