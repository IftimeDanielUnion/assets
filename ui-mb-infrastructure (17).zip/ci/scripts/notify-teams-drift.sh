#!/usr/bin/env bash
#
# notify-teams-drift.sh
#
# Sends a Teams Adaptive Card notification about drift-check results to a Power
# Automate Workflow webhook. Receives all inputs via environment variables.
#
# Required env vars:
#   TEAMS_WEBHOOK_URL  - Power Automate Workflow webhook URL (secret)
#   EXIT_CODE          - terragrunt exit code: 2=drift, 1=error, 0=clean (caller filters out 0)
#   ENVIRONMENT        - DEV / TEST / PROD
#   SUBSCRIPTION       - subscription label for context, e.g. S_MARKTBEARBEITUNG_PROD
#   BUILD_URL          - clickable link to the pipeline run
#   SUMMARY_FILE       - path to a text file containing per-stack `Plan: ...` lines
#
# Behaviour:
#   - On drift (EXIT_CODE=2): warning-style card with plan summary
#   - On error (any other non-zero): attention-style card, generic message
#   - Caller is expected to skip invocation when EXIT_CODE=0
#   - On delivery failure: prints verbose diagnostics (TLS handshake, proxy env, response body)
#     so a self-hosted-agent network issue can be debugged from the pipeline log alone.
#   - Failure to deliver does NOT fail the pipeline (notification failure must
#     not mask the underlying drift signal).

set -uo pipefail

if [[ -z "${TEAMS_WEBHOOK_URL:-}" ]]; then
  echo "TEAMS_WEBHOOK_URL not set - skipping notification."
  exit 0
fi

if ! command -v jq >/dev/null 2>&1; then
  echo "##vso[task.logissue type=warning]jq not available on agent - cannot send Teams notification"
  exit 0
fi

case "${EXIT_CODE:-}" in
  2)
    title="⚠️ Drift detected in ${ENVIRONMENT}"
    color="warning"
    if [[ -s "${SUMMARY_FILE}" ]]; then
      # Limit to 30 lines so the card stays under Teams' size limit
      summary=$(head -n 30 "${SUMMARY_FILE}")
    else
      summary="(no per-stack summary; see plan log artifact)"
    fi
    ;;
  0)
    echo "EXIT_CODE=0 - no notification needed."
    exit 0
    ;;
  *)
    title="❌ Drift check failed in ${ENVIRONMENT}"
    color="attention"
    summary="Pipeline encountered an error during plan (exit ${EXIT_CODE}). Check the pipeline run for details."
    ;;
esac

# Build Adaptive Card payload via jq - safer than heredoc for content with quotes/newlines.
payload=$(jq -n \
  --arg title       "${title}" \
  --arg color       "${color}" \
  --arg subtext     "Subscription: ${SUBSCRIPTION}" \
  --arg summary     "${summary}" \
  --arg url         "${BUILD_URL}" \
  '{
    type: "message",
    attachments: [{
      contentType: "application/vnd.microsoft.card.adaptive",
      content: {
        "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
        type: "AdaptiveCard",
        version: "1.4",
        body: [
          { type: "TextBlock", size: "Medium", weight: "Bolder", color: $color, text: $title, wrap: true },
          { type: "TextBlock", text: $subtext, isSubtle: true, wrap: true },
          { type: "TextBlock", text: "Plan summary:", weight: "Bolder", spacing: "Medium" },
          { type: "TextBlock", text: $summary, wrap: true, fontType: "Monospace" }
        ],
        actions: [
          { type: "Action.OpenUrl", title: "View pipeline run", url: $url }
        ]
      }
    }]
  }')

# Validate payload is well-formed before sending
if ! echo "${payload}" | jq empty 2>/dev/null; then
  echo "##vso[task.logissue type=warning]Constructed payload is not valid JSON, falling back to minimal card"
  payload=$(jq -n \
    --arg title "${title}" \
    --arg url "${BUILD_URL}" \
    '{
      type: "message",
      attachments: [{
        contentType: "application/vnd.microsoft.card.adaptive",
        content: {
          type: "AdaptiveCard",
          version: "1.4",
          body: [{ type: "TextBlock", weight: "Bolder", text: $title, wrap: true }],
          actions: [{ type: "Action.OpenUrl", title: "View pipeline run", url: $url }]
        }
      }]
    }')
fi

response_file=$(mktemp)
stderr_file=$(mktemp)

# Attempt delivery. Capture HTTP code and curl exit code separately.
# --connect-timeout fails fast if outbound is blocked at the firewall.
# --max-time caps total operation time so a hanging proxy can't stall the pipeline.
http_code=$(curl -sS \
  -o "${response_file}" \
  -w "%{http_code}" \
  --connect-timeout 10 \
  --max-time 30 \
  -X POST \
  -H "Content-Type: application/json" \
  --data "${payload}" \
  "${TEAMS_WEBHOOK_URL}" 2>"${stderr_file}") || true
curl_exit=$?

if [[ "${http_code}" =~ ^2[0-9]{2}$ ]]; then
  echo "Teams notification delivered (HTTP ${http_code})"
  rm -f "${response_file}" "${stderr_file}"
  exit 0
fi

# --- Failure path: emit diagnostics so the pipeline operator can see why ---
echo "##vso[task.logissue type=warning]Teams notification failed (curl exit=${curl_exit}, http_code=${http_code:-none})"
echo ""
echo "=== curl stderr ==="
cat "${stderr_file}" 2>/dev/null || echo "(empty)"
echo ""
echo "=== response body (first 500 bytes) ==="
head -c 500 "${response_file}" 2>/dev/null || echo "(empty)"
echo ""
echo "=== proxy environment ==="
env | grep -iE '^(https?_proxy|no_proxy)=' || echo "(no proxy env vars set)"
echo ""
echo "=== webhook host DNS lookup ==="
# Pull host out of the URL without leaking the signature
webhook_host=$(echo "${TEAMS_WEBHOOK_URL}" | sed -E 's|^https?://([^/:]+).*|\1|')
echo "Host: ${webhook_host}"
getent hosts "${webhook_host}" 2>/dev/null || echo "DNS lookup failed for ${webhook_host}"
echo ""
echo "=== verbose retry (TLS handshake detail; signature redacted) ==="
# Re-run with -v to capture TLS layer info. The signature query parameters are
# redacted from the log output so they don't leak into the pipeline log.
redacted_url="${TEAMS_WEBHOOK_URL%%\?*}"
curl -v \
  --connect-timeout 10 \
  --max-time 30 \
  -X POST \
  -H "Content-Type: application/json" \
  --data '{}' \
  "${redacted_url}?diagnostic=1" 2>&1 \
  | sed -E 's/(sig|sv|sp)=[^&[:space:]]+/\1=***/g' \
  | head -n 40 || true

echo ""
echo "----"
echo "Pipeline result still reflects the drift signal. Investigate webhook reachability:"
echo "  - Is *.environment.api.powerplatform.com:443 allowed for outbound from the build agent?"
echo "  - Does the corporate proxy require HTTPS_PROXY env var to be set on the agent?"
echo "  - Is there a TLS-inspection appliance breaking the handshake?"

rm -f "${response_file}" "${stderr_file}"
exit 0
