# Drift Detection

Scheduled pipeline that detects drift between the Terraform state and the actual
Azure resources. Runs `terragrunt run --all plan -detailed-exitcode` over all
applications in DEV / TEST / PROD on a daily schedule and notifies Microsoft
Teams when drift is detected.

## Owner

DevOps Engineers in der Marktbearbeitung. The Teams Workflow that owns the
webhook is co-owned by at least two team members so that the flow does not
become an orphan when one owner leaves.

## What it runs

- Pipeline: `ci/pipeline.drift-check.yml`
- Stage template: `ci/templates/stages.drift-check.yml`
- Notification helper: `ci/scripts/notify-teams-drift.sh`
- Schedule: `Mon-Fri 06:00 UTC` (only fires when YAML is on `main`)
- Per environment: separate stage with `dependsOn: []`, runs in parallel
- Pool: `azdo_agent_marktbearbeitung_prod` (existing self-hosted pool)
- Service connection: existing `Workload CI/CD Service Connection (S_MARKTBEARBEITUNG_<ENV>)`
- Operation: PLAN ONLY. The pipeline never applies and is therefore safe to run
  manually from any branch against any environment.

## Pipeline result mapping

| terragrunt exit code | Meaning                | Pipeline result        | Teams notification |
| -------------------- | ---------------------- | ---------------------- | ------------------ |
| 0                    | No changes anywhere    | Succeeded              | none               |
| 2                    | Drift detected         | SucceededWithIssues    | warning card       |
| 1 / other            | Plan errored           | Failed                 | attention card     |

## Setup (one-time)

These steps must be done in Azure DevOps and Microsoft Teams once before the
pipeline can be merged to `main`.

### 1. Create the Teams channel and Workflow webhook

1. Create channel `MB-Infra Drift Alerts` in the appropriate Team
2. In the channel: `…` → `Workflows` → template `Post to a channel when a webhook request is received`
3. Name the workflow `MB-Infra Drift Alerts Webhook`
4. Pick the team and channel from step 1
5. Copy the webhook URL (long URL containing `prod-…logic.azure.com`)
6. Add a co-owner from the team via the Power Automate portal so the flow does
   not become an orphan

### 2. Create the Variable Group

1. In Azure DevOps: `Pipelines` → `Library` → `+ Variable group`
2. Name: `mb-infra-drift-notifications`
3. Add variable `TEAMS_WEBHOOK_URL` with the URL from step 1
4. Mark it as a secret (the lock icon)
5. `Pipeline permissions`: grant access to the `pipeline.drift-check` pipeline

### 3. Run the manual baseline

Before merging to `main` and letting the schedule fire, run the pipeline
manually for each environment from the feature branch. The first run will very
likely surface drift that has accumulated unnoticed over time. Either resolve
that drift or document it explicitly (e.g. add to `lifecycle.ignore_changes` in
the affected module) before going live with the schedule.

### 4. Merge the feature branch

After the baseline is clean, merge the PR to `main`. The schedule only fires on
`main`, so the daily check is active from that point.

## Manual triggering

From the Azure DevOps Pipelines UI: `Run pipeline`. The form lets you pick:

- `environments` - subset of `[DEV, TEST, PROD]` to check. Default: all three.
- `sendNotification` - default true. Set to false when running test/calibration
  passes to avoid spamming the channel.

## Triage runbook

When a drift notification appears in the channel:

1. Open the linked pipeline run, scroll to the failed/warning stage
2. Look at the `Plan summary` step output (per-stack `Plan: X to add ...` lines)
3. For each affected stack:
   - **Expected drift** (someone made a manual change for a known reason):
     either add the property to `lifecycle.ignore_changes` in the relevant
     module, or commit the change properly via a PR. Document briefly in the
     stack's `terragrunt.hcl` if the manual change is intentional and ongoing.
   - **Unexpected drift** (no known cause): treat as incident, identify who or
     what changed the resource, restore desired state via apply or via portal.
   - **Provider-update noise** (after an azurerm bump): expected for a few
     stacks; either accept and apply, or pin a specific provider behaviour.
4. Confirm the next scheduled run goes green again.

## False-positive calibration phase

The first 2 weeks after going live are calibration: expect noise, document each
finding, fold suppressions or fixes back into the modules. Track in a small
list in this file under "Known calibrations":

### Known calibrations

(Empty initially - fill in during the first 2 weeks.)
