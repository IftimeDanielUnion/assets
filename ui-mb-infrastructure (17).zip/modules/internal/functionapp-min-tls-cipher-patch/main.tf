# WORKAROUND
# Setting this is currently not supported by the Azurerm provider resources for functions
# See the following for more information https://github.com/hashicorp/terraform-provider-azurerm/issues/24223
# And related PR https://github.com/hashicorp/terraform-provider-azurerm/pull/26584
data "azapi_resource_id" "funcconfig" {
  type      = "Microsoft.Web/sites/config@2023-12-01"
  parent_id = var.function_app_id
  name      = "web"
}

resource "azapi_resource_action" "setMinTlsCipherSuite" {
  type        = "Microsoft.Web/sites/config@2023-12-01"
  resource_id = data.azapi_resource_id.funcconfig.id
  method      = "PATCH"

  body = {
    name = "web"
    properties = {
      minTlsCipherSuite = "TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256"
    }
  }
}
