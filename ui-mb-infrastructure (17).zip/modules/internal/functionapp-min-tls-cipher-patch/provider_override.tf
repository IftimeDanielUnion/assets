## Add Azure/azapi for the patching of the TLS Cipher
terraform {
  # required_version = "~> 1.10"
  required_providers {
    azapi = {
      source  = "Azure/azapi"
      version = ">= 2.0"
    }
  }
}
