output "resource_id" {
  description = "The ID of the Log Analytics Workspace"
  value       = azurerm_log_analytics_workspace.main.id
}

output "resource_group" {
  description = "The name of the Resource Group of the Log Analytics Workspace"
  value       = azurerm_resource_group.main.name
}

output "name" {
  description = "The name of the Log Analytics Workspace"
  value       = azurerm_log_analytics_workspace.main.name
}

output "action_groups" {
  description = "The list of Action Groups"
  value = {
    for k, v in azurerm_monitor_action_group.main : k => {
      resource_id = v.id
      name        = v.name
      short_name  = v.short_name
    }
  }
}

output "application_insights" {
  description = "Info about the Application Insights"
  value = var.integrate_application_insights ? {
    id                  = azurerm_application_insights.main[0].id
    app_id              = azurerm_application_insights.main[0].app_id
    instrumentation_key = azurerm_application_insights.main[0].instrumentation_key
    connection_string   = azurerm_application_insights.main[0].connection_string
  } : {}
  sensitive = true
}

output "scheduled_log_alerts" {
  description = "The list of Scheduled Log Alerts (Application Insights)"
  value = {
    for k, v in azurerm_monitor_scheduled_query_rules_alert_v2.main : k => {
      id   = v.id
      name = v.name
    }
  }
}

output "log_analytics_alerts" {
  description = "The list of Log Analytics Alerts"
  value = {
    for k, v in azurerm_monitor_scheduled_query_rules_alert_v2.log_analytics : k => {
      id   = v.id
      name = v.name
    }
  }
}
