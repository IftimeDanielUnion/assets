## ALERTING

## Dynamically defined Scheduled Query Alerts (Application Insights)
resource "azurerm_monitor_scheduled_query_rules_alert_v2" "main" {
  for_each = var.scheduled_log_alerts

  name                = replace(each.value.name, "%scope_name%", azurerm_application_insights.main[0].name)
  resource_group_name = azurerm_resource_group.main.name
  location            = azurerm_resource_group.main.location
  scopes              = [azurerm_application_insights.main[0].id]

  description          = replace(each.value.description, "%scope_name%", azurerm_application_insights.main[0].name)
  enabled              = each.value.enabled
  auto_mitigation_enabled = each.value.auto_mitigation_enabled
  evaluation_frequency = each.value.evaluation_frequency
  severity             = each.value.severity
  tags                 = var.tags
  window_duration      = each.value.window_duration

  dynamic "criteria" {
    for_each = each.value.criteria
    iterator = crit
    content {
      operator                = crit.value.operator
      query                   = crit.value.query
      threshold               = crit.value.threshold
      time_aggregation_method = crit.value.time_aggregation_method
      metric_measure_column   = crit.value.metric_measure_column

      dynamic "dimension" {
        for_each = crit.value.dimension
        iterator = dim
        content {
          values   = dim.value.values
          name     = dim.value.name
          operator = dim.value.operator
        }
      }

      failing_periods {
        minimum_failing_periods_to_trigger_alert = 1
        number_of_evaluation_periods             = 1
      }
    }
  }
  action {
    action_groups = [azurerm_monitor_action_group.main[each.value.action_group_map_key].id]
  }
}

## Dynamically defined Scheduled Query Alerts (Log Analytics)
resource "azurerm_monitor_scheduled_query_rules_alert_v2" "log_analytics" {
  for_each = var.log_analytics_alerts

  name                = replace(each.value.name, "%scope_name%", azurerm_log_analytics_workspace.main.name)
  resource_group_name = azurerm_resource_group.main.name
  location            = azurerm_resource_group.main.location
  scopes              = [azurerm_log_analytics_workspace.main.id]

  description          = replace(each.value.description, "%scope_name%", azurerm_log_analytics_workspace.main.name)
  enabled              = each.value.enabled
  auto_mitigation_enabled = each.value.auto_mitigation_enabled
  evaluation_frequency = each.value.evaluation_frequency
  severity             = each.value.severity
  tags                 = var.tags
  window_duration      = each.value.window_duration

  dynamic "criteria" {
    for_each = each.value.criteria
    iterator = crit
    content {
      operator                = crit.value.operator
      query                   = crit.value.query
      threshold               = crit.value.threshold
      time_aggregation_method = crit.value.time_aggregation_method
      metric_measure_column   = crit.value.metric_measure_column

      dynamic "dimension" {
        for_each = crit.value.dimension
        iterator = dim
        content {
          values   = dim.value.values
          name     = dim.value.name
          operator = dim.value.operator
        }
      }

      failing_periods {
        minimum_failing_periods_to_trigger_alert = 1
        number_of_evaluation_periods             = 1
      }
    }
  }
  action {
    action_groups = [azurerm_monitor_action_group.main[each.value.action_group_map_key].id]
  }
}

## Alerts for expiring secrets in KeyVaults
resource "azurerm_monitor_scheduled_query_rules_alert_v2" "secret" {
  for_each = var.secret_alerts

  name                = "TAB - secret ${each.value.secret.name} expiring in 30 days in S_MARKTBEARBEITUNG_${upper(var.workload_environment)}"
  resource_group_name = azurerm_resource_group.main.name
  location            = azurerm_resource_group.main.location
  scopes              = [each.value.key_vault.id]

  description          = <<-EOT
  Das Secret ${each.value.secret.name} läuft in 30 Tagen in der Umgebung ${var.workload_environment} ab.
  Dafür sind manuelle Schritte notwendig. SOP: ${each.value.sop.url}"
  EOT
  enabled              = each.value.enabled
  evaluation_frequency = each.value.evaluation_frequency
  severity             = each.value.severity
  tags                 = var.tags
  window_duration      = each.value.window_duration

  criteria {
    query = <<-EOT
      AzureDiagnostics
      | where OperationName == "SecretNearExpiryEventGridNotification"
      | where eventGridEventProperties_data_ObjectName_s == "${each.value.secret.key}"
    EOT

    time_aggregation_method = "Count"
    operator                = "GreaterThan"
    threshold               = 0

    failing_periods {
      minimum_failing_periods_to_trigger_alert = 1
      number_of_evaluation_periods             = 1
    }
  }

  action {
    action_groups = [azurerm_monitor_action_group.main[each.value.action_group_map_key].id]
  }
}

## Standard Web Tests and corresponding Alerts
# Test
resource "azurerm_application_insights_standard_web_test" "availability_check" {
  for_each                = try({ for endpoint in var.external_endpoint_check.endpoints : endpoint.url => endpoint }, {})
  name                    = "Availability-Test ${each.value.name}"
  resource_group_name     = azurerm_resource_group.main.name
  location                = azurerm_resource_group.main.location
  application_insights_id = azurerm_application_insights.main[0].id
  # We try to ping our sites from 2 different and relevant geo locations West-Europe and North Europe
  # see https://learn.microsoft.com/en-us/previous-versions/azure/azure-monitor/app/monitor-web-app-availability#location-population-tags
  geo_locations = ["emea-nl-ams-azr", "emea-gb-db3-azr"]

  request {
    url                              = "https://${each.key}/"
    parse_dependent_requests_enabled = false
  }
  retry_enabled = true
  validation_rules {
    ssl_check_enabled = true
  }
  enabled = true
  tags    = var.tags
}

# Alert on failed test
resource "azurerm_monitor_metric_alert" "availability_alert" {
  for_each            = try({ for endpoint in var.external_endpoint_check.endpoints : endpoint.url => endpoint }, {})
  name                = replace(var.external_endpoint_check.name, "%scope_name%", each.value.name)
  resource_group_name = azurerm_resource_group.main.name
  scopes = [
    azurerm_application_insights_standard_web_test.availability_check[each.key].id,
    azurerm_application_insights.main[0].id
  ]

  description = replace(var.external_endpoint_check.description, "%scope_name%", each.value.name)
  severity    = var.external_endpoint_check.severity

  frequency   = var.external_endpoint_check.frequency
  window_size = var.external_endpoint_check.window_size

  application_insights_web_test_location_availability_criteria {
    web_test_id           = azurerm_application_insights_standard_web_test.availability_check[each.key].id
    component_id          = azurerm_application_insights.main[0].id
    failed_location_count = 1
  }
  action {
    action_group_id = azurerm_monitor_action_group.main[var.external_endpoint_check.action_group_map_key].id
  }
  enabled = true
  tags    = var.tags
}

# Alert for security related events
resource "azurerm_monitor_activity_log_alert" "activity_alerts" {
  for_each = { for a in var.activity_log_alerts : a.name => a }
  name                = "${each.key}"
  resource_group_name = azurerm_resource_group.main.name
  location            = "westeurope"
  scopes              = ["/subscriptions/${var.subscription_id}"]
  description         = each.value.description

  criteria {
    category       = each.value.category
    operation_name = each.value.operation_name
    levels = ["Verbose", "Informational", "Warning", "Error", "Critical"]
  }
  action {
    action_group_id = azurerm_monitor_action_group.main[var.action_group_map_key].id
  }
}

## Alert Processing Rules for Suppression
resource "azurerm_monitor_alert_processing_rule_suppression" "main" {
  for_each = var.alert_processing_rules

  name                = each.value.name
  resource_group_name = azurerm_resource_group.main.name
  # If scopes are empty, default to the resource group scope
  # If scopes contain placeholder variables, replace them with actual values
  scopes = length(each.value.scopes) > 0 ? [
    for scope in each.value.scopes :
    replace(
      replace(
        replace(scope, "$${subscription_id}", var.subscription_id),
        "$${resource_group_name}", azurerm_resource_group.main.name
      ),
      "$${resource_group_id}", azurerm_resource_group.main.id
    )
  ] : [azurerm_resource_group.main.id]
  description = each.value.description
  enabled     = each.value.enabled
  tags        = var.tags

  dynamic "condition" {
    for_each = each.value.condition != null ? [each.value.condition] : []
    content {
      dynamic "alert_rule_name" {
        for_each = condition.value.alert_rule_name != null ? [condition.value.alert_rule_name] : []
        content {
          operator = alert_rule_name.value.operator
          values   = alert_rule_name.value.values
        }
      }

      dynamic "severity" {
        for_each = condition.value.severity != null ? [condition.value.severity] : []
        content {
          operator = severity.value.operator
          values   = severity.value.values
        }
      }
    }
  }

  dynamic "schedule" {
    for_each = each.value.schedule != null ? [each.value.schedule] : []
    content {
      effective_from  = schedule.value.effective_from
      effective_until = schedule.value.effective_until
      time_zone       = schedule.value.time_zone

      dynamic "recurrence" {
        for_each = schedule.value.recurrence != null ? [schedule.value.recurrence] : []
        content {
          dynamic "daily" {
            for_each = recurrence.value.daily
            content {
              start_time = daily.value.start_time
              end_time   = daily.value.end_time
            }
          }

          dynamic "weekly" {
            for_each = recurrence.value.weekly
            content {
              days_of_week = weekly.value.days_of_week
              start_time   = weekly.value.start_time
              end_time     = weekly.value.end_time
            }
          }

          dynamic "monthly" {
            for_each = recurrence.value.monthly
            content {
              days_of_month = monthly.value.days_of_month
              start_time    = monthly.value.start_time
              end_time      = monthly.value.end_time
            }
          }
        }
      }
    }
  }
}
