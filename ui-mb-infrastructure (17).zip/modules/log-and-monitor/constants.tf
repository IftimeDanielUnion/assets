locals {
  ### Generic module behaviour
  ###

  ## Tag the module details
  module_name = {
    terraform_module         = "log-and-monitor",
    terraform_module_version = "1.0.0"
  }

  tags = merge(
    try(var.tags, {}),
    local.module_name
  )

  ### Specific module behaviour
  ###

  # Merge the action group's tags with the other tags
  action_group_tags = {
    for k, v in var.action_groups :
    k => {
      tags = merge(
        local.tags,
        v.tags
      )
    }
  }
}
module "naming" {
  source        = "Azure/naming/azurerm"
  version       = "0.4.2"
  suffix        = [lower(var.app_name), lower(var.workload_environment), lower(var.component_name)]
  unique-length = 8
}
