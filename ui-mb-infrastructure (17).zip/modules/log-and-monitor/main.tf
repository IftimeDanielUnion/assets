resource "azurerm_resource_group" "main" {
  name     = module.naming.resource_group.name
  location = var.location
  tags     = local.tags
}

resource "azurerm_log_analytics_workspace" "main" {

  name                = module.naming.log_analytics_workspace.name_unique
  resource_group_name = azurerm_resource_group.main.name
  location            = azurerm_resource_group.main.location
  tags                = local.tags

  sku               = "PerGB2018"
  retention_in_days = 30
  daily_quota_gb    = 5
}

resource "azurerm_application_insights" "main" {
  count = var.integrate_application_insights == true ? 1 : 0

  name                = module.naming.application_insights.name_unique
  resource_group_name = azurerm_resource_group.main.name
  location            = azurerm_resource_group.main.location
  workspace_id        = azurerm_log_analytics_workspace.main.id
  tags                = local.tags

  application_type   = "web"
  retention_in_days  = 30
  ip_masking_enabled = true
}

resource "azurerm_monitor_action_group" "main" {
  for_each            = var.action_groups
  name                = "${module.naming.monitor_action_group.name}-${each.key}"
  resource_group_name = azurerm_resource_group.main.name
  short_name          = each.value.short_name

  dynamic "email_receiver" {
    for_each = each.value.email_receiver
    iterator = email
    content {
      name                    = email.value.name
      email_address           = email.value.email_address
      use_common_alert_schema = email.value.use_common_alert_schema
    }
  }
  tags = local.action_group_tags[each.key].tags
}
