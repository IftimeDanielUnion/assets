variable "integrate_application_insights" {
  type        = bool
  description = <<DESCRIPTION
    (optional) If true an Application Insights instance is integrated with the Log Analytics Workspace. Defaults to false.
  DESCRIPTION
  default     = false
}

variable "action_groups" {
  type = map(object({
    short_name = string
    tags       = optional(map(string), {})
    email_receiver = list(object({
      name                    = string
      email_address           = string
      use_common_alert_schema = optional(bool)
    }))
  }))
  default     = {}
  nullable    = false
  description = <<DESCRIPTION
  (optional) A map of action group definitions. The keys are used as part of each action group's name.
  - `short_name` - (required) Display name of this Action Group
  - `tags` - (optional) Additional tags for this Action Group. These tags are merged with the general list of tags from variable `tags`.
  ---
  Block `email_receiver` defines the receivers with these arguments
  - `name` - (required) The name of the email receiver. Names must be unique (case-insensitive) across all receivers within an action group.
  - `email_address` - (required) The email address of this receiver.
  - `use_common_alert_schema` - (optional) Enables or disables the common alert schema. Defaults to false (don't use).
    See https://learn.microsoft.com/en-gb/azure/azure-monitor/alerts/alerts-common-schema for more
  DESCRIPTION
  validation {
    condition     = alltrue([for k, v in var.action_groups : (length(v.short_name) >= 1 && length(v.short_name) <= 12)])
    error_message = "expected length of short_name to be in the range (1 - 12)"
  }
}

variable "external_endpoint_check" {
  type = object({
    name                 = string
    description          = optional(string, "")
    action_group_map_key = string
    frequency            = string
    severity             = number
    window_size          = string
    endpoints = list(object({
      name = string
      url  = string
    }))
  })
  default     = null
  description = <<DESCRIPTION
  (optional) A definition of an Alert based on standard web tests on a list of endpoints.
  For each endpoint a dedicated alert is created. To distinguish these alerts, the two attributes `name` and `description`
  can have a placeholder `%scope_name%` which will be replaced with the name of the endpoint.

  - `name` - (required) The name of the Alerts. Use placeholder %scope_name%.
  - `description` - (optional) The description of the Alerts. Use placeholder %scope_name%.
  - `action_group_map_key` - (required) The key of an item in the variable `action_groups`. This action group is used for the Alerts.
  - `frequency` - (required) The evaluation frequency of the Alerts, represented in ISO 8601 duration format.
  - `severity` - (required Severity of the alerts. Should be an integer between 0 and 4. Value of 0 is severest.
  - `window_size` - (required) The period of time that is used to monitor alert activity, represented in ISO 8601 duration format. This value must be greater than frequency.

  ---
  Required block `endpoints` defines the list of Web Addresses which will be checked with a Standard Web Test each. These addresses must be reachable via https
  - `name` - (required) Display Name for this address
  - `fqdn` - (required) The domain name of the web address

  DESCRIPTION

  validation {
    condition     = var.external_endpoint_check == null || (var.integrate_application_insights && length(var.action_groups) > 0)
    error_message = "The checks of external endpoints needs Application Insights and at least one Action Group. You cannot create these checks without it."
  }

  validation {
    condition     = var.external_endpoint_check == null || contains([for k, v in var.action_groups : k], try(var.external_endpoint_check.action_group_map_key, ""))
    error_message = "The value of action_group_map_key must reference an existing key of variable action_groups."
  }
}


variable "scheduled_log_alerts" {
  type = map(object({
    name                 = string
    description          = optional(string, "")
    action_group_map_key = string
    enabled              = optional(bool, true)
    auto_mitigation_enabled = optional(bool, false)
    evaluation_frequency = string
    severity             = number
    window_duration      = string
    criteria = list(object({
      operator                = string
      query                   = string
      threshold               = number
      time_aggregation_method = string
      metric_measure_column   = optional(string, null)
      dimension = optional(set(object({
        name     = string
        operator = string
        values   = list(string)
      })), [])
    }))

  }))
  default     = {}
  nullable    = false
  description = <<DESCRIPTION
  (optional) A map of scheduled-query-alert-definitions which will be created in the scope of the Application Insights.
  If this variable is set, `integrate_application_insights` must be `true` and at least one item in `action_groups` is required.

  The two attributes `name` and `description` can have a placeholder `%scope_name%` which will be replaced with the name of the App Service Plan.
  - `name` - (required) The name of the Alert. Changing this forces a new resource to be created.
  - `description` - (optional) The description of this Alert.
  - `action_group_map_key` - (required) The key of an item in the variable `action_groups`. This action group is used for the Alert.
  - `enabled` - (optional) Should this Alert be enabled? Defaults to `true`.
  - `auto_mitigation_enabled` - (optional) Automatically resolve the alert and suppress repeated actions while the condition remains active. Defaults to `false`.
  - `evaluation_frequency` - (required) How often the scheduled query rule is evaluated, represented in ISO 8601 duration format.
  - `severity` - (required Severity of the alert. Should be an integer between 0 and 4. Value of 0 is severest.
  - `window_duration` - (required) Specifies the period of time in ISO 8601 duration format on which the Scheduled Query Rule will be executed.

  ---
  Required block `criteria` defines a list of queries to consider in the alert. The block supports these attributes:
  - `operator` - (required) The criteria operator.
  - `query` - (required) The query to run on logs. The results returned by this query are used to populate the alert.
  - `threshold` - (required) The criteria threshold value that activates the alert.
  - `time_aggregation_method` - (required) The type of aggregation to apply to the data points in aggregation granularity.
  - `metric_measure_column` - (optional) The column containing the metric measure number. Do not specify if `time_aggregation_method` is `Count`.

  ---
  Optional block `dimension` defines the filters for the metric. The block supports these attributes:
  - `name` - (required) One of the dimension names.
  - `operator` - (required) The dimension operator.
  - `values` - (required) The list of dimension values. Use a wildcard `*` to collect all.
  DESCRIPTION

  validation {
    condition     = length(var.scheduled_log_alerts) == 0 || (var.integrate_application_insights && length(var.action_groups) > 0)
    error_message = "Scheduled Log Alerts need Application Insights. You cannot create these alerts without it."
  }

  validation {
    condition     = alltrue([for k, v in var.scheduled_log_alerts : contains([for agk, agv in var.action_groups : agk], v.action_group_map_key)])
    error_message = "The value of action_group_map_key must reference an existing key of variable action_groups."
  }
}

variable "secret_alerts" {
  type = map(object({
    action_group_map_key = string
    enabled              = optional(bool, true)
    severity             = optional(number, 2)
    evaluation_frequency = optional(string, "PT15M")
    window_duration      = optional(string, "PT1H")
    key_vault = object({
      id  = string
    })
    secret = object({
      name = string
      key  = string
    })
    sop = object({
      url = string
    })
  }))
  default  = {}
  nullable = false
  description = <<DESCRIPTION
Map of secret expiration alert definitions, each defining an alert that triggers when a specific Azure Key Vault secret is near expiry.

Attributes:
- `action_group_map_key` (string, required): Key to select an action group from a predefined `action_groups` map for alert notification.
- `enabled` (bool, optional, default `true`): Whether this alert is enabled.
- `severity` (number, optional, default `2`): Alert severity level (0=critical to 4=informational).
- `evaluation_frequency` (string, optional, default `"PT15M"`): How often (ISO 8601 duration) the alert query is evaluated.
- `window_duration` (string, optional, default `"PT1H"`): Time window (ISO 8601 duration) for the query evaluation.

Nested objects:
- `key_vault` (object, required):
  - `id` (string): Key Vault resource ID.
- `secret` (object, required):
  - `name` (string): Descriptive name of the secret to monitor for expiry.
  - `key` (string): Key identifier for the secret.
- `sop` (object, required):
  - `url` (string): URL to the Standard Operating Procedure (SOP) or documentation related to secret renewal.

This variable drives the creation of scheduled query alerts in Azure Monitor that fire when the secret named in `secret.name` is about to expire, using a fixed KQL query filtered on that secret name.

DESCRIPTION

  validation {
    condition     = length(var.secret_alerts) == 0 || (length(var.action_groups) > 0)
    error_message = "Secret Alerts need action groups. You cannot create these alerts without it."
  }

  validation {
    condition     = alltrue([for k, v in var.secret_alerts : contains([for agk, agv in var.action_groups : agk], v.action_group_map_key)])
    error_message = "The value of action_group_map_key must reference an existing key of variable action_groups."
  }
}

variable "log_analytics_alerts" {
  type = map(object({
    name                 = string
    description          = optional(string, "")
    action_group_map_key = string
    enabled              = optional(bool, true)
    auto_mitigation_enabled = optional(bool, false)
    evaluation_frequency = string
    severity             = number
    window_duration      = string
    criteria = list(object({
      operator                = string
      query                   = string
      threshold               = number
      time_aggregation_method = string
      metric_measure_column   = optional(string, null)
      dimension = optional(set(object({
        name     = string
        operator = string
        values   = list(string)
      })), [])
    }))

  }))
  default     = {}
  nullable    = false
  description = <<DESCRIPTION
  (optional) A map of scheduled-query-alert-definitions which will be created in the scope of the Log Analytics Workspace.
  At least one item in `action_groups` is required if this variable is set.

  The two attributes `name` and `description` can have a placeholder `%scope_name%` which will be replaced with the name of the Log Analytics Workspace.
  - `name` - (required) The name of the Alert. Changing this forces a new resource to be created.
  - `description` - (optional) The description of this Alert.
  - `action_group_map_key` - (required) The key of an item in the variable `action_groups`. This action group is used for the Alert.
  - `enabled` - (optional) Should this Alert be enabled? Defaults to `true`.
  - `auto_mitigation_enabled` - (optional) Automatically resolve the alert and suppress repeated actions while the condition remains active. Defaults to `false`.
  - `evaluation_frequency` - (required) How often the scheduled query rule is evaluated, represented in ISO 8601 duration format.
  - `severity` - (required Severity of the alert. Should be an integer between 0 and 4. Value of 0 is severest.
  - `window_duration` - (required) Specifies the period of time in ISO 8601 duration format on which the Scheduled Query Rule will be executed.

  ---
  Required block `criteria` defines a list of queries to consider in the alert. The block supports these attributes:
  - `operator` - (required) The criteria operator.
  - `query` - (required) The query to run on logs. The results returned by this query are used to populate the alert.
  - `threshold` - (required) The criteria threshold value that activates the alert.
  - `time_aggregation_method` - (required) The type of aggregation to apply to the data points in aggregation granularity.
  - `metric_measure_column` - (optional) The column containing the metric measure number. Do not specify if `time_aggregation_method` is `Count`.

  ---
  Optional block `dimension` defines the filters for the metric. The block supports these attributes:
  - `name` - (required) One of the dimension names.
  - `operator` - (required) The dimension operator.
  - `values` - (required) The list of dimension values. Use a wildcard `*` to collect all.
  DESCRIPTION

  validation {
    condition     = length(var.log_analytics_alerts) == 0 || length(var.action_groups) > 0
    error_message = "Log Analytics Alerts need at least one Action Group. You cannot create these alerts without it."
  }

  validation {
    condition     = alltrue([for k, v in var.log_analytics_alerts : contains([for agk, agv in var.action_groups : agk], v.action_group_map_key)])
    error_message = "The value of action_group_map_key must reference an existing key of variable action_groups."
  }
}

variable "activity_log_alerts" {
  type = map(object({
    name           = string
    description    = string
    category       = string
    operation_name = string
  }))
  default     = {}
  description = <<DESCRIPTION
  (optional) A map of activity log alerts to identify and track suspicious activities within the Azure subscription.

  - `name` - (required) The name of the activity log alert. Changing this forces a new resource to be created..
  - `description` - (optional) The description of this activity log alert..
  - `category` - (required) The category of the operation. Possible values are Administrative, Autoscale, Policy, Recommendation, ResourceHealth, Security and ServiceHealth.
  - `operation_name` - (optional) The Resource Manager Role-Based Access Control operation name. Supported operation should be of the form: <resourceProvider>/<resourceType>/<operation>.
  DESCRIPTION
}

variable "action_group_map_key" {
  description = "Key of the action group to use for all alerts"
  type        = string
  default     = null
  nullable    = true
}

variable "alert_processing_rules" {
  type = map(object({
    name        = string
    description = optional(string, "")
    enabled     = optional(bool, true)
    scopes      = optional(list(string), [])
    condition = optional(object({
      alert_rule_name = optional(object({
        operator = string
        values   = list(string)
      }))
      severity = optional(object({
        operator = string
        values   = list(string)
      }))
    }))
    schedule = optional(object({
      effective_from  = optional(string)
      effective_until = optional(string)
      time_zone       = optional(string, "W. Europe Standard Time")
      recurrence = optional(object({
        daily = optional(list(object({
          start_time = string
          end_time   = string
        })), [])
        weekly = optional(list(object({
          days_of_week = list(string)
          start_time   = optional(string)
          end_time     = optional(string)
        })), [])
        monthly = optional(list(object({
          days_of_month = list(number)
          start_time    = optional(string)
          end_time      = optional(string)
        })), [])
      }))
    }))
  }))
  default     = {}
  nullable    = false
  description = <<DESCRIPTION
  (optional) A map of alert processing rule definitions for suppressing alerts during specific time windows (e.g., holidays, maintenance windows).

  - `name` - (required) The name of the Alert Processing Rule. Changing this forces a new resource to be created.
  - `description` - (optional) The description of this Alert Processing Rule.
  - `enabled` - (optional) Should this Alert Processing Rule be enabled? Defaults to `true`.
  - `scopes` - (required) List of resource IDs (alert rule IDs) that this processing rule applies to.

  ---
  Optional block `condition` defines filters for which alerts this rule applies to:
  - `alert_rule_name` - (optional) Filter by alert rule name
    - `operator` - (required) Operator for condition. Possible values: `Equals`, `NotEquals`, `Contains`, `DoesNotContain`.
    - `values` - (required) List of alert rule names to match.
  - `severity` - (optional) Filter by severity
    - `operator` - (required) Operator for condition. Possible values: `Equals`, `NotEquals`.
    - `values` - (required) List of severities to match. Possible values: `Sev0`, `Sev1`, `Sev2`, `Sev3`, `Sev4`.

  ---
  Optional block `schedule` defines when the suppression rule is active:
  - `effective_from` - (optional) Alert Processing Rule effective start time (Y-m-d'T'H:M:S).
  - `effective_until` - (optional) Alert Processing Rule effective end time (Y-m-d'T'H:M:S).
  - `time_zone` - (optional) Time zone. Defaults to `W. Europe Standard Time`.
  - `recurrence` - (optional) Recurrence block for recurring suppressions
    - `daily` - (optional) List of daily recurrence blocks
      - `start_time` - (required) Recurrence start time (H:M:S).
      - `end_time` - (required) Recurrence end time (H:M:S).
    - `weekly` - (optional) List of weekly recurrence blocks
      - `days_of_week` - (required) List of days. Possible values: `Sunday`, `Monday`, `Tuesday`, `Wednesday`, `Thursday`, `Friday`, `Saturday`.
      - `start_time` - (optional) Recurrence start time (H:M:S).
      - `end_time` - (optional) Recurrence end time (H:M:S).
    - `monthly` - (optional) List of monthly recurrence blocks
      - `days_of_month` - (required) List of days (1-31).
      - `start_time` - (optional) Recurrence start time (H:M:S).
      - `end_time` - (optional) Recurrence end time (H:M:S).
  DESCRIPTION
}
