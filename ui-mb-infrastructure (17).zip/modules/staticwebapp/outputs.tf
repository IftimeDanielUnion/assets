output "resource_id" {
  value       = azurerm_static_web_app.main.id
  description = "Resource Id of this Static Web App"
}

output "default_host_name" {
  value       = azurerm_static_web_app.main.default_host_name
  description = "The internal domain name of this Static Web App"
}

output "principal_id" {
  value       = azurerm_static_web_app.main.identity[0].principal_id
  description = "Principal ID of the System Assigned Identity (always available)"
}

output "key_vault_id" {
  value       = azurerm_key_vault.main.id
  description = "Resource ID of the associated Key Vault"
}
