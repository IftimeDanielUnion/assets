##
# Default Subnet for Private Endpoint Integration

data "azurerm_subnet" "default" {
  name                 = var.vnet_subnet_name
  virtual_network_name = var.vnet_name
  resource_group_name  = var.vnet_resource_group_name
}

##
# System Details
data "azurerm_client_config" "current" {
}
