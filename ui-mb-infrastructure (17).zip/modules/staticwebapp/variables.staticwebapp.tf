variable "static_web_app_custom_domain" {
  type        = string
  description = <<DESCRIPTION
  The FQDN of a custom domain to apply to the Static Web App.
  Add this domain name into a dns server separately and add the txt-token in a TXT-Record for this domain.
  See https://learn.microsoft.com/en-us/azure/static-web-apps/custom-domain
  DESCRIPTION
  default     = null
}

variable "static_web_app_location" {
  type        = string
  description = <<DESCRIPTION
  A dedicated region for the Static Web App. If set, this variable overrules the given `location`.

  As the resource is only available in a small couple of regions, the resource can be deployed in one of those
  regardless of the other resources of the application.
  DESCRIPTION
  default     = null
}
