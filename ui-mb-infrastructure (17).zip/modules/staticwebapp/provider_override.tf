##
# Do not recover a soft deleted key vault during a re-creation.
# The secrets are fully recoverable from within this module.
# Nonetheless, KV is kept in soft-delete to prevent accidential deletions in portal.
#
# If the full purge seems to heavy weighted, use the second and third options only
# purge_soft_deleted_secrets_on_destroy = true
# recover_soft_deleted_key_vaults       = false
# recover_soft_deleted_secrets          = false
provider "azurerm" {
  features {
    key_vault {
      purge_soft_delete_on_destroy = true
    }
  }
}
