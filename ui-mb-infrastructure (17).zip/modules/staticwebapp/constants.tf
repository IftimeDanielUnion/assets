locals {
  ### Generic module behaviour
  ###

  ## Tag the module details
  module_name = {
    terraform_module         = "staticwebapp",
    terraform_module_version = "1.2.0"
  }

  tags = merge(
    try(var.tags, {}),
    local.module_name
  )

  ### Specific module behaviour
  ###
  kv_name = "kv-${random_id.keyvault.hex}"

  kv_tags = merge(
    local.tags,
    {
      purpose = "ci/cd pipeline integration"
    }
  )


}

module "naming" {
  source        = "Azure/naming/azurerm"
  version       = "0.4.2"
  suffix        = [lower(var.app_name), lower(var.workload_environment), lower(var.component_name)]
  unique-length = 8
}

resource "random_id" "keyvault" {
  byte_length = 10
}
