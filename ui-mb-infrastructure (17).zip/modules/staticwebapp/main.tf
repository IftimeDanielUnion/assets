resource "azurerm_resource_group" "main" {
  name     = module.naming.resource_group.name
  location = var.location
  tags     = local.tags
}

##  Static Web App
#   https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/static_web_app
resource "azurerm_static_web_app" "main" {
  name                = module.naming.static_web_app.name_unique
  resource_group_name = azurerm_resource_group.main.name
  location            = coalesce(var.static_web_app_location, var.location)

  configuration_file_changes_enabled = true
  preview_environments_enabled       = true
  public_network_access_enabled      = false
  sku_size                           = "Standard"
  sku_tier                           = "Standard"
  tags                               = local.tags

  identity {
    type = "SystemAssigned"
  }

  lifecycle {
    ignore_changes = [
      app_settings,
      repository_branch,
      repository_url
    ]
  }
}

# https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/static_web_app_custom_domain
resource "azurerm_static_web_app_custom_domain" "main" {
  count             = (var.static_web_app_custom_domain != null) ? 1 : 0
  static_web_app_id = azurerm_static_web_app.main.id
  domain_name       = var.static_web_app_custom_domain
  validation_type   = "dns-txt-token"
}

# Private endpoint for the static web app
resource "azurerm_private_endpoint" "pep_for_web" {
  depends_on = [azurerm_static_web_app.main]

  name                = "${module.naming.private_endpoint.name}-web"
  resource_group_name = azurerm_resource_group.main.name
  location            = azurerm_resource_group.main.location
  subnet_id           = data.azurerm_subnet.default.id
  tags                = local.tags

  private_service_connection {
    is_manual_connection           = false
    name                           = "${module.naming.private_service_connection.name}-web"
    private_connection_resource_id = azurerm_static_web_app.main.id
    subresource_names              = ["staticSites"]
  }
}

##  Key Vault for API Key and optional Identity Provider Credentials
#   The Key Vault is public, so it is accessible from within an AzDO Library
resource "azurerm_key_vault" "main" {
  tenant_id                     = data.azurerm_client_config.current.tenant_id
  resource_group_name           = azurerm_resource_group.main.name
  location                      = azurerm_resource_group.main.location
  name                          = local.kv_name
  sku_name                      = "standard"
  rbac_authorization_enabled    = true
  public_network_access_enabled = true
  purge_protection_enabled      = false
  tags                          = local.kv_tags
}

# Secret is deployment token of static web app
resource "azurerm_key_vault_secret" "kv_stapp_api_key" {
  key_vault_id     = azurerm_key_vault.main.id
  name             = "static-web-app-api-key"
  value_wo         = azurerm_static_web_app.main.api_key
  value_wo_version = 1 # static with no intention to update this value
  content_type     = "static-site-api-key"

  lifecycle {
    ignore_changes = [value]
  }
}

##  RBAC Assignment
#   Note: RBAC assignments are handled separately in environment-specific configurations
#   to avoid circular dependencies with dynamic identity blocks.
#   See: environment/_apps/*/rbac-on-staticwebapps.hcl
