resource "time_sleep" "rbac_propagation" {
  count           = var.backup_vault_id != null ? 1 : 0
  create_duration = "300s" # 5 minutes for external RBAC propagation

  triggers = {
    backup_vault_id = var.backup_vault_id
    principal_id    = var.backup_vault_principal_id
  }
}

# Backup Instance for PostgreSQL Flexible Server
resource "azurerm_data_protection_backup_instance_postgresql_flexible_server" "main" {
  count = var.backup_vault_id != null ? 1 : 0

  name             = "${azurerm_postgresql_flexible_server.main.name}-backup-instance"
  location         = azurerm_resource_group.main.location
  vault_id         = var.backup_vault_id
  server_id        = azurerm_postgresql_flexible_server.main.id
  backup_policy_id = var.backup_policy_id

  depends_on = [
    # Ensure PostgreSQL server is created first
    azurerm_postgresql_flexible_server.main,
    # Wait for RBAC propagation
    time_sleep.rbac_propagation
  ]
}
