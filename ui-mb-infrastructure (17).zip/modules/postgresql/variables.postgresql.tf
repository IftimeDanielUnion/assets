variable "retention_days" {
  type        = number
  description = "Number of backup retention days for the PostgreSQL Flexible Server. Possible values are between 7 and 35. Defaults to 7"
  default     = 7
}

variable "server_admins" {
  type = map(object({
    user_principal_name      = string
    user_principal_object_id = string
  }))
  description = <<DESCRIPTION
  (optional) A list of users to be added as server administrators.
  Due to a lack of permissions in the pipeline, the user has to be identified outside of terraform.
  You can use `az ad list user --upn <genoid>@union-investment.de` to retrieve the necessary details of a single user.
  The 'id' in the result is the required 'object_id'. You can use 'displayName' as the 'name' to make the entry more readable.
  ---
  - `user_principal_name` (required) Name of the user. Can be principal name or display name.
  - `user_principal_object_id` (required) Object Id of the user.

  DESCRIPTION
  default     = {}
}

variable "server_parameters" {
  type        = map(string)
  description = <<DESCRIPTION
  (optional) A list of parameter settings for the PostgreSQL Flexible Server as key-value-pairs. For example `"max_connections"="1000"`

  It is possible to add server extensions. To do this, provide `azure.extensions` with a value of all extensions as comma-separated list.
  DESCRIPTION
  default     = {}
}

variable "sku_settings" {
  type = object({
    name    = optional(string, "Standard_B1ms")
    tier    = optional(string, "Burstable")
    storage = optional(number, 32)
  })
  nullable    = false
  default     = {}
  description = <<DESCRIPTION
  (optional) Defines the specifics about this PostgreSQL Flexible Server. Defaults to a Burstable Standard_B1ms with 32GB Storage.
  ---
  `name` (optional) The SKU Name for the PostgreSQL Flexible Server. Defaults to `Standard_B1ms`
  `tier` (optional) The name of the SKU tier to use. Valid values are GeneralPurpose, MemoryOptimized, Burstable. Defaults to `Burstable`
  `storage` (optional) The storage in GB that is provisioned for the flexible server (billed GiB/month). Defaults to 32.
    !! Note that storage cannot be scaled down once the server is created.
  DESCRIPTION

  validation {
    condition = (
      contains([
        "GeneralPurpose",
        "MemoryOptimized",
        "Burstable",
        ], var.sku_settings.tier
      )
    )
    error_message = <<ERR
`tier` has to be one of the following values:
GeneralPurpose, MemoryOptimized, Burstable
ERR
  }
  validation {
    condition = (
      contains([
        32, 64, 128, 256, 512, 1024, 2048, 4096, 8192, 16384, 32767
        ], var.sku_settings.storage
      )
    )
    error_message = <<ERR
`storage` has to be one of the following values:
32, 64, 128, 256, 512, 1024, 2048, 4096, 8192, 16384, 32767
ERR
  }
}
