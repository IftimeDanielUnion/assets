variable "backup_vault_id" {
  type        = string
  description = "(optional) The ID of the Backup Vault to use for PostgreSQL backups. If not provided, no backup will be configured."
  default     = null
}

variable "backup_policy_id" {
  type        = string
  description = "(optional) The ID of the Backup Policy to use for PostgreSQL backups. Required if backup_vault_id is provided."
  default     = null
}

variable "backup_vault_principal_id" {
  type        = string
  description = "(optional) The Principal ID of the Backup Vault's Identity (System or User Assigned). Used for RBAC assignments."
  default     = null
}

variable "enable_backup_rbac" {
  type        = bool
  description = "(deprecated) RBAC assignments are now managed externally via Building Blocks system. This variable is ignored."
  default     = false
}
