resource "azurerm_private_endpoint" "main" {
  name                = module.naming.private_endpoint.name
  resource_group_name = azurerm_resource_group.main.name
  location            = azurerm_resource_group.main.location
  subnet_id           = data.azurerm_subnet.default.id
  tags                = local.tags

  private_service_connection {
    is_manual_connection           = false
    name                           = module.naming.private_service_connection.name
    private_connection_resource_id = azurerm_postgresql_flexible_server.main.id
    subresource_names              = ["postgresqlServer"]
  }
}
