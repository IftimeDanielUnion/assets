resource "azurerm_resource_group" "main" {
  name     = module.naming.resource_group.name
  location = var.location
  tags     = local.tags
}

resource "azurerm_postgresql_flexible_server" "main" {
  name                          = module.naming.postgresql_server.name_unique
  resource_group_name           = azurerm_resource_group.main.name
  location                      = azurerm_resource_group.main.location
  public_network_access_enabled = false
  create_mode                   = "Default"
  version                       = "16"
  tags                          = local.tags

  # see https://registry.terraform.io/providers/hashicorp/azurerm/3.117.0/docs/resources/postgresql_flexible_server#sku_name-3
  sku_name          = format("%s_%s", local.sku_tier[var.sku_settings.tier], var.sku_settings.name)
  storage_mb        = var.sku_settings.storage * 1024
  auto_grow_enabled = true

  backup_retention_days        = var.retention_days
  geo_redundant_backup_enabled = false

  authentication {
    active_directory_auth_enabled = true
    password_auth_enabled         = false
    tenant_id                     = data.azurerm_client_config.current.tenant_id
  }

  lifecycle {
    ignore_changes = [
      zone
    ]
  }
}

# Allow some time for start-up after the server creation
resource "time_sleep" "flexible_server_creation" {
  count           = (length(var.server_parameters) >= 1) ? 1 : 0
  depends_on      = [azurerm_postgresql_flexible_server.main]
  create_duration = "90s"

  triggers = {
    flexible_server = azurerm_postgresql_flexible_server.main.id
  }
}

# Add configuration for server parameters
resource "azurerm_postgresql_flexible_server_configuration" "main" {
  for_each  = var.server_parameters
  name      = each.key
  server_id = azurerm_postgresql_flexible_server.main.id
  value     = each.value

  # wait during creation and make sure the configuration values are destroyed before the server itself
  depends_on = [time_sleep.flexible_server_creation, azurerm_postgresql_flexible_server.main]
}

resource "azurerm_postgresql_flexible_server_active_directory_administrator" "main" {
  for_each            = var.server_admins
  server_name         = azurerm_postgresql_flexible_server.main.name
  resource_group_name = azurerm_resource_group.main.name
  tenant_id           = data.azurerm_client_config.current.tenant_id
  object_id           = each.value.user_principal_object_id
  principal_name      = upper(each.value.user_principal_name)
  principal_type      = "User"
}
