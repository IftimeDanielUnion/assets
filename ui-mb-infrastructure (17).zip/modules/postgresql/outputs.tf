output "host_name" {
  description = "The host name of the PostgreSQL Flexible Server"
  value       = azurerm_postgresql_flexible_server.main.fqdn
}

output "resource_id" {
  description = "The Id of the PostgreSQL Flexible Server"
  value       = azurerm_postgresql_flexible_server.main.id
}

output "backup_instance_id" {
  description = "The ID of the backup instance (if backup is configured)"
  value       = var.backup_vault_id != null ? azurerm_data_protection_backup_instance_postgresql_flexible_server.main[0].id : null
}
