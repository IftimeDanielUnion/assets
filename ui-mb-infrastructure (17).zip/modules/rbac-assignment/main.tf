resource "azurerm_role_assignment" "main" {
  for_each = var.role_assignments

  principal_id         = each.value.principal_id
  role_definition_name = each.value.role_definition_name
  scope                = each.value.scope
  condition            = each.value.condition
  condition_version    = each.value.condition_version
  description          = each.value.description

  skip_service_principal_aad_check = false
}
