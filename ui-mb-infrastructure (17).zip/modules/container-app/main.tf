resource "azurerm_resource_group" "main" {
  name     = module.naming.resource_group.name
  location = var.location
  tags     = local.tags
}

resource "azurerm_container_app" "main" {
  name                         = module.naming.container_app.name_unique
  container_app_environment_id = var.container_app_environment_id
  workload_profile_name        = "Consumption"
  resource_group_name          = azurerm_resource_group.main.name
  revision_mode                = "Single"

  identity {
    type         = local.user_type
    identity_ids = var.user_assigned_resource_ids
  }

  registry {
    identity = var.registry_identity
    server   = var.registry_server
  }

  ingress {
    client_certificate_mode = "ignore"
    target_port = var.target_port
    external_enabled = true # Neccessary to enable access from outside the container environment (other subnets)
    traffic_weight {
      latest_revision = true
      percentage = 100
    }
  }
  template {
    min_replicas = var.min_replicas
    max_replicas = var.max_replicas
    container {
      name   = module.naming.container_app.name_unique
      image  = var.image
      cpu    = var.cpu
      memory = var.memory
      liveness_probe {
        failure_count_threshold   = var.liveness_probe.failure_count_threshold
        initial_delay             = var.liveness_probe.initial_delay
        interval_seconds          = var.liveness_probe.interval_seconds
        path                      = var.liveness_probe.path
        port                      = var.liveness_probe.port
        timeout                   = var.liveness_probe.timeout
        transport                 = var.liveness_probe.transport
      }
      readiness_probe {
        failure_count_threshold   = var.readiness_probe.failure_count_threshold
        initial_delay             = var.readiness_probe.initial_delay
        interval_seconds          = var.readiness_probe.interval_seconds
        path                      = var.readiness_probe.path
        port                      = var.readiness_probe.port
        timeout                   = var.readiness_probe.timeout
        transport                 = var.readiness_probe.transport
      }
      startup_probe {
        failure_count_threshold   = var.startup_probe.failure_count_threshold
        initial_delay             = var.startup_probe.initial_delay
        interval_seconds          = var.startup_probe.interval_seconds
        path                      = var.startup_probe.path
        port                      = var.startup_probe.port
        timeout                   = var.startup_probe.timeout
        transport                 = var.startup_probe.transport
      }
    }
  }
  lifecycle {
    ignore_changes = [
      container_app_environment_id,
      template[0].container[0].image,
      template[0].container[0].env
    ]
  }
}
