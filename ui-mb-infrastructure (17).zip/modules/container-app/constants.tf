locals {
  ### Generic module behaviour
  ###

  ## Tag the module details
  module_name = {
    terraform_module         = "container-app",
    terraform_module_version = "1.0.0"
  }

  tags = merge(
    try(var.tags, {}),
    local.module_name
  )
  user_type = length(var.user_assigned_resource_ids) > 0 ? "SystemAssigned, UserAssigned" : "SystemAssigned"
}
module "naming" {
  source        = "Azure/naming/azurerm"
  version       = "0.4.2"
  suffix        = [lower(var.app_name), lower(var.workload_environment), lower(var.component_name)]
  unique-length = 8
}
