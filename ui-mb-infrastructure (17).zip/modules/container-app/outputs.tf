output "identity_principal_id" {
  description = "The principal id of the containers identity"
  value = azurerm_container_app.main.identity[0].principal_id
}

output "identity_tenant_id" {
  description = "The tenant id of the containers identity"
  value = azurerm_container_app.main.identity[0].tenant_id
}