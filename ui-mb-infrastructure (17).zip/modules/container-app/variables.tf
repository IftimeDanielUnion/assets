variable "location" {
  type        = string
  description = "(required) Name of the Azure Region. This is the short name like westeurope or swedencentral"
}

variable "min_replicas" {
  type        = number
  description = "(optional) Minimum number of replicas"
  default     = 1
}

variable "max_replicas" {
  type        = number
  description = "(optional) Maximum number of replicas"
  default     = 1
}

variable "cpu" {
  type        = number
  description = "(optional) Number of CPUs to provision for the container"
  default     = 1
}

variable "memory" {
  type        = string
  description = "(optional) Amount of RAM to provision for this container"
  default     = "2Gi"
}

variable "tags" {
  type        = map(string)
  description = "(optional) List of tags for use with this resource"
}

variable "container_app_environment_id" {
  type        = string
  description = "(required) Id of the Container App Environment to use"
}

variable "image" {
  type        = string
  description = "(optional) Image to be deployed"
  default     = "mcr.microsoft.com/azuredocs/containerapps-helloworld"
}

variable "user_assigned_resource_ids" {
  type        = list(string)
  description = "(optional) List of user assigned managed identities"
  default     = []
}

variable "registry_identity" {
  type        = string
  description = "(optional) Registry Identity"
}

variable "registry_server" {
  type        = string
  description = "(optional) Registry Server"
}

variable "target_port" {
  type        = number
  description = "(optional) Port the ingress uses to conect to the contaier"
  default     = 80
}

variable "liveness_probe" {
  type = object({
    failure_count_threshold   = optional(number)
    initial_delay             = optional(number)
    interval_seconds          = optional(number)
    path                      = optional(string)
    port                      = number
    timeout                   = optional(number)
    transport                 = string
  })
  default     = {
    port      = 80
    transport = "TCP"
  }
}

variable "readiness_probe" {
  type = object({
    failure_count_threshold   = optional(number)
    initial_delay             = optional(number)
    interval_seconds          = optional(number)
    path                      = optional(string)
    port                      = number
    timeout                   = optional(number)
    transport                 = string
  })
  default     = {
    port      = 80
    transport = "TCP"
  }
}

variable "startup_probe" {
  type = object({
    failure_count_threshold   = optional(number)
    initial_delay             = optional(number)
    interval_seconds          = optional(number)
    path                      = optional(string)
    port                      = number
    timeout                   = optional(number)
    transport                 = string
  })
  default     = {
    port      = 80
    transport = "TCP"
  }
}

##
# Workload and Application information
##
variable "app_name" {
  type        = string
  description = "(required) Name of the Application."
}
variable "component_name" {
  type        = string
  description = "(optional) Name of the Application's component. Used as suffix for resource naming. They follow the pattern <prefix>-<app_name>-<environment>-<component_name>"
  default     = "container-app"
}

variable "workload_environment" {
  type        = string
  description = "(required) Name of the environment/stage of the workload"
}

