locals {
  ### Generic module behaviour
  ###

  ## Tag the module details
  module_name = {
    terraform_module         = "functions",
    terraform_module_version = "1.0.1"
  }

  tags = merge(
    try(var.tags, {}),
    local.module_name
  )

  ### Specific module behaviour
  ###
  create_app_insights  = (var.logging.application_insights_connection_string == null) ? true : false
  create_metric_alerts = (var.alerts != null && length(var.alerts.metric_alerts) >= 1) ? true : false
  create_service_plan  = (var.service_plan.resource_id == null) ? true : false

  health_check_eviction_time_in_min = (var.health_check != null) ? var.health_check.eviction_time_in_min : null
  health_check_path                 = (var.health_check != null) ? var.health_check.path : null
  health_check_alert_enabled        = (var.health_check != null) ? var.health_check.monitoring_alert != null : false

  user_type = length(var.user_assigned_resource_ids) > 0 ? "SystemAssigned, UserAssigned" : "SystemAssigned"

  storage_name    = (var.storage_account.name_prefix != null) ? "${var.storage_account.name_prefix}${random_id.storage.hex}" : module.naming.storage_account.name_unique
  valid_pep_names = ["blob", "file", "table", "queue"]

  # Add the discovery key to the tags, used for the function app
  func_tags = {
    for k, v in var.functions :
    k => {
      tags = merge(
        local.tags,
        { "discovery_key" = v.discovery_key }
      )
    }
  }

}

module "naming" {
  source        = "Azure/naming/azurerm"
  version       = "0.4.2"
  suffix        = [lower(var.app_name), lower(var.workload_environment), lower(var.component_name)]
  unique-length = 8
}

module "function_naming" {
  source  = "Azure/naming/azurerm"
  version = "0.4.2"

  for_each      = var.functions
  suffix        = [lower(var.app_name), lower(var.workload_environment), lower(each.value.name)]
  unique-length = 8
}

resource "random_id" "storage" {
  byte_length = 10
}
