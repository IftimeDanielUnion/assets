##
# Default Subnet (inbound)
data "azurerm_subnet" "default" {
  name                 = var.vnet_subnet_name
  virtual_network_name = var.vnet_name
  resource_group_name  = var.vnet_resource_group_name
}

##
# Delegated Subnet (outbound)
data "azurerm_subnet" "delegated" {
  name                 = var.vnet_subnet_name_functionapp
  virtual_network_name = var.vnet_name
  resource_group_name  = var.vnet_resource_group_name
}
