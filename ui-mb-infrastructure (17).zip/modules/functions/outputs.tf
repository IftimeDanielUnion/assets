output "functions" {
  value = {
    for k, v in azurerm_linux_function_app.main : k => {
      resource_id                  = v.id,
      name                         = v.name,
      hostname                     = v.default_hostname
      system_assigned_principal_id = v.identity[0].principal_id
    }
  }
  description = "Map of these function apps' hostnames."
}

output "resource_group" {
  value       = azurerm_resource_group.main.name
  description = "The resource group name of the Function Apps."
}

output "system_assigned_principal_ids" {
  description = "List of all Principal IDs of the function apps' system assigned identities"
  value       = values(azurerm_linux_function_app.main)[*].identity[0].principal_id
}
