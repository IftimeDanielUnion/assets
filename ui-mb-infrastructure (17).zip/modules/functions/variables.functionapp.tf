variable "cors" {
  type = object({
    allowed_origins = optional(list(string), [])
  })
  nullable    = false
  default     = {}
  description = "Specifies origins that should be allowed to make cross-origin calls."

  validation {
    condition     = alltrue([for k, v in var.cors.allowed_origins : trimspace(v) != "*"])
    error_message = "Wildcard is not allowed."
  }

  validation {
    condition     = alltrue([for k, v in var.cors.allowed_origins : startswith(v, "https://")])
    error_message = "Origins must start with https."
  }
}

##
# Allow multiple function apps to be created. These function apps will all share the same resources
##
variable "functions" {
  type = map(object({
    name          = string
    discovery_key = string
  }))
  description = <<FUNCTIONS
  (required) The `functions` block contains either the definitions of at least one function app.
  All function apps defined here will be created with the same Runtime, on the same Service Plan, using the same storage and logging.
  ---
  - `name` The name of the function app. Full name is created according to this pattern <prefix>-<app_name>-<environment>-<name>"
  - `discovery_key`  This value is used with for tag `discovery_key`. It will be added to the list of tags, if provided.
  If a tag with the same name is part of that list, it is overridden by this value.
  Use this tag during deployment to build environment agnostic pipelines
  FUNCTIONS
  nullable    = false
}

variable "health_check" {
  type = object({
    eviction_time_in_min = number
    path                 = string
    monitoring_alert = optional(object({
      actions = list(object({
        action_group_id = string
      }))
      resource_group_name = optional(string, null)
    }))
  })
  description = <<DESCRIPTION
    (optional) Specifies the health check.
    - `eviction_time_in_min` Minutes until an unhealthy instance will be replaced
    - `path` The URL Path at which an http-triger responds with health information

    ---
    Optional block `monitoring_alert` defines whether or not an alert is created for the health check. The block supports these attributes:
    - `action_group_id` (required) Resource Id of the action group
    - `resource_group_name` (optional) Name of the resource group in which the alert is created. Defaults to the resource group of the function app
  DESCRIPTION
  default     = null
}

variable "logging" {
  type = object({
    log_analytics_workspace_resource_id    = optional(string, null)
    application_insights_connection_string = optional(string, null)
  })
  description = <<DESCRIPTION
    Logging of the Function App requires an Application Insights. If one does not exist,
    a new one (dedicated to this Function App) is created on the given Log Analytics Workspace.

    - `application_insights_connection_string` - Connection String of an Application Insights instance.
    - `log_analytics_workspace_resource_id` - The resource ID of the log analytics workspace to send logs and metrics to.
  DESCRIPTION

  validation {
    condition = (
      var.logging.log_analytics_workspace_resource_id != null &&
      var.logging.application_insights_connection_string == null ||
      var.logging.log_analytics_workspace_resource_id == null &&
      var.logging.application_insights_connection_string != null
    )
    error_message = <<ERR
      Either `application_insights_connection_string` or `log_analytics_workspace_resource_id` has to be specified.
    ERR
  }
}

variable "runtime" {
  type = object({
    stack   = string
    version = string
  })
  description = <<DESCRIPTION
    (required) Specifies the Runtime Stack and Version.
    - `stack` Possible Runtime Stacks are `java`, `node` and `python`.
    - `version` See Microsoft's documentation about possible versions for each of the stacks. Defaults to the most recent version.
  DESCRIPTION
  nullable    = false
}

variable "service_plan" {
  type = object({
    resource_id    = optional(string)
    sku_name       = optional(string)
    instance_count = optional(number)
  })
  description = <<SERVICE_PLAN
    (required) The `service_plan` block contains either the resource id of an existing service plan or the sku and instance count for a new service plan.
    ---
    - `resource_id` Resource Id of an existing service plan to create the function app on. If this is empty an new service plan dedicated to this Function App will be created
    - `sku_name` Specifies the SKU for the Function App's service plan. Required, if `service_plan_resource_id` is empty.
    - `instance_count` Specifies how many instances will the service plan will have. Required, if `service_plan_resource_id` is empty.
  SERVICE_PLAN

  validation {
    condition = (
      var.service_plan.resource_id != null &&
      (var.service_plan.sku_name == null && var.service_plan.instance_count == null) ||
      var.service_plan.resource_id == null &&
      (var.service_plan.sku_name != null && var.service_plan.instance_count != null)
    )
    error_message = "Either the `service_plan_resource_id` or the `sku_name` and `instance_count` are required."
  }
  validation {
    condition = (var.service_plan.resource_id != null) ? true : alltrue([
      !startswith(var.service_plan.sku_name, "Y"),
      !startswith(var.service_plan.sku_name, "F"),
      !startswith(var.service_plan.sku_name, "E"),
      !startswith(var.service_plan.sku_name, "I")
    ])
    error_message = "SKU must specify a dedicated Hosting Plan. Consumption, Elastic or Isolated Plans are not supported."
  }
}

variable "storage_account" {
  type = object({
    account_replication_type = optional(string, "LRS")
    name_prefix              = optional(string, "fa")
    private_endpoints        = set(string)
  })

  description = <<STORAGE_ACCOUNT
  (required) The `storage_account` block holds specifics about the storage account for the Function App(s).
  ---
  - `account_replication_type` (optional) Defines the type of replication for this storage account. Valid options are `LRS`, `ZRS` among others, defaults to `LRS`.
  - `name_prefix` (optional) A short string (2 or 4 chars) used as prefix in this storage account's name.
    Providing this prefix overrides the usual naming of the storage account and the part of the name after the prefix will be made up of random chars.
    The length is fixed on either 2 or 4 characters.
  - `private_endpoints` (required) The list of sub-resources, like 'blob', 'file', 'table' or 'queue'. A private endpoint is created for each of these names.
  STORAGE_ACCOUNT

  validation {
    condition     = (var.storage_account.name_prefix == null ? true : length(var.storage_account.name_prefix) == 2 || length(var.storage_account.name_prefix) == 4)
    error_message = "Prefix must be either 2 or 4 characters long"
  }
  validation {
    condition     = alltrue([for k, v in var.storage_account.private_endpoints : contains(local.valid_pep_names, v)])
    error_message = "Valid sub-resource names are: ${join(", ", local.valid_pep_names)}"
  }
}

variable "user_assigned_resource_ids" {
  type        = set(string)
  description = "(optional) List of user assigned managed identities"
  default     = []
}

variable "vnet_subnet_name_functionapp" {
  type        = string
  description = "(required) Name of the delegated subnet used for Function app"
}
