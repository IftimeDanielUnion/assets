resource "azurerm_resource_group" "main" {
  name     = module.naming.resource_group.name
  location = var.location
  tags     = local.tags
}

resource "azurerm_application_insights" "main" {
  count = local.create_app_insights ? 1 : 0

  name                = module.naming.application_insights.name_unique
  resource_group_name = azurerm_resource_group.main.name
  location            = azurerm_resource_group.main.location
  workspace_id        = var.logging.log_analytics_workspace_resource_id

  application_type   = "web"
  retention_in_days  = 30
  ip_masking_enabled = true

  tags = local.tags
}

resource "azurerm_service_plan" "main" {
  count = local.create_service_plan ? 1 : 0

  name                = module.naming.app_service_plan.name_unique
  resource_group_name = azurerm_resource_group.main.name
  location            = azurerm_resource_group.main.location

  os_type      = "Linux"
  sku_name     = var.service_plan.sku_name
  worker_count = var.service_plan.instance_count

  per_site_scaling_enabled = false
  zone_balancing_enabled   = false

  tags = local.tags
}

resource "azurerm_storage_account" "main" {
  name                = local.storage_name
  resource_group_name = azurerm_resource_group.main.name
  location            = azurerm_resource_group.main.location

  access_tier                     = "Hot"
  account_kind                    = "StorageV2"
  account_tier                    = "Standard"
  account_replication_type        = var.storage_account.account_replication_type
  allow_nested_items_to_be_public = false
  https_traffic_only_enabled      = true
  min_tls_version                 = "TLS1_2"
  public_network_access_enabled   = false
  shared_access_key_enabled       = true

  tags = local.tags
}


resource "azurerm_linux_function_app" "main" {
  for_each = var.functions

  name                = module.function_naming[each.key].function_app.name_unique
  resource_group_name = azurerm_resource_group.main.name
  location            = azurerm_resource_group.main.location

  service_plan_id = (local.create_service_plan) ? azurerm_service_plan.main[0].id : var.service_plan.service_plan_resource_id

  storage_account_name       = azurerm_storage_account.main.name
  storage_account_access_key = azurerm_storage_account.main.primary_access_key

  public_network_access_enabled = false
  virtual_network_subnet_id     = data.azurerm_subnet.delegated.id
  https_only                    = true
  functions_extension_version   = "~4"

  identity {
    type         = local.user_type
    identity_ids = var.user_assigned_resource_ids
  }

  site_config {
    always_on                              = true # This theoretically depends on the app service plan. Since we only allow dedicated ones, this fits.
    application_insights_connection_string = (local.create_app_insights) ? azurerm_application_insights.main[0].connection_string : var.logging.application_insights_connection_string

    application_stack {
      java_version   = var.runtime.stack == "java" ? var.runtime.version : null
      node_version   = var.runtime.stack == "node" ? var.runtime.version : null
      python_version = var.runtime.stack == "python" ? var.runtime.version : null
    }

    dynamic "cors" {
      for_each = length(var.cors.allowed_origins) > 0 ? [var.cors.allowed_origins] : []
      iterator = each
      content {
        allowed_origins     = each.value
        support_credentials = false
      }
    }

    health_check_path                 = local.health_check_path
    health_check_eviction_time_in_min = local.health_check_eviction_time_in_min

    # Stadard requirements. These values shall not be changed
    minimum_tls_version         = "1.2"
    remote_debugging_enabled    = false
    scm_minimum_tls_version     = "1.2"
    scm_use_main_ip_restriction = true
    vnet_route_all_enabled      = false

  }

  builtin_logging_enabled = false

  client_certificate_enabled                     = false # Incompatible with http/2.0
  ftp_publish_basic_authentication_enabled       = false
  webdeploy_publish_basic_authentication_enabled = false

  tags = local.func_tags[each.key].tags

  lifecycle {
    ignore_changes = [
      # Ignore all app settings so that app-specific environment variables don't get removed.
      app_settings,
      sticky_settings,

      # The following are set automatically. Ignore them so terraform doesn't
      # try to remove them.
      tags["hidden-link: /app-insights-resource-id"],
      tags["hidden-link: /app-insights-conn-string"],
      tags["hidden-link: /app-insights-instrumentation-key"]
    ]

  }
  depends_on = [time_sleep.storage_private_endpoints]
}

# WORKAROUND - to be done directly in the azurerm_linux_function_app resource once supported
module "min_tls_cipher_suite_patch" {
  source = "../internal/functionapp-min-tls-cipher-patch"

  for_each        = azurerm_linux_function_app.main
  function_app_id = azurerm_linux_function_app.main[each.key].id
}

## ALERTING
# Monitoring Alert for the Health Check of each Function App
resource "azurerm_monitor_metric_alert" "health_check" {
  for_each = local.health_check_alert_enabled ? azurerm_linux_function_app.main : {}

  name                = "TAB - Function Health Check (${each.value.name}) S_MARKTBEARBEITUNG_${upper(var.workload_environment)}"
  resource_group_name = (var.health_check.monitoring_alert.resource_group_name != null) ? var.health_check.monitoring_alert.resource_group_name : azurerm_resource_group.main.name
  scopes              = [each.value.id]

  auto_mitigate = true
  description   = "Der Health-Endpunkt der Function ${each.value.name} konnte in den letzten 5 Minuten nicht erreicht werden."
  severity      = 2
  enabled       = true
  frequency     = "PT5M" # Abfrageintervall
  tags          = local.tags
  window_size   = "PT5M" # Betrachtungszeitraum

  criteria {
    metric_namespace = "Microsoft.Web/sites"
    metric_name      = "HealthCheckStatus"
    aggregation      = "Average"
    operator         = "LessThan"
    threshold        = 100
  }
  dynamic "action" {
    for_each = var.health_check.monitoring_alert.actions
    content {
      action_group_id = action.value.action_group_id
    }  
  }
}

# Further Alerts in the scope of the App Service Plan
resource "azurerm_monitor_metric_alert" "main" {
  for_each = (local.create_metric_alerts) ? var.alerts.metric_alerts : {}

  name                = (local.create_service_plan) ? replace(each.value.name, "%scope_name%", azurerm_service_plan.main[0].name) : replace(each.value.name, "%scope_name%", "")
  resource_group_name = (var.alerts.resource_group_name != null) ? var.alerts.resource_group_name : azurerm_resource_group.main.name
  scopes              = (local.create_service_plan) ? [azurerm_service_plan.main[0].id] : [var.service_plan.service_plan_resource_id]

  auto_mitigate = true
  description   = (local.create_service_plan) ? replace(each.value.description, "%scope_name%", azurerm_service_plan.main[0].name) : replace(each.value.description, "%scope_name%", "")
  enabled       = each.value.enabled
  frequency     = each.value.frequency
  severity      = each.value.severity
  tags          = local.tags
  window_size   = each.value.window_size

  dynamic "criteria" {
    for_each = each.value.criteria
    iterator = crit
    content {
      metric_namespace = crit.value.metric_namespace
      metric_name      = crit.value.metric_name
      aggregation      = crit.value.aggregation
      operator         = crit.value.operator
      threshold        = crit.value.threshold
      dynamic "dimension" {
        for_each = crit.value.dimension
        iterator = dim
        content {
          name     = dim.value.name
          operator = dim.value.operator
          values   = dim.value.values
        }
      }
    }
  }
  dynamic "action" {
    for_each = each.value.actions
    content {
      action_group_id = action.value.action_group_id
    }
  }
}
