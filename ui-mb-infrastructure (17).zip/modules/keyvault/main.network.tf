resource "azurerm_private_endpoint" "main" {
  name                = "${module.naming.private_endpoint.name}-kv"
  resource_group_name = azurerm_resource_group.main.name
  location            = azurerm_resource_group.main.location
  subnet_id           = data.azurerm_subnet.private_endpoints.id
  tags                = local.tags

  private_service_connection {
    is_manual_connection           = false
    name                           = module.naming.private_service_connection.name
    private_connection_resource_id = azurerm_key_vault.main.id
    subresource_names              = ["vault"]
  }
}
