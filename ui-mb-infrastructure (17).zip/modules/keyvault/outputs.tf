output "resource_id" {
  description = "The ID of the Key Vault"
  value       = azurerm_key_vault.main.id
}

output "role_assignments" {
  description = "Map of role assignments. Empty if none."
  value = {
    for k, v in azurerm_role_assignment.key_vault : k => {
      id                   = v.id,
      principal_id         = v.principal_id
      role_definition_name = v.role_definition_name
    }
  }
}

output "uri" {
  description = "URI of the Key Vault"
  value       = azurerm_key_vault.main.vault_uri
}
