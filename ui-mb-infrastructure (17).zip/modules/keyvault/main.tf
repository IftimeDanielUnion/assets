resource "azurerm_resource_group" "main" {
  name     = module.naming.resource_group.name
  location = var.location
  tags     = local.tags
}

resource "azurerm_key_vault" "main" {
  name                          = local.kv_name
  resource_group_name           = azurerm_resource_group.main.name
  location                      = azurerm_resource_group.main.location
  tenant_id                     = data.azurerm_client_config.current.tenant_id
  sku_name                      = "standard"
  soft_delete_retention_days    = var.soft_delete_retention_days
  rbac_authorization_enabled    = true
  purge_protection_enabled      = false
  tags                          = local.tags
  public_network_access_enabled = local.public_access

  # App Gateway needs public access to the KeyVault (as of December 2024)
  dynamic "network_acls" {
    for_each = var.use_with_app_gateway ? [1] : []

    content {
      bypass                     = "AzureServices"
      default_action             = "Deny"
      virtual_network_subnet_ids = [data.azurerm_subnet.appgw.id]
    }
  }
}

resource "azurerm_role_assignment" "key_vault" {
  for_each = var.role_assignments

  principal_id         = each.value.principal_id
  role_definition_name = each.value.role_definition_name
  scope                = azurerm_key_vault.main.id
  condition            = each.value.condition
  condition_version    = each.value.condition_version
  description          = each.value.description

  skip_service_principal_aad_check = false
}
