variable "location" {
  type        = string
  description = "(required) Name of the Azure Region. This is the short name like westeurope or swedencentral"
}

variable "tags" {
  type        = map(string)
  description = "(optional) List of tags for use with this resource"
}

##
# Network Resources
##
variable "vnet_name" {
  type        = string
  description = "(required) Name of the VNet Ressource, which holds the subnet"
}

variable "vnet_resource_group_name" {
  type        = string
  description = "(required) Name of the resource group of the VNet."
}

variable "vnet_subnet_name" {
  type        = string
  description = "(required) Name of the general subnet used for integration of private endpoints"
}

variable "vnet_subnet_name_privateendpoints" {
  type        = string
  description = "(optional) Name of the subnet used for private endpoints. If not set, uses vnet_subnet_name."
  default     = null
}

variable "vnet_subnet_name_appgw" {
  type        = string
  description = "(required) Name of the delegated subnet of the Application Gateway"
}

##
# Workload and Application information
##
variable "app_name" {
  type        = string
  description = "(required) Name of the Application."
}
variable "component_name" {
  type        = string
  description = "(optional) Name of the Application's component. Used as suffix for resource naming. They follow the pattern <prefix>-<app_name>-<environment>-<component_name>"
  default     = "keyvault"
}

variable "workload_environment" {
  type        = string
  description = "(required) Name of the environment/stage of the workload"
}
