variable "key_vault_name" {
  type        = string
  description = <<DESCRIPTION
    (optional) Name for this Key Vault. If none is provided a random name will be generated
  DESCRIPTION
  default     = null
}

variable "public_access_allowed" {
  type        = bool
  description = <<DESCRIPTION
    (optional) If `true` this Key Vault is publicly accessible.
    This access is restricted if the integration with the Application Gateway (var `use_with_app_gateway`) is also `true`.
    Defaults to `false`.
  DESCRIPTION
  default     = false
}

variable "role_assignments" {
  type = map(object({
    principal_id         = string
    role_definition_name = string
    condition            = optional(string, null)
    condition_version    = optional(string, null)
    description          = optional(string, null)
    principal_type       = optional(string, null)
  }))
  description = <<DESCRIPTION
    (optional) A map of role assignments to create on the resource.
- `principal_id` - (required) The ID of the principal to assign the role to.
- `role_definition_name` - (required) The name of the role definition to assign to the principal.
- `principal_type` - (optional) The type of the principal_id. Possible values are `User`, `Group` and `ServicePrincipal`. It is necessary to
  explicitly set this attribute when creating role assignments if the principal creating the assignment is constrained by ABAC rules that filters on the PrincipalType attribute.
- `description` - (optional) The description of the role assignment.
- `condition` - (optional) The condition which will be used to scope the role assignment.
- `condition_version` - (optional) The version of the condition syntax. Valid values are '2.0'. It is required if `condition` is set.
DESCRIPTION
  default     = {}
  nullable    = false
}

variable "soft_delete_retention_days" {
  type        = number
  description = "(optional) The number of days that items should be retained for once soft-deleted. Default is `null`, falling back to the provider's default."
  default     = null
}

variable "use_with_app_gateway" {
  type        = bool
  description = <<DESCRIPTION
    (optional) If `true` this Key Vault will allow public access for the Application Gateway's subnet, as defined in variable `vnet_subnet_name_appgw`.
    This will limit the public access, if the variable `public_access_allowed` is also `true`.
    Defaults to `false`.
  DESCRIPTION
  default     = false
}
