##
# Default Subnet (legacy fallback)
data "azurerm_subnet" "default" {
  name                 = var.vnet_subnet_name
  virtual_network_name = var.vnet_name
  resource_group_name  = var.vnet_resource_group_name
}

##
# Private Endpoints Subnet (uses dedicated subnet if defined, otherwise falls back to default)
data "azurerm_subnet" "private_endpoints" {
  name                 = coalesce(var.vnet_subnet_name_privateendpoints, var.vnet_subnet_name)
  virtual_network_name = var.vnet_name
  resource_group_name  = var.vnet_resource_group_name
}

##
# App Gateway Subnet
data "azurerm_subnet" "appgw" {
  name                 = var.vnet_subnet_name_appgw
  virtual_network_name = var.vnet_name
  resource_group_name  = var.vnet_resource_group_name
}

##
# System Details
data "azurerm_client_config" "current" {
}
