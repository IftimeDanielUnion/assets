resource "azurerm_monitor_diagnostic_setting" "main" {
  for_each = var.diagnostic_settings

  name               = each.value.name != null ? each.value.name : "diag-${var.component_name}"
  target_resource_id = azurerm_key_vault.main.id

  log_analytics_destination_type = each.value.log_analytics_destination_type
  log_analytics_workspace_id     = each.value.workspace_resource_id


  dynamic "enabled_log" {
    for_each = each.value.log_categories

    content {
      category = enabled_log.value
    }
  }
  dynamic "enabled_log" {
    for_each = each.value.log_groups

    content {
      category_group = enabled_log.value
    }
  }
  dynamic "enabled_metric" {
    for_each = each.value.metric_categories

    content {
      category = enabled_metric.value
    }
  }
}
