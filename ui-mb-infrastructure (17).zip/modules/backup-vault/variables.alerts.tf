variable "alerts" {
  type = object({
    resource_group_name = optional(string)

    metric_alerts = optional(
      map(object({
        name        = string
        description = string
        enabled     = optional(bool, true)
        frequency   = string
        severity    = number
        window_size = string
        criteria = list(object({
          metric_namespace = string
          metric_name      = string
          aggregation      = string
          operator         = string
          threshold        = number
          dimension = optional(set(object({
            name     = string
            operator = string
            values   = list(string)
          })), [])
        }))
        actions = list(object({
          action_group_id = string
        }))
      }))
    , {})

    log_analytics_alerts = optional(
      map(object({
        name                  = string
        description           = string
        enabled               = optional(bool, true)
        evaluation_frequency  = string
        severity              = number
        window_duration       = string
        workspace_resource_id = string
        criteria = list(object({
          operator                = string
          query                   = string
          threshold               = number
          time_aggregation_method = string
          metric_measure_column   = optional(string, null)
          dimension = optional(set(object({
            name     = string
            operator = string
            values   = list(string)
          })), [])
        }))
        actions = list(object({
          action_group_id = string
        }))
      }))
    , {})
  })
  default     = {}
  description = <<DESCRIPTION
    (optional) Definition of alerts for the Backup Vault
    The attributes `name` and `description` can have a placeholder `%scope_name%` which will be replaced with the backup vault name.
    - `resource_group_name` - (optional) Name of the resource group for alerts. Defaults to the backup vault's resource group.

    ---
    Optional block `metric_alerts` defines Metric Alerts for backup vault metrics.
    Optional block `log_analytics_alerts` defines Log Analytics queries for backup operations monitoring.
  DESCRIPTION
}
