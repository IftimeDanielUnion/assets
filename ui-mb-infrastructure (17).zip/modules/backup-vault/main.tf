resource "azurerm_resource_group" "main" {
  name     = module.naming.resource_group.name
  location = var.location
  tags     = local.tags
}

resource "azurerm_data_protection_backup_vault" "main" {
  name                = local.backup_vault_name
  resource_group_name = azurerm_resource_group.main.name
  location            = azurerm_resource_group.main.location
  datastore_type      = "VaultStore"
  redundancy          = var.backup_vault_redundancy
  soft_delete         = var.soft_delete_enabled ? "On" : "Off"
  tags                = local.tags

  identity {
    type = "SystemAssigned"
  }
}

# Backup Policy for PostgreSQL Flexible Server
resource "azurerm_data_protection_backup_policy_postgresql_flexible_server" "main" {
  name     = local.backup_policy_name
  vault_id = azurerm_data_protection_backup_vault.main.id

  backup_repeating_time_intervals = [var.backup_schedule_interval]
  time_zone                       = var.backup_timezone

  default_retention_rule {
    life_cycle {
      duration        = "P${var.retention_days}D"
      data_store_type = "VaultStore"
    }
  }

  # Prevent recreation when configuration changes
  # Policy cannot be deleted while backup instances exist (soft delete protection)
  # Manual intervention required to change schedule: disable backup instance first
  lifecycle {
    ignore_changes = [
      backup_repeating_time_intervals,
      default_retention_rule
    ]
  }
}

# Diagnostic Settings for Backup Vault
resource "azurerm_monitor_diagnostic_setting" "main" {
  for_each = var.diagnostic_settings

  name               = each.value.name != null ? each.value.name : "diag-${var.component_name}"
  target_resource_id = azurerm_data_protection_backup_vault.main.id

  log_analytics_destination_type = each.value.log_analytics_destination_type
  log_analytics_workspace_id     = each.value.workspace_resource_id

  dynamic "enabled_log" {
    for_each = each.value.log_categories

    content {
      category = enabled_log.value
    }
  }
  dynamic "enabled_log" {
    for_each = each.value.log_groups

    content {
      category_group = enabled_log.value
    }
  }
  dynamic "enabled_metric" {
    for_each = each.value.metric_categories

    content {
      category = enabled_metric.value
    }
  }

  # Microsoft.DataProtection/backupVaults exposes the named metric category "Health".
  # The configured "AllMetrics" (module default) is mapped to "Health" by the Azure API
  # and read back as "Health", so the block never converges -> the drift-check pipeline
  # (DBI-8960) kept flagging the two backup-vault stacks. Azure does not retain
  # "AllMetrics" for this resource type, so reconciling the block can never succeed.
  # Keep "AllMetrics" as the declared intent (module default) and stop Terraform from
  # fighting the API over this single block. "Health" is the only metric a backup vault
  # emits, so the collected data is identical. Applies to every backup-vault stack
  # (mashub, verbundintegration) across all environments. See DBI-9745 / DBI-8960.
  lifecycle {
    ignore_changes = [enabled_metric]
  }
}
