variable "diagnostic_settings" {
  type = map(object({
    name                           = optional(string, null)
    log_categories                 = optional(set(string), [])
    log_groups                     = optional(set(string), ["allLogs"])
    metric_categories              = optional(set(string), ["AllMetrics"])
    log_analytics_destination_type = optional(string, "Dedicated")
    workspace_resource_id          = string
  }))
  default     = {}
  description = <<DESCRIPTION
A map of diagnostic settings to create on backup vault.

- `name` - (Optional) The name of the diagnostic setting. One will be generated if not set, however this will not be unique if you want to create multiple diagnostic setting resources.
- `log_categories` - (Optional) A set of log categories to send to the log analytics workspace. Defaults to `[]`.
- `log_groups` - (Optional) A set of log groups to send to the log analytics workspace. Defaults to `["allLogs"]`.
- `metric_categories` - (Optional) A set of metric categories to send to the log analytics workspace. Defaults to `["AllMetrics"]`.
- `log_analytics_destination_type` - (Optional) The destination type for the diagnostic setting. Possible values are `Dedicated` and `AzureDiagnostics`. Defaults to `Dedicated`.
- `workspace_resource_id` - (required) The resource ID of the log analytics workspace to send logs and metrics to.
DESCRIPTION
  nullable    = false

  validation {
    condition     = alltrue([for _, v in var.diagnostic_settings : contains(["Dedicated", "AzureDiagnostics"], v.log_analytics_destination_type)])
    error_message = "Log analytics destination type must be one of: 'Dedicated', 'AzureDiagnostics'."
  }
}
