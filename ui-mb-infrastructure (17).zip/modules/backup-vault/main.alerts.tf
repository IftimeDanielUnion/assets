## METRIC ALERTS
# Alerts in the scope of the Backup Vault
resource "azurerm_monitor_metric_alert" "alerts" {
  for_each = try(var.alerts.metric_alerts, {})

  name                = replace(each.value.name, "%scope_name%", azurerm_data_protection_backup_vault.main.name)
  resource_group_name = try(var.alerts.resource_group_name, azurerm_resource_group.main.name)
  scopes              = [azurerm_data_protection_backup_vault.main.id]
  description         = replace(each.value.description, "%scope_name%", azurerm_data_protection_backup_vault.main.name)
  severity            = each.value.severity
  enabled             = each.value.enabled
  frequency           = each.value.frequency
  window_size         = each.value.window_size
  auto_mitigate       = true

  dynamic "criteria" {
    for_each = each.value.criteria
    content {
      metric_namespace = criteria.value.metric_namespace
      metric_name      = criteria.value.metric_name
      aggregation      = criteria.value.aggregation
      operator         = criteria.value.operator
      threshold        = criteria.value.threshold

      dynamic "dimension" {
        for_each = try(criteria.value.dimension, [])
        content {
          name     = dimension.value.name
          operator = dimension.value.operator
          values   = dimension.value.values
        }
      }
    }
  }

  dynamic "action" {
    for_each = each.value.actions
    content {
      action_group_id = action.value.action_group_id
    }
  }

  tags = local.tags
}

## LOG ANALYTICS ALERTS
# Scheduled query alerts for backup operations
resource "azurerm_monitor_scheduled_query_rules_alert_v2" "log_analytics" {
  for_each = try(var.alerts.log_analytics_alerts, {})

  name                = replace(each.value.name, "%scope_name%", azurerm_data_protection_backup_vault.main.name)
  resource_group_name = try(var.alerts.resource_group_name, azurerm_resource_group.main.name)
  location            = azurerm_resource_group.main.location
  scopes              = [each.value.workspace_resource_id]

  description          = replace(each.value.description, "%scope_name%", azurerm_data_protection_backup_vault.main.name)
  enabled              = each.value.enabled
  evaluation_frequency = each.value.evaluation_frequency
  severity             = each.value.severity
  window_duration      = each.value.window_duration

  dynamic "criteria" {
    for_each = each.value.criteria
    iterator = crit
    content {
      operator                = crit.value.operator
      query                   = crit.value.query
      threshold               = crit.value.threshold
      time_aggregation_method = crit.value.time_aggregation_method
      metric_measure_column   = crit.value.metric_measure_column

      dynamic "dimension" {
        for_each = crit.value.dimension
        iterator = dim
        content {
          values   = dim.value.values
          name     = dim.value.name
          operator = dim.value.operator
        }
      }

      failing_periods {
        minimum_failing_periods_to_trigger_alert = 1
        number_of_evaluation_periods             = 1
      }
    }
  }

  action {
    action_groups = [for action in each.value.actions : action.action_group_id]
  }

  tags = local.tags
}
