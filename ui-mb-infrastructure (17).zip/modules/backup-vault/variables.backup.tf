variable "backup_vault_name" {
  type        = string
  description = "(optional) Name for this Backup Vault. If none is provided a name will be generated"
  default     = null
}

variable "backup_vault_redundancy" {
  type        = string
  description = "(optional) The backup storage redundancy. Possible values are LocallyRedundant, ZoneRedundant and GeoRedundant."
  default     = "LocallyRedundant"

  validation {
    condition = contains([
      "GeoRedundant",
      "LocallyRedundant",
      "ZoneRedundant"
    ], var.backup_vault_redundancy)
    error_message = "backup_vault_redundancy must be one of: GeoRedundant, LocallyRedundant, ZoneRedundant"
  }
}

variable "soft_delete_enabled" {
  type        = bool
  description = "(optional) Enable soft delete for the backup vault. Defaults to false."
  default     = false
}

variable "backup_schedule_interval" {
  type        = string
  description = "(required) Backup schedule interval in ISO 8601 format."
}

variable "retention_days" {
  type        = number
  description = "(optional) Number of days to retain backups. Defaults to 14."
  default     = 14

  validation {
    condition     = var.retention_days >= 7 && var.retention_days <= 9999
    error_message = "retention_days must be between 7 and 9999."
  }
}

variable "backup_timezone" {
  type        = string
  description = "(optional) The timezone for backup scheduling. Defaults to UTC."
  default     = "UTC"
}

variable "enable_private_endpoint" {
  type        = bool
  description = "(optional) Enable private endpoint for the backup vault. Defaults to false."
  default     = false
}
