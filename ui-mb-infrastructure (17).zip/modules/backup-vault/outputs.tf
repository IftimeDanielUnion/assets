output "vault_id" {
  description = "The ID of the Backup Vault"
  value       = azurerm_data_protection_backup_vault.main.id
}

output "backup_policy_id" {
  description = "The ID of the PostgreSQL backup policy"
  value       = azurerm_data_protection_backup_policy_postgresql_flexible_server.main.id
}

output "vault_identity_principal_id" {
  description = "The Principal ID of the Backup Vault's Identity (System or User Assigned)"
  value       = azurerm_data_protection_backup_vault.main.identity[0].principal_id
}

output "vault_identity_type" {
  description = "The type of identity used by the Backup Vault"
  value       = azurerm_data_protection_backup_vault.main.identity[0].type
}

output "resource_group_name" {
  description = "The name of the resource group containing the Backup Vault"
  value       = azurerm_resource_group.main.name
}

output "name" {
  description = "The name of the Backup Vault"
  value       = azurerm_data_protection_backup_vault.main.name
}
