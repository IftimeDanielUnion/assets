locals {
  ### Generic module behaviour
  ###

  ## Tag the module details
  module_name = {
    terraform_module         = "backup-vault",
    terraform_module_version = "1.0.0"
  }

  tags = merge(
    try(var.tags, {}),
    local.module_name
  )

  ### Specific module behaviour
  ###
  # Generate backup vault name manually since naming module doesn't support it
  backup_vault_name = coalesce(var.backup_vault_name, "bv-${var.app_name}-${var.workload_environment}-${var.component_name}-${random_string.suffix.result}")

  # Backup policy configuration
  backup_policy_name = "${local.backup_vault_name}-postgresql-policy"
}

module "naming" {
  source        = "Azure/naming/azurerm"
  version       = "0.4.2"
  suffix        = [lower(var.app_name), lower(var.workload_environment), lower(var.component_name)]
  unique-length = 8
}

resource "random_string" "suffix" {
  length  = 8
  special = false
  upper   = false
}
