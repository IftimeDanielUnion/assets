output "resource_id" {
  description = "The ID of the User Assigned Identity"
  value       = azurerm_user_assigned_identity.main.id
}

output "principal_id" {
  description = "The ID of the Service Principal object associated with the created Identity."
  value       = azurerm_user_assigned_identity.main.principal_id
}
