resource "azurerm_resource_group" "main" {
  name     = module.naming.resource_group.name
  location = var.location
  tags     = local.tags
}

resource "azurerm_user_assigned_identity" "main" {
  name                = module.naming.user_assigned_identity.name_unique
  resource_group_name = azurerm_resource_group.main.name
  location            = azurerm_resource_group.main.location
  tags                = local.tags
}

# Wait a small amount of time after the creation. This prevents failures
# during subsequent role assignments in other resources.
resource "time_sleep" "main" {
  depends_on      = [azurerm_user_assigned_identity.main]
  create_duration = "45s"
  triggers = {
    identity = azurerm_user_assigned_identity.main.id
  }
}
