##
# Budget Outputs
##

output "monthly_budget_id" {
  description = "The ID of the monthly consumption budget"
  value       = azurerm_consumption_budget_subscription.monthly.id
}

output "monthly_budget_name" {
  description = "The name of the monthly consumption budget"
  value       = azurerm_consumption_budget_subscription.monthly.name
}

output "annual_budget_id" {
  description = "The ID of the annual consumption budget"
  value       = azurerm_consumption_budget_subscription.annual.id
}

output "annual_budget_name" {
  description = "The name of the annual consumption budget"
  value       = azurerm_consumption_budget_subscription.annual.name
}
