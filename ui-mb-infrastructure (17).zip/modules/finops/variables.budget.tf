##
# Budget Configuration Variables
##

variable "budget_name_prefix" {
  type        = string
  description = "(required) Prefix for budget names. Will be suffixed with '-monthly' and '-annual'"
}

variable "monthly_budget_amount" {
  type        = number
  description = "(required) The monthly budget amount in USD"
}

variable "annual_budget_amount" {
  type        = number
  description = "(required) The annual budget amount in USD"
}

variable "monthly_start_date" {
  type        = string
  description = "(required) The start date for the monthly budget in YYYY-MM-DD format. Must be first day of current or future month."

  validation {
    condition     = can(regex("^[0-9]{4}-[0-9]{2}-01$", var.monthly_start_date))
    error_message = "monthly_start_date must be in YYYY-MM-01 format (first day of month)"
  }
}

variable "annual_start_date" {
  type        = string
  description = "(required) The start date for the annual budget in YYYY-MM-DD format. Typically YYYY-01-01."

  validation {
    condition     = can(regex("^[0-9]{4}-[0-9]{2}-[0-9]{2}$", var.annual_start_date))
    error_message = "annual_start_date must be in YYYY-MM-DD format"
  }
}

variable "end_date" {
  type        = string
  description = "(optional) The end date for the budget in YYYY-MM-DD format. If not set, budget runs indefinitely"
  default     = null

  validation {
    condition     = var.end_date == null || can(regex("^[0-9]{4}-[0-9]{2}-[0-9]{2}$", var.end_date))
    error_message = "end_date must be in YYYY-MM-DD format or null"
  }
}

variable "notification_thresholds" {
  type = list(object({
    threshold      = number
    operator       = string
    threshold_type = string
  }))
  description = <<DESCRIPTION
(required) List of notification thresholds for the budget.
- `threshold` - Percentage of budget when notification should trigger (e.g., 80 for 80%)
- `operator` - Comparison operator. Typically "GreaterThan"
- `threshold_type` - Type of threshold: "Actual" or "Forecasted"
DESCRIPTION

  validation {
    condition     = alltrue([for t in var.notification_thresholds : contains(["GreaterThan", "GreaterThanOrEqualTo", "EqualTo"], t.operator)])
    error_message = "operator must be one of: GreaterThan, GreaterThanOrEqualTo, EqualTo"
  }

  validation {
    condition     = alltrue([for t in var.notification_thresholds : contains(["Actual", "Forecasted"], t.threshold_type)])
    error_message = "threshold_type must be either Actual or Forecasted"
  }

  validation {
    condition     = alltrue([for t in var.notification_thresholds : t.threshold > 0 && t.threshold <= 1000])
    error_message = "threshold must be between 0 and 1000"
  }
}

variable "notification_emails" {
  type        = list(string)
  description = "(required) List of email addresses to notify when budget thresholds are exceeded"

  validation {
    condition     = length(var.notification_emails) > 0
    error_message = "At least one notification email must be provided"
  }
}

variable "filter_resource_groups" {
  type        = list(string)
  description = "(optional) List of resource group names to filter the budget scope"
  default     = []
}

variable "filter_tags" {
  type        = map(list(string))
  description = "(optional) Map of tag names to tag values to filter the budget scope"
  default     = {}
}
