##
# Azure Consumption Budgets
# Tracks spending and sends alerts when thresholds are exceeded
##

# Monthly Budget - Tracks spending per month
resource "azurerm_consumption_budget_subscription" "monthly" {
  name            = "${var.budget_name_prefix}-monthly"
  subscription_id = "/subscriptions/${var.subscription_id}"

  amount     = var.monthly_budget_amount
  time_grain = "Monthly"

  time_period {
    start_date = "${var.monthly_start_date}T00:00:00Z"
    end_date   = var.end_date != null ? "${var.end_date}T00:00:00Z" : null
  }

  # Create a notification block for each threshold
  dynamic "notification" {
    for_each = var.notification_thresholds

    content {
      enabled        = true
      threshold      = notification.value.threshold
      operator       = notification.value.operator
      threshold_type = notification.value.threshold_type

      contact_emails = var.notification_emails
    }
  }

  # Optional: Filter by resource groups
  dynamic "filter" {
    for_each = length(var.filter_resource_groups) > 0 || length(var.filter_tags) > 0 ? [1] : []

    content {
      # Filter by resource groups
      dynamic "dimension" {
        for_each = length(var.filter_resource_groups) > 0 ? [1] : []

        content {
          name   = "ResourceGroupName"
          values = var.filter_resource_groups
        }
      }

      # Filter by tags
      dynamic "tag" {
        for_each = var.filter_tags

        content {
          name   = tag.key
          values = tag.value
        }
      }
    }
  }
}

# Annual Budget - Tracks spending per year
resource "azurerm_consumption_budget_subscription" "annual" {
  name            = "${var.budget_name_prefix}-annual"
  subscription_id = "/subscriptions/${var.subscription_id}"

  amount     = var.annual_budget_amount
  time_grain = "Annually"

  time_period {
    start_date = "${var.annual_start_date}T00:00:00Z"
    end_date   = var.end_date != null ? "${var.end_date}T00:00:00Z" : null
  }

  # Create a notification block for each threshold
  dynamic "notification" {
    for_each = var.notification_thresholds

    content {
      enabled        = true
      threshold      = notification.value.threshold
      operator       = notification.value.operator
      threshold_type = notification.value.threshold_type

      contact_emails = var.notification_emails
    }
  }

  # Optional: Filter by resource groups
  dynamic "filter" {
    for_each = length(var.filter_resource_groups) > 0 || length(var.filter_tags) > 0 ? [1] : []

    content {
      # Filter by resource groups
      dynamic "dimension" {
        for_each = length(var.filter_resource_groups) > 0 ? [1] : []

        content {
          name   = "ResourceGroupName"
          values = var.filter_resource_groups
        }
      }

      # Filter by tags
      dynamic "tag" {
        for_each = var.filter_tags

        content {
          name   = tag.key
          values = tag.value
        }
      }
    }
  }
}
