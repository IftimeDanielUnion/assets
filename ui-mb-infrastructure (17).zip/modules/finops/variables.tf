variable "workload_name" {
  type        = string
  description = "(required) Name of the workload"
}

variable "workload_environment" {
  type        = string
  description = "(required) Name of the environment/stage of the workload"
}

variable "subscription_id" {
  type        = string
  description = "(required) Azure Subscription ID where the budget will be created"
}

variable "tags" {
  type        = map(string)
  description = "(optional) Tags to apply to FinOps resources"
  default     = {}
}
