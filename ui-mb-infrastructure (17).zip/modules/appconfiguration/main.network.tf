resource "azurerm_private_endpoint" "pep_for_appconfig" {
  name                = "${module.naming.private_endpoint.name}-config"
  resource_group_name = azurerm_resource_group.main.name
  location            = azurerm_resource_group.main.location
  subnet_id           = data.azurerm_subnet.private_endpoints.id
  tags                = local.tags

  private_service_connection {
    is_manual_connection           = false
    name                           = "${module.naming.private_service_connection.name}-config"
    private_connection_resource_id = azurerm_app_configuration.main.id
    subresource_names              = ["configurationStores"]
  }
}
