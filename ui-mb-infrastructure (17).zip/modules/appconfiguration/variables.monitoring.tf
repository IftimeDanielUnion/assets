variable "diagnostic_settings" {
  type = map(object({
    name                           = optional(string, null)
    log_categories                 = optional(set(string), [])
    log_groups                     = optional(set(string), ["allLogs"])
    metric_categories              = optional(set(string), ["AllMetrics"])
    log_analytics_destination_type = optional(string, null)
    workspace_resource_id          = string
  }))
  default     = {}
  description = <<DESCRIPTION
A map of diagnostic settings to create on app config. 

- `name` - (Optional) The name of the diagnostic setting. One will be generated if not set, however this will not be unique if you want to create multiple diagnostic setting resources.
- `log_categories` - (Optional) A set of log categories to send to the log analytics workspace. Defaults to `[]`.
- `log_groups` - (Optional) A set of log groups to send to the log analytics workspace. Defaults to `["allLogs"]`.
- `metric_categories` - (Optional) A set of metric categories to send to the log analytics workspace. Defaults to `["AllMetrics"]`.
- `log_analytics_destination_type` - (Optional) The destination type for the diagnostic setting. Possible values are `Dedicated` and `AzureDiagnostics`. In the current version this is not supported by the app config resource. Therefore, defaults to `null`.
- `workspace_resource_id` - (required) The resource ID of the log analytics workspace to send logs and metrics to.
DESCRIPTION
  nullable    = false
}
