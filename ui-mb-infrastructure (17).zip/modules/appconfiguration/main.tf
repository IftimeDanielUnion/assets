resource "azurerm_resource_group" "main" {
  name     = module.naming.resource_group.name
  location = var.location
  tags     = local.tags
}

resource "azurerm_app_configuration" "main" {
  name                = module.naming.app_configuration.name_unique
  resource_group_name = azurerm_resource_group.main.name
  location            = azurerm_resource_group.main.location
  tags                = local.tags

  sku                        = "standard"
  local_auth_enabled         = false
  public_network_access      = "Disabled"
  purge_protection_enabled   = false
  soft_delete_retention_days = 7
}

resource "azurerm_role_assignment" "app_configuration" {
  for_each = var.role_assignments

  principal_id         = each.value.principal_id
  role_definition_name = each.value.role_definition_name
  scope                = azurerm_app_configuration.main.id
  condition            = each.value.condition
  condition_version    = each.value.condition_version
  description          = each.value.description

  skip_service_principal_aad_check = false
}
