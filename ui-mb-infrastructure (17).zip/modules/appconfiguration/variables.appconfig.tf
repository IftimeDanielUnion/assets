variable "role_assignments" {
  type = map(object({
    principal_id         = string
    role_definition_name = string
    condition            = optional(string, null)
    condition_version    = optional(string, null)
    description          = optional(string, null)
  }))
  description = <<DESCRIPTION
    (optional) A map of role assignments to create on the resource.
- `principal_id` - (required) The ID of the principal to assign the role to.
- `role_definition_name` - (required) The name of the role definition to assign to the principal.
- `description` - (optional) The description of the role assignment.
- `condition` - (optional) The condition which will be used to scope the role assignment.
- `condition_version` - (optional) The version of the condition syntax. Valid values are '2.0'. It is required if `condition` is set.
DESCRIPTION
  default     = {}
  nullable    = false
}
