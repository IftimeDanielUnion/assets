variable "location" {
  type        = string
  description = "(required) Name of the Azure Region. This is the short name like westeurope or swedencentral"
}

variable "tags" {
  type        = map(string)
  description = "(optional) List of tags for use with this resource"
}

variable "container_subnet_id" {
  type        = string
  description = "(required) The id of the subnet to use for containers"
}

##
# Workload and Application information
##
variable "app_name" {
  type        = string
  description = "(required) Name of the Application."
}
variable "component_name" {
  type        = string
  description = "(optional) Name of the Application's component. Used as suffix for resource naming. They follow the pattern <prefix>-<app_name>-<environment>-<component_name>"
  default     = "app-environment"
}

variable "workload_environment" {
  type        = string
  description = "(required) Name of the environment/stage of the workload"
}
