resource "azurerm_resource_group" "main" {
  name     = module.naming.resource_group.name
  location = var.location
  tags     = var.tags
}

resource "azurerm_log_analytics_workspace" "main" {

  name                = module.naming.log_analytics_workspace.name_unique
  resource_group_name = azurerm_resource_group.main.name
  location            = azurerm_resource_group.main.location
  tags                = var.tags

  sku               = "PerGB2018"
  retention_in_days = 30
  daily_quota_gb    = 5
}

resource "azurerm_container_app_environment" "main" {
  name                            = module.naming.container_app_environment.name_unique
  location                        = azurerm_resource_group.main.location
  resource_group_name             = azurerm_resource_group.main.name
  log_analytics_workspace_id      = azurerm_log_analytics_workspace.main.id
  internal_load_balancer_enabled  = true
  public_network_access           = "Disabled"
  infrastructure_subnet_id        = var.container_subnet_id
  tags                            = var.tags

  workload_profile {
    name = "Consumption"
    maximum_count = 0
    minimum_count = 0
    workload_profile_type = "Consumption"
  }
  lifecycle {
    ignore_changes = [
      infrastructure_resource_group_name
    ]
  }
}