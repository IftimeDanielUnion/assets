variable "location" {
  type        = string
  description = "(required) Name of the Azure Region. This is the short name like westeurope or swedencentral"
}

variable "tags" {
  type        = map(string)
  description = "(optional) List of tags for use with this resource"
}

##
# Network Resources
##
variable "vnet_name" {
  type        = string
  description = "(required) Name of the VNet Ressource, which holds the subnet"
}

variable "vnet_resource_group_name" {
  type        = string
  description = "(required) Name of the resource group of the VNet."
}

variable "vnet_subnet_name_appgw" {
  type        = string
  description = "(required) Name of the subnet of the Application Gateway."
}

##
# Workload and Application information
##
variable "app_name" {
  type        = string
  description = "(required) Name of the Application."
}

variable "component_name" {
  type        = string
  description = "(optional) Name of the Application's component. Used as suffix for resource naming. They follow the pattern <prefix>-<app_name>-<environment>-<component_name>"
  default     = "staticwebapp"
}

variable "workload_environment" {
  type        = string
  description = "(required) Name of the environment/stage of the workload"
}

variable "subscription_id" {
  type        = string
  description = "(required) Id of the subscription, in which the Application Gateway resides."
}

variable "csp_connect_src_urls" {
  type        = list(string)
  description = "(optional) Additional URLs to allow in the Content-Security-Policy connect-src directive. These are environment-specific URLs for auth and API endpoints."
  default     = []
}

variable "custom_rewrite_rule_sets" {
  type = map(object({
    csp_connect_src_urls = optional(list(string), [])
    csp_font_src_urls    = optional(list(string), [])
    csp_frame_src_urls   = optional(list(string), [])
    csp_img_src_urls     = optional(list(string), [])
    csp_style_src_urls   = optional(list(string), [])
    csp_script_src_urls  = optional(list(string), [])
  }))
  description = <<DESCRIPTION
(optional) Custom rewrite rule sets with specific CSP policies. Each rule set will include HSTS + a custom CSP policy.
The key is the name of the rewrite rule set, and the value contains the CSP directive URLs for that specific frontend.

Supported CSP directives:
- `csp_connect_src_urls` - (optional) List of URLs to allow in the CSP connect-src directive (API endpoints, WebSockets)
- `csp_font_src_urls`    - (optional) List of URLs to allow in the CSP font-src directive (external fonts)
- `csp_frame_src_urls`   - (optional) List of URLs to allow in the CSP frame-src directive (embedded iframes)
- `csp_img_src_urls`     - (optional) List of URLs to allow in the CSP img-src directive (external images)
- `csp_style_src_urls`   - (optional) List of URLs to allow in the CSP style-src directive (external stylesheets)
- `csp_script_src_urls`  - (optional) List of URLs to allow in the CSP script-src directive (external scripts)

Example:
custom_rewrite_rule_sets = {
  "mbportal-security-headers" = {
    csp_connect_src_urls = ["https://auth-dev.user.union-investment.de", "https://uiapimf5c41c8714ee.azure-api.net"]
    csp_font_src_urls    = ["https://global-resources.fe.union-investment.de"]
    csp_frame_src_urls   = ["https://app.powerbi.com"]
    csp_img_src_urls     = ["https://cdn.example.com"]
  }
}
DESCRIPTION
  default     = {}
}
