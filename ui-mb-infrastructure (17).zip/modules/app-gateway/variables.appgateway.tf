##
# Variables, specifig to the configuration of the application gateway
##

# Settings for the app gateway itself
variable "app_gateway_properties" {
  type = object({
    name           = string
    resource_group = string

    sku = optional(object({
      name     = string
      tier     = string
      capacity = number
    }), { name = "WAF_v2", tier = "WAF_v2", capacity = 2 })

    gateway_ip_configuration_name         = string
    frontend_public_ip_configuration_name = string

    user_assigned_resource_ids = optional(set(string), [])

  })
  default     = null
  description = <<DESCRIPTION
(required) The basic settings for the Application Gateway. The Application Gateway itself is not created but configured only.
 - `name` - (required) Name of an existing Application Gateway.
 - `resource_group` - (required) The Resource Group containing the existing Application Gateway.
 - `gateway_ip_configuration_name` - (required) Name of the IP configuration created for this App Gateway. This is expected to be in the Subnet as given in `vnet_subnet_name_appgw`
 - `frontend_public_ip_configuration_name` - (required) Name of the frontend_ip_configuration holding the `public_ip_address`.
 - `user_assigned_resource_ids` - (optional) List of User Assigned Identities, which will be assigned to this Application Gateway.

 ---
 `sku` block supports the following:
 - `name` - (optional) The SKU Name. Possible values are `Standard_v2` and `WAF_v2`. Defaults to `WAF_v2`.
 - `tier` - (optional) The SKU Tier. Possible values are `Standard_v2` and `WAF_v2`. Defaults to `WAF_v2`.
 - `capacity` - (optional) This SKUs capacity. Possible values range from 1 to 132. Defaults to 2.

DESCRIPTION
  validation {
    condition     = can(regex("^(Standard_v2|WAF_v2)$", var.app_gateway_properties.sku.name))
    error_message = "SKU name must be 'Standard_v2' or 'WAF_v2'."
  }
  validation {
    condition     = can(regex("^(Standard_v2|WAF_v2)$", var.app_gateway_properties.sku.tier))
    error_message = "SKU tier must be 'Standard_v2' or 'WAF_v2'."
  }
}

variable "backend_address_pools" {
  type = map(object({
    name         = string
    fqdns        = optional(set(string))
    ip_addresses = optional(set(string))
  }))
  description = <<DESCRIPTION
 - `name` - (required) The name of the Backend Address Pool.
 - `fqdns` - (optional) A list of FQDN's which should be part of the Backend Address Pool.
 - `ip_addresses` - (optional) A list of IP Addresses which should be part of the Backend Address Pool.
DESCRIPTION
  nullable    = false
}

variable "backend_http_settings" {
  type = map(object({
    cookie_based_affinity               = optional(string, "Disabled")
    name                                = string
    port                                = number
    protocol                            = string
    affinity_cookie_name                = optional(string)
    host_name                           = optional(string)
    path                                = optional(string)
    pick_host_name_from_backend_address = optional(bool)
    probe_name                          = optional(string)
    request_timeout                     = optional(number)
    trusted_root_certificate_names      = optional(list(string))
    authentication_certificate = optional(list(object({
      name = string
    })))
    connection_draining = optional(object({
      drain_timeout_sec          = number
      enable_connection_draining = bool
    }))
  }))
  description = <<-DESCRIPTION
 - `cookie_based_affinity` - (required) Is Cookie-Based Affinity enabled? Possible values are `Enabled` and `Disabled`.
 - `name` - (required) The name of the Backend HTTP Settings Collection.
 - `port` - (required) The port which should be used for this Backend HTTP Settings Collection.
 - `protocol` - (required) The Protocol which should be used. Possible values are `Http` and `Https`.
 - `affinity_cookie_name` - (optional) The name of the affinity cookie.
 - `host_name` - (optional) Host header to be sent to the backend servers. Cannot be set if `pick_host_name_from_backend_address` is set to `true`.
 - `path` - (optional) The Path which should be used as a prefix for all HTTP requests.
 - `pick_host_name_from_backend_address` - (optional) Whether host header should be picked from the host name of the backend server. Defaults to `false`.
 - `probe_name` - (optional) The name of an associated HTTP Probe.
 - `request_timeout` - (optional) The request timeout in seconds, which must be between 1 and 86400 seconds. Defaults to `30`.
 - `trusted_root_certificate_names` - (optional) A list of `trusted_root_certificate` names.

 ---
 `authentication_certificate` block supports the following:
 - `name` - (required) The Name of the Authentication Certificate to use.

 ---
 `connection_draining` block supports the following:
 - `drain_timeout_sec` - (required) The number of seconds connection draining is active. Acceptable values are from `1` second to `3600` seconds.
 - `enable_connection_draining` - (required) If connection draining is enabled or not.
DESCRIPTION
  nullable    = false

  validation {
    # checks host_name is null if pick_host_name_from_backend_address is set to true
    condition     = alltrue([for _, v in var.backend_http_settings : v.pick_host_name_from_backend_address == true ? v.host_name == null : true])
    error_message = "host_name must not be set if pick_host_name_from_backend_address is set to true."
  }
}

variable "frontend_ip_configuration_private" {
  type = object({
    name                            = optional(string)
    private_ip_address              = optional(string)
    private_ip_address_allocation   = optional(string)
    private_link_configuration_name = optional(string)
  })
  default     = {}
  description = <<DESCRIPTION
 - `name` - (optional) The name of the private  Frontend IP Configuration.
 - `private_ip_address` - (optional) The Private IP Address to use for the Application Gateway.
 - `private_ip_address_allocation` - (optional) The Allocation Method for the Private IP Address. Possible values are `Dynamic` and `Static`. Defaults to `Dynamic`.
 - `private_link_configuration_name` - (optional) The name of the private link configuration to use for this frontend IP configuration.

The subnet id must be the same as supplied to the general VNet configuration so is not required as a parameter.

DESCRIPTION
}

variable "frontend_ports" {
  type = map(object({
    name = string
    port = number
  }))
  description = <<-DESCRIPTION
 - `name` - (required) The name of the Frontend Port.
 - `port` - (required) The port used for this Frontend Port.
DESCRIPTION
  nullable    = false
}

variable "http_listeners" {
  type = map(object({
    name                           = string
    frontend_port_name             = string
    frontend_ip_configuration_name = optional(string)
    firewall_policy_id             = optional(string)
    require_sni                    = optional(bool)
    host_name                      = optional(string)
    host_names                     = optional(list(string))
    ssl_certificate_name           = optional(string)
    ssl_profile_name               = optional(string)
    custom_error_configuration = optional(list(object({
      status_code           = string
      custom_error_page_url = string
    })))
  }))
  description = <<-DESCRIPTION
 - `firewall_policy_id` - (optional) The ID of the Web Application Firewall Policy which should be used for this HTTP Listener.
 - `frontend_ip_configuration_name` - (required) The Name of the Frontend IP Configuration used for this HTTP Listener.
 - `frontend_port_name` - (required) The Name of the Frontend Port use for this HTTP Listener.
 - `host_name` - (optional) The Hostname which should be used for this HTTP Listener. Setting this value changes Listener Type to 'Multi site'.
 - `host_names` - (optional) A list of Hostname(s) should be used for this HTTP Listener. It allows special wildcard characters.
 - `name` - (required) The Name of the HTTP Listener.
 - `require_sni` - (optional) Should Server Name Indication be required? Defaults to `false`.
 - `ssl_certificate_name` - (optional) The name of the associated SSL Certificate which should be used for this HTTP Listener.
 - `ssl_profile_name` - (optional) The name of the associated SSL Profile which should be used for this HTTP Listener.

 ---
 `custom_error_configuration` block supports the following:
 - `custom_error_page_url` - (required) Error page URL of the application gateway customer error.
 - `status_code` - (required) Status code of the application gateway customer error. Possible values are `HttpStatus403` and `HttpStatus502`
DESCRIPTION
  nullable    = false
}

variable "private_subdomain" {
  type = object({
    name = string
    zone = object({
      name                = string
      resource_group_name = string
    })
  })
  description = <<DESCRIPTION
    (optional) A private subdomain for the internal addresses of the Application Gateway.
  - `name` - (required) The name of the subdomain.
  ---
  `zone` block defines the internal dns-zone resource:
  - `name` - (required) Name of a Private DNS zone
  - `resource_group_name` - (required) Name of the resource group of the Private DNS zone.
  DESCRIPTION
  default     = null
  nullable    = true

  validation {
    condition     = try(regex("[^a-zA-Z0-9]", var.private_subdomain.name), "") == ""
    error_message = <<ERR
    The name of the subdomain must only contain alpha-numeric characters.
    ERR
  }
  validation {
    condition     = var.private_subdomain == null || (length(var.private_subdomain.name) >= 2 && length(var.private_subdomain.name) <= 20)
    error_message = <<ERR
    The name of the subdomain must be between 2-20 characters.
    ERR
  }
  validation {
    condition     = try(regex("^[0-9]", var.private_subdomain.name), "") == ""
    error_message = <<ERR
    The name of the subdomain must start with a letter.
    ERR
  }
}

variable "probe_configurations" {
  type = map(object({
    name                                      = string
    host                                      = optional(string)
    interval                                  = number
    timeout                                   = number
    unhealthy_threshold                       = number
    protocol                                  = string
    port                                      = optional(number)
    path                                      = string
    pick_host_name_from_backend_http_settings = optional(bool)
    minimum_servers                           = optional(number)
    match = optional(object({
      body        = optional(string)
      status_code = optional(list(string))
    }))
  }))
  default     = null
  description = <<-DESCRIPTION
 - `host` - (optional) The Hostname used for this Probe. If the Application Gateway is configured for a single site, by default the Host name should be specified as `127.0.0.1`, unless otherwise configured in custom probe. Cannot be set if `pick_host_name_from_backend_http_settings` is set to `true`.
 - `interval` - (required) The Interval between two consecutive probes in seconds. Possible values range from 1 second to a maximum of 86,400 seconds.
 - `minimum_servers` - (optional) The minimum number of servers that are always marked as healthy. Defaults to `0`.
 - `name` - (required) The Name of the Probe.
 - `path` - (required) The Path used for this Probe.
 - `pick_host_name_from_backend_http_settings` - (optional) Whether the host header should be picked from the backend HTTP settings. Defaults to `false`.
 - `port` - (optional) Custom port which will be used for probing the backend servers. The valid value ranges from 1 to 65535. In case not set, port from HTTP settings will be used. This property is valid for Standard_v2 and WAF_v2 only.
 - `protocol` - (required) The Protocol used for this Probe. Possible values are `Http` and `Https`.
 - `timeout` - (required) The Timeout used for this Probe, which indicates when a probe becomes unhealthy. Possible values range from 1 second to a maximum of 86,400 seconds.
 - `unhealthy_threshold` - (required) The Unhealthy Threshold for this Probe, which indicates the amount of retries which should be attempted before a node is deemed unhealthy. Possible values are from 1 to 20.

 ---
 `match` block supports the following:
 - `body` - (optional) A snippet from the Response Body which must be present in the Response.
 - `status_code` - (required) A list of allowed status codes for this Health Probe.
DESCRIPTION
}

variable "public_ip_address" {
  type = object({
    name           = string
    resource_group = string
  })
  description = <<DESCRIPTION
  - `name` - (required) The name of the Public IP Address associated with the Application Gateway
  - `resource_group` - (required) The Resource Group of the Public IP Address

  This Public IP Address is not created if it does not exist.
  DESCRIPTION
}

variable "redirect_configuration" {
  type = map(object({
    include_path         = optional(bool)
    include_query_string = optional(bool)
    name                 = string
    redirect_type        = string
    target_listener_name = optional(string)
    target_url           = optional(string)
  }))
  default     = null
  description = <<-DESCRIPTION
 - `include_path` - (optional) Whether to include the path in the redirected URL. Defaults to `false`
 - `include_query_string` - (optional) Whether to include the query string in the redirected URL. Default to `false`
 - `name` - (required) Unique name of the redirect configuration block
 - `redirect_type` - (required) The type of redirect. Possible values are `Permanent`, `Temporary`, `Found` and `SeeOther`
 - `target_listener_name` - (optional) The name of the listener to redirect to. Cannot be set if `target_url` is set.
 - `target_url` - (optional) The URL to redirect the request to. Cannot be set if `target_listener_name` is set.
DESCRIPTION
}

variable "request_routing_rules" {
  type = map(object({
    name                        = string
    rule_type                   = string
    http_listener_name          = string
    backend_address_pool_name   = optional(string)
    priority                    = optional(number)
    url_path_map_name           = optional(string)
    backend_http_settings_name  = optional(string)
    redirect_configuration_name = optional(string)
    rewrite_rule_set_name       = optional(string)
    # Define other attributes as needed
  }))
  description = <<-DESCRIPTION
 - `backend_address_pool_name` - (optional) The Name of the Backend Address Pool which should be used for this Routing Rule. Cannot be set if `redirect_configuration_name` is set.
 - `backend_http_settings_name` - (optional) The Name of the Backend HTTP Settings Collection which should be used for this Routing Rule. Cannot be set if `redirect_configuration_name` is set.
 - `http_listener_name` - (required) The Name of the HTTP Listener which should be used for this Routing Rule.
 - `name` - (required) The Name of this Request Routing Rule.
 - `priority` - (optional) Rule evaluation order can be dictated by specifying an integer value from `1` to `20000` with `1` being the highest priority and `20000` being the lowest priority.
 - `redirect_configuration_name` - (optional) The Name of the Redirect Configuration which should be used for this Routing Rule. Cannot be set if either `backend_address_pool_name` or `backend_http_settings_name` is set.
 - `rewrite_rule_set_name` - (optional) The Name of the Rewrite Rule Set which should be used for this Routing Rule. Only valid for v2 SKUs.
 - `rule_type` - (required) The Type of Routing that should be used for this Rule. Possible values are `Basic` and `PathBasedRouting`.
 - `url_path_map_name` - (optional) The Name of the URL Path Map which should be associated with this Routing Rule.
DESCRIPTION
  nullable    = false
}

variable "ssl_certificates" {
  type = map(object({
    name                = string
    data                = optional(string)
    password            = optional(string)
    key_vault_secret_id = optional(string)
  }))
  default     = null
  description = <<-DESCRIPTION
 - `data` - (optional) The base64-encoded PFX certificate data. required if `key_vault_secret_id` is not set.
 - `key_vault_secret_id` - (optional) The Secret ID of (base-64 encoded unencrypted pfx) the `Secret` or `Certificate` object stored in Azure KeyVault. You need to enable soft delete for Key Vault to use this feature. required if `data` is not set.
 - `name` - (required) The Name of the SSL certificate that is unique within this Application Gateway
 - `password` - (optional) Password for the pfx file specified in data. required if `data` is set.
DESCRIPTION
}

# Define a list of URL path map configurations
variable "url_path_map_configurations" {
  type = map(object({
    name                                = string
    default_redirect_configuration_name = optional(string)
    default_backend_http_settings_name  = optional(string)
    default_backend_address_pool_name   = optional(string)
    default_rewrite_rule_set_name       = optional(string)
    path_rules = map(object({
      name                        = string
      paths                       = list(string)
      backend_address_pool_name   = optional(string)
      backend_http_settings_name  = optional(string)
      redirect_configuration_name = optional(string)
      rewrite_rule_set_name       = optional(string)
      firewall_policy_id          = optional(string)
    }))
  }))
  default     = null
  description = <<-DESCRIPTION
 - `default_backend_address_pool_name` - (optional) The Name of the Default Backend Address Pool which should be used for this URL Path Map. Cannot be set if `default_redirect_configuration_name` is set.
 - `default_backend_http_settings_name` - (optional) The Name of the Default Backend HTTP Settings Collection which should be used for this URL Path Map. Cannot be set if `default_redirect_configuration_name` is set.
 - `default_redirect_configuration_name` - (optional) The Name of the Default Redirect Configuration which should be used for this URL Path Map. Cannot be set if either `default_backend_address_pool_name` or `default_backend_http_settings_name` is set.
 - `default_rewrite_rule_set_name` - (optional) The Name of the Default Rewrite Rule Set which should be used for this URL Path Map. If not set, the default Security-Headers rule set will be used.
 - `name` - (required) The Name of the URL Path Map.

 ---
 `path_rule` block supports the following:
 - `backend_address_pool_name` - (optional) The Name of the Backend Address Pool to use for this Path Rule. Cannot be set if `redirect_configuration_name` is set.
 - `backend_http_settings_name` - (optional) The Name of the Backend HTTP Settings Collection to use for this Path Rule. Cannot be set if `redirect_configuration_name` is set.
 - `firewall_policy_id` - (optional) The ID of the Web Application Firewall Policy which should be used as an HTTP Listener.
 - `name` - (required) The Name of the Path Rule.
 - `paths` - (required) A list of Paths used in this Path Rule.
 - `redirect_configuration_name` - (optional) The Name of a Redirect Configuration to use for this Path Rule. Cannot be set if `backend_address_pool_name` or `backend_http_settings_name` is set.
 - `rewrite_rule_set_name` - (optional) The Name of the Rewrite Rule Set which should be used for this URL Path Map. Only valid for v2 SKUs.
DESCRIPTION
}
