# Import the Application Gateway. It is created within the Workload
import {
  id = local.app_gw_id
  to = azurerm_application_gateway.main
}

# A single A-Record is created pointing to all private frontend ips of the application gateway
resource "azurerm_private_dns_a_record" "main" {
  count = var.private_subdomain != null ? 1 : 0

  name                = var.private_subdomain.name
  zone_name           = one(data.azurerm_private_dns_zone.default).name
  resource_group_name = one(data.azurerm_private_dns_zone.default).resource_group_name
  ttl                 = 300
  records             = [for i in azurerm_application_gateway.main.frontend_ip_configuration : i.private_ip_address if i.private_ip_address != ""]
}

# Application Gateway Configuration
resource "azurerm_application_gateway" "main" {
  name                = var.app_gateway_properties.name
  resource_group_name = data.azurerm_resource_group.appgw.name
  location            = var.location

  enable_http2                      = false
  fips_enabled                      = false
  firewall_policy_id                = azurerm_web_application_firewall_policy.main.id
  force_firewall_policy_association = true
  tags                              = local.tags
  #   zones                             = var.zones

  # Default SSL Policy. Overrides the outdated default of the Workload AppGw
  # CC-V3-13
  ssl_policy {
    policy_name = "AppGwSslPolicy20220101S" # Policy without CBC-Ciphers
    policy_type = "Predefined"
  }

  # Default Rewrite Rule Set for Security Headers (HSTS + CSP)
  # CC-V3-12 'HTTP Strict Transport Security (HSTS) ist aktiviert'
  # PENT00001392-1 'Content-Security-Policy (CSP) ist konfiguriert'

  # Custom Rewrite Rule Sets for specific frontends
  dynamic "rewrite_rule_set" {
    for_each = var.custom_rewrite_rule_sets

    content {
      name = rewrite_rule_set.key

      # HSTS Header
      rewrite_rule {
        name          = "HSTS-Rewrite"
        rule_sequence = 100
        response_header_configuration {
          header_name  = "Strict-Transport-Security"
          header_value = "max-age=15552000"
        }
      }

      # CSP Header (frontend-specific)
      rewrite_rule {
        name          = "CSP-Rewrite"
        rule_sequence = 110
        response_header_configuration {
          header_name = "Content-Security-Policy"
          header_value = join("", [
            "default-src 'self'; ",
            "script-src 'self' 'unsafe-inline' 'unsafe-eval'${length(try(rewrite_rule_set.value.csp_script_src_urls, [])) > 0 ? " ${join(" ", rewrite_rule_set.value.csp_script_src_urls)}" : ""}; ",
            "style-src 'self' 'unsafe-inline'${length(try(rewrite_rule_set.value.csp_style_src_urls, [])) > 0 ? " ${join(" ", rewrite_rule_set.value.csp_style_src_urls)}" : ""}; ",
            "img-src 'self' data: https:${length(try(rewrite_rule_set.value.csp_img_src_urls, [])) > 0 ? " ${join(" ", rewrite_rule_set.value.csp_img_src_urls)}" : ""}; ",
            "font-src 'self' data:${length(try(rewrite_rule_set.value.csp_font_src_urls, [])) > 0 ? " ${join(" ", rewrite_rule_set.value.csp_font_src_urls)}" : ""}; ",
            "connect-src 'self'${length(try(rewrite_rule_set.value.csp_connect_src_urls, [])) > 0 ? " ${join(" ", rewrite_rule_set.value.csp_connect_src_urls)}" : ""}; ",
            "frame-ancestors 'none'; base-uri 'self'; form-action 'self'",
            length(try(rewrite_rule_set.value.csp_frame_src_urls, [])) > 0 ? "; frame-src ${join(" ", rewrite_rule_set.value.csp_frame_src_urls)}" : ""
          ])
        }
      }
    }
  }

  sku {
    name     = var.app_gateway_properties.sku.name
    tier     = var.app_gateway_properties.sku.tier
    capacity = var.app_gateway_properties.sku.capacity
  }

  gateway_ip_configuration {
    name      = var.app_gateway_properties.gateway_ip_configuration_name
    subnet_id = data.azurerm_subnet.appgw.id
  }

  # public ip configuration
  frontend_ip_configuration {
    name                 = var.app_gateway_properties.frontend_public_ip_configuration_name
    public_ip_address_id = data.azurerm_public_ip.appgw.id
  }

  # private frontend ip configurations
  dynamic "frontend_ip_configuration" {
    for_each = var.frontend_ip_configuration_private.private_ip_address == null ? [] : [var.frontend_ip_configuration_private]

    content {
      name                            = frontend_ip_configuration.value.name
      private_ip_address              = frontend_ip_configuration.value.private_ip_address
      private_ip_address_allocation   = frontend_ip_configuration.value.private_ip_address_allocation
      private_link_configuration_name = frontend_ip_configuration.value.private_link_configuration_name
      subnet_id                       = data.azurerm_subnet.appgw.id
    }
  }

  # Add user assigned Identity for KeyVault Access.
  identity {
    type         = "UserAssigned"
    identity_ids = var.app_gateway_properties.user_assigned_resource_ids
  }

  # Frontend IP Port configuration
  dynamic "frontend_port" {
    for_each = var.frontend_ports

    content {
      name = lookup(frontend_port.value, "name", null)
      port = lookup(frontend_port.value, "port", null)
    }
  }


  # Backend Address Pool Configuration
  dynamic "backend_address_pool" {
    for_each = var.backend_address_pools

    content {
      name         = backend_address_pool.value.name
      fqdns        = backend_address_pool.value.fqdns != null ? backend_address_pool.value.fqdns : null
      ip_addresses = backend_address_pool.value.ip_addresses != null ? backend_address_pool.value.ip_addresses : null
    }
  }
  # Backend Http Settings Configuration
  dynamic "backend_http_settings" {
    for_each = var.backend_http_settings

    content {
      cookie_based_affinity               = backend_http_settings.value.cookie_based_affinity
      name                                = backend_http_settings.value.name
      port                                = backend_http_settings.value.port
      protocol                            = backend_http_settings.value.protocol
      affinity_cookie_name                = backend_http_settings.value.affinity_cookie_name
      host_name                           = backend_http_settings.value.host_name
      path                                = backend_http_settings.value.path
      pick_host_name_from_backend_address = backend_http_settings.value.pick_host_name_from_backend_address
      probe_name                          = backend_http_settings.value.probe_name
      request_timeout                     = backend_http_settings.value.request_timeout
      trusted_root_certificate_names      = backend_http_settings.value.trusted_root_certificate_names

      dynamic "authentication_certificate" {
        for_each = backend_http_settings.value.authentication_certificate == null ? [] : backend_http_settings.value.authentication_certificate

        content {
          name = authentication_certificate.value.name
        }
      }
      dynamic "connection_draining" {
        for_each = backend_http_settings.value.connection_draining == null ? [] : [backend_http_settings.value.connection_draining]

        content {
          drain_timeout_sec = connection_draining.value.drain_timeout_sec
          enabled           = connection_draining.value.enable_connection_draining
        }
      }
    }
  }



  # Http Listener Configuration
  dynamic "http_listener" {
    for_each = var.http_listeners

    content {
      frontend_ip_configuration_name = coalesce(http_listener.value.frontend_ip_configuration_name, local.public_ip_configuration_name, local.private_ip_configuration_name)

      frontend_port_name   = http_listener.value.frontend_port_name
      name                 = http_listener.value.name
      protocol             = http_listener.value.ssl_certificate_name == null ? "Http" : "Https"
      firewall_policy_id   = http_listener.value.firewall_policy_id
      host_name            = http_listener.value.host_name
      host_names           = http_listener.value.host_names
      require_sni          = http_listener.value.require_sni
      ssl_certificate_name = http_listener.value.ssl_certificate_name
      ssl_profile_name     = http_listener.value.ssl_profile_name

      dynamic "custom_error_configuration" {
        for_each = http_listener.value.custom_error_configuration != null ? lookup(http_listener.value, "custom_error_configuration", {}) : []

        content {
          custom_error_page_url = lookup(custom_error_configuration.value, "custom_error_page_url", null)
          status_code           = lookup(custom_error_configuration.value, "status_code", null)
        }
      }
    }
  }

  # Rules Configuration
  dynamic "request_routing_rule" {
    for_each = var.request_routing_rules

    content {
      http_listener_name          = request_routing_rule.value.http_listener_name
      name                        = request_routing_rule.value.name
      rule_type                   = request_routing_rule.value.rule_type
      backend_address_pool_name   = request_routing_rule.value.backend_address_pool_name
      backend_http_settings_name  = request_routing_rule.value.backend_http_settings_name
      priority                    = request_routing_rule.value.priority
      redirect_configuration_name = request_routing_rule.value.redirect_configuration_name
      rewrite_rule_set_name       = request_routing_rule.value.rewrite_rule_set_name
      url_path_map_name           = request_routing_rule.value.url_path_map_name
    }
  }

  dynamic "redirect_configuration" {
    for_each = var.redirect_configuration != null ? var.redirect_configuration : {}

    content {
      include_path         = redirect_configuration.value.include_path
      include_query_string = redirect_configuration.value.include_query_string
      name                 = redirect_configuration.value.name
      redirect_type        = redirect_configuration.value.redirect_type
      target_listener_name = redirect_configuration.value.target_listener_name
      target_url           = redirect_configuration.value.target_url
    }
  }

  dynamic "url_path_map" {
    for_each = var.url_path_map_configurations != null ? var.url_path_map_configurations : {}

    content {
      name                                = url_path_map.value.name
      default_backend_address_pool_name   = url_path_map.value.default_backend_address_pool_name
      default_backend_http_settings_name  = url_path_map.value.default_backend_http_settings_name
      default_redirect_configuration_name = url_path_map.value.default_redirect_configuration_name
      default_rewrite_rule_set_name       = url_path_map.value.default_rewrite_rule_set_name != null ? url_path_map.value.default_rewrite_rule_set_name : local.default_rewrite_rule_set_name

      dynamic "path_rule" {
        for_each = url_path_map.value.path_rules != null ? url_path_map.value.path_rules : {}

        content {
          name                       = path_rule.value.name
          paths                      = path_rule.value.paths
          backend_address_pool_name  = path_rule.value.backend_address_pool_name
          backend_http_settings_name = path_rule.value.backend_http_settings_name
          # WAF Enable Web Application Firewall policies
          firewall_policy_id          = path_rule.value.firewall_policy_id
          redirect_configuration_name = path_rule.value.redirect_configuration_name
          rewrite_rule_set_name       = path_rule.value.rewrite_rule_set_name
        }
      }
    }
  }

  # Health Probes Configuration
  dynamic "probe" {
    for_each = var.probe_configurations != null ? var.probe_configurations : {}

    content {
      interval                                  = probe.value.interval
      name                                      = probe.value.name
      path                                      = probe.value.path
      protocol                                  = probe.value.protocol
      timeout                                   = probe.value.timeout
      unhealthy_threshold                       = probe.value.unhealthy_threshold
      host                                      = probe.value.host
      minimum_servers                           = probe.value.minimum_servers
      pick_host_name_from_backend_http_settings = probe.value.pick_host_name_from_backend_http_settings
      port                                      = probe.value.port

      dynamic "match" {
        for_each = probe.value.match == null ? [] : [probe.value.match]

        content {
          status_code = match.value.status_code
          body        = match.value.body
        }
      }
    }
  }

  # SSL Certificates
  dynamic "ssl_certificate" {
    for_each = var.ssl_certificates == null ? {} : var.ssl_certificates

    content {
      name                = ssl_certificate.value.name
      data                = ssl_certificate.value.data
      key_vault_secret_id = ssl_certificate.value.key_vault_secret_id
      password            = ssl_certificate.value.password
    }
  }

}
