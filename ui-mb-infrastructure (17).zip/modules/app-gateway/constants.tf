locals {
  ### Generic module behaviour
  ###

  ## Tag the module details
  module_name = {
    terraform_module         = "app-gateway",
    terraform_module_version = "1.1.0"
  }

  tags = merge(
    try(var.tags, {}),
    local.module_name
  )

  ### Specific module behaviour
  ###
  app_gw_id       = "/subscriptions/${var.subscription_id}/resourceGroups/${var.app_gateway_properties.resource_group}/providers/Microsoft.Network/applicationGateways/${var.app_gateway_properties.name}"
  waf_policy_name = "${var.app_gateway_properties.name}-waf-policy"

  public_ip_configuration_name  = var.app_gateway_properties.frontend_public_ip_configuration_name
  private_ip_configuration_name = var.frontend_ip_configuration_private.name

  default_rewrite_rule_set_name = "Security-Headers"
}

module "naming" {
  source        = "Azure/naming/azurerm"
  version       = "0.4.2"
  suffix        = [lower(var.app_name), lower(var.workload_environment), lower(var.component_name)]
  unique-length = 8
}
