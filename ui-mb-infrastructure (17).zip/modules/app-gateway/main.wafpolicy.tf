##
# The resource group is only used for the WAF Policy
resource "azurerm_resource_group" "main" {
  name     = module.naming.resource_group.name
  location = var.location
}


##
# The WAF Policy is currently the only Policy in the AppGw and identical in all stages.
# Therefore, it does not provide any means to configure it, appart from name, group and location
resource "azurerm_web_application_firewall_policy" "main" {
  name                = local.waf_policy_name
  resource_group_name = azurerm_resource_group.main.name
  location            = var.location
  tags                = local.tags

  policy_settings {
    enabled                     = true
    mode                        = "Prevention"
    request_body_check          = true
    max_request_body_size_in_kb = 128
  }

  managed_rules {
    managed_rule_set {
      type    = "OWASP"
      version = "3.2"
    }
    managed_rule_set {
      type    = "Microsoft_BotManagerRuleSet"
      version = "1.1"
    }

    ## EXCLUDE ARGS:code
    # SQL Injection FALSE POSITIVES
    # during Token Request with Azure AD B2C
    # 'code' is the Argument containing the token value
    exclusion {
      match_variable          = "RequestArgNames"
      selector_match_operator = "Equals"
      selector                = "code"
      excluded_rule_set {
        type    = "OWASP"
        version = "3.2"
        rule_group {
          rule_group_name = "REQUEST-942-APPLICATION-ATTACK-SQLI"
          excluded_rules = [
            "942430",
            "942440",
            "942450"
          ]
        }
      }
    }

    ## EXCLUDE COOKIE:msal.cache.encryption
    # SQL Injection FALSE POSITIVES
    # during Token Request with Azure AD B2C
    # 'msal.cache.encryption' has falsly identified content
    exclusion {
      match_variable          = "RequestCookieNames"
      selector_match_operator = "Equals"
      selector                = "msal.cache.encryption"
      excluded_rule_set {
        type    = "OWASP"
        version = "3.2"
        rule_group {
          rule_group_name = "REQUEST-942-APPLICATION-ATTACK-SQLI"
          excluded_rules = [
            "942200",
            "942260",
            "942340",
            "942370"
          ]
        }
      }
    }

    ## EXCLUDE ARGS:rscd
    # SQL Injection FALSE POSITIVES
    # during SAS Token Requests
    # 'rscd' is the Argument containing the Content Disposition header (e.G. Which filename should be used for downloads)
    exclusion {
      match_variable          = "RequestArgNames"
      selector_match_operator = "Equals"
      selector                = "rscd"
      excluded_rule_set {
        type    = "OWASP"
        version = "3.2"
        rule_group {
          rule_group_name = "REQUEST-942-APPLICATION-ATTACK-SQLI"
          excluded_rules = [
            "942430",
            "942440",
            "942450",
            "942370",
            "942110"
          ]
        }
        rule_group {
          rule_group_name = "REQUEST-941-APPLICATION-ATTACK-XSS"
          excluded_rules = [
            "941340"
          ]
        }
      }
    }
  }


  custom_rules {
    name      = "BlockOtherThanHttpGet"
    priority  = "10"
    rule_type = "MatchRule"
    action    = "Block"
    match_conditions {
      match_variables {
        variable_name = "RequestMethod"
      }
      operator           = "Equal"
      negation_condition = true
      match_values       = ["GET"]
    }
  }
}
