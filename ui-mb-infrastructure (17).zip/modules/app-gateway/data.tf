# ##
# # Resource Group of the App Gateway
data "azurerm_resource_group" "appgw" {
  name = var.app_gateway_properties.resource_group
}

data "azurerm_subnet" "appgw" {
  name                 = var.vnet_subnet_name_appgw
  virtual_network_name = var.vnet_name
  resource_group_name  = var.vnet_resource_group_name
}

data "azurerm_public_ip" "appgw" {
  name                = var.public_ip_address.name
  resource_group_name = var.public_ip_address.resource_group
}

##
# DNS Zone
data "azurerm_private_dns_zone" "default" {
  count = var.private_subdomain != null ? 1 : 0

  name                = var.private_subdomain.zone.name
  resource_group_name = var.private_subdomain.zone.resource_group_name
}
