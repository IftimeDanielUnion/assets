variable "access_tier" {
  type        = string
  description = "(optional) Defines the access tier for this storage account. Valid options are `Hot` and `Cool`, defaults to `Hot`."
  default     = "Hot"
}

variable "account_replication_type" {
  type        = string
  description = "(optional) Defines the type of replication for this storage account. Valid options are `LRS`, `ZRS` among others, defaults to `LRS`."
  default     = "LRS"
}

variable "allow_public_access" {
  type        = bool
  description = "(optional) Defines whether this storage account is accessible via public endpoint, defaults to `false`."
  default     = false
}

variable "integrate_defender_for_storage" {
  type = object({
    endpoint_resource_id = string
    endpoint_tenant_id   = string
  })
  description = <<DESCRIPTION
    (optional) Defines a private link which will be granted access to this Storage Account. Defaults to `null` and no private link will be added to the network rules.
  DESCRIPTION
  default     = null
}
