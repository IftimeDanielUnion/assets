resource "azurerm_resource_group" "main" {
  name     = module.naming.resource_group.name
  location = var.location
  tags     = local.tags
}

module "blob-storage" {
  source  = "Azure/avm-res-storage-storageaccount/azurerm"
  version = "0.6.4"

  enable_telemetry = false

  name                = module.naming.storage_account.name_unique
  resource_group_name = azurerm_resource_group.main.name
  location            = azurerm_resource_group.main.location
  tags                = local.tags

  access_tier                     = var.access_tier
  account_kind                    = "StorageV2"
  account_tier                    = "Standard"
  account_replication_type        = var.account_replication_type
  allow_nested_items_to_be_public = false
  https_traffic_only_enabled      = true
  min_tls_version                 = "TLS1_2"

  public_network_access_enabled = var.allow_public_access
  shared_access_key_enabled     = false
  network_rules                 = local.network_rules

  private_endpoints_manage_dns_zone_group = false
  private_endpoints = {
    primary = {
      name               = "${module.naming.private_endpoint.name}-queue"
      subnet_resource_id = data.azurerm_subnet.default.id
      subresource_name   = "queue"
    }
  }

  queues           = var.queues
  queue_properties = var.queue_properties

}
