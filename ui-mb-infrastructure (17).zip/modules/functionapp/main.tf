resource "azurerm_resource_group" "main" {
  name     = module.naming.resource_group.name
  location = var.location
  tags     = local.tags
}

resource "azurerm_application_insights" "main" {
  count = local.create_app_insights ? 1 : 0

  name                = module.naming.application_insights.name_unique
  resource_group_name = azurerm_resource_group.main.name
  location            = azurerm_resource_group.main.location
  workspace_id        = var.logging.log_analytics_workspace_resource_id
  tags                = local.tags

  application_type   = "web"
  retention_in_days  = 30
  ip_masking_enabled = true
}

resource "azurerm_service_plan" "main" {
  name                = module.naming.app_service_plan.name_unique
  resource_group_name = azurerm_resource_group.main.name
  location            = var.location
  tags                = local.tags

  os_type      = "Linux"
  sku_name     = var.sku_name
  worker_count = var.instance_count

  per_site_scaling_enabled = false
  zone_balancing_enabled   = false

}

resource "azurerm_storage_account" "main" {
  name                = local.storage_name
  resource_group_name = azurerm_resource_group.main.name
  location            = azurerm_resource_group.main.location
  tags = merge(
    local.tags,
    { purpose = "function app storage" }
  )

  public_network_access_enabled   = false
  account_tier                    = "Standard"
  account_kind                    = "StorageV2"
  account_replication_type        = "LRS"
  allow_nested_items_to_be_public = false
  https_traffic_only_enabled      = true
  min_tls_version                 = "TLS1_2"
  shared_access_key_enabled       = true
  network_rules {
    default_action = local.network_deny_all.default_action
    bypass         = local.network_deny_all.bypass
    dynamic "private_link_access" {
      for_each = var.integrate_defender_for_storage != null ? ["dummy"] : []
      content {
        endpoint_resource_id = var.integrate_defender_for_storage.endpoint_resource_id
        endpoint_tenant_id   = var.integrate_defender_for_storage.endpoint_tenant_id
      }
    }
  }

  large_file_share_enabled = false
  dynamic "share_properties" {
    for_each = length(var.fileshare) > 0 ? ["dummy"] : []
    content {
      smb {
        # the only working combination for function apps (tested may '25)
        channel_encryption_type = ["AES-128-GCM", "AES-256-GCM"]
        versions                = ["SMB3.1.1"]
      }
    }
  }
}

resource "azapi_resource" "share" {
  for_each = var.fileshare

  type      = "Microsoft.Storage/storageAccounts/fileServices/shares@2024-01-01"
  name      = each.value.name
  parent_id = "${azurerm_storage_account.main.id}/fileServices/default"
  body = {
    properties = {
      accessTier        = "TransactionOptimized"
      enabledProtocols  = "SMB"
      shareQuota        = 10
      signedIdentifiers = []
    }
  }
}

resource "azurerm_linux_function_app" "main" {

  depends_on = [time_sleep.storage_private_endpoints, azapi_resource.share]

  name                = module.naming.function_app.name_unique
  resource_group_name = azurerm_resource_group.main.name
  location            = azurerm_resource_group.main.location

  service_plan_id = azurerm_service_plan.main.id

  storage_account_name       = azurerm_storage_account.main.name
  storage_account_access_key = azurerm_storage_account.main.primary_access_key

  public_network_access_enabled = false
  virtual_network_subnet_id     = data.azurerm_subnet.delegated.id
  https_only                    = true
  functions_extension_version   = "~4"

  identity {
    type         = local.user_type
    identity_ids = var.user_assigned_resource_ids
  }

  site_config {
    always_on                              = true # This theoretically depends on the app service plan. Since we only allow dedicated ones, this fits.
    application_insights_connection_string = (local.create_app_insights) ? azurerm_application_insights.main[0].connection_string : var.logging.application_insights_connection_string

    application_stack {
      java_version   = var.runtime.stack == "java" ? var.runtime.version : null
      node_version   = var.runtime.stack == "node" ? var.runtime.version : null
      python_version = var.runtime.stack == "python" ? var.runtime.version : null
    }

    dynamic "cors" {
      for_each = length(var.cors.allowed_origins) > 0 ? [var.cors.allowed_origins] : []
      iterator = each
      content {
        allowed_origins     = each.value
        support_credentials = false
      }
    }

    health_check_path                 = local.health_check_path
    health_check_eviction_time_in_min = local.health_check_eviction_time_in_min

    # Stadard requirements. These values shall not be changed
    minimum_tls_version         = "1.2"
    remote_debugging_enabled    = false
    scm_minimum_tls_version     = "1.2"
    scm_use_main_ip_restriction = true
    vnet_route_all_enabled      = false

  }

  builtin_logging_enabled = false

  client_certificate_enabled                     = false # Incompatible with http/2.0
  ftp_publish_basic_authentication_enabled       = false
  webdeploy_publish_basic_authentication_enabled = false

  dynamic "storage_account" {
    for_each = var.fileshare
    iterator = share
    content {
      access_key   = azurerm_storage_account.main.primary_access_key
      account_name = azurerm_storage_account.main.name
      mount_path   = share.value.mount_path
      name         = share.value.mount_name
      type         = "AzureFiles"
      share_name   = share.value.name
    }
  }

  dynamic "auth_settings_v2" {
    for_each = var.auth_settings != null ? [1] : []
    content {
      auth_enabled           = true
      require_authentication = true
      unauthenticated_action = "Return401"
      runtime_version        = "~1"
      require_https          = true
      excluded_paths         = var.auth_settings.excluded_paths

      login {
        token_store_enabled = true
      }

      active_directory_v2 {
        client_id                  = var.auth_settings.client_id
        tenant_auth_endpoint       = var.auth_settings.tenant_auth_endpoint
        client_secret_setting_name = var.auth_settings.client_secret_setting_name
        allowed_audiences          = var.auth_settings.allowed_audiences
        allowed_applications       = var.auth_settings.allowed_applications
      }
    }
  }

  # App Settings with Key Vault reference for client secret (only when auth is enabled and client_secret_setting_name is set)
  app_settings = var.auth_settings != null && var.auth_settings.client_secret_setting_name != null ? {
    "${var.auth_settings.client_secret_setting_name}" = var.auth_settings.client_secret_keyvault_reference
  } : {}

  tags = local.func_tags

  lifecycle {
    ignore_changes = [
      # Ignore app_settings changes except for the auth secret which is managed by Terraform
      # This allows the application to add its own app settings without Terraform removing them
      app_settings,
      sticky_settings,

      # The following are set automatically. Ignore them so terraform doesn't
      # try to remove them.
      tags["hidden-link: /app-insights-resource-id"],
      tags["hidden-link: /app-insights-conn-string"],
      tags["hidden-link: /app-insights-instrumentation-key"]
    ]

  }
}
# WORKAROUND - to be done directly in the azurerm_linux_function_app resource once supported
module "min_tls_cipher_suite_patch" {
  source          = "../internal/functionapp-min-tls-cipher-patch"
  function_app_id = azurerm_linux_function_app.main.id
}

## ALERTING
# Monitoring Alert for the Health Check of each Function App
resource "azurerm_monitor_metric_alert" "health_check" {
  count = local.health_check_alert_enabled ? 1 : 0

  name                = "TAB - Function Health Check (${azurerm_linux_function_app.main.name}) S_MARKTBEARBEITUNG_${upper(var.workload_environment)}"
  resource_group_name = (var.health_check.monitoring_alert.resource_group_name != null) ? var.health_check.monitoring_alert.resource_group_name : azurerm_resource_group.main.name
  scopes              = [azurerm_linux_function_app.main.id]

  auto_mitigate = true
  description   = "Der Health-Endpunkt der Function ${azurerm_linux_function_app.main.name} konnte in den letzten 5 Minuten nicht erreicht werden."
  severity      = 2
  enabled       = true
  frequency     = "PT5M" # Abfrageintervall
  tags          = local.tags
  window_size   = "PT5M" # Betrachtungszeitraum

  criteria {
    metric_namespace = "Microsoft.Web/sites"
    metric_name      = "HealthCheckStatus"
    aggregation      = "Average"
    operator         = "LessThan"
    threshold        = 100
  }
  dynamic "action" {
    for_each = var.health_check.monitoring_alert.actions
    content {
      action_group_id = action.value.action_group_id
    }
  }
}

# Further Alerts in the scope of the App Service Plan
resource "azurerm_monitor_metric_alert" "main" {
  for_each = (local.create_metric_alerts) ? var.alerts.metric_alerts : {}

  name                = replace(each.value.name, "%scope_name%", azurerm_service_plan.main.name)
  resource_group_name = (var.alerts.resource_group_name != null) ? var.alerts.resource_group_name : azurerm_resource_group.main.name
  scopes              = [azurerm_service_plan.main.id]

  auto_mitigate = true
  description   = replace(each.value.description, "%scope_name%", azurerm_service_plan.main.name)
  enabled       = each.value.enabled
  frequency     = each.value.frequency
  severity      = each.value.severity
  tags          = local.tags
  window_size   = each.value.window_size

  dynamic "criteria" {
    for_each = each.value.criteria
    iterator = crit
    content {
      metric_namespace = crit.value.metric_namespace
      metric_name      = crit.value.metric_name
      aggregation      = crit.value.aggregation
      operator         = crit.value.operator
      threshold        = crit.value.threshold
      dynamic "dimension" {
        for_each = crit.value.dimension
        iterator = dim
        content {
          name     = dim.value.name
          operator = dim.value.operator
          values   = dim.value.values
        }
      }
    }
  }
  dynamic "action" {
    for_each = each.value.actions
    content {
      action_group_id = action.value.action_group_id
    }
  }
}
