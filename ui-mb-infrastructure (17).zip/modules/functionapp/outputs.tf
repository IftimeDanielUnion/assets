output "hostname" {
  value       = azurerm_linux_function_app.main.default_hostname
  description = "The function app's hostname."
}

output "identity" {
  value       = azurerm_linux_function_app.main.identity
  description = "The function app's system-assigned identity."
}

output "name" {
  value       = azurerm_linux_function_app.main.name
  description = "The resource name of the Function App."
}

output "resource_group" {
  value       = azurerm_linux_function_app.main.resource_group_name
  description = "The resource group name of the Function App."
}

output "resource_id" {
  value       = azurerm_linux_function_app.main.id
  description = "The resource id of the Function App"
}

output "storage" {
  value = {
    id   = azurerm_storage_account.main.id
    name = azurerm_storage_account.main.name
  }
  description = "The function app's storage account."
}

output "system_assigned_principal_id" {
  description = "The principal id of the Function App's system assigned identity"
  value       = azurerm_linux_function_app.main.identity[0].principal_id
}
