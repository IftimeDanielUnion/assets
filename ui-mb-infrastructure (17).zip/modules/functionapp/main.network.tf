resource "azurerm_private_endpoint" "pep_for_func" {
  name                = "${module.naming.private_endpoint.name}-func"
  resource_group_name = azurerm_resource_group.main.name
  location            = azurerm_resource_group.main.location
  subnet_id           = data.azurerm_subnet.private_endpoints.id

  private_service_connection {
    is_manual_connection           = false
    name                           = "${module.naming.private_service_connection.name}-func"
    private_connection_resource_id = azurerm_linux_function_app.main.id
    subresource_names              = ["sites"]
  }
}

resource "azurerm_private_endpoint" "pep_for_storage" {
  for_each            = var.storage_account.private_endpoints
  name                = "pe-${local.storage_name}-${each.value}"
  resource_group_name = azurerm_resource_group.main.name
  location            = azurerm_resource_group.main.location
  subnet_id           = data.azurerm_subnet.private_endpoints.id

  private_service_connection {
    is_manual_connection           = false
    name                           = "psc-${local.storage_name}-${each.value}"
    private_connection_resource_id = azurerm_storage_account.main.id
    subresource_names              = [each.value]
  }
  tags = local.tags
}

## Wait for DNS to pick up the new private endpoints.
# All timers start at the same time after creation of all peps. They do not accumulate
resource "time_sleep" "storage_private_endpoints" {
  depends_on = [azurerm_private_endpoint.pep_for_storage]

  for_each        = var.storage_account.private_endpoints
  create_duration = "900s"
  triggers = {
    pep_for_storage = azurerm_private_endpoint.pep_for_storage[each.value].id
  }
}
