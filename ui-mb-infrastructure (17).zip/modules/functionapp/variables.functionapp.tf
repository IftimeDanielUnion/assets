variable "cors" {
  type = object({
    allowed_origins = optional(list(string), [])
  })
  nullable    = false
  default     = {}
  description = "Specifies origins that should be allowed to make cross-origin calls."

  validation {
    condition     = alltrue([for k, v in var.cors.allowed_origins : trimspace(v) != "*"])
    error_message = "Wildcard is not allowed."
  }

  validation {
    condition     = alltrue([for k, v in var.cors.allowed_origins : startswith(v, "https://")])
    error_message = "Origins must start with https."
  }
}

variable "discovery_key" {
  type        = string
  description = <<DESCRIPTION
    (required) This value is used to describe the tag `discovery_key`. If a tag of the same name already exists in the variable `tags`, the value from `tags` is overwritten with this value.
    Use this tag during deployment to build environment agnostic pipelines
    DESCRIPTION
  nullable    = false
}

variable "fileshare" {
  type = map(object({
    mount_path = string
    mount_name = string
    name       = string
  }))
  description = <<DESCRIPTION
    (optional) Specifies file shares to be mounted onto the function app.
    The file shares will be created within the internal storage account. Each fileshare is accessible via SMB and has a limit of 10GB
    ---
    - `mount_path` - (required) absolute path within the linux file system to which the share will be mounted
    - `mount_name` - (required) Name of the mount point as seen in the Function App
    - `name` - (required) Name of the share in the storage account
  DESCRIPTION

  # "Create for each map entry a share on the internal storage account and mount it into the function app"
  nullable = false
  default  = {}
}

variable "health_check" {
  type = object({
    eviction_time_in_min = number
    path                 = string
    monitoring_alert = optional(object({
      actions = list(object({
        action_group_id = string
      }))
      resource_group_name = optional(string, null)
    }))
  })
  description = <<DESCRIPTION
    (optional) Specifies the health check.
    - `eviction_time_in_min` Minutes until an unhealthy instance will be replaced
    - `path` The URL Path at which an http-triger responds with health information

    ---
    Optional block `monitoring_alert` defines whether or not an alert is created for the health check. The block supports these attributes:
    - `action_group_id` (required) Resource Id of the action group
    - `resource_group_name` (optional) Name of the resource group in which the alert is created. Defaults to the resource group of the function app
  DESCRIPTION
  default     = null
}

variable "instance_count" {
  type        = number
  description = "Specifies how many instances will be run in parallel"
}

variable "integrate_defender_for_storage" {
  type = object({
    endpoint_resource_id = string
    endpoint_tenant_id   = string
  })
  description = <<DESCRIPTION
    (optional) Defines a private link which will be granted access to this Storage Account. Defaults to `null` and no private link will be added to the network rules.
  DESCRIPTION
  default     = null
}

variable "logging" {
  type = object({
    log_analytics_workspace_resource_id    = optional(string, null)
    application_insights_connection_string = optional(string, null)
  })
  description = <<DESCRIPTION
    Logging of the Function App requires an Application Insights. If one does not exist,
    a new one (dedicated to this Function App) is created on the given Log Analytics Workspace.

    - `application_insights_connection_string` - Connection String of an Application Insights instance.
    - `log_analytics_workspace_resource_id` - The resource ID of the log analytics workspace to send logs and metrics to.
  DESCRIPTION

  validation {
    condition = (
      var.logging.log_analytics_workspace_resource_id != null &&
      var.logging.application_insights_connection_string == null ||
      var.logging.log_analytics_workspace_resource_id == null &&
      var.logging.application_insights_connection_string != null
    )
    error_message = <<ERR
      Either `application_insights_connection_string` or `log_analytics_workspace_resource_id` has to be specified.
    ERR
  }
}

variable "runtime" {
  type = object({
    stack   = string
    version = string
  })
  description = <<DESCRIPTION
    (required) Specifies the Runtime Stack and Version.
    - `stack` Possible Runtime Stacks are `java`, `node` and `python`.
    - `version` See Microsoft's documentation about possible versions for each of the stacks. Defaults to the most recent version.
  DESCRIPTION
  nullable    = false
}

variable "sku_name" {
  type        = string
  description = "specifies the SKU for the Function App's hosting plan"
}

variable "storage_account" {
  type = object({
    private_endpoints = set(string)
  })

  description = <<DESCRIPTION
  (required) The `storage_account` block holds specifics about the storage account for the Function App(s).
  ---
  - `private_endpoints` (required) The list of sub-resources, like 'blob', 'file', 'table' or 'queue'. A private endpoint is created for each of these names.
  DESCRIPTION

  validation {
    condition     = alltrue([for k, v in var.storage_account.private_endpoints : contains(local.valid_pep_names, v)])
    error_message = "Valid sub-resource names are: ${join(", ", local.valid_pep_names)}"
  }
}

variable "user_assigned_resource_ids" {
  type        = list(string)
  description = "(optional) List of user assigned managed identities"
  default     = []
}

variable "auth_settings" {
  type = object({
    client_id                        = string
    tenant_auth_endpoint             = string
    client_secret_setting_name       = optional(string)
    client_secret_keyvault_reference = optional(string)
    allowed_audiences                = list(string)
    allowed_applications             = list(string)
    excluded_paths                   = optional(list(string), [])
  })
  description = <<DESCRIPTION
    (optional) Azure AD authentication settings for the Function App.
    - `client_id` - (required) The Client ID of the Azure AD application
    - `tenant_auth_endpoint` - (required) The Azure AD tenant authentication endpoint
    - `client_secret_setting_name` - (required) Name of the app setting containing the client secret
    - `client_secret_keyvault_reference` - (required) Key Vault reference for the client secret (format: @Microsoft.KeyVault(SecretUri=https://kv-xxx.vault.azure.net/secrets/secret-name/version))
    - `allowed_audiences` - (required) List of allowed audiences for token validation
    - `allowed_applications` - (required) List of allowed application IDs
    - `excluded_paths` - (optional) List of paths excluded from authentication (e.g. health check endpoints)
  DESCRIPTION
  default     = null
  nullable    = true
}

variable "vnet_subnet_name_functionapp" {
  type        = string
  description = "(required) Name of the delegated subnet used for Function app"
}

variable "vnet_subnet_name_privateendpoints" {
  type        = string
  description = "(optional) Name of the subnet used for private endpoints. If not set, uses vnet_subnet_name."
  default     = null
}
