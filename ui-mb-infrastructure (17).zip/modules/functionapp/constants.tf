locals {
  ### Generic module behaviour
  ###

  ## Tag the module details
  module_name = {
    terraform_module         = "functionapp",
    terraform_module_version = "1.0.1"
  }

  tags = merge(
    try(var.tags, {}),
    local.module_name
  )
  ## Network rules
  # Default behaviour >> Deny all and do not allow Azure Services!
  network_deny_all = {
    default_action = "Deny"
    bypass         = ["None"]
    private_link_access = {
      endpoint_resource_id = var.integrate_defender_for_storage.endpoint_resource_id
      endpoint_tenant_id   = var.integrate_defender_for_storage.endpoint_tenant_id
    }
  }

  ### Specific module behaviour
  ###

  # Possible values for names of the subresource of private endpoints for storage accounts
  valid_pep_names = ["blob", "file", "table", "queue"]

  storage_name         = "stfa${random_id.storage.hex}"
  create_app_insights  = (var.logging.application_insights_connection_string == null) ? true : false
  create_metric_alerts = (var.alerts != null && length(var.alerts.metric_alerts) >= 1) ? true : false

  health_check_alert_enabled        = (var.health_check != null) ? var.health_check.monitoring_alert != null : false
  health_check_eviction_time_in_min = (var.health_check != null) ? var.health_check.eviction_time_in_min : null
  health_check_path                 = (var.health_check != null) ? var.health_check.path : null

  user_type = length(var.user_assigned_resource_ids) > 0 ? "SystemAssigned, UserAssigned" : "SystemAssigned"

  # Add the discovery key to the tags, used for the function app
  func_tags = merge(
    local.tags,
    { "discovery_key" = var.discovery_key }
  )

}

module "naming" {
  source        = "Azure/naming/azurerm"
  version       = "0.4.2"
  suffix        = [lower(var.app_name), lower(var.workload_environment), lower(var.component_name)]
  unique-length = 8
}

resource "random_id" "storage" {
  byte_length = 10
}
