resource "azurerm_resource_group" "main" {
  name     = module.naming.resource_group.name
  location = var.location
  tags     = local.tags
}

module "blob-storage" {
  source  = "Azure/avm-res-storage-storageaccount/azurerm"
  version = "0.6.4"

  enable_telemetry = false

  name                = module.naming.storage_account.name_unique
  resource_group_name = azurerm_resource_group.main.name
  location            = azurerm_resource_group.main.location
  tags                = local.tags

  access_tier                     = var.access_tier
  account_kind                    = "StorageV2"
  account_tier                    = "Standard"
  account_replication_type        = var.account_replication_type

  # Pin allowed_copy_scope to "All" (= no copy restriction; the Azure default).
  # Azure reports "All" once the account exists. Left unset (null), the azurerm provider
  # tried to reset it on every apply and sent an empty string, which Azure rejects with
  # 400 "The value '' is not allowed for property AllowedCopyScope" -- this broke
  # `terraform apply` for the doc-share / doc-store / dms / uba storage accounts and
  # produced permanent drift in the drift-check (DBI-8960). "All" is a valid write value
  # (SDK enum: AAD / All / PrivateLink), so setting the value Azure already holds aligns
  # config and state: no diff, no failed apply, no behaviour change. See DBI-9745.
  allowed_copy_scope              = "All"

  https_traffic_only_enabled      = true
  min_tls_version                 = "TLS1_2"
  default_to_oauth_authentication = true

  public_network_access_enabled   = local.allow_public_access
  shared_access_key_enabled       = var.shared_access_key_enabled
  allow_nested_items_to_be_public = var.allow_anonymous_containers
  network_rules                   = local.network_rules

  role_assignments = var.role_assignments

  containers                     = var.containers
  blob_properties                = var.blob_properties
  storage_management_policy_rule = var.storage_management_policy_rule

  tables = var.tables

  private_endpoints_manage_dns_zone_group = false
  private_endpoints = merge(
    {
      primary = {
        name               = "${module.naming.private_endpoint.name}-blob"
        subnet_resource_id = data.azurerm_subnet.default.id
        subresource_name   = "blob"
      }
    },
    length(var.tables) > 0 ? {
      table = {
        name               = "${module.naming.private_endpoint.name}-table"
        subnet_resource_id = data.azurerm_subnet.default.id
        subresource_name   = "table"
      }
    } : {}
  )

}
