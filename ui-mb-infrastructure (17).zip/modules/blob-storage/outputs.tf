output "blob_host_name" {
  description = "The host name of the blob service on this storage account"
  value       = module.blob-storage.fqdn.blob
}

output "resource_id" {
  value       = module.blob-storage.resource_id
  description = "The resource id of the Storage Account"
}

output "backup_policy_id" {
  description = "The ID of the Backup Policy for Blob Storage (if Azure Backup is enabled)"
  value       = var.enable_azure_backup ? azurerm_data_protection_backup_policy_blob_storage.main[0].id : null
}

output "backup_instance_id" {
  description = "The ID of the Backup Instance for Blob Storage (if Azure Backup is enabled)"
  value       = var.enable_azure_backup ? azurerm_data_protection_backup_instance_blob_storage.main[0].id : null
}
