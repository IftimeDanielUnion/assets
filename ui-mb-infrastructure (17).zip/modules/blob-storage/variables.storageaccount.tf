variable "access_tier" {
  type        = string
  description = "(optional) Defines the access tier for this storage account. Valid options are `Hot` and `Cool`, defaults to `Hot`."
  default     = "Hot"
}

variable "account_replication_type" {
  type        = string
  description = "(optional) Defines the type of replication for this storage account. Valid options are `LRS`, `ZRS` among others, defaults to `LRS`."
  default     = "LRS"
}

variable "shared_access_key_enabled" {
  type        = bool
  description = "(optional) Defines whether this storage account allows access with a shared access signature (SAS), defaults to `false`."
  default     = false
}

variable "allow_anonymous_containers" {
  type        = bool
  description = "(optional) Defines whether containers in this storage account can allow anonymous access to their blobs, defaults to `false`."
  default     = false
}

variable "use_with_app_gateway" {
  type        = bool
  description = "(optional) If set, this Blob Storage will be accessible from the Appliation Gateway's Subnet on its public endpoint. Defaults to `false`."
  default     = false
  validation {
    condition     = (var.use_with_app_gateway && var.vnet_subnet_name_appgw != null) || (!var.use_with_app_gateway)
    error_message = "`vnet_subnet_name_appgw` must be set if `use_with_app_gateway` is set."
  }
}

variable "vnet_subnet_name_appgw" {
  type        = string
  description = <<DESCRIPTION
    (optional) Name of the subnet which holds the Application Gateway. This subnet is expected to be part of the same VNet as the default subnet.
    Defaults to `null`.
  DESCRIPTION
  default     = null
}

variable "integrate_defender_for_storage" {
  type = object({
    endpoint_resource_id = string
    endpoint_tenant_id   = string
  })
  description = <<DESCRIPTION
    (optional) Defines a private link which will be granted access to this Storage Account. Defaults to `null` and no private link will be added to the network rules.
  DESCRIPTION
  default     = null
}

variable "role_assignments" {
  type = map(object({
    role_definition_id_or_name             = string
    principal_id                           = string
    description                            = optional(string, null)
    skip_service_principal_aad_check       = optional(bool, false)
    condition                              = optional(string, null)
    condition_version                      = optional(string, null)
    delegated_managed_identity_resource_id = optional(string, null)
    principal_type                         = optional(string, null)
  }))
  description = <<DESCRIPTION
    (optional) A map of role assignments to create on the resource. The map key is deliberately arbitrary to avoid issues where map keys maybe unknown at plan time.
- `role_definition_id_or_name` - The ID or name of the role definition to assign to the principal.
- `principal_id` - The ID of the principal to assign the role to.
- `principal_type` - (optional) The type of the principal_id. Possible values are `User`, `Group` and `ServicePrincipal`.
  It is necessary to explicitly set this attribute when creating role assignments if the principal creating the assignment is constrained by ABAC rules that filters on the PrincipalType attribute.
- `description` - (optional) The description of the role assignment.
- `skip_service_principal_aad_check` - (optional) If set to true, skips the Azure Active Directory check for the service principal in the tenant. Defaults to false.
- `condition` - (optional) The condition which will be used to scope the role assignment.
- `condition_version` - (optional) The version of the condition syntax. Valid values are '2.0'. It is required if `condition` is set.
- `delegated_managed_identity_resource_id` (optional) cross-tenant-scenario only. The delegated Azure Resource Id which contains a Managed Identity.
> Note: only set `skip_service_principal_aad_check` to true if you are assigning a role to a newly created service principal, this will solve issues with the replication lag.
DESCRIPTION
  default     = {}
  nullable    = false
}
