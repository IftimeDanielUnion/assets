##
# Azure Backup for Blobs
# Provides operational backup capabilities for blob storage
##

# Role Assignment für Backup Vault Identity auf Storage Account
# Erforderlich damit Backup Vault auf den Storage Account zugreifen kann
resource "azurerm_role_assignment" "backup_vault" {
  count = var.enable_azure_backup && var.backup_vault_principal_id != null ? 1 : 0

  scope                = module.blob-storage.resource_id
  principal_id         = var.backup_vault_principal_id
  role_definition_name = "Storage Account Backup Contributor"
  description          = "Backup Vault Identity has Backup Contributor Role on Storage Account"
}

resource "azurerm_data_protection_backup_policy_blob_storage" "main" {
  count = var.enable_azure_backup ? 1 : 0

  name     = "bkpol-${lower(var.app_name)}-${lower(var.workload_environment)}-${lower(replace(var.component_name, "-", ""))}-blob"
  vault_id = var.backup_vault_id

  operational_default_retention_duration = var.backup_policy_blob_retention_duration

  lifecycle {
    precondition {
      condition     = var.backup_vault_id != null
      error_message = "backup_vault_id must be provided when enable_azure_backup is true"
    }
  }
}

resource "azurerm_data_protection_backup_instance_blob_storage" "main" {
  count = var.enable_azure_backup ? 1 : 0

  name               = "bkpi-${lower(var.app_name)}-${lower(var.workload_environment)}-${lower(replace(var.component_name, "-", ""))}-blob"
  vault_id           = var.backup_vault_id
  location           = azurerm_resource_group.main.location
  storage_account_id = module.blob-storage.resource_id
  backup_policy_id   = azurerm_data_protection_backup_policy_blob_storage.main[0].id

  depends_on = [
    module.blob-storage,
    azurerm_role_assignment.backup_vault
  ]
}
