##
# Default Subnet for Private Endpoint Integration
data "azurerm_subnet" "default" {
  name                 = var.vnet_subnet_name
  virtual_network_name = var.vnet_name
  resource_group_name  = var.vnet_resource_group_name
}

##
# App Gateway Subnet
data "azurerm_subnet" "appgw" {
  count                = (var.vnet_subnet_name_appgw != null) ? 1 : 0
  name                 = var.vnet_subnet_name_appgw
  virtual_network_name = var.vnet_name
  resource_group_name  = var.vnet_resource_group_name
}
