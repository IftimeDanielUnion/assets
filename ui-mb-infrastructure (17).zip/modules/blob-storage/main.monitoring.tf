## ALERTING
# Alerts in the scope of the Blob Storage
resource "azurerm_monitor_metric_alert" "alerts" {
  for_each = try(var.alerts.metric_alerts, {})

  name                = replace(each.value.name, "%scope_name%", module.blob-storage.name)
  resource_group_name = try(var.alerts.resource_group_name, azurerm_resource_group.main.name)
  scopes              = ["${module.blob-storage.resource_id}/blobservices/default"]
  description         = replace(each.value.description, "%scope_name%", module.blob-storage.name)
  severity            = each.value.severity
  enabled             = each.value.enabled
  frequency           = each.value.frequency
  window_size         = each.value.window_size
  auto_mitigate       = true

  dynamic "criteria" {
    for_each = each.value.criteria
    content {
      metric_namespace = "Microsoft.Storage/storageAccounts/blobservices" # Only possible value, given the scope
      metric_name      = criteria.value.metric_name
      aggregation      = criteria.value.aggregation
      operator         = criteria.value.operator
      threshold        = criteria.value.threshold

      dynamic "dimension" {
        for_each = try(criteria.value.dimension, [])
        content {
          name     = dimension.value.name
          operator = dimension.value.operator
          values   = dimension.value.values
        }
      }
    }
  }

  dynamic "action" {
    for_each = each.value.actions
    content {
      action_group_id = action.value.action_group_id
    }
  }

  tags = local.tags
}
