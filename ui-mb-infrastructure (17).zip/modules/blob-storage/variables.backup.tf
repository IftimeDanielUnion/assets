variable "enable_azure_backup" {
  type        = bool
  description = "(optional) Enable Azure Backup for Blobs using Azure Backup Vault. Requires `backup_vault_id` and `backup_vault_principal_id` to be set. Defaults to `false`."
  default     = false
}

variable "backup_vault_id" {
  type        = string
  description = "(optional) The ID of the Azure Backup Vault to use for blob backup. Required when `enable_azure_backup` is `true`."
  default     = null
  validation {
    condition     = var.enable_azure_backup == false || (var.enable_azure_backup && var.backup_vault_id != null)
    error_message = "`backup_vault_id` must be set when `enable_azure_backup` is `true`."
  }
}

variable "backup_vault_principal_id" {
  type        = string
  description = "(optional) The Principal ID of the Backup Vault's managed identity. Required when `enable_azure_backup` is `true` for role assignment."
  default     = null
}

variable "backup_policy_blob_retention_duration" {
  type        = string
  description = "(optional) The retention duration for blob backups in ISO 8601 format (e.g., 'P30D' for 30 days). Defaults to 'P30D'."
  default     = "P30D"
}
