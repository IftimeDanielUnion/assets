locals {
  ### Generic module behaviour
  ###

  ## Tag the module details
  module_name = {
    terraform_module         = "blob-storage",
    terraform_module_version = "1.0.0"
  }

  tags = merge(
    try(var.tags, {}),
    local.module_name
  )

  ## Definition network rules
  # Default behaviour >> Do not allow Azure Services!
  network_deny_all = { bypass = ["None"] }

  # Add private link access for the datascanner ressource of Defender for Storage
  network_defender = (var.integrate_defender_for_storage != null) ? {
    private_link_access = [{
      endpoint_resource_id = var.integrate_defender_for_storage.endpoint_resource_id
      endpoint_tenant_id   = var.integrate_defender_for_storage.endpoint_tenant_id
    }]
  } : {}

  # Allow access from the app gateway subnet
  network_app_gw = (var.use_with_app_gateway) ? {
    virtual_network_subnet_ids = [
      data.azurerm_subnet.appgw[0].id
    ]
  } : {}

  # Bring it all together
  network_rules = merge(
    local.network_deny_all,
    local.network_defender,
    local.network_app_gw
  )

  ### Specific module behaviour
  ###
  allow_public_access = var.use_with_app_gateway
}

module "naming" {
  source        = "Azure/naming/azurerm"
  version       = "0.4.2"
  suffix        = [lower(var.app_name), lower(var.workload_environment), lower(replace(var.component_name, "-", ""))]
  unique-length = 8
}
