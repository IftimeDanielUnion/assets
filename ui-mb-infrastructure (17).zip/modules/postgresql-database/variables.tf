variable "server_name" {
  description = "Name of the existing PostgreSQL Flexible Server"
  type        = string
}

variable "server_resource_group_name" {
  description = "Resource group name of the existing PostgreSQL Flexible Server"
  type        = string
}

variable "database_name" {
  description = "Name of the database to create"
  type        = string
}

variable "charset" {
  description = "Character set for the database"
  type        = string
  default     = "UTF8"
}

variable "collation" {
  description = "Collation for the database"
  type        = string
  default     = "en_US.utf8"
}
