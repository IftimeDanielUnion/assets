output "database_id" {
  description = "The ID of the PostgreSQL Database"
  value       = azurerm_postgresql_flexible_server_database.main.id
}

output "database_name" {
  description = "The name of the PostgreSQL Database"
  value       = azurerm_postgresql_flexible_server_database.main.name
}

output "server_fqdn" {
  description = "The FQDN of the PostgreSQL Server"
  value       = data.azurerm_postgresql_flexible_server.existing.fqdn
}
