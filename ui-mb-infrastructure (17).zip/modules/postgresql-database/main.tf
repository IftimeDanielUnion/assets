# PostgreSQL Database Module
# Creates a database on an existing PostgreSQL Flexible Server

data "azurerm_postgresql_flexible_server" "existing" {
  name                = var.server_name
  resource_group_name = var.server_resource_group_name
}

resource "azurerm_postgresql_flexible_server_database" "main" {
  name      = var.database_name
  server_id = data.azurerm_postgresql_flexible_server.existing.id
  charset   = var.charset
  collation = var.collation

  lifecycle {
    prevent_destroy = true
  }
}
