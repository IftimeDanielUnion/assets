resource "azurerm_resource_group" "main" {
  name     = module.naming.resource_group.name
  location = var.location
  tags     = local.tags
}

resource "azurerm_servicebus_namespace" "main" {
  name                = local.sb_name
  location            = azurerm_resource_group.main.location
  resource_group_name = azurerm_resource_group.main.name
  tags                = local.tags

  sku                          = "Premium"
  capacity                     = var.capacity
  premium_messaging_partitions = var.premium_messaging_partitions

  minimum_tls_version           = "1.2"
  public_network_access_enabled = false
}

resource "azurerm_role_assignment" "servicebus" {
  for_each = var.role_assignments

  principal_id         = each.value.principal_id
  role_definition_name = each.value.role_definition_name
  scope                = azurerm_servicebus_namespace.main.id
  condition            = each.value.condition
  condition_version    = each.value.condition_version
  description          = each.value.description

  skip_service_principal_aad_check = false
}
