variable "capacity" {
  type        = number
  description = "(optional) The amount of 'Messaging units' for this instance. Defaults to `1`."
  default     = 1
}

variable "premium_messaging_partitions" {
  type        = number
  description = "(optional) The amount of partitions for this instance. Defaults to `1`."
  default     = 1
}

variable "role_assignments" {
  type = map(object({
    principal_id         = string
    role_definition_name = string
    condition            = optional(string, null)
    condition_version    = optional(string, null)
    description          = optional(string, null)
    principal_type       = optional(string, null)
  }))
  description = <<DESCRIPTION
    (optional) A map of role assignments to create on the resource.
- `principal_id` - (required) The ID of the principal to assign the role to.
- `role_definition_name` - (required) The name of the role definition to assign to the principal.
- `principal_type` - (optional) The type of the principal_id. Possible values are `User`, `Group` and `ServicePrincipal`. It is necessary to
  explicitly set this attribute when creating role assignments if the principal creating the assignment is constrained by ABAC rules that filters on the PrincipalType attribute.
- `description` - (optional) The description of the role assignment.
- `condition` - (optional) The condition which will be used to scope the role assignment.
- `condition_version` - (optional) The version of the condition syntax. Valid values are '2.0'. It is required if `condition` is set.
DESCRIPTION
  default     = {}
  nullable    = false
}
