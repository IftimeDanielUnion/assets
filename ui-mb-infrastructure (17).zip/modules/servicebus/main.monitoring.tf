resource "azurerm_monitor_diagnostic_setting" "main" {
  for_each = var.diagnostic_settings

  name               = each.value.name != null ? each.value.name : "diag-${var.component_name}"
  target_resource_id = azurerm_servicebus_namespace.main.id

  log_analytics_destination_type = each.value.log_analytics_destination_type
  log_analytics_workspace_id     = each.value.workspace_resource_id


  dynamic "enabled_log" {
    for_each = each.value.log_categories

    content {
      category = enabled_log.value
    }
  }
  dynamic "enabled_log" {
    for_each = each.value.log_groups

    content {
      category_group = enabled_log.value
    }
  }
  dynamic "enabled_metric" {
    for_each = each.value.metric_categories

    content {
      category = enabled_metric.value
    }
  }
}

## ALERTING
# Alerts in the scope of the Service Bus Namespace
resource "azurerm_monitor_metric_alert" "main" {
  for_each = (local.create_metric_alerts) ? var.alerts.metric_alerts : {}

  name                = replace(each.value.name, "%scope_name%", azurerm_servicebus_namespace.main.name)
  resource_group_name = (var.alerts.resource_group_name != null) ? var.alerts.resource_group_name : azurerm_resource_group.main.name
  scopes              = [azurerm_servicebus_namespace.main.id]

  auto_mitigate = true
  description   = replace(each.value.description, "%scope_name%", azurerm_servicebus_namespace.main.name)
  enabled       = each.value.enabled
  frequency     = each.value.frequency
  severity      = each.value.severity
  tags          = var.tags
  window_size   = each.value.window_size

  dynamic "criteria" {
    for_each = each.value.criteria
    iterator = crit
    content {
      metric_namespace = crit.value.metric_namespace
      metric_name      = crit.value.metric_name
      aggregation      = crit.value.aggregation
      operator         = crit.value.operator
      threshold        = crit.value.threshold
      dynamic "dimension" {
        for_each = crit.value.dimension
        iterator = dim
        content {
          name     = dim.value.name
          operator = dim.value.operator
          values   = dim.value.values
        }
      }
    }
  }
  dynamic "action" {
    for_each = each.value.actions
    content {
      action_group_id = action.value.action_group_id
    }
  }
}
