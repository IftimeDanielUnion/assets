variable "diagnostic_settings" {
  type = map(object({
    name                           = optional(string, null)
    log_categories                 = optional(set(string), [])
    log_groups                     = optional(set(string), ["allLogs"])
    metric_categories              = optional(set(string), ["AllMetrics"])
    log_analytics_destination_type = optional(string, "Dedicated")
    workspace_resource_id          = string
  }))
  default     = {}
  description = <<DESCRIPTION
A map of diagnostic settings to create.

- `name` - (Optional) The name of the diagnostic setting. One will be generated if not set, however this will not be unique if you want to create multiple diagnostic setting resources.
- `log_categories` - (Optional) A set of log categories to send to the log analytics workspace. Defaults to `[]`.
- `log_groups` - (Optional) A set of log groups to send to the log analytics workspace. Defaults to `["allLogs"]`.
- `metric_categories` - (Optional) A set of metric categories to send to the log analytics workspace. Defaults to `["AllMetrics"]`.
- `log_analytics_destination_type` - (Optional) The destination type for the diagnostic setting. Possible values are `Dedicated` and `AzureDiagnostics`. Defaults to `Dedicated`.
- `workspace_resource_id` - (required) The resource ID of the log analytics workspace to send logs and metrics to.
DESCRIPTION
  nullable    = false

  validation {
    condition     = alltrue([for _, v in var.diagnostic_settings : contains(["Dedicated", "AzureDiagnostics"], v.log_analytics_destination_type)])
    error_message = "Log analytics destination type must be one of: 'Dedicated', 'AzureDiagnostics'."
  }
}

variable "alerts" {
  type = object({
    resource_group_name = optional(string)

    metric_alerts = optional(
      map(object({
        name        = string
        description = string
        enabled     = optional(bool, true)
        frequency   = string
        severity    = number
        window_size = string
        criteria = list(object({
          metric_namespace = string
          metric_name      = string
          aggregation      = string
          operator         = string
          threshold        = number
          dimension = optional(set(object({
            name     = string
            operator = string
            values   = list(string)
          })), [])
        }))
        actions = list(object({
          action_group_id = string
        }))
      }))
    , {})
  })
  default     = {}
  description = <<DESCRIPTION
    (optional) Definition of alerts, added for the scope of the Service Bus Namespace
    The two attributes `name` and `description` can have a placeholder `%scope_name%` which will be replaced with the name of the Service Bus Namespace.
    - `resource_group_name` - (optional) Name of the resource group in which the alerts are created. Defaults to the resource group of the Service Bus.

    ---
    Optional block `metric_alerts` defines a map of Metric Alerts to be added. The map-key is ambigious.
    The block supports these attributes:
    - `name` - (required) The name of the Metric Alert. Changing this forces a new resource to be created.
    - `description` - (optional) The description of this Metric Alert.
    - `enabled` - (optional) Should this Metric Alert be enabled? Defaults to `true`.
    - `frequency` - (required) The evaluation frequency of this Metric Alert, represented in ISO 8601 duration format.
    - `severity` - (required The severity of this Metric Alert
    - `window_size` - (required) The period of time that is used to monitor alert activity, represented in ISO 8601 duration format. This value must be greater than frequency.

    ---
    Required block `criteria` defines a list of metrics to consider in the alert. The block supports these attributes:
    - `metric_namespace` - (required) One of the metric namespaces to be monitored.
    - `metric_name` - (required) One of the metric names to be monitored.
    - `aggregation` - (required) The statistic that runs over the metric values.
    - `operator` - (required) The criteria operator.
    - `threshold` (required) The criteria threshold value that activates the alert.

    ---
    Optional block `dimension` defines the filters for the metric. The block supports these attributes:
    - `name` - (required) One of the dimension names.
    - `operator` - (required) The dimension operator.
    - `values` - (required) The list of dimension values.

    ---
    Block `action` supports this attribute
    - `action_group_id` - (required) The ID of the Action Group
  DESCRIPTION
}
