locals {
  ### Generic module behaviour
  ###

  ## Tag the module details
  module_name = {
    terraform_module         = "servicebus",
    terraform_module_version = "1.0.0"
  }

  tags = merge(
    try(var.tags, {}),
    local.module_name
  )

  ### Specific module behaviour
  ###
  create_metric_alerts = (var.alerts != null && length(var.alerts.metric_alerts) >= 1) ? true : false
  sb_name              = "sb-${random_id.servicebus.hex}"
}

module "naming" {
  source        = "Azure/naming/azurerm"
  version       = "0.4.2"
  suffix        = [lower(var.app_name), lower(var.workload_environment), lower(var.component_name)]
  unique-length = 8
}

resource "random_id" "servicebus" {
  byte_length = 10
}
