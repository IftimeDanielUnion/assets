resource "azurerm_private_endpoint" "pep_for_namespace" {
  name                = "${module.naming.private_endpoint.name}-namespace"
  resource_group_name = azurerm_resource_group.main.name
  location            = azurerm_resource_group.main.location
  subnet_id           = data.azurerm_subnet.default.id
  tags                = local.tags

  private_service_connection {
    is_manual_connection           = false
    name                           = "${module.naming.private_service_connection.name}-namespace"
    private_connection_resource_id = azurerm_servicebus_namespace.main.id
    subresource_names              = ["namespace"]
  }
}
