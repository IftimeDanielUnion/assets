output "resource_id" {
  value       = azurerm_servicebus_namespace.main.id
  description = "Resource Id of this Service Bus"
}
