# DBI-6455: Neustart nach Timos Vorschlag

**Stand: 06.10.2026. Nur dieses Ticket, keine anderen UMP-Aufgaben.**

Wir verwenden das vorhandene Modul `log-and-monitor`. Die Log-Alerts zeigen künftig auf den **Log Analytics Workspace (LAW)**. In `live` wird nur TEST konfiguriert. **Zuerst ein MR in `catalog`, danach ein MR in `live`.** Der alte separate Alert-Baustein entfällt.

| Repository | Neue Änderung | Neuer Branch |
|---|---|---|
| `catalog` | Zwei vorhandene Moduldateien: LAW-Scope, passende Validierung und optional zustandsbehaftete Alerts | `feat/DBI-6455-law-alert-scope` |
| `live` | Nur `live/test/terragrunt.stack.hcl`: Action Group, error/fatal-Regel und feste Catalog-Referenz | `feat/DBI-6455-test-law-alerts` |

**Nicht kopieren:** alte `.gitlab-ci.yml`, alte DEV-/PROD-Stacks, `modules/ump-exception-alerts` und `units/ump-exception-alerts`. Die existierende Pipeline reagiert bereits auf `live/test/**`.

Die zwei vollständigen Catalog-Dateien liegen im Paket. Vor dem Kopieren aktualisiert die Vorbereitung sie anhand deines aktuellen Checkouts. Die vollständige Live-Datei wird erst nach dem Catalog-Merge erzeugt, mit dessen echter Commit-ID. Dadurch bleiben zwischenzeitliche Änderungen von Timo erhalten. Das Werkzeug kopiert selbst nichts in deine Repos und deployed nichts.

## 1. Alten MR !52 schließen

**Wo:** GitLab, Repository `live`, dein alter DBI-6455-MR **!52**.

Er muss noch **Open**, nicht **Merged**, sein. Unten diesen Kommentar setzen und anschließend **Close merge request** wählen, nicht Revert und nicht Merge:

> Ich schließe diesen MR ungemerged und ersetze den bisherigen separaten Alert-Baustein durch die mit Timo abgestimmte Lösung: Log-Alerts im vorhandenen Modul `log-and-monitor` direkt auf den LAW ausrichten und die TEST-Konfiguration in `live` ergänzen. Dafür folgen getrennte MRs in `catalog` und `live`. Dieser MR wird nicht mehr ausgerollt.

**Warum kein Revert?** Ein ungemergter MR hat `main` noch nicht geändert. Wir schließen den Vorschlag und verwerfen anschließend nur den alten Arbeitsbranch. Falls GitLab schon **Merged** anzeigt oder der alte Ansatz bereits deployed wurde: hier stoppen, nicht diese Bereinigung ausführen.

## 2. Im originalen `live`-Repo zurück auf `main`

**Wo:** VS Code, WSL-Terminal, Wurzel deines echten `live`-Git-Repos. Das neue Paket liegt außerhalb des Repos.

Der folgende Block erkennt den alten DBI-6455-Branch. Er sichert seinen Commit als lokalen Tag und noch uncommittete Dateien bei Bedarf im Stash. Danach wechselt er auf aktuelles `main` und entfernt den alten lokalen und gegebenenfalls entfernten Branch. **`main` wird weder hart zurückgesetzt noch force-gepusht.**

```bash
(
  set -euo pipefail
  cd "$(git rev-parse --show-toplevel)"
  git remote get-url origin | grep -Eq '[:/]ump_legacy/infrastructure/live(\.git)?/?$' || {
    echo "STOPP: Das ist nicht das originale UMP-live-Repo."; exit 1;
  }
  ALT="$(git branch --show-current)"
  case "$ALT" in
    *DBI-6455*) ;;
    *) echo "STOPP: Erst den alten DBI-6455-Branch aus MR !52 auswählen. Aktuell: $ALT"; exit 1 ;;
  esac
  [[ "$ALT" != "feat/DBI-6455-test-law-alerts" ]] || {
    echo "STOPP: Das ist bereits der neue Branch."; exit 1;
  }
  read -r -p "Ist MR !52 ungemergt geschlossen und nichts daraus deployed? Tippe JA: " BESTAETIGUNG
  [[ "$BESTAETIGUNG" == "JA" ]] || exit 1
  git fetch --prune origin
  git cat-file -e origin/main:live/test/terragrunt.stack.hcl
  if git merge-base --is-ancestor "$ALT" origin/main; then
    echo "STOPP: Der Branch ist bereits in main enthalten. Nicht blind entfernen."; exit 1
  fi
  SICHERUNG="backup-DBI-6455-$(date -u +%Y%m%dT%H%M%SZ)"
  git tag "$SICHERUNG" HEAD
  if [[ -n "$(git status --porcelain --untracked-files=all)" ]]; then
    git stash push -u -m "$SICHERUNG-uncommitted"
  fi
  if git show-ref --verify --quiet refs/heads/main; then
    git switch main
  else
    git switch --track -c main origin/main
  fi
  git pull --ff-only origin main
  [[ "$(git rev-parse HEAD)" == "$(git rev-parse origin/main)" ]] || {
    echo "STOPP: Lokales main enthält eigene Commits. Nicht überschreiben."; exit 1;
  }
  if git show-ref --verify --quiet "refs/remotes/origin/$ALT"; then
    REMOTE_ALT="$(git rev-parse "refs/remotes/origin/$ALT")"
    git tag "${SICHERUNG}-remote" "$REMOTE_ALT"
    git push --force-with-lease="refs/heads/$ALT:$REMOTE_ALT" origin ":refs/heads/$ALT"
  fi
  git branch -D "$ALT"
  git status --short --branch
  echo "Alter Branch entfernt. Lokale Sicherung: $SICHERUNG"
)
```

**Erwartung:** Du stehst auf `main`, `git status` zeigt keine Änderungen. Der Lease im Löschbefehl verhindert das Löschen einer inzwischen von jemand anderem aktualisierten Remote-Branch-Version. Den Sicherungs-Stash **nicht** auf dem neuen Branch wieder einspielen. Ignorierte lokale Dateien werden nicht gelöscht.

Falls du den alten Branch bereits entfernt hast: keinen neuen alten Branch erstellen. Einfach auf sauberes `main` wechseln und mit Schritt 3 fortfahren.

## 3. Paket und Catalog auswählen, neuen Catalog-Branch anlegen

**Im selben WSL-Terminal weitermachen.** Bei den zwei Abfragen die WSL-Pfade ohne zusätzliche Anführungszeichen eingeben. Beispiel für einen Windows-Downloadordner: `/mnt/c/Users/DEINNAME/Downloads/DBI-6455`. Das Beispiel ist kein auszuführender Befehl.

```bash
export LIVE_REPO="$(git rev-parse --show-toplevel)"
read -r -e -p "WSL-Pfad zum entpackten DBI-6455-Paket: " PAKET
export PAKET
read -r -e -p "WSL-Pfad zum originalen catalog-Repo: " CATALOG_REPO
export CATALOG_REPO
(
  set -euo pipefail
  test -f "$PAKET/vorbereiten.py"
  cd "$CATALOG_REPO"
  [[ -z "$(git status --porcelain --untracked-files=all)" ]] || {
    echo "STOPP: Catalog hat eigene Änderungen. Zuerst separat sichern."; exit 1;
  }
  git fetch --prune origin
  git switch main
  git pull --ff-only origin main
  [[ "$(git rev-parse HEAD)" == "$(git rev-parse origin/main)" ]] || exit 1
  git switch -c feat/DBI-6455-law-alert-scope
  python3 "$PAKET/vorbereiten.py" catalog --repo "$PWD"
)
```

Das Werkzeug prüft Repo, Branch und Modulpfade und zeigt den Diff. **Bei STOPP nicht weiterkopieren.** Falls es „Catalog ist bereits passend“ meldet, ist der neue Catalog-MR unnötig. Dann zu Schritt 5 wechseln.

## 4. Catalog-Dateien per Drag & Drop übernehmen und MR erstellen

**Quelle im Paket:** Inhalt von `KOPIEREN/catalog/`.
**Ziel:** Wurzel deines originalen `catalog`-Repos, dort wo bereits `modules/`, `units/` und `.git/` liegen.

Nur den enthaltenen Ordner **`modules`** ins Repo ziehen und die zwei Dateien ersetzen. Nicht noch einen `catalog`-Ordner im Repo erzeugen.

Danach im WSL-Terminal:

```bash
(
  set -euo pipefail
  cd "$CATALOG_REPO"
  python3 "$PAKET/vorbereiten.py" pruefen catalog --repo "$PWD"
  git diff --check
  git diff --stat
  git add .
  git commit -m "DBI-6455: scope existing log alerts to LAW"
  git push -u origin feat/DBI-6455-law-alert-scope
)
```

**Erwarteter Diff: genau zwei MODIFIZIERTE Dateien:**

```text
modules/log-and-monitor/main.alerts.tf
modules/log-and-monitor/variables.logs.tf
```

MR **nach `main` im Catalog**, Reviewer Timo. Titel: **DBI-6455: Log-Alerts im bestehenden Modul auf LAW ausrichten**

Beschreibung zum Kopieren:

> Stellt Scheduled Query Alerts im vorhandenen `log-and-monitor`-Modul auf den Log Analytics Workspace um. Entfernt die Application-Insights-Pflicht nur für diese Log-Alerts und korrigiert die Scope-Beschreibung. Die bisherigen Availability-Webtests bleiben unverändert. `auto_mitigation_enabled` kann pro Alert gesetzt werden; TEST wird damit zustandsbehaftet alarmieren. Bestehende Action-Group- und Unit-Struktur werden weiterverwendet. Keine Umgebungsaktivierung in diesem MR. Die TEST-Konfiguration folgt separat in `live`. Native Terraform-/Azure-Prüfung und End-to-End-Abnahme stehen noch aus.

**Hier auf Catalog-Review und Merge warten. Kein Catalog-Apply starten.** Im hochgeladenen Catalog ist keine eigene `.gitlab-ci.yml` enthalten. Die echte Integration wird anschließend durch die TEST-Pipeline in `live` geplant.

## 5. Nach Catalog-Merge: aktuelle TEST-Kopierdatei erzeugen

**Warum erst jetzt?** Die TEST-Unit muss den Commit verwenden, in dem die LAW-Änderung wirklich auf `catalog/main` liegt. Ein Merge allein ändert die bisher gepinnte Catalog-Version in `live` noch nicht.

```bash
(
  set -euo pipefail
  cd "$CATALOG_REPO"
  [[ -z "$(git status --porcelain --untracked-files=all)" ]] || exit 1
  git fetch --prune origin
  git switch main
  git pull --ff-only origin main
  cd "$LIVE_REPO"
  [[ -z "$(git status --porcelain --untracked-files=all)" ]] || exit 1
  git fetch --prune origin
  git switch main
  git pull --ff-only origin main
  [[ "$(git rev-parse HEAD)" == "$(git rev-parse origin/main)" ]] || exit 1
  git switch -c feat/DBI-6455-test-law-alerts
  python3 "$PAKET/vorbereiten.py" live --repo "$PWD" --catalog "$CATALOG_REPO"
)
```

Jetzt existiert im Paket die **vollständige, zu deinem neuen main passende** Datei:

```text
KOPIEREN/live/live/test/terragrunt.stack.hcl
```

Nur die bestehende TEST-Unit `monitoring` bekommt die Einstellungen und eine feste Catalog-Commit-ID. Die globale Catalog-Version für die übrigen Units, DEV, PROD und die CI bleiben unverändert. Kein erfundener Tag und kein dauerhaftes `ref=main`.

## 6. Live-Datei kopieren, committen, neuen Live-MR erstellen

**Am einfachsten diese EINE Datei kopieren:**

| Quelle | Ziel |
|---|---|
| Paket: `KOPIEREN/live/live/test/terragrunt.stack.hcl` | Originales live-Repo: `live/test/terragrunt.stack.hcl` |

Dabei ersetzt du eine vorhandene Datei. **Im MR darf nicht `live/live/test/...` als neue Datei auftauchen.** Der äußere Paketordner `KOPIEREN/live` bezeichnet das Repository und gehört nicht zusätzlich ins Repository.

```bash
(
  set -euo pipefail
  cd "$LIVE_REPO"
  python3 "$PAKET/vorbereiten.py" pruefen live --repo "$PWD"
  git diff --check
  git diff --stat
  git add .
  git commit -m "DBI-6455: configure TEST OTEL alerts via catalog monitoring"
  git push -u origin feat/DBI-6455-test-law-alerts
)
```

**Erwarteter Diff: genau eine MODIFIZIERTE Datei**, nicht tausende neu angelegte Zeilen:

```text
live/test/terragrunt.stack.hcl
```

MR **nach `main` im Live-Repo**, Reviewer Timo. Titel: **DBI-6455: TEST error/fatal-Alarmierung über vorhandenes Monitoring**

Beschreibung zum Kopieren:

> Konfiguriert die bestehende TEST-Monitoring-Unit für `OTelLogs` mit `SeverityText` error/fatal. Der Alert prüft jede Minute ein Fünf-Minuten-Fenster, trennt nach `ServiceName` und benachrichtigt `ui-team@os-cillation.de` über die vorhandene Action-Group-Funktion des Moduls. Nur diese Unit verwendet den gemergten LAW-fähigen Catalog-Commit. Keine neuen lokalen Module/Units in `live`, keine CI-Änderung, kein DEV-/PROD-Rollout. Nach Planprüfung und Merge folgt der manuelle TEST-Apply und ein End-to-End-Test mit OSC.

## 7. Plan, manueller TEST-Apply, Abnahme

**Warum:** Kopieren, Commit und Merge erstellen noch keine Alarmmail.

In der Branch-Pipeline `checkTestEnvironment`, im MR `planTestEnvironment` prüfen. Erwartet werden im bestehenden Monitoring-State eine Action Group und ein Scheduled Query Alert. Bei bereits verwalteten passenden Ressourcen kann der Plan anders aussehen; bestehende Empfänger nicht überschreiben und dieselbe Gruppe nicht doppelt anlegen. **Bei VM-/Storage-/Gateway-Änderungen, Destroy/Replace oder State-Konflikten stoppen.**

Nach Review/Merge den **neuen Plan der main-Pipeline** prüfen und nur **`applyTestEnvironment` manuell** starten. Gespeicherten Plan nutzen; `usePlan=false` nicht als Abkürzung setzen. Bei abgelaufenem Plan neuen Plan erzeugen.

Erwartete Namen gemäß vorhandenem Modul:

```text
Action Group: log-ump-test-mag-osc-exceptions
Alert Rule:   ump-test-otel-error-fatal
Scope:        bestehender Workspace log-ump-test
```

Mit Alex einen kontrollierten echten error/fatal aus einer TEST-Anwendung erzeugen. Logeingang, Alarm und Mail-Empfang prüfen. Eine Test-Mail aus der Action Group allein belegt nicht die gesamte Strecke. `ServiceName` wird als Dimension mitgeliefert; ein dynamischer E-Mail-Betreff ist hier nicht implementiert.

Nachricht an Alex, erst wenn TEST bereitgestellt ist:

> Hi Alex, die error/fatal-Alarmierung ist jetzt in TEST bereitgestellt. Können wir einen kontrollierten Testfehler aus einer Anwendung erzeugen und danach kurz prüfen, ob der Alarm samt ServiceName und die E-Mail bei eurem Verteiler ankommen? Danke dir!

**Bis dahin bleibt DBI-6455 offen.** Dieses Paket erledigt den TEST-Schritt, nicht automatisch die gegebenenfalls noch notwendige PROD-Abnahme.

## Nachricht an Timo

> Hi Timo, danke dir, ich nehme deinen Vorschlag auf. Ich schließe den bisherigen MR ungemergt und passe die Log-Alerts direkt im vorhandenen `log-and-monitor`-Modul auf den LAW an, inklusive der bisherigen App-Insights-Pflicht in der Validierung. Anschließend ergänze ich nur die TEST-Konfiguration in `live`. Dafür bekommst du zwei getrennte MRs, zuerst Catalog und danach Live. Die bestehenden Action-Group-/Unit-Bausteine bleiben erhalten.

## Was ist schon geprüft?

Die neuen Dateien und die sichere Kopiervorbereitung wurden lokal gegen den Upload und temporäre Git-Repositories geprüft. **Kein Zugriff auf deinen aktuellen GitLab-main, kein Terraform-Plan, kein Azure-Deployment und kein Mail-Test wurden hier durchgeführt.** Details, Quellen und reproduzierbare Tests: [PRUEFUNG.md](PRUEFUNG.md).

Falls die Vorbereitung eine inzwischen geänderte Modulstruktur oder bereits vorhandene OSC-Gruppe meldet, stoppt sie bewusst. Dann bestehende Konfiguration wiederverwenden statt neue parallele Ressourcen anzulegen.
