#!/usr/bin/env python3
"""DBI-6455: create complete copy files from a clean, up-to-date checkout.

No Azure calls, deployments, commits, resets or changes to the original checkout.
Python 3.10+ standard library only. `git fetch origin` refreshes read-only refs.
"""
from __future__ import annotations

import argparse
import difflib
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
import textwrap

PACKAGE = Path(__file__).resolve().parent
CATALOG_BRANCH = "feat/DBI-6455-law-alert-scope"
LIVE_BRANCH = "feat/DBI-6455-test-law-alerts"
ALERT_FILE = "modules/log-and-monitor/main.alerts.tf"
VARS_FILE = "modules/log-and-monitor/variables.logs.tf"
UNIT_FILE = "units/log-and-monitor/terragrunt.hcl"
STACK_FILE = "live/test/terragrunt.stack.hcl"


class PreparationError(RuntimeError):
    pass


def git(repo: Path, *args: str) -> str:
    result = subprocess.run(
        ["git", "-C", str(repo), *args], capture_output=True, text=True,
        encoding="utf-8", errors="strict", check=False,
    )
    if result.returncode:
        # Git may report remote URLs; never print credential-bearing URLs.
        message = re.sub(r"(https?://)[^/\s@]+@", r"\1[redacted]@", result.stderr.strip())
        raise PreparationError(f"git {' '.join(args[:2])}: {message}")
    return result.stdout.rstrip("\n")


def digest(text: str) -> str:
    # Git's Windows line-ending conversion must not look like a content change.
    return hashlib.sha256(text.replace("\r\n", "\n").encode("utf-8")).hexdigest()


def mask_hcl(text: str) -> str:
    """Mask strings/comments/heredocs, preserving character positions and newlines.

    This is a structural scanner, not a replacement for Terraform validation.
    It lets us edit only named existing blocks, without reformatting the file.
    """
    out = list(text)
    i, n = 0, len(text)
    while i < n:
        end = None
        if text.startswith("//", i) or text[i] == "#":
            end = text.find("\n", i)
            end = n if end < 0 else end
        elif text.startswith("/*", i):
            end = text.find("*/", i + 2)
            if end < 0:
                raise PreparationError("Nicht abgeschlossener HCL-Kommentar.")
            end += 2
        elif text[i] == '"':
            end = i + 1
            while end < n:
                if text[end] == "\\":
                    end += 2
                elif text[end] == '"':
                    end += 1
                    break
                else:
                    end += 1
            else:
                raise PreparationError("Nicht abgeschlossene HCL-Zeichenkette.")
        elif text.startswith("<<", i):
            head = re.match(r"<<-?([A-Za-z_][A-Za-z0-9_]*)[^\S\n]*\n", text[i:])
            if head:
                stop = re.search(r"(?m)^[ \t]*" + re.escape(head[1]) + r"[ \t]*(?:\n|$)", text[i + head.end():])
                if not stop:
                    raise PreparationError("Nicht abgeschlossenes HCL-Heredoc.")
                end = i + head.end() + stop.end()
        if end is not None:
            for j in range(i, end):
                if out[j] != "\n":
                    out[j] = " "
            i = end
        else:
            i += 1
    return "".join(out)


def matching_brace(text: str, opening: int) -> int:
    masked = mask_hcl(text)
    if opening >= len(text) or masked[opening] != "{":
        raise PreparationError("Erwarteter HCL-Block fehlt.")
    depth = 0
    for pos in range(opening, len(text)):
        if masked[pos] == "{":
            depth += 1
        elif masked[pos] == "}":
            depth -= 1
            if depth == 0:
                return pos
    raise PreparationError("Nicht abgeschlossener HCL-Block.")


def block_span(text: str, header: str) -> tuple[int, int, int]:
    masked = mask_hcl(text)
    matches = [m for m in re.finditer(r"(?m)^[ \t]*" + header + r"[ \t]*\{", text)
               if masked[m.end() - 1] == "{"]
    if len(matches) != 1:
        raise PreparationError(f"Erwartet genau einen Block: {header}; gefunden: {len(matches)}.")
    m = matches[0]
    return m.start(), m.end() - 1, matching_brace(text, m.end() - 1)


def top_attribute(text: str, name: str) -> tuple[int, int] | None:
    """Find an attribute directly inside a block body, not in a child object."""
    masked = mask_hcl(text)
    found = []
    for m in re.finditer(r"(?m)^[ \t]*" + re.escape(name) + r"[ \t]*=", masked):
        prefix = masked[:m.start()]
        depth = prefix.count("{") - prefix.count("}") + prefix.count("[") - prefix.count("]")
        if depth == 0:
            found.append((m.start(), m.end()))
    if len(found) > 1:
        raise PreparationError(f"Attribut {name} mehrfach vorhanden.")
    return found[0] if found else None


def map_span(text: str, name: str) -> tuple[int, int, int] | None:
    attr = top_attribute(text, name)
    if attr is None:
        return None
    opening = attr[1]
    while opening < len(text) and text[opening].isspace():
        opening += 1
    if opening >= len(text) or text[opening] != "{":
        raise PreparationError(f"{name} wird dynamisch berechnet. Nicht automatisch überschreiben; Map gezielt zusammenführen.")
    return attr[0], opening, matching_brace(text, opening)


def assert_balanced(text: str) -> None:
    stack = []
    for char in mask_hcl(text):
        if char in "{[":
            stack.append(char)
        elif char in "}]":
            if not stack or stack.pop() != ("{" if char == "}" else "["):
                raise PreparationError("HCL-Klammerstruktur ist ungueltig.")
    if stack:
        raise PreparationError("HCL-Klammerstruktur ist unvollstaendig.")


def transform_catalog(alerts: str, variables: str) -> tuple[str, str]:
    start, opening, end = block_span(alerts, r'resource\s+"azurerm_monitor_scheduled_query_rules_alert_v2"\s+"main"')
    part = alerts[start:end + 1]
    part = part.replace("azurerm_application_insights.main[0].name", "azurerm_log_analytics_workspace.main.name")
    part = part.replace("azurerm_application_insights.main[0].id", "azurerm_log_analytics_workspace.main.id")
    if "azurerm_application_insights" in part:
        raise PreparationError("Unbekannte App-Insights-Referenz im Log-Alert; Abgleich erforderlich.")
    if not re.search(r"scopes\s*=\s*\[azurerm_log_analytics_workspace\.main\.id\]", part):
        raise PreparationError("Der Log-Alert-Scope ist anders aufgebaut als erwartet; kein blindes Überschreiben.")
    if "auto_mitigation_enabled" not in part:
        part, count = re.subn(
            r"(?m)^([ \t]*)enabled\s*=\s*each\.value\.enabled[^\S\n]*$",
            r"\1enabled              = each.value.enabled\n\1auto_mitigation_enabled = each.value.auto_mitigation_enabled",
            part,
        )
        if count != 1:
            raise PreparationError("enabled-Attribut im bestehenden Alert nicht eindeutig.")
    elif not re.search(r"auto_mitigation_enabled\s*=\s*each\.value\.auto_mitigation_enabled", part):
        raise PreparationError("auto_mitigation_enabled ist bereits anders konfiguriert.")
    if "skip_query_validation" not in part:
        part = part.replace("  dynamic \"criteria\"", "  # Validate the real workspace query during deployment.\n  skip_query_validation = false\n\n  dynamic \"criteria\"", 1)
    elif not re.search(r"skip_query_validation\s*=\s*false", part):
        raise PreparationError("Query-Validierung ist im aktuellen Modul anders konfiguriert.")
    # Align only resource-level assignments in this changed block.
    lines = part.splitlines()
    assignment = re.compile(r"^  ([a-z_]+)\s*=\s*(.*)$")
    i = 0
    while i < len(lines):
        if not assignment.match(lines[i]):
            i += 1
            continue
        j = i
        while j < len(lines) and assignment.match(lines[j]):
            j += 1
        width = max(len(assignment.match(line)[1]) for line in lines[i:j])
        for k in range(i, j):
            item = assignment.match(lines[k])
            lines[k] = f"  {item[1]:<{width}} = {item[2]}"
        i = j
    alerts = alerts[:start] + "\n".join(lines) + alerts[end + 1:]

    start, opening, end = block_span(variables, r'variable\s+"scheduled_log_alerts"')
    part = variables[start:end + 1]
    if not re.search(r"(?m)^\s*auto_mitigation_enabled\s*=", part):
        part, count = re.subn(
            r"(?m)^(\s*)enabled\s*=\s*optional\(bool,\s*true\)[^\S\n]*$",
            r"\1enabled                 = optional(bool, true)\n\1auto_mitigation_enabled = optional(bool, false)", part,
        )
        if count != 1:
            raise PreparationError("Typdefinition von scheduled_log_alerts weicht ab.")
    elif not re.search(r"auto_mitigation_enabled\s*=\s*optional\(bool,\s*(?:true|false)\)", part):
        raise PreparationError("Bestehender auto_mitigation_enabled-Typ wird nicht automatisch ersetzt.")
    part = part.replace("which will be created in the scope of the Application Insights.", "which will be created in the scope of the Log Analytics Workspace.")
    part = part.replace("If this variable is set, `integrate_application_insights` must be `true` and at least one item in `action_groups` is required.",
                        "If this variable is set, at least one item in `action_groups` is required. Application Insights is not required.")
    part = part.replace("replaced with the name of the App Service Plan.", "replaced with the name of the Log Analytics Workspace.")
    part = part.replace("length(var.scheduled_log_alerts) == 0 || (var.application_insights_enabled && length(var.action_groups) > 0)",
                        "length(var.scheduled_log_alerts) == 0 || length(var.action_groups) > 0")
    part = part.replace("Scheduled Log Alerts need Application Insights. You cannot create these alerts without it.",
                        "Scheduled Log Alerts need at least one Action Group. Application Insights is not required.")
    if "var.application_insights_enabled" in part:
        raise PreparationError("Unbekannte Application-Insights-Pflicht in der Alert-Validierung.")
    if "- `auto_mitigation_enabled`" not in part:
        marker = "  - `evaluation_frequency`"
        if marker not in part:
            raise PreparationError("Beschreibung der Alert-Parameter weicht ab.")
        part = part.replace(marker,
            "  - `auto_mitigation_enabled` - (optional) Automatically resolve alerts (stateful). Defaults to `false`; enable explicitly per alert.\n" + marker, 1)
    # Preserve all existing input schemas. Align the attributes of this object only.
    type_end = part.index("    criteria =") if "    criteria =" in part else None
    if type_end is not None:
        prefix = part[:type_end]
        lines = prefix.splitlines()
        assignment = re.compile(r"^    ([a-z_]+)\s*=\s*(.*)$")
        width = max((len(m[1]) for line in lines if (m := assignment.match(line))), default=0)
        lines = [f"    {m[1]:<{width}} = {m[2]}" if (m := assignment.match(line)) else line for line in lines]
        part = "\n".join(lines) + "\n" + part[type_end:]
    variables = variables[:start] + part + variables[end + 1:]
    assert_balanced(alerts)
    assert_balanced(variables)
    return alerts, variables


def add_map_entry(body: str, map_name: str, snippet: str, key: str) -> str:
    source = map_span(snippet, map_name)
    if source is None:
        raise PreparationError("Konfigurationsvorlage unvollstaendig.")
    definition = snippet[source[0]:source[2] + 1]
    current = map_span(body, map_name)
    if current is None:
        return body.rstrip() + "\n\n" + textwrap.indent(definition, "    ") + "\n  "
    _, opening, end = current
    content = body[opening + 1:end]
    if top_attribute(content, key) or re.search(r'(?m)^\s*"' + re.escape(key) + r'"\s*=', mask_hcl(content)):
        raise PreparationError(f"{map_name}.{key} ist schon vorhanden. Nicht doppelt anlegen; vorhandene Konfiguration prüfen.")
    # Keys with quotes are masked, check original as well. Conservative on nested duplicates.
    if re.search(r'(?m)^\s*"?' + re.escape(key) + r'"?\s*=', content):
        raise PreparationError(f"{key} ist bereits vorhanden.")
    addition = snippet[source[1] + 1:source[2]].strip("\n")
    merged = content.rstrip() + "\n" + textwrap.indent(addition, "    ") + "\n    "
    return body[:opening + 1] + merged + body[end:]


def transform_live(stack: str, catalog_commit: str, template: str) -> str:
    if not re.fullmatch(r"[0-9a-f]{40}", catalog_commit):
        raise PreparationError("Für den Catalog wird eine volle, unveränderliche Git-Commit-ID benötigt.")
    start, opening, end = block_span(stack, r'unit\s+"monitoring"')
    part = stack[start:end + 1]
    source_pattern = r'(?m)^(\s*source\s*=\s*")git::\$\{local\.tg_catalog_uri\}//units/log-and-monitor\?ref=[^"\n]+("\s*)$'
    part, count = re.subn(source_pattern,
                         lambda m: m[1] + 'git::${local.tg_catalog_uri}//units/log-and-monitor?ref=' + catalog_commit + m[2], part)
    if count != 1:
        raise PreparationError("Die monitoring-Unit nutzt nicht die erwartete Catalog-Quelle. Kein Überschreiben.")
    value_span = map_span(part[part.index("{") + 1:-1], "values")
    if value_span is None:
        raise PreparationError("values in monitoring fehlt.")
    offset = part.index("{") + 1
    vo, ve = offset + value_span[1], offset + value_span[2]
    body = part[vo + 1:ve]
    ag = map_span(body, "action_groups")
    if ag and "ui-team@os-cillation.de" in body[ag[1]:ag[2]]:
        raise PreparationError("OSC-Empfänger ist im bestehenden action_groups-Block bereits vorhanden. Dessen Schlüssel wiederverwenden, keine zweite Gruppe erzeugen.")
    body = add_map_entry(body, "action_groups", template, "osc-exceptions")
    body = add_map_entry(body, "scheduled_log_alerts", template, "otel-error-fatal")
    part = part[:vo + 1] + body + part[ve:]
    result = stack[:start] + part + stack[end + 1:]
    assert_balanced(result)
    return result


def resolve_path(value: str) -> Path:
    value = value.strip().strip('"').strip("'")
    if re.match(r"^[A-Za-z]:[\\/]", value) or value.startswith("\\\\"):
        result = subprocess.run(["wslpath", "-u", value], capture_output=True, text=True, check=True)
        value = result.stdout.strip()
    return Path(value).expanduser().resolve()


def verified_repo(value: str, name: str) -> Path:
    path = resolve_path(value)
    root = Path(git(path, "rev-parse", "--show-toplevel")).resolve()
    if path != root:
        raise PreparationError(f"Bitte die Repo-Wurzel verwenden, nicht einen Unterordner: {root}")
    remote = git(root, "remote", "get-url", "origin")
    if not re.search(r"(?:/|:)ump_legacy/infrastructure/" + re.escape(name) + r"(?:\.git)?/?$", remote, re.I):
        raise PreparationError(f"origin zeigt nicht auf das erwartete UMP-{name}-Repository.")
    git(root, "fetch", "--prune", "origin")
    if git(root, "status", "--porcelain", "--untracked-files=all"):
        raise PreparationError("Checkout hat Änderungen. Erst sichern/bereinigen, damit nichts überschrieben wird.")
    return root


def write_copy_files(name: str, repo: Path, baseline: str, originals: dict[str, str], changes: dict[str, str], catalog_commit: str | None = None) -> list[str]:
    out = PACKAGE / "KOPIEREN" / name
    paths = []
    manifest = {"repo": str(repo), "baseline": baseline, "catalog_commit": catalog_commit, "files": {}}
    # Refuse unexpected files in the copy area. Never recursively erase user files.
    permitted = set(changes)
    if out.exists():
        unexpected = [str(p.relative_to(out)) for p in out.rglob("*") if p.is_file() and str(p.relative_to(out)) not in permitted]
        if unexpected:
            raise PreparationError("Unerwartete Dateien im Kopierordner, bitte separat sichern: " + ", ".join(unexpected))
    for relative, updated in changes.items():
        if digest(originals[relative]) == digest(updated):
            # A no-op file needs no copying; remove only this tool's known output file.
            p = out / relative
            if p.exists():
                p.unlink()
            continue
        p = out / relative
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(updated, encoding="utf-8", newline="\n")
        manifest["files"][relative] = {"before": digest(originals[relative]), "after": digest(updated)}
        paths.append(relative)
        print(f"  {relative}")
        print("".join(difflib.unified_diff(originals[relative].splitlines(True), updated.splitlines(True),
                                           fromfile="a/" + relative, tofile="b/" + relative, n=2)))
    control = PACKAGE / "PRUEFDATEN"
    control.mkdir(exist_ok=True)
    (control / f"{name}.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"Kopierquelle: {out}")
    print(f"Zielwurzel:  {repo}")
    print(f"Dateien zum Kopieren: {len(paths)}. Kein Repository wurde verändert.")
    return paths


def prepare_catalog(repo_arg: str) -> None:
    repo = verified_repo(repo_arg, "catalog")
    branch = git(repo, "branch", "--show-current")
    if branch != CATALOG_BRANCH or git(repo, "rev-parse", "HEAD") != git(repo, "rev-parse", "origin/main"):
        raise PreparationError(f"Zuerst {CATALOG_BRANCH} frisch von origin/main anlegen (siehe README).")
    unit = (repo / UNIT_FILE).read_text(encoding="utf-8-sig")
    if not re.search(r'source\s*=\s*"\.\./\.\./modules//log-and-monitor"', unit):
        raise PreparationError("Die Unit verweist inzwischen auf ein anderes Modul/Repo. Aktuellen Quellcode abgleichen.")
    for key in ("action_groups", "scheduled_log_alerts"):
        if not re.search(r"(?m)^\s*" + key + r"\s*=\s*try\(values\." + key, unit):
            raise PreparationError(f"Die Unit reicht {key} nicht wie erwartet durch.")
    original = {p: (repo / p).read_text(encoding="utf-8-sig") for p in (ALERT_FILE, VARS_FILE)}
    alerts, variables = transform_catalog(original[ALERT_FILE], original[VARS_FILE])
    changed = write_copy_files("catalog", repo, git(repo, "rev-parse", "HEAD"), original,
                              {ALERT_FILE: alerts, VARS_FILE: variables})
    if not changed:
        print("Catalog ist bereits passend. Kein neuer Catalog-Commit nötig; weiter mit live.")


def prepare_live(repo_arg: str, catalog_arg: str) -> None:
    repo = verified_repo(repo_arg, "live")
    if git(repo, "branch", "--show-current") != LIVE_BRANCH or git(repo, "rev-parse", "HEAD") != git(repo, "rev-parse", "origin/main"):
        raise PreparationError(f"Zuerst {LIVE_BRANCH} frisch von origin/main anlegen (siehe README).")
    for old in ("modules/ump-exception-alerts/main.tf", "units/ump-exception-alerts/terragrunt.hcl", "live/live/test/terragrunt.stack.hcl"):
        if (repo / old).exists():
            raise PreparationError(f"Alter Ansatz oder falscher Pfad vorhanden: {old}. Nicht überkopieren.")
    catalog = verified_repo(catalog_arg, "catalog")
    if git(catalog, "branch", "--show-current") != "main" or git(catalog, "rev-parse", "HEAD") != git(catalog, "rev-parse", "origin/main"):
        raise PreparationError("Catalog muss nach dem Merge auf aktuellem main stehen. Erst Catalog-MR mergen.")
    a = (catalog / ALERT_FILE).read_text(encoding="utf-8-sig")
    v = (catalog / VARS_FILE).read_text(encoding="utf-8-sig")
    ta, tv = transform_catalog(a, v)
    if (digest(a), digest(v)) != (digest(ta), digest(tv)):
        raise PreparationError("Der aktualisierte LAW-Alert ist noch nicht vollständig in catalog/main enthalten.")
    commit = git(catalog, "rev-parse", "origin/main")
    stack = (repo / STACK_FILE).read_text(encoding="utf-8-sig")
    template = (PACKAGE / "VORLAGE/test-alerts.hcl").read_text(encoding="utf-8")
    updated = transform_live(stack, commit, template)
    write_copy_files("live", repo, git(repo, "rev-parse", "HEAD"), {STACK_FILE: stack}, {STACK_FILE: updated}, commit)
    print(f"Nur monitoring in TEST ist auf catalog/{commit} gepinnt; keine globalen Versionswechsel.")


def verify_copied(name: str, repo_arg: str) -> None:
    # Verification is local. Do not fetch or write the checkout here.
    repo = resolve_path(repo_arg)
    control = PACKAGE / "PRUEFDATEN" / f"{name}.json"
    if not control.is_file():
        raise PreparationError("Zuerst die Kopierdateien mit diesem Paket vorbereiten.")
    info = json.loads(control.read_text(encoding="utf-8"))
    if Path(git(repo, "rev-parse", "--show-toplevel")).resolve() != repo:
        raise PreparationError("Bitte in der originalen Repo-Wurzel starten.")
    branch = CATALOG_BRANCH if name == "catalog" else LIVE_BRANCH
    if git(repo, "branch", "--show-current") != branch:
        raise PreparationError(f"Falscher Branch, erwartet: {branch}.")
    if git(repo, "rev-parse", "HEAD") != info["baseline"]:
        raise PreparationError("Der Ausgangscommit hat sich verändert. Nicht ungeprüft weiterkopieren.")
    expected = set(info["files"])
    modified = set(filter(None, git(repo, "diff", "HEAD", "--name-only").splitlines()))
    untracked = set(filter(None, git(repo, "ls-files", "--others", "--exclude-standard").splitlines()))
    if modified | untracked != expected:
        raise PreparationError(f"Falsche Dateimenge. Erwartet: {sorted(expected)}; tatsächlich: {sorted(modified | untracked)}")
    for rel, hashes in info["files"].items():
        if digest((repo / rel).read_text(encoding="utf-8-sig")) != hashes["after"]:
            raise PreparationError(f"Kopie weicht ab: {rel}. Vollständige generierte Datei verwenden.")
    git(repo, "diff", "--check")
    print(f"OK: genau {len(expected)} vorgesehene Dateien an den richtigen Pfaden. Jetzt git add/commit/push.")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="mode", required=True)
    for name in ("catalog", "live"):
        p = sub.add_parser(name)
        p.add_argument("--repo", default=".", help="Originale Repository-Wurzel; Standard aktuelles Verzeichnis")
        if name == "live":
            p.add_argument("--catalog", required=True, help="Lokaler Catalog-Checkout nach dem Merge, auf main")
    p = sub.add_parser("pruefen")
    p.add_argument("repo_name", choices=("catalog", "live"))
    p.add_argument("--repo", default=".")
    args = parser.parse_args()
    try:
        if args.mode == "catalog":
            prepare_catalog(args.repo)
        elif args.mode == "live":
            prepare_live(args.repo, args.catalog)
        else:
            verify_copied(args.repo_name, args.repo)
        return 0
    except (PreparationError, OSError, subprocess.SubprocessError, UnicodeError, json.JSONDecodeError) as exc:
        print(f"STOPP: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
