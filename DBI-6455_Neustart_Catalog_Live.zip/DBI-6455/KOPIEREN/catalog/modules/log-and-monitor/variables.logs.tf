variable "application_insights_enabled" {
  type        = bool
  description = <<DESCRIPTION
    (optional) If true an Application Insights instance is created for the Log Analytics Workspace. Defaults to false.
    If the name for the Log Analytics Workspace is set (variable `name`), the same value is used for the Application Insights
    with an appended `-appi`.
  DESCRIPTION
  default     = false
  nullable    = false
}

variable "action_groups" {
  type = map(object({
    short_name = string
    tags       = optional(map(string), {})
    email_receiver = list(object({
      name                    = string
      email_address           = string
      use_common_alert_schema = optional(bool)
    }))
  }))
  default     = {}
  nullable    = false
  description = <<DESCRIPTION
  (optional) A map of action group definitions. The keys are used as part of each action group's name.
  - `short_name` - (required) Display name of this Action Group
  - `tags` - (optional) Additional tags for this Action Group. These tags are merged with the general list of tags from variable `tags`.
  ---
  Block `email_receiver` defines the receivers with these arguments
  - `name` - (required) The name of the email receiver. Names must be unique (case-insensitive) across all receivers within an action group.
  - `email_address` - (required) The email address of this receiver.
  - `use_common_alert_schema` - (optional) Enables or disables the common alert schema. Defaults to false (don't use).
    See https://learn.microsoft.com/en-gb/azure/azure-monitor/alerts/alerts-common-schema for more
  DESCRIPTION
  validation {
    condition     = alltrue([for k, v in var.action_groups : (length(v.short_name) >= 1 && length(v.short_name) <= 12)])
    error_message = "expected length of short_name to be in the range (1 - 12)"
  }
}

variable "external_endpoint_check" {
  type = object({
    name                 = string
    description          = optional(string, "")
    action_group_map_key = string
    frequency            = string
    severity             = number
    window_size          = string
    endpoints = list(object({
      name = string
      url  = string
    }))
  })
  default     = null
  description = <<DESCRIPTION
  (optional) A definition of an Alert based on standard web tests on a list of endpoints.
  For each endpoint a dedicated alert is created. To distinguish these alerts, the two attributes `name` and `description`
  can have a placeholder `%scope_name%` which will be replaced with the name of the endpoint.

  - `name` - (required) The name of the Alerts. Use placeholder %scope_name%.
  - `description` - (optional) The description of the Alerts. Use placeholder %scope_name%.
  - `action_group_map_key` - (required) The key of an item in the variable `action_groups`. This action group is used for the Alerts.
  - `frequency` - (required) The evaluation frequency of the Alerts, represented in ISO 8601 duration format.
  - `severity` - (required Severity of the alerts. Should be an integer between 0 and 4. Value of 0 is severest.
  - `window_size` - (required) The period of time that is used to monitor alert activity, represented in ISO 8601 duration format. This value must be greater than frequency.

  ---
  Required block `endpoints` defines the list of Web Addresses which will be checked with a Standard Web Test each. These addresses must be reachable via https
  - `name` - (required) Display Name for this address
  - `fqdn` - (required) The domain name of the web address

  DESCRIPTION

  validation {
    condition     = var.external_endpoint_check == null || (var.application_insights_enabled && length(var.action_groups) > 0)
    error_message = "The checks of external endpoints needs Application Insights and at least one Action Group. You cannot create these checks without it."
  }

  validation {
    condition     = var.external_endpoint_check == null || contains([for k, v in var.action_groups : k], try(var.external_endpoint_check.action_group_map_key, ""))
    error_message = "The value of action_group_map_key must reference an existing key of variable action_groups."
  }
}

variable "scheduled_log_alerts" {
  type = map(object({
    name                    = string
    description             = optional(string, "")
    action_group_map_key    = string
    enabled                 = optional(bool, true)
    auto_mitigation_enabled = optional(bool, false)
    evaluation_frequency    = string
    severity                = number
    window_duration         = string
    criteria = list(object({
      operator                = string
      query                   = string
      threshold               = number
      time_aggregation_method = string
      metric_measure_column   = optional(string, null)
      dimension = optional(set(object({
        name     = string
        operator = string
        values   = list(string)
      })), [])
    }))

  }))
  default     = {}
  nullable    = false
  description = <<DESCRIPTION
  (optional) A map of scheduled-query-alert-definitions which will be created in the scope of the Log Analytics Workspace.
  If this variable is set, at least one item in `action_groups` is required. Application Insights is not required.

  The two attributes `name` and `description` can have a placeholder `%scope_name%` which will be replaced with the name of the Log Analytics Workspace.
  - `name` - (required) The name of the Alert. Changing this forces a new resource to be created.
  - `description` - (optional) The description of this Alert.
  - `action_group_map_key` - (required) The key of an item in the variable `action_groups`. This action group is used for the Alert.
  - `enabled` - (optional) Should this Alert be enabled? Defaults to `true`.
  - `auto_mitigation_enabled` - (optional) Automatically resolve alerts (stateful). Defaults to `false`; enable explicitly per alert.
  - `evaluation_frequency` - (required) How often the scheduled query rule is evaluated, represented in ISO 8601 duration format.
  - `severity` - (required Severity of the alert. Should be an integer between 0 and 4. Value of 0 is severest.
  - `window_duration` - (required) Specifies the period of time in ISO 8601 duration format on which the Scheduled Query Rule will be executed.

  ---
  Required block `criteria` defines a list of queries to consider in the alert. The block supports these attributes:
  - `operator` - (required) The criteria operator.
  - `query` - (required) The query to run on logs. The results returned by this query are used to populate the alert.
  - `threshold` - (required) The criteria threshold value that activates the alert.
  - `time_aggregation_method` - (required) The type of aggregation to apply to the data points in aggregation granularity.
  - `metric_measure_column` - (optional) The column containing the metric measure number. Do not specify if `time_aggregation_method` is `Count`.

  ---
  Optional block `dimension` defines the filters for the metric. The block supports these attributes:
  - `name` - (required) One of the dimension names.
  - `operator` - (required) The dimension operator.
  - `values` - (required) The list of dimension values. Use a wildcard `*` to collect all.
  DESCRIPTION

  validation {
    condition     = length(var.scheduled_log_alerts) == 0 || length(var.action_groups) > 0
    error_message = "Scheduled Log Alerts need at least one Action Group. Application Insights is not required."
  }

  validation {
    condition     = alltrue([for k, v in var.scheduled_log_alerts : contains([for agk, agv in var.action_groups : agk], v.action_group_map_key)])
    error_message = "The value of action_group_map_key must reference an existing key of variable action_groups."
  }
}
