## ALERTING

## Dynamically defined Scheduled Query Alerts
resource "azurerm_monitor_scheduled_query_rules_alert_v2" "main" {
  for_each = var.scheduled_log_alerts

  name                = replace(each.value.name, "%scope_name%", azurerm_log_analytics_workspace.main.name)
  resource_group_name = azurerm_log_analytics_workspace.main.resource_group_name
  location            = azurerm_log_analytics_workspace.main.location
  scopes              = [azurerm_log_analytics_workspace.main.id]

  description             = replace(each.value.description, "%scope_name%", azurerm_log_analytics_workspace.main.name)
  enabled                 = each.value.enabled
  auto_mitigation_enabled = each.value.auto_mitigation_enabled
  evaluation_frequency    = each.value.evaluation_frequency
  severity                = each.value.severity
  tags                    = var.tags
  window_duration         = each.value.window_duration

  # Validate the real workspace query during deployment.
  skip_query_validation = false

  dynamic "criteria" {
    for_each = each.value.criteria
    iterator = crit
    content {
      operator                = crit.value.operator
      query                   = crit.value.query
      threshold               = crit.value.threshold
      time_aggregation_method = crit.value.time_aggregation_method
      metric_measure_column   = crit.value.metric_measure_column

      dynamic "dimension" {
        for_each = crit.value.dimension
        iterator = dim
        content {
          values   = dim.value.values
          name     = dim.value.name
          operator = dim.value.operator
        }
      }

      failing_periods {
        minimum_failing_periods_to_trigger_alert = 1
        number_of_evaluation_periods             = 1
      }
    }
  }
  action {
    action_groups = [azurerm_monitor_action_group.main[each.value.action_group_map_key].id]
  }
}

## Standard Web Tests and corresponding Alerts
# Test
resource "azurerm_application_insights_standard_web_test" "availability_check" {
  for_each                = try({ for endpoint in var.external_endpoint_check.endpoints : endpoint.url => endpoint }, {})
  name                    = "Availability-Test ${each.value.name}"
  resource_group_name     = azurerm_log_analytics_workspace.main.resource_group_name
  location                = azurerm_log_analytics_workspace.main.location
  application_insights_id = azurerm_application_insights.main[0].id
  # We try to ping our sites from 2 different and relevant geo locations West-Europe and North Europe
  # see https://learn.microsoft.com/en-us/previous-versions/azure/azure-monitor/app/monitor-web-app-availability#location-population-tags
  geo_locations = ["emea-nl-ams-azr", "emea-gb-db3-azr"]

  request {
    url                              = "https://${each.key}/"
    parse_dependent_requests_enabled = false
  }
  retry_enabled = true
  validation_rules {
    ssl_check_enabled = true
  }
  enabled = true
  tags    = var.tags
}

# Alert on failed test
resource "azurerm_monitor_metric_alert" "availability_alert" {
  for_each            = try({ for endpoint in var.external_endpoint_check.endpoints : endpoint.url => endpoint }, {})
  name                = replace(var.external_endpoint_check.name, "%scope_name%", each.value.name)
  resource_group_name = azurerm_log_analytics_workspace.main.resource_group_name
  scopes = [
    azurerm_application_insights_standard_web_test.availability_check[each.key].id,
    azurerm_application_insights.main[0].id
  ]

  description = replace(var.external_endpoint_check.description, "%scope_name%", each.value.name)
  severity    = var.external_endpoint_check.severity

  frequency   = var.external_endpoint_check.frequency
  window_size = var.external_endpoint_check.window_size

  application_insights_web_test_location_availability_criteria {
    web_test_id           = azurerm_application_insights_standard_web_test.availability_check[each.key].id
    component_id          = azurerm_application_insights.main[0].id
    failed_location_count = 1
  }
  action {
    action_group_id = azurerm_monitor_action_group.main[var.external_endpoint_check.action_group_map_key].id
  }
  enabled = true
  tags    = var.tags
}
