"""Local regression tests, no network, Terraform provider or Azure account required."""
from contextlib import redirect_stdout
import io
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import vorbereiten as m

A = '''resource "azurerm_monitor_scheduled_query_rules_alert_v2" "main" {
  for_each = var.scheduled_log_alerts
  name = replace(each.value.name, "%scope_name%", azurerm_application_insights.main[0].name)
  scopes = [azurerm_application_insights.main[0].id]
  description = replace(each.value.description, "%scope_name%", azurerm_application_insights.main[0].name)
  enabled = each.value.enabled
  dynamic "criteria" {
    for_each = each.value.criteria
    content { query = criteria.value.query }
  }
}
# The following web test must keep its Application Insights reference.
resource "azurerm_application_insights_standard_web_test" "availability_check" {
  application_insights_id = azurerm_application_insights.main[0].id
}
'''
V = '''variable "external_endpoint_check" {
  default = null
  validation {
    condition = var.external_endpoint_check == null || var.application_insights_enabled
    error_message = "Needs Application Insights."
  }
}
variable "scheduled_log_alerts" {
  type = map(object({
    name = string
    enabled = optional(bool, true)
    criteria = list(object({ query = string }))
  }))
  default = {}
  description = <<DESCRIPTION
  A map which will be created in the scope of the Application Insights.
  If this variable is set, `integrate_application_insights` must be `true` and at least one item in `action_groups` is required.
  %scope_name% is replaced with the name of the App Service Plan.
  - `evaluation_frequency` - frequency
  DESCRIPTION
  validation {
    condition = length(var.scheduled_log_alerts) == 0 || (var.application_insights_enabled && length(var.action_groups) > 0)
    error_message = "Scheduled Log Alerts need Application Insights. You cannot create these alerts without it."
  }
}
'''
S = '''locals {
  tg_catalog_version = "v0.13.0"
  environment = "test"
}
unit "monitoring" {
  source = "git::${local.tg_catalog_uri}//units/log-and-monitor?ref=${local.tg_catalog_version}"
  path = "monitoring"
  values = {
    application_insights_enabled = true
    name = "log-ump-${local.environment}"
    dependencies_paths = ["../resourcegroup-monitor"]
  }
}
unit "other" {
  source = "git::${local.tg_catalog_uri}//units/other?ref=${local.tg_catalog_version}"
  path = "other"
  values = { environment = local.environment }
}
'''
TEMPLATE = (m.PACKAGE / 'VORLAGE/test-alerts.hcl').read_text()
SHA = 'a' * 40


class StructureTests(unittest.TestCase):
    def test_strings(self):
        m.assert_balanced('a = "{ [ } ]"\nb = {}')
    def test_comments(self):
        m.assert_balanced('# }\na = { /* [ } */ b = true } // [')
    def test_heredoc(self):
        m.assert_balanced('a = <<-KQL\n  { [ }\n  KQL\nb = {}')
    def test_bad_comment(self):
        with self.assertRaises(m.PreparationError): m.mask_hcl('/* unfinished')
    def test_bad_string(self):
        with self.assertRaises(m.PreparationError): m.mask_hcl('a = "unfinished')
    def test_bad_heredoc(self):
        with self.assertRaises(m.PreparationError): m.mask_hcl('a = <<EOF\nbroken')
    def test_bad_braces(self):
        with self.assertRaises(m.PreparationError): m.assert_balanced('{ [ } ]')
    def test_open_brace(self):
        with self.assertRaises(m.PreparationError): m.assert_balanced('{')
    def test_duplicate_header(self):
        with self.assertRaises(m.PreparationError): m.block_span(S + S, r'unit\s+"monitoring"')
    def test_line_endings_hash(self):
        self.assertEqual(m.digest('abc\r\n'), m.digest('abc\n'))


class CatalogTests(unittest.TestCase):
    def setUp(self): self.a, self.v = m.transform_catalog(A, V)
    def test_law_scope(self): self.assertIn('scopes', self.a); self.assertIn('[azurerm_log_analytics_workspace.main.id]', self.a)
    def test_name_and_description(self): self.assertEqual(self.a.count('azurerm_log_analytics_workspace.main.name'), 2)
    def test_availability_unchanged(self): self.assertEqual(A[A.index('# The following'):], self.a[self.a.index('# The following'):])
    def test_web_validation_unchanged(self): self.assertEqual(V[:V.index('variable "scheduled')], self.v[:self.v.index('variable "scheduled')])
    def test_optional_auto_mitigation(self): self.assertIn('optional(bool, false)', self.v); self.assertIn('each.value.auto_mitigation_enabled', self.a)
    def test_validation_removed(self): self.assertNotIn('var.application_insights_enabled', self.v[self.v.index('variable "scheduled'):])
    def test_validate_query(self): self.assertIn('skip_query_validation = false', self.a)
    def test_idempotence(self): self.assertEqual((self.a, self.v), m.transform_catalog(self.a, self.v))
    def test_unknown_scope_refused(self):
        with self.assertRaises(m.PreparationError): m.transform_catalog(A.replace('[azurerm_application_insights.main[0].id]', '[var.scope]'), V)
    def test_unknown_mitigation_refused(self):
        with self.assertRaises(m.PreparationError): m.transform_catalog(self.a.replace('each.value.auto_mitigation_enabled', 'true'), V)
    def test_missing_resource(self):
        with self.assertRaises(m.PreparationError): m.transform_catalog('', V)


class LiveTests(unittest.TestCase):
    def setUp(self): self.s = m.transform_live(S, SHA, TEMPLATE)
    def test_pin(self): self.assertIn('ref=' + SHA, self.s)
    def test_others_unchanged(self): self.assertEqual(S[S.index('unit "other"'):], self.s[self.s.index('unit "other"'):])
    def test_global_version_unchanged(self): self.assertIn('tg_catalog_version = "v0.13.0"', self.s)
    def test_state_path_same(self): self.assertEqual(self.s.count('path = "monitoring"'), 1)
    def test_recipient(self): self.assertIn('ui-team@os-cillation.de', self.s)
    def test_query(self): self.assertIn('where SeverityText in~ ("error", "fatal")', self.s)
    def test_dimension(self): self.assertIn('name     = "ServiceName"', self.s)
    def test_auto_mitigation(self): self.assertIn('auto_mitigation_enabled = true', self.s)
    def test_frequency_and_count(self):
        self.assertIn('"PT1M"', self.s); self.assertIn('"PT5M"', self.s); self.assertIn('"GreaterThan"', self.s)
    def test_duplicate_stops(self):
        with self.assertRaises(m.PreparationError): m.transform_live(self.s, SHA, TEMPLATE)
    def test_branch_as_pin_stops(self):
        with self.assertRaises(m.PreparationError): m.transform_live(S, 'main', TEMPLATE)
    def test_non_sha_stops(self):
        with self.assertRaises(m.PreparationError): m.transform_live(S, 'x' * 40, TEMPLATE)
    def test_dynamic_map_stops(self):
        changed = S.replace('    dependencies_paths', '    action_groups = merge(local.groups, {})\n    dependencies_paths')
        with self.assertRaises(m.PreparationError): m.transform_live(changed, SHA, TEMPLATE)
    def test_existing_groups_preserved(self):
        changed = S.replace('    dependencies_paths', '    action_groups = {\n      support = { short_name = "support" }\n    }\n    dependencies_paths')
        out = m.transform_live(changed, SHA, TEMPLATE)
        self.assertIn('support = { short_name = "support" }', out)
        self.assertEqual(out.count('action_groups ='), 1)
    def test_existing_alerts_preserved(self):
        changed = S.replace('    dependencies_paths', '    scheduled_log_alerts = {\n      unrelated = { name = "unrelated" }\n    }\n    dependencies_paths')
        out = m.transform_live(changed, SHA, TEMPLATE)
        self.assertIn('unrelated = { name = "unrelated" }', out)
        self.assertEqual(out.count('scheduled_log_alerts ='), 1)
    def test_empty_maps(self):
        changed = S.replace('    dependencies_paths', '    action_groups = {}\n    scheduled_log_alerts = {}\n    dependencies_paths')
        out = m.transform_live(changed, SHA, TEMPLATE)
        m.assert_balanced(out)
        self.assertEqual(out.count('action_groups ='), 1)
    def test_existing_recipient_stops(self):
        changed = S.replace('    dependencies_paths', '    action_groups = {\n      old = { email_address = "ui-team@os-cillation.de" }\n    }\n    dependencies_paths')
        with self.assertRaises(m.PreparationError): m.transform_live(changed, SHA, TEMPLATE)
    def test_unrelated_new_main_changes_survive(self):
        changed = S.replace('locals {', '# New change from Timo\nlocals {').replace('path = "other"', 'path = "other-v2"')
        out = m.transform_live(changed, SHA, TEMPLATE)
        self.assertTrue(out.startswith('# New change from Timo'))
        self.assertIn('path = "other-v2"', out)


class GitCopyTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        self.package = self.root / 'package'
        self.package.mkdir()
        (self.package / 'VORLAGE').mkdir()
        (self.package / 'VORLAGE/test-alerts.hcl').write_text(TEMPLATE)
        self.repo = self.root / 'live'; self.repo.mkdir()
        subprocess.run(['git','init','-q','-b','main',str(self.repo)],check=True)
        for key, val in [('user.name','Local Test'),('user.email','test@example.invalid')]: m.git(self.repo,'config',key,val)
        p = self.repo / m.STACK_FILE; p.parent.mkdir(parents=True); p.write_text(S)
        m.git(self.repo,'add','.'); m.git(self.repo,'commit','-qm','baseline')
        self.sha=m.git(self.repo,'rev-parse','HEAD')
        m.git(self.repo,'switch','-c',m.LIVE_BRANCH)
        self.patch=patch.object(m,'PACKAGE',self.package); self.patch.start()
    def tearDown(self): self.patch.stop(); self.tmp.cleanup()
    def write_output(self):
        out=m.transform_live(S,SHA,TEMPLATE)
        with redirect_stdout(io.StringIO()):
            m.write_copy_files('live',self.repo,self.sha,{m.STACK_FILE:S},{m.STACK_FILE:out},SHA)
        return out
    def test_preparation_does_not_modify_checkout(self):
        self.write_output(); self.assertEqual(m.git(self.repo,'status','--porcelain'),'')
    def test_correct_copy_passes(self):
        out=self.write_output(); (self.repo/m.STACK_FILE).write_text(out)
        with redirect_stdout(io.StringIO()): m.verify_copied('live',str(self.repo))
    def test_wrong_nested_path_stops(self):
        out=self.write_output(); p=self.repo/'live/live/test/terragrunt.stack.hcl'; p.parent.mkdir(parents=True); p.write_text(out)
        with self.assertRaises(m.PreparationError): m.verify_copied('live',str(self.repo))
    def test_extra_ci_file_stops(self):
        out=self.write_output(); (self.repo/m.STACK_FILE).write_text(out); (self.repo/'.gitlab-ci.yml').write_text('oops')
        with self.assertRaises(m.PreparationError): m.verify_copied('live',str(self.repo))
    def test_changed_content_stops(self):
        out=self.write_output(); (self.repo/m.STACK_FILE).write_text(out.replace('"fatal"','"info"'))
        with self.assertRaises(m.PreparationError): m.verify_copied('live',str(self.repo))
    def test_wrong_branch_stops(self):
        out=self.write_output(); m.git(self.repo,'switch','main'); (self.repo/m.STACK_FILE).write_text(out)
        with self.assertRaises(m.PreparationError): m.verify_copied('live',str(self.repo))
    def test_changed_baseline_stops(self):
        out=self.write_output(); (self.repo/m.STACK_FILE).write_text(out); m.git(self.repo,'add','.'); m.git(self.repo,'commit','-qm','premature commit')
        with self.assertRaises(m.PreparationError): m.verify_copied('live',str(self.repo))
    def test_existing_own_output_can_be_refreshed(self):
        self.write_output(); self.write_output()
    def test_unknown_copy_file_not_deleted(self):
        self.write_output(); p=self.package/'KOPIEREN/live/keep.txt'; p.write_text('mine')
        with self.assertRaises(m.PreparationError): self.write_output()
        self.assertEqual(p.read_text(),'mine')
    def test_crlf_copy_accepted(self):
        out=self.write_output(); (self.repo/m.STACK_FILE).write_bytes(out.replace('\n','\r\n').encode())
        m.git(self.repo,'config','core.whitespace','cr-at-eol')
        with redirect_stdout(io.StringIO()): m.verify_copied('live',str(self.repo))



class CleanupWorkflowTests(unittest.TestCase):
    def setUp(self):
        import re
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        self.remote = self.root / 'remote.git'
        self.repo = self.root / 'work'
        subprocess.run(['git','init','-q','--bare',str(self.remote)],check=True)
        subprocess.run(['git','init','-q','-b','main',str(self.repo)],check=True)
        for key,val in [('user.name','Local Test'),('user.email','test@example.invalid')]: m.git(self.repo,'config',key,val)
        p=self.repo/m.STACK_FILE; p.parent.mkdir(parents=True); p.write_text(S)
        m.git(self.repo,'add','.'); m.git(self.repo,'commit','-qm','base')
        m.git(self.repo,'remote','add','origin',str(self.remote))
        m.git(self.repo,'push','-u','origin','main')
        self.base=m.git(self.repo,'rev-parse','HEAD')
        self.old='feat/DBI-6455-otel-email-alerts'
        m.git(self.repo,'switch','-c',self.old)
        (self.repo/'old-code.tf').write_text('# old draft\n')
        m.git(self.repo,'add','.'); m.git(self.repo,'commit','-qm','old change')
        self.oldsha=m.git(self.repo,'rev-parse','HEAD')
        m.git(self.repo,'push','-u','origin',self.old)
        self.script=re.findall(r'```bash\n(.*?)```',(m.PACKAGE/'README.md').read_text(),re.S)[0]
        self.wrapper='''git() {
  if [[ "$*" == "remote get-url origin" ]]; then
    printf '%s\\n' 'https://gitlab.apps.union-investment.de/ump_legacy/infrastructure/live.git'
  else
    command git "$@"
  fi
}
'''
    def tearDown(self): self.tmp.cleanup()
    def execute(self,answer='JA\n'):
        return subprocess.run(['bash','-c',self.wrapper+self.script],cwd=self.repo,input=answer,text=True,capture_output=True)
    def test_cleanup_preserves_main_and_backup(self):
        result=self.execute(); self.assertEqual(result.returncode,0,result.stdout+result.stderr)
        self.assertEqual(m.git(self.repo,'branch','--show-current'),'main')
        self.assertEqual(m.git(self.repo,'rev-parse','HEAD'),self.base)
        self.assertNotIn(self.old,m.git(self.repo,'branch','--list'))
        self.assertNotIn(self.old,m.git(self.repo,'ls-remote','--heads','origin'))
        self.assertIn(self.oldsha,[m.git(self.repo,'rev-parse',t) for t in m.git(self.repo,'tag','--list').splitlines()])
    def test_uncommitted_and_untracked_saved(self):
        (self.repo/'old-code.tf').write_text('# modified\n'); (self.repo/'untracked.txt').write_text('mine')
        result=self.execute(); self.assertEqual(result.returncode,0,result.stdout+result.stderr)
        self.assertEqual(m.git(self.repo,'status','--porcelain'),'')
        self.assertTrue(m.git(self.repo,'stash','list'))
        self.assertIn('mine',m.git(self.repo,'show','stash@{0}^3:untracked.txt'))
    def test_missing_confirmation_stops(self):
        self.assertNotEqual(self.execute('NEIN\n').returncode,0)
        self.assertEqual(m.git(self.repo,'branch','--show-current'),self.old)
        self.assertEqual(m.git(self.repo,'tag','--list'),'')
    def test_already_merged_stops(self):
        m.git(self.repo,'push','origin',self.old+':main')
        result=self.execute(); self.assertNotEqual(result.returncode,0)
        self.assertIn('bereits in main',result.stdout)
    def test_main_ahead_not_reset(self):
        m.git(self.repo,'switch','main'); (self.repo/'local-main.txt').write_text('keep')
        m.git(self.repo,'add','.'); m.git(self.repo,'commit','-qm','keep local main')
        ahead=m.git(self.repo,'rev-parse','HEAD'); m.git(self.repo,'switch',self.old)
        result=self.execute(); self.assertNotEqual(result.returncode,0)
        self.assertEqual(m.git(self.repo,'rev-parse','main'),ahead)
    def test_remote_branch_already_deleted(self):
        m.git(self.repo,'push','origin','--delete',self.old)
        result=self.execute(); self.assertEqual(result.returncode,0,result.stdout+result.stderr)
        self.assertEqual(m.git(self.repo,'branch','--show-current'),'main')

if __name__ == '__main__': unittest.main(verbosity=2)
