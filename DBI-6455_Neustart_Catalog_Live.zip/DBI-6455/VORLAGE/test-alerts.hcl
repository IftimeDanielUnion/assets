# DBI-6455: inputs for the existing monitoring unit in TEST.
# This file is consumed by vorbereiten.py, not copied to a repository on its own.
action_groups = {
  osc-exceptions = {
    short_name = "ump-test"
    email_receiver = [{
      name                    = "osc-ui-team"
      email_address           = "ui-team@os-cillation.de"
      use_common_alert_schema = true
    }]
  }
}

scheduled_log_alerts = {
  otel-error-fatal = {
    name                    = "ump-${local.environment}-otel-error-fatal"
    description             = "DBI-6455: OTel error/fatal per ServiceName in TEST."
    action_group_map_key    = "osc-exceptions"
    enabled                 = true
    auto_mitigation_enabled = true
    evaluation_frequency    = "PT1M"
    severity                = 1
    window_duration         = "PT5M"
    criteria = [{
      query = <<-KQL
        OTelLogs
        | where SeverityText in~ ("error", "fatal")
        | extend ServiceName = iff(isempty(ServiceName), "unknown-service", ServiceName)
        | project TimeGenerated, ServiceName
      KQL
      operator                = "GreaterThan"
      threshold               = 0
      time_aggregation_method = "Count"
      dimension = [{
        name     = "ServiceName"
        operator = "Include"
        values   = ["*"]
      }]
    }]
  }
}
