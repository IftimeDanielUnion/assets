# Prüfstand und Quellen

## Ergebnis der lokalen Prüfungen

**55 automatisierte Tests bestanden.** Enthalten sind Block-Erkennung, Scope-/Validierungsänderung, unveränderte Availability-Checks, Erhalt bestehender anderer Einstellungen, feste Catalog-Commit-Referenz und Kopierkontrollen. Getestet sind auch der Abbruch bei falschem Branch, falschem Zielpfad, zusätzlichen CI-Dateien, abweichenden Inhalten und bereits konfiguriertem OSC-Empfänger.

Der Bereinigungsblock aus der README wurde mit echten temporären Git-Repositories und einem lokalen Bare-Remote ausgeführt: alter Branch lokal/remote entfernt, `main` unverändert erhalten, lokale Änderungen gesichert, fehlende Bestätigung und bereits gemergter Branch abgefangen. Das betrifft **nicht** dein GitLab.

Zusätzlich wurde der gesamte Ablauf mit den tatsächlichen Dateien aus deinem Upload durchlaufen: Catalog-Dateien erzeugen, manuell kopieren, Catalog-Merge lokal simulieren, Live-Datei mit dessen Commit-ID erzeugen und kopieren. Die Kopierkontrolle akzeptiert genau die vorgesehenen Dateien. Der Live-Diff verändert nur die vorhandene `monitoring`-Unit. Außerhalb dieses Blocks bleiben alle Zeilen identisch. Die fünf Bash-Blöcke der README bestehen `bash -n`.

Die Tests verändern keine Azure-Ressourcen und versenden keine E-Mails. Der HCL-Scanner prüft Struktur und gezielte Änderungen, ist aber kein vollständiger Terraform-Parser.

## Noch nicht geprüft

**Kein nativer Terraform-/Terragrunt-Lauf, kein Azure-Plan/Apply, keine KQL-Ausführung und kein E-Mail-End-to-End-Test für diese neue Variante.** Die dafür benötigten Tools/Netzwerkverbindungen stehen hier nicht zur Verfügung. Die echte Provider- und Integrationsprüfung muss in eurer Umgebung erfolgen, spätestens mit der TEST-Pipeline vor dem manuellen Apply. Die vorhandenen früheren Logbelege werden nicht als Abnahme der neuen Regel ausgegeben.

Es wurde weder der aktuelle GitLab-Stand abgerufen noch ein MR oder Remote-Branch verändert. Das lokale Vorbereitungswerkzeug holt deshalb bei dir `origin/main` neu und bricht bei einem nicht passenden Checkout ab. Unerwartete aktuelle Modulstrukturen werden nicht durch den alten Snapshot ersetzt.

## Was aus dem Code belegt ist

Basis: `UMP_repos.zip`, Verzeichnis `UMP_repos/UMP_legacy/`.

- `catalog`: im Upload `main` / Tag `v0.13.0`, Commit `86bc6125155279f57688a9932717ca065eeb3cd5`.
- `live`: im Upload `main`, Commit `dd42ccc` vom 25.09.2026. Das ist nicht der behauptete aktuelle GitLab-Stand.
- `catalog/modules/log-and-monitor/main.alerts.tf`: Scheduled Query Alerts referenzieren ursprünglich Application Insights. Dieser Abschnitt wird auf den bestehenden LAW umgestellt.
- `catalog/modules/log-and-monitor/variables.logs.tf`: die ursprüngliche Validierung verlangt Application Insights; diese Pflicht entfällt nur für Scheduled Log Alerts. Die Action-Group-Zuordnung bleibt geprüft.
- `catalog/modules/log-and-monitor/main.tf`: Action Groups mit E-Mail-Empfängern sind schon implementiert. Es wird kein zweiter Ressourcenbaustein daneben gebaut.
- `catalog/units/log-and-monitor/terragrunt.hcl`: reicht `action_groups` und `scheduled_log_alerts` bereits durch. Die Unit zeigt im Upload auf `../../modules//log-and-monitor`. Daher ist für diese Lösung kein zusätzliches separates GitLab-Modulprojekt erforderlich. Bei abweichender aktueller Quelle stoppt das Werkzeug.
- `live/live/test/terragrunt.stack.hcl`: enthält die vorhandene `monitoring`-Unit. Nur deren Quelle und Werte werden gezielt ergänzt.
- `live/.gitlab-ci.yml`: vorhandene TEST-Jobs reagieren bereits auf `live/test/**`. Keine neue CI-Datei erforderlich. TEST-Apply auf `main` ist manuell; die Plan-Artefakte laufen nach einem Tag ab.
- Timos zuletzt hochgeladene Teams-Nachricht: bestehenden Log-Alert auf LAW ausrichten, anschließend TEST konfigurieren; laut Nachricht wird dieser Alert-Teil bisher nicht eingesetzt. Eine organisationsweite Nutzungsinventur ist damit nicht nachgewiesen.
- Jira-Export `ump_jiras.zip/ump_jiras/DBI-6455.doc`, 30.09.2026: OSC fordert error/fatal-Mails an `ui-team@os-cillation.de`, möglichst mit ServiceName. Die neue Konfiguration liefert ServiceName als Dimension, aber keinen eigens implementierten dynamischen Mail-Betreff.

## Reproduzierbare lokale Tests

Im entpackten DBI-6455-Ordner, ohne Azure-Anmeldung:

```bash
PYTHONDONTWRITEBYTECODE=1 python3 -m unittest discover -s tests -v
```

## Primärdokumentation

Die Links erklären das Plattformverhalten, nicht den Laufzeitstand eurer Umgebung.

- GitLab: ungemergte MRs schließen, Historie erhalten: https://docs.gitlab.com/user/project/merge_requests/
- Git: Branch wechseln/anlegen: https://git-scm.com/docs/git-switch
- Git: lokale Änderungen einschließlich untracked Dateien sichern: https://git-scm.com/docs/git-stash
- Azure: Query-basierte Alerts, Dimensionen, Action Groups und zustandsbehaftete Auswertung: https://learn.microsoft.com/en-us/azure/azure-monitor/alerts/alerts-create-log-alert-rule
- AzureRM: Ressourcenschema für Scheduled Query Alerts: https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/monitor_scheduled_query_rules_alert_v2
- Terragrunt: Versions-/Commit-Referenzen und Quellenauflösung: https://terragrunt.gruntwork.io/docs/reference/hcl/blocks/

Bei einer Abweichung zwischen dieser aktuellen Dokumentation und der bei euch gepinnten Provider-/Toolversion gelten die tatsächlich verwendeten Versionsschemas. Der Upload pinnt Terraform `1.13.4`, Terragrunt `1.1.6` und im generierten Provider AzureRM `~> 4.63`; diese Pins werden nicht geändert.
