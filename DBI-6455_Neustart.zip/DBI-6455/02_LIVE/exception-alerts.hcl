# DBI-6455: TEST configuration for catalog/units/log-and-monitor.
# Read these locals from the existing monitoring unit in terragrunt.stack.hcl.
# This file does not declare a second monitoring unit or a new workspace.
locals {
  action_groups = {
    "osc-exceptions" = {
      short_name = "ump-test"
      email_receiver = [
        {
          name                    = "osc-ui-team"
          email_address           = "ui-team@os-cillation.de"
          use_common_alert_schema = true
        }
      ]
    }
  }

  scheduled_log_alerts = {
    "otel-error-fatal" = {
      name                    = "ump-test-otel-error-fatal"
      description             = "DBI-6455: error/fatal in OTelLogs on %scope_name%, split by ServiceName."
      action_group_map_key    = "osc-exceptions"
      enabled                 = true
      evaluation_frequency    = "PT1M"
      severity                = 1
      window_duration         = "PT5M"
      auto_mitigation_enabled = true

      criteria = [
        {
          operator                = "GreaterThan"
          threshold               = 0
          time_aggregation_method = "Count"
          query                   = <<-KQL
            OTelLogs
            | where SeverityText in~ ("error", "fatal")
            | extend ServiceName = iff(isempty(ServiceName), "unknown-service", ServiceName)
            | project TimeGenerated, ServiceName
          KQL
          dimension = [
            {
              name     = "ServiceName"
              operator = "Include"
              values   = ["*"]
            }
          ]
        }
      ]
    }
  }
}
