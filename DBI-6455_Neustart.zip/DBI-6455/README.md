# DBI-6455: Neuaufbau nach Timos Vorschlag

**Nur dieses Ticket. Nur manuelle Schritte, keine Starter oder Übernahmeskripte.**

Wir schließen den bisherigen `live`-MR **!52** und beginnen auf dem aktuellen `main` neu. Der bestehende Baustein `catalog/modules/log-and-monitor` bekommt den Log Analytics Workspace (LAW) als Scope für seine Log-Alerts. `live` bekommt anschließend nur die TEST-Konfiguration. Die vorhandene Action-Group-Funktion wird weiterverwendet.

**Ergebnis: zwei kleine MRs, zuerst `catalog`, danach `live`.** Kein neues `ump-exception-alerts`-Modul, keine neue Monitoring-Unit, keine CI-Datei aus dem alten Paket, keine DEV-/PROD-Änderungen.

## 1. Alten MR in GitLab schließen

Diese Anleitung gilt, solange **MR !52 nicht gemerged und der alte Alert-Code nicht deployed wurde**. Dann gibt es auf `main` nichts zu reverten und in Azure nichts zurückzubauen. Wenn bereits gemerged oder angewendet wurde: nicht nach dieser Anleitung löschen; dann muss der tatsächliche Code-/State-Stand zuerst berücksichtigt werden.

Öffne im Projekt `infrastructure/live` den MR **!52**, schreibe diesen Kommentar und wähle **Close merge request / Merge Request schließen**. Nicht mergen und nicht den MR-Datensatz löschen.

> Ich ersetze diesen MR nach Abstimmung mit Timo durch die Einbindung in den bestehenden log-and-monitor-Baustein. Die Log-Alerts werden dort direkt auf den LAW ausgerichtet; in live folgt nur die TEST-Konfiguration. Der separate Alert-Baustein und die bisherigen zusätzlichen Kopierpfade werden nicht übernommen. Die Umsetzung erfolgt in getrennten catalog- und live-MRs.

Ein gegebenenfalls aktiviertes Auto-Merge ausschalten. Keine Apply-Jobs des alten Branches starten.

## 2. Im originalen live-Repo zurück auf main und alten Branch löschen

Öffne **dein originales `live`-Repository** in VS Code, dann dessen WSL-Terminal. Nicht das entpackte Ticketpaket öffnen und dort Git ausführen. Die folgenden Schritte im selben Terminal ausführen; die Pfadvariablen gelten dort weiter. Bei einem Fehler stoppen, nicht einfach den nächsten Block ausführen.

```bash
cd "$(git rev-parse --show-toplevel)"
LIVE_REPO="$PWD"
git remote -v
git status --short
git branch --show-current
```

`origin` muss dein Projekt `ump_legacy/infrastructure/live` sein. Kopiere den **vollständigen Quellbranch aus MR !52** in die Eingabe. Der Screenshot kürzt ihn ab; deshalb wird sein Name hier nicht geraten.

```bash
read -r -p "Alter Quellbranch aus MR !52: " OLD_BRANCH
printf 'Zu löschen: %s\n' "$OLD_BRANCH"
```

Das muss der alte DBI-6455-Featurebranch sein, nicht `main` und kein Branch eines Kollegen.

```bash
git stash push --include-untracked -m "DBI-6455 vor Neuaufbau"
git fetch origin --prune
git switch main
git pull --ff-only origin main
git status --short
git log --oneline origin/main..main
```

**Warum der Stash?** Noch nicht committete Änderungen einschließlich neuer Dateien werden gesichert statt unwiederbringlich gelöscht. `No local changes to save` ist in Ordnung. Diesen Stash später **nicht zurückspielen**, sonst kommt der alte Kopierstand wieder.

Die letzten zwei Befehle sollten nichts ausgeben. Bei lokalen Zusatz-Commits auf `main` oder Pull-Konflikten stoppen. Kein `reset --hard` und kein Force-Push auf `main`.

Jetzt nur den bestätigten alten Featurebranch entfernen:

```bash
test -n "$OLD_BRANCH" && test "$OLD_BRANCH" != main && test "$OLD_BRANCH" != master && git push origin --delete "$OLD_BRANCH"
```

Wenn GitLab den Remote-Branch bereits gelöscht hat, ist die Meldung `remote ref does not exist` erwartbar. Anschließend lokal löschen:

```bash
test -n "$OLD_BRANCH" && test "$OLD_BRANCH" != main && test "$OLD_BRANCH" != master && git branch -D "$OLD_BRANCH"
git fetch origin --prune
git status --short
git ls-files live/test/terragrunt.stack.hcl
```

Die letzte Ausgabe muss repo-relativ `live/test/terragrunt.stack.hcl` sein. Ein vollständiger Windows-/WSL-Pfad kann durch den Repo-Namen zweimal `live` enthalten; entscheidend ist dieser **Git-relative** Pfad. Im MR darf kein zusätzliches `live/live/test/...` neu auftauchen.

**Der alte Code ist jetzt aus deinem Arbeitsstand heraus.** Der geschlossene MR dokumentiert den verworfenen Ansatz. `main` und Azure wurden dabei nicht zurückgesetzt.

## 3. catalog: neuer Branch und zwei Dateien kopieren

Gib den absoluten **WSL-Pfad** zu deinem bereits geklonten `catalog`-Repo ein, zum Beispiel den dort mit `pwd` angezeigten Pfad. Keine Windows-Schreibweise mit `C:\` verwenden.

```bash
read -e -r -p "WSL-Pfad zum catalog-Repo: " CATALOG_REPO
cd "$CATALOG_REPO"
git remote -v
git status --short
```

`origin` muss das `catalog`-Projekt sein. Bei eigenen offenen Änderungen diese zuerst sichern. Dann:

```bash
git fetch origin --prune
git switch main
git pull --ff-only origin main
git switch -c feat/DBI-6455-law-alerts
```

### Vor dem Überschreiben einmal den Ausgangsstand vergleichen

Die gelieferten Komplettdateien basieren auf deinem hochgeladenen `catalog`-Commit. Dieser Vergleich schützt inzwischen hinzugekommene Moduländerungen:

```bash
git diff 86bc6125155279f57688a9932717ca065eeb3cd5 origin/main -- modules/log-and-monitor/main.alerts.tf modules/log-and-monitor/variables.logs.tf
```

**Keine Ausgabe:** Du kannst die beiden Dateien direkt ersetzen. **Änderungen oder unbekannter Commit:** Nicht blind überschreiben. Übernimm dann nur die im Abschnitt „Änderungen im Modul“ beschriebenen Anpassungen in die aktuellen Dateien und lasse andere Änderungen stehen.

Ziehe die **zwei Dateien**, nicht den Ordner `01_CATALOG`, in den bereits vorhandenen Zielordner:

| Aus diesem Paket | Ziel im originalen catalog-Repo |
|---|---|
| `01_CATALOG/main.alerts.tf` | `modules/log-and-monitor/main.alerts.tf` |
| `01_CATALOG/variables.logs.tf` | `modules/log-and-monitor/variables.logs.tf` |

Danach:

```bash
git diff --check
git diff --stat
git diff -- modules/log-and-monitor/main.alerts.tf modules/log-and-monitor/variables.logs.tf
```

Erwartet werden nur diese zwei geänderten Dateien. Kein neuer Modulordner. Wenn Terraform lokal vorhanden ist, zusätzlich:

```bash
terraform fmt -check modules/log-and-monitor/main.alerts.tf modules/log-and-monitor/variables.logs.tf
```

Nach der Kontrolle:

```bash
git add modules/log-and-monitor/main.alerts.tf modules/log-and-monitor/variables.logs.tf
git diff --cached --stat
git commit -m "DBI-6455: scope existing log alerts to LAW"
git push -u origin feat/DBI-6455-law-alerts
```

Die zwei gezielten `git add`-Pfade verhindern, dass alte Dateien versehentlich mitcommittet werden.

**Neuer MR im catalog:** `feat/DBI-6455-law-alerts` nach `main`. Timo als Reviewer eintragen.

**Titel:** `DBI-6455: Bestehende Log-Alerts auf LAW ausrichten`

**Beschreibung zum Kopieren:**

> Der bestehende log-and-monitor-Baustein verwendet für Scheduled Query Alerts künftig den Log Analytics Workspace statt Application Insights als Scope. Namens-/Beschreibungsersetzungen und Eingabevalidierung werden entsprechend angepasst. Die Action-Group-Funktion bleibt bestehen; die automatische Alarmauflösung ist optional konfigurierbar. Application Insights und die Availability-Webtests bleiben unverändert. Laut Abstimmung wird der bisherige Log-Alert-Teil noch nicht verwendet. Die konkrete TEST-Konfiguration folgt separat im live-Repo. Mit diesem MR wird keine Umgebung auf einen neuen Katalogstand umgestellt.

### Änderungen im Modul

Nur für Review oder falls die Komplettdateien wegen neuerer Moduländerungen nicht übernommen werden können:

Im Resource-Block `azurerm_monitor_scheduled_query_rules_alert_v2.main` zeigen `name`, `description` und `scopes` auf den LAW:

```hcl
name        = replace(each.value.name, "%scope_name%", azurerm_log_analytics_workspace.main.name)
description = replace(each.value.description, "%scope_name%", azurerm_log_analytics_workspace.main.name)
scopes      = [azurerm_log_analytics_workspace.main.id]
```

Im selben Resource-Block kommt hinzu:

```hcl
auto_mitigation_enabled = each.value.auto_mitigation_enabled
```

Im Objekt-Typ von `variable "scheduled_log_alerts"` kommt hinzu:

```hcl
auto_mitigation_enabled = optional(bool, null)
```

Nur dessen bisherige Application-Insights-Validierung ersetzen durch:

```hcl
validation {
  condition     = length(var.scheduled_log_alerts) == 0 || length(var.action_groups) > 0
  error_message = "Scheduled Log Alerts need at least one Action Group."
}
```

Die Beschreibung dieser Variable muss LAW statt Application Insights nennen; `%scope_name%` wird jetzt durch den Workspace-Namen ersetzt. Die zweite Validierung für gültige Action-Group-Keys sowie die Application-Insights-Abhängigkeit der **Webtests** bleiben erhalten. Ohne expliziten Wert für `auto_mitigation_enabled` bleibt die Provider-Vorgabe bestehen; TEST setzt den Wert ausdrücklich auf `true`.

## 4. Nach dem catalog-Merge: tatsächlichen Commit übernehmen

**Erst wenn der neue catalog-MR in `main` gemerged wurde.** Der alte globale Katalog-Tag in `live` enthält diese Änderung noch nicht. Deshalb pinnen wir ausschließlich die TEST-Monitoring-Unit auf den neuen, echten Commit. Andere Units bleiben bei ihren bisherigen Versionen.

```bash
cd "$CATALOG_REPO"
git switch main
git pull --ff-only origin main
git log -3 --oneline
CATALOG_REF="$(git rev-parse HEAD)"
printf 'Katalog-Commit für TEST-Monitoring: %s\n' "$CATALOG_REF"
```

Kontrolliere, dass der Merge deiner Änderung enthalten ist. Es wird kein erfundener neuer Versions-Tag und kein bewegliches `main` als Source in die Infrastruktur geschrieben.

## 5. live: neuer Branch, eine Datei kopieren, drei Stellen ergänzen

```bash
cd "$LIVE_REPO"
git status --short
git fetch origin --prune
git switch main
git pull --ff-only origin main
git switch -c feat/DBI-6455-test-law-alerts
```

Ziehe **nur diese Datei** in den vorhandenen TEST-Ordner:

| Aus diesem Paket | Ziel im originalen live-Repo |
|---|---|
| `02_LIVE/exception-alerts.hcl` | `live/test/exception-alerts.hcl` |

**Keine alte komplette `terragrunt.stack.hcl` darüberkopieren.** So bleiben Timos zwischenzeitliche Gateway-/Storage-Änderungen und andere neue Änderungen auf `main` erhalten.

Öffne in VS Code **`live/test/terragrunt.stack.hcl`** und suche genau:

```hcl
unit "monitoring" {
```

### A. Nur dessen source-Zeile ersetzen

Der folgende Befehl gibt die **fertige Source-Zeile mit deinem echten gemergten catalog-Commit** aus. Er verändert keine Datei:

```bash
printf '  source = "git::${local.tg_catalog_uri}//units/log-and-monitor?ref=%s"\n' "$CATALOG_REF"
```

Kopiere diese eine ausgegebene Zeile anstelle der bisherigen `source`-Zeile im Block `unit "monitoring"`. Hinter `?ref=` muss eine vollständige 40-stellige Commit-ID stehen, nicht ein leerer Wert. `path = "monitoring"` bleibt unverändert. **Nicht** die globale Variable `tg_catalog_version` ändern.

### B. Zwei Eingaben innerhalb des vorhandenen values-Blocks ergänzen

Im `values = { ... }` **derselben Monitoring-Unit**, zum Beispiel direkt vor `dependencies_paths`, hinzufügen:

```hcl
    action_groups        = read_terragrunt_config("exception-alerts.hcl").locals.action_groups
    scheduled_log_alerts = read_terragrunt_config("exception-alerts.hcl").locals.scheduled_log_alerts
```

Alle vorhandenen Eingaben wie Name, Tags, Resource Group und `application_insights_enabled` bleiben stehen. Wenn dein neuerer Main hier bereits `action_groups` oder `scheduled_log_alerts` definiert, keine doppelten Attribute einfügen und keine bestehenden Einträge löschen: die neuen Einträge in die vorhandenen Maps integrieren. Das war im Upload noch nicht der Fall.

**Damit ist die Codeänderung im live-Repo fertig.** Die Katalog-Unit reicht beide Maps bereits an das Terraform-Modul durch. Weder `units/` noch `.gitlab-ci.yml` brauchen dafür eine Änderung.

### C. Prüfen, committen, pushen

```bash
git diff --check
git status --short
git diff -- live/test/terragrunt.stack.hcl
```

Erwartet: eine kleine Änderung an `live/test/terragrunt.stack.hcl` und die neue `live/test/exception-alerts.hcl`. Keine DEV-/PROD-Dateien, kein zusätzliches `live/live/...`, keine alte CI-Datei und kein `ump-exception-alerts`-Ordner.

```bash
git add live/test/terragrunt.stack.hcl live/test/exception-alerts.hcl
git diff --cached --check
git diff --cached --stat
git commit -m "DBI-6455: configure TEST OTel email alerts via catalog"
git push -u origin feat/DBI-6455-test-law-alerts
```

**Neuer MR im live:** `feat/DBI-6455-test-law-alerts` nach `main`. Timo als Reviewer eintragen.

**Titel:** `DBI-6455: TEST-Alarmierung über bestehenden Monitoring-Baustein`

**Beschreibung zum Kopieren:**

> Ersetzt den Ansatz aus !52 durch den bestehenden log-and-monitor-Baustein aus catalog. Nur die TEST-Monitoring-Unit wird auf den gemergten Katalog-Commit gepinnt. Konfiguriert werden eine Action Group für ui-team@os-cillation.de und eine Log-Alert-Regel für error/fatal in OTelLogs, aufgeteilt nach ServiceName. Prüfung jede Minute über ein Fünf-Minuten-Fenster, zustandsbehaftet mit automatischer Auflösung. Keine DEV-/PROD-, Gateway-/Storage- oder CI-Änderungen. Nach Review: main-Plan prüfen, TEST manuell bereitstellen und echten Alarm einschließlich E-Mail-Eingang abnehmen.

## 6. Plan und manuelles Deployment

Die vorhandene Pipeline berücksichtigt Änderungen unter `live/test/` bereits. Im Upload läuft `checkTestEnvironment` in der Featurebranch-Pipeline und `planTestEnvironment` in der MR-Pipeline. Nicht allein auf die Zahl der Pipelines im MR-Reiter verlassen.

Vor Merge den TEST-Plan prüfen. Aus dieser Konfiguration werden im vorhandenen **Monitoring-State** erwartet:

- eine Action Group: `log-ump-test-mag-osc-exceptions`;
- eine Log-Alert-Regel: `ump-test-otel-error-fatal`, Scope `log-ump-test`.

Bei vorher nicht vorhandenen Ressourcen sind das zwei Neuanlagen. Besteht inzwischen eine gleichnamige oder gleichwertige Alarmierung, zuerst Besitz/State und Doppelsendungen klären, nicht blind eine zweite Lösung anlegen. Vorhandene Action Groups dürfen durch die neuen Maps nicht verschwinden.

**Kein LAW, Application Insights, Storage oder Gateway darf für dieses Ticket gelöscht oder ersetzt werden.** Der Umgebungsplan kann auch anderen ausstehenden Drift zeigen: unerwartete Änderungen nicht mitanwenden, sondern mit Timo trennen.

Nach Review und Merge den **neuen `planTestEnvironment` auf main** prüfen. In genau dieser Pipeline **`applyTestEnvironment` manuell starten**, mit dem gespeicherten Plan. Sind die Plan-Artefakte abgelaufen, neu planen und prüfen; nicht zur Abkürzung ohne Plan anwenden.

Im Portal der TEST-Subscription im Workspace `log-ump-test` kontrollieren, ob die Regel aktiv ist. Mit Alex einen kontrollierten `error`/`fatal` aus der Anwendung erzeugen und die ganze Kette prüfen: Anwendung, `OTelLogs`, ausgelöster Alert, E-Mail bei `ui-team@os-cillation.de`. Danach auch die Auflösung prüfen. Der Action-Group-Testbutton allein ersetzt diesen End-to-End-Test nicht. `ServiceName` steht im Alarmkontext; ein bestimmter E-Mail-Betreff ist nicht zugesichert.

**Danach ist TEST abgenommen, nicht automatisch der gesamte erforderliche PROD-Rollout.**

## Kurze Nachricht an Timo

> Hi Timo, ich übernehme deinen Vorschlag und ersetze meinen bisherigen MR. Im catalog-Modul log-and-monitor richte ich die bestehenden Log-Alerts direkt auf den LAW aus und nutze die vorhandene Action-Group-Funktion. Danach ergänze ich nur die TEST-Konfiguration im live-Repo. Die Monitoring-Unit pinne ich auf den gemergten Katalog-Commit, die übrigen Units bleiben unverändert. Die beiden neuen MRs schicke ich dir zum Review. Danke dir!

## Quellen und Prüfstand

Basis: hochgeladenes `UMP_repos.zip`, `catalog` Commit `86bc6125155279f57688a9932717ca065eeb3cd5`, `live` Commit `dd42ccc2ffe0344e805fc80f06d9e76eea015ac6`, und Timos zuletzt gezeigte Nachricht. Das aktuelle GitLab-main wurde nicht live abgerufen; deshalb die Aktualisierung und der Vergleich vor dem Kopieren.

Das Modul liegt in diesem Quellstand **im catalog-Repo unter `modules/log-and-monitor`**. Die GitLab-Untergruppe `modules` ist nicht automatisch ein zusätzlich zu änderndes Repository. Die bestehende Unit `catalog/units/log-and-monitor/terragrunt.hcl` reicht `action_groups` und `scheduled_log_alerts` bereits weiter. Die Scope-Umstellung betrifft nur Log-Alerts; die App-Insights-Webtests bleiben unverändert. Allgemein sind App-Insights-Scopes nicht pauschal ungeeignet: Hier wird gezielt der Workspace mit der Tabelle `OTelLogs` verwendet.

Prüfstand dieses Pakets: Quellvergleich, strukturelle Kontrollen und Git-Neustart-/Kopierablauf in lokalen Test-Repositories. **Keine native Terraform-/Terragrunt-Validierung, kein Azure-Plan, kein Deployment und kein E-Mail-Test durchgeführt.** Diese Prüfungen erfolgen über eure Werkzeuge/Pipeline; die bereitgestellten Dateien sind kein Live-Abnahmebeleg.

Referenzen zum Nachlesen:

- GitLab: [MRs verwalten](https://docs.gitlab.com/user/project/merge_requests/manage/)
- Git: [Stash](https://git-scm.com/docs/git-stash), [Branches löschen](https://git-scm.com/docs/git-branch), [Branch wechseln](https://git-scm.com/docs/git-switch)
- Azure: [Log-Alerts](https://learn.microsoft.com/en-us/azure/azure-monitor/alerts/alerts-create-log-alert-rule), [OTelLogs-Schema](https://learn.microsoft.com/en-us/azure/azure-monitor/reference/tables/otellogs)
