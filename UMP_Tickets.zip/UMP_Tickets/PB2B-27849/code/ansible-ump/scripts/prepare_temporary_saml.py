#!/usr/bin/env python3
"""PB2B-27849: validate and stage temporary IdP metadata. No server is changed."""
from __future__ import annotations
import argparse
import base64
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import shutil
import ssl
import subprocess
import sys
from urllib.parse import urlsplit
from urllib.request import HTTPRedirectHandler, Request, build_opener
import xml.etree.ElementTree as ET

NS = {'md': 'urn:oasis:names:tc:SAML:2.0:metadata', 'ds': 'http://www.w3.org/2000/09/xmldsig#'}
POLICY = 'B2C_1A_signin_saml_ump_tmp'
TENANT = 'b2cunioninvestmentprod.onmicrosoft.com'
METADATA_URL = f'https://auth.user.union-investment.de/{TENANT}/{POLICY}/samlp/metadata'
IDP_ENTITY = f'https://b2cunioninvestmentprod.b2clogin.com/{TENANT}/{POLICY}'
SSO_URL = f'https://auth.user.union-investment.de/{TENANT}/{POLICY}/samlp/sso/login'
LIMIT = 1024 * 1024

class MetadataError(ValueError):
    pass

class NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None

def parse(data: bytes) -> ET.Element:
    if not data or len(data) > LIMIT or re.search(br'<!\s*(DOCTYPE|ENTITY)', data, flags=re.I):
        raise MetadataError('Empty, oversized or unsafe XML metadata.')
    root = ET.fromstring(data)
    if root.tag != '{' + NS['md'] + '}EntityDescriptor':
        raise MetadataError('Expected exactly one SAML EntityDescriptor, not HTML or a bundle.')
    if root.get('validUntil'):
        expires = datetime.fromisoformat(root.attrib['validUntil'].replace('Z', '+00:00'))
        if expires.tzinfo is None or expires <= datetime.now(timezone.utc):
            raise MetadataError('Metadata expired or its expiry lacks a timezone.')
    return root

def certificate_dates(der: bytes) -> dict:
    executable = shutil.which('openssl')
    if not executable:
        raise MetadataError('openssl is required to check signing-certificate validity.')
    result = subprocess.run([executable, 'x509', '-inform', 'DER', '-noout', '-startdate', '-enddate'],
                            input=der, capture_output=True, timeout=15, check=False)
    if result.returncode:
        raise MetadataError('Invalid X.509 signing certificate.')
    lines = dict(line.split('=', 1) for line in result.stdout.decode('ascii').splitlines() if '=' in line)
    start, end = (ssl.cert_time_to_seconds(lines[key]) for key in ('notBefore', 'notAfter'))
    timestamp = datetime.now(timezone.utc).timestamp()
    if not start <= timestamp < end:
        raise MetadataError('Signing certificate is expired or not yet valid.')
    return {'sha256': hashlib.sha256(der).hexdigest(), 'not_before': lines['notBefore'], 'not_after': lines['notAfter']}

def verify_idp(data: bytes) -> dict:
    root = parse(data)
    if root.get('entityID') != IDP_ENTITY:
        raise MetadataError('This is not the approved temporary IdP entity. Do not replace the normal IdP.')
    descriptor = root.find('md:IDPSSODescriptor', NS)
    if descriptor is None:
        raise MetadataError('IDPSSODescriptor missing.')
    endpoints = descriptor.findall('md:SingleSignOnService', NS)
    if not endpoints or any(x.get('Location') != SSO_URL for x in endpoints):
        raise MetadataError('SSO endpoint does not match the temporary PROD policy.')
    signing = [key for key in descriptor.findall('md:KeyDescriptor', NS) if key.get('use', 'signing') == 'signing']
    certificates = [node for key in signing for node in key.findall('.//ds:X509Certificate', NS)]
    if not certificates:
        raise MetadataError('No signing certificate in IdP metadata.')
    valid, rejected = [], []
    for node in certificates:
        try:
            der = base64.b64decode(re.sub(r'\s+', '', node.text or ''), validate=True)
            valid.append(certificate_dates(der))
        except (ValueError, OSError, subprocess.SubprocessError) as exc:
            rejected.append(str(exc))
    if not valid:
        raise MetadataError('No currently valid signing certificate: ' + '; '.join(rejected))
    return {'entity_id': root.attrib['entityID'], 'sso_url': SSO_URL, 'valid_signing_certificates': valid,
            'other_signing_certificate_warnings': rejected,
            'verification': 'HTTPS source, XML structure, exact endpoints and certificate dates; not an XML-signature trust-chain validation.'}

def verify_sp(data: bytes, entity: str, acs: str) -> dict:
    root = parse(data)
    for value in (entity, acs):
        url = urlsplit(value)
        if url.scheme != 'https' or not url.netloc or url.username or url.password or url.query or url.fragment:
            raise MetadataError('Expected an approved HTTPS entity/ACS URL without credentials or query parameters.')
    if urlsplit(entity).netloc != urlsplit(acs).netloc:
        raise MetadataError('SP entity and ACS URL belong to different hosts.')
    descriptor = root.find('md:SPSSODescriptor', NS)
    endpoints = [] if descriptor is None else descriptor.findall('md:AssertionConsumerService', NS)
    locations = [e.get('Location') for e in endpoints]
    if root.get('entityID') != entity or not locations or any(value != acs for value in locations):
        raise MetadataError('Active SP entity or ACS differs from the independently approved temporary application.')
    return {'entity_id': entity, 'acs_urls': locations}

def read_file(path: Path) -> bytes:
    if path.stat().st_size > LIMIT:
        raise MetadataError('Metadata exceeds the 1 MiB limit.')
    return path.read_bytes()

def fetch_metadata() -> bytes:
    request = Request(METADATA_URL, headers={'User-Agent': 'PB2B-27849-metadata-check/1.0'})
    with build_opener(NoRedirect()).open(request, timeout=30) as response:
        data = response.read(LIMIT + 1)
    if len(data) > LIMIT:
        raise MetadataError('Metadata response exceeds the 1 MiB limit.')
    return data

def prepare(args: argparse.Namespace) -> dict:
    repo = args.repo.resolve()
    if not (repo / 'host_vars' / 'ump-app').is_file():
        raise MetadataError('Please point --repo at the ansible-ump repository root.')
    def value(current, prompt):
        if current:
            return current
        if not sys.stdin.isatty():
            raise MetadataError('Missing required argument: ' + prompt)
        return input(prompt + ': ').strip()
    host = value(args.host, 'Confirmed inventory host of the TEMPORARY UMP')
    entity = value(args.entity_id, 'Entity ID confirmed by Oliver')
    acs = value(args.acs_url, 'ACS URL confirmed by Oliver')
    sp_path = Path(value(str(args.sp_metadata) if args.sp_metadata else None, 'Local copy of the ACTIVE temporary SP metadata XML'))
    if not re.fullmatch(r'[A-Za-z0-9_][A-Za-z0-9_.-]*', host):
        raise MetadataError('An exact single inventory hostname is required; no group or wildcard.')
    sp = verify_sp(read_file(sp_path), entity, acs)
    payload = fetch_metadata()
    idp = verify_idp(payload)
    destination = repo / 'playbooks/configuration/files/app/mellon/prod-temp/idp_metadata_azure.xml'
    if destination.exists() and destination.read_bytes() != payload and not args.replace:
        raise MetadataError('A different staged file already exists. Review it, then use --replace if intended.')
    destination.parent.mkdir(parents=True, exist_ok=True)
    if destination.exists() and destination.read_bytes() != payload:
        backup = destination.with_name(destination.name + '.bak-' + datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ'))
        shutil.copy2(destination, backup)
    temporary = destination.with_name(destination.name + '.tmp')
    temporary.write_bytes(payload)
    temporary.replace(destination)
    variables = {'temporary_ump_host': host, 'temporary_ump_entity_id': entity, 'temporary_ump_acs_url': acs,
                 'mellon_idp_metadata_source': 'files/app/mellon/prod-temp/idp_metadata_azure.xml'}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(variables, indent=2) + '\n', encoding='utf-8')
    return {'ticket': 'PB2B-27849', 'status': 'staged_locally_only', 'destination': str(destination),
            'extra_vars': str(args.output), 'sp': sp, 'idp': idp,
            'next': 'Use the guarded temporary playbook only after target confirmation. Nothing was sent to a server.'}

def main() -> int:
    cli = argparse.ArgumentParser(description=__doc__)
    commands = cli.add_subparsers(dest='command', required=True)
    stage = commands.add_parser('prepare')
    stage.add_argument('--repo', type=Path, default=Path(__file__).resolve().parents[1])
    stage.add_argument('--host')
    stage.add_argument('--entity-id')
    stage.add_argument('--acs-url')
    stage.add_argument('--sp-metadata', type=Path)
    stage.add_argument('--replace', action='store_true')
    stage.add_argument('--output', type=Path, default=Path('ergebnisse/temp-saml-vars.json'))
    idp = commands.add_parser('check-idp')
    idp.add_argument('file', type=Path)
    sp = commands.add_parser('check-sp')
    sp.add_argument('file', type=Path)
    sp.add_argument('--entity-id', required=True)
    sp.add_argument('--acs-url', required=True)
    args = cli.parse_args()
    try:
        if args.command == 'prepare':
            result = prepare(args)
        elif args.command == 'check-idp':
            result = verify_idp(read_file(args.file))
        else:
            result = verify_sp(read_file(args.file), args.entity_id, args.acs_url)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0
    except (OSError, ValueError, ET.ParseError, subprocess.SubprocessError) as error:
        print('ABBRUCH: ' + str(error), file=sys.stderr)
        return 2

if __name__ == '__main__':
    raise SystemExit(main())
