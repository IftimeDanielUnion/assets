# PB2B-27849: Temporären SAML-Login fertig anschließen

**Checkpoint: sicherer Vorbereitungs- und Deployment-Ablauf fertig programmiert. Aktiver Blocker ist die bestätigte Zuordnung der temporären Instanz.** Bei dadurch blockierten Migrationstests vorziehen; sonst nach Monitoring.

## Was bereits fertig ist

Ziel-Repository: **`ansible-ump`**. Vollständige Dateien liegen unter `code/ansible-ump`:

`prepare_temporary_saml.py` holt die echte temporäre IdP-Metadatendatei und prüft Policy, Adressen und gültige Signierzertifikate. Zusätzlich muss die aktive SP-Datei zur bestätigten Instanz passen. Unbekannte Werte werden abgefragt, nicht erfunden.

`mellon-temporary.yml` ist ein **separater**, nicht automatisch gestarteter Ansible-Ablauf: genau ein bestätigter Zielhost, explizite Freigabe, Backup der bestehenden Datei, Apache-Konfigurationstest und Rücknahme bei Fehler.

Die vollständige `host_vars/ump-app` enthält nur eine fachliche Änderung: eine optionale IdP-Dateiauswahl. Ohne diese spezielle Vorgabe bleibt die normale IdP-Datei unverändert.

**Nicht enthalten:** erfundene XML-Metadaten oder ein neuer Schlüssel. Der echte Metadatenabruf war hier nicht möglich. Die normale PROD-Datei wurde nicht ersetzt und die temporäre App nicht neu angelegt.

## 1. Oliver genau diese Zuordnung bestätigen lassen

> Hi Oliver, für PB2B-27849 habe ich den Ablauf für die temporären SAML-Metadaten vorbereitet. Bevor ich an der laufenden Instanz etwas ändere, brauche ich bitte die eindeutige Zuordnung: konkreter Ansible-Zielhost, öffentliche UMP-URL, SAML-Entity-ID und ACS-/Rücksprungadresse der temporären App. Soll dafür weiterhin `B2C_1A_signin_saml_ump_tmp` verwendet werden? Danach gleiche ich die aktive SP-Konfiguration ab und teste nur diese temporäre Instanz. Blockiert das aktuell eure Migrationstests? Danke dir!

Diese Werte sind ein echter Sicherheits-/Integrationsblocker, keine Aufgabe für die Urlaubenden. Eine normale PROD-Entity-ID darf nicht auf Verdacht zur temporären Instanz erklärt werden.

## 2. Dateien übernehmen, aktuelle SP-Datei besorgen

Code ins Repository übernehmen, wie in der Haupt-README. Von der **bestätigten temporären Instanz** eine lesende Kopie von `/etc/apache2/mellon/ump-app_metadata.xml` auf deinen Arbeitsrechner holen. Das ist öffentliche SP-Metadaten-XML, nicht der private Schlüssel. Den bereits eingerichteten administrativen Zugangsweg verwenden.

Dann im `ansible-ump`-Repository, beispielsweise in eurer Linux-/WSL-Ansible-Umgebung mit Python 3.10+ und OpenSSL:

```bash
python3 scripts/prepare_temporary_saml.py prepare --repo .
```

Das Werkzeug fragt die bestätigten Werte und den Pfad zur kopierten SP-Datei ab. Es erzeugt lokal:

```text
playbooks/configuration/files/app/mellon/prod-temp/idp_metadata_azure.xml
ergebnisse/temp-saml-vars.json
```

Noch kein Server wird geändert. Quelle ist die im Ticket genannte temporäre `_tmp`-Policy. Bei abweichender Policy/SSO-Adresse, ungültigen Zertifikaten oder falscher SP-Zuordnung bricht die Vorbereitung ab. Die XML-Prüfung ersetzt keine zusätzliche organisatorische Vertrauensfreigabe.

## 3. Inventory und normalen Deployment-Weg verwenden

Im Upload zeigt `ansible.cfg` standardmäßig auf ein lokales Inventory. Deshalb **nicht einfach den Default benutzen**. In der vorhandenen Ansible-Umgebung das richtige Inventory ausdrücklich wählen:

```bash
read -r -p 'Pfad zum bestätigten Inventory: ' INVENTORY
ansible-playbook -i "$INVENTORY" playbooks/configuration/mellon-temporary.yml --syntax-check
ansible-playbook -i "$INVENTORY" playbooks/configuration/mellon-temporary.yml \
  --extra-vars @ergebnisse/temp-saml-vars.json \
  --extra-vars 'temporary_ump_approved=true' --check --diff
```

Erst nach Review desselben eindeutig einzelnen Ziels tatsächlich ausführen:

```bash
ansible-playbook -i "$INVENTORY" playbooks/configuration/mellon-temporary.yml \
  --extra-vars @ergebnisse/temp-saml-vars.json \
  --extra-vars 'temporary_ump_approved=true'
```

Der Zielhost braucht Python 3.10+, Apache/Mellon und eure bestehende Ansible-Erreichbarkeit. Ein leeres/misslungenes Syntax-/Check-Ergebnis ist keine Freigabe. Eine grüne Apache-Prüfung beweist noch keinen funktionierenden SAML-Login.

Für spätere normale Konfigurationsläufe die ausgewählte `mellon_idp_metadata_source` **nur im bestätigten temporären Host-/Job-Kontext** hinterlegen. Nicht global auf reguläre PROD-Hosts übertragen, sonst würdet ihr deren normalen Login ändern. Ohne dauerhafte temporäre Zuordnung könnte ein späterer normaler Lauf die alte Auswahl wiederherstellen.

## 4. Login und Rückbau prüfen

Mit freigegebenem Testbenutzer die bestätigte temporäre URL öffnen, Login bis zur richtigen UMP-Instanz durchführen und den normalen Login separat gegenprüfen. Keine Assertions, Cookies oder privaten Schlüssel ins Jira kopieren.

Bei Ansible-Fehler versucht der Ablauf seine gerade erzeugte Sicherung wiederherzustellen. Bei erst später bemerktem Loginfehler die Sicherung über den kontrollierten Konfigurationsweg zurücknehmen; Backup-Pfad steht im Ansible-Ergebnis. Mit Oliver zusätzlich festlegen, wann die temporäre App und die spezielle Host-Zuordnung entfernt werden.

## Fertig, wenn

- [ ] Temporäre Instanz, Policy, Entity und ACS unabhängig bestätigt.
- [ ] Echte Metadaten geprüft; Ansible-Syntax-/Check-/Deploy-Lauf erfolgreich.
- [ ] Tatsächlicher temporärer Login funktioniert, normaler Login unverändert.
- [ ] Rückbauzeitpunkt und Konfigurationszuordnung im Jira dokumentiert.
