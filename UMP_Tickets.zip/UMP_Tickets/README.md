# UMP Tickets: Code und nächster Schritt

**Stand: 01.10.2026.** Du hast noch kein Ticket umgesetzt. Zeljko hast du DBI-12139 bereits zugesagt. Die Arbeiten unten wurden hier am hochgeladenen Quellcode vorbereitet und lokal geprüft, nicht in eurem Azure ausgerollt.

## 1. Alte Paketversion ersetzen

ZIP entpacken, den enthaltenen Ordner **`UMP_Tickets`** über deinen bisherigen gleichnamigen Ordner ziehen und in Windows **„Dateien im Ziel ersetzen“** wählen. Alle neun bisherigen Dateipfade sind enthalten und aktualisiert. Zusätzliche alte Dateien löscht Windows dabei nicht; maßgeblich sind ab jetzt diese README und die fünf Ticket-READMEs.

**Das aktualisiert zuerst nur deinen Arbeitsordner.** Für die eigentlichen Repositories liegen vollständige neue bzw. geänderte Dateien unter `TICKET/code/REPOSITORY/`. Keine Code-Patches nötig. Bereits vorhandene, unverändert richtige Infrastruktur wird nicht noch einmal als vermeintlich neue Lösung ausgeliefert.

## 2. Reihenfolge und aktueller Stand

| Reihenfolge | Ticket | Schon vorbereitet | Was jetzt wirklich fehlt |
|---|---|---|---|
| Jetzt | [DBI-12139](DBI-12139/README.md) | Bestehenden Aufbau aller Umgebungen geprüft; ausführbares Werkzeug für Inventar, Test-Upload, anonymen Download, große Medien und Aufräumen. | Azure-Ist-Stand und echte Erreichbarkeit prüfen. |
| Parallel anstoßen | [DBI-11149](DBI-11149/README.md) | Neuer UMP-Prüfbefehl ohne Auftragsbearbeitung; echter Public Key und Mail an Marc. | Schlüssel bei Lukas, bestätigter Host-Key, Test aus der UMP-Instanz. |
| Danach | [DBI-6455](DBI-6455/README.md) | Vollständiges Alert-Modul, Integration für drei Umgebungen und CI-Anpassung. TEST aktiviert vorgesehen, DEV/PROD zunächst deaktiviert. | Echte Logs, Terraform-/CI-Validierung, Plan und empfangene Testmail. |
| Danach, bei Migrationsblocker vorziehen | [PB2B-27849](PB2B-27849/README.md) | Metadatenprüfer und abgesicherter Ansible-Ablauf mit Backup/Rücknahme. | Oliver muss die temporäre Instanz zuordnen; echte Metadaten und Login prüfen. |
| Zuletzt | [DBI-7161](DBI-7161/README.md) | Eigenständiger Event-Grid-Infrastrukturbaustein mit Berechtigungen und Fehlerablage. Noch in keinem Live-Stack aktiv. | Schnittstellenvertrag, Identitäten, Netzwerkfreigabe und Anwendungsimplementierung. |

Die Reihenfolge ist ein Arbeitsvorschlag, keine neue offizielle Priorisierung. SFTP und Blob Storage sind im vorliegenden Stand beide Prio 1. Die Tickets bauen nicht zwingend aufeinander auf. Auf Timo, Marcel oder Christoph musst du für die beschriebenen Schritte nicht warten.

## 3. Code sicher in ein Repository übernehmen

**Pro Ticket einen eigenen Branch verwenden.** Beispielsweise im richtigen Repository:

```powershell
git status
git switch -c feat/DBI-12139-lp-assets
```

Zurück im Ordner `UMP_Tickets`:

```powershell
$repo = Read-Host 'Vollständiger Pfad zu deinem live-Repository'
py -3 .\uebernehmen.py --ticket DBI-12139 --ziel "$repo"
```

Das ist nur eine Vorschau. Sie prüft, ob die alten Dateien noch zum hochgeladenen Stand passen. Bei fremden Änderungen stoppt sie, statt sie zu überschreiben.

Danach entweder den **Inhalt** von `DBI-12139/code/live` in deinen `live`-Repository-Stamm ziehen, oder mit Sicherung kopieren lassen:

```powershell
py -3 .\uebernehmen.py --ticket DBI-12139 --ziel "$repo" --anwenden
```

Für die automatische Übernahme muss Git sauber sein; du bestätigst zusätzlich die Ticketnummer. Geänderte Dateien werden vorher unter `.git/ump-ticket-backups` gesichert. Kein Commit, Push oder Deployment wird ausgeführt. Danach `git diff` und `git status` prüfen, einschließlich neuer Dateien. Für andere Tickets deren Nummer und das in ihrer README genannte Repository verwenden.

**Bei einem neueren Checkout nicht blind ersetzen.** Die vollständigen Dateien basieren auf deinem Upload, nicht auf einem frisch gelesenen GitLab-Stand. Der Kopierhelfer ist genau dafür die Schutzschranke. Eigene Änderungen zuerst sichern bzw. fachlich zusammenführen.

## 4. Selbst nachprüfen

Python 3.10 oder neuer genügt für die Python-Werkzeuge; keine zusätzlichen Python-Pakete nötig. Unter Linux statt `py -3` einfach `python3` verwenden.

```powershell
py -3 .\pruefen.py
```

Für die PHP-Tests muss PHP vorhanden sein, sonst werden diese ausdrücklich übersprungen. Für die echten Azure-Prüfungen brauchst du separat Azure CLI und die passenden Rechte. Terraform, Ansible und das UMP-PHP-Laufzeitsystem bleiben eure vorhandenen Werkzeuge.

Die tatsächlichen Prüfergebnisse und Grenzen stehen in [PRUEFPROTOKOLL.md](PRUEFPROTOKOLL.md). Es wurde nichts an Zeljko, Marc, Alex, Oliver oder Sinan verschickt und kein Jira verändert.
