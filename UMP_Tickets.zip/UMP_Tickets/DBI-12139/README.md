# DBI-12139: Landingpage-Dateien öffentlich erreichbar machen

**Checkpoint: Quellcode geprüft, vollständige Prüfwerkzeuge fertig. Nächster Schritt ist der echte Azure-Abgleich.** Standalone, kein anderes Jira muss zuerst fertig werden.

## Was bereits erledigt ist

Der hochgeladene `live`-Stand enthält bereits die drei LP-Asset-Storages, getrennte Release-Container und Gateway-Routen. Der lokale Abgleich hat **48 Prüfungen über dev/test/prod bestanden**. Deshalb wurde kein zweiter Storage erfunden und die bestehende Infrastruktur nicht unnötig geändert.

Neu ist die vollständige Datei `code/live/scripts/lp_assets.py`. Sie prüft den Aufbau, kann eine neue synthetische Testdatei hochladen, den anonymen Abruf prüfen und ausschließlich ihre eigene Testdatei wieder entfernen. Für große vorhandene Medien liest sie nur kleine Ausschnitte vom Anfang und Ende.

**Wichtige Unterscheidung:** Die Release-Blobs sollen anonym lesbar sein. Der Storage-Netzwerkzugang bleibt aber privat und die Asset-Domain läuft über das Gateway. Dessen Listener ist im Snapshot ebenfalls privat. Ob die vorgeschaltete Veröffentlichung aus dem Internet funktioniert, beweist der Quellcode nicht. Nicht `publicNetworkAccess` öffnen, nur um den Test grün zu bekommen. Der alte Container `assets` bleibt privat.

## 1. Code übernehmen und Bestand lesen

Ziel-Repository: **`live`**. Übernahme wie in der Haupt-README. Danach im `live`-Repository, PowerShell:

```powershell
py -3 scripts/lp_assets.py source-check --repo . --output ergebnisse/quellcode.json
az login
py -3 scripts/lp_assets.py inventory --env all --output ergebnisse/inventar.json
```

Beide Befehle verändern keine Cloud-Ressource. `source-check` prüft den Code, `inventory` liest Azure. Subscription und Ressourcennamen kommen aus dem geprüften Upload. Ein Fehler wegen fehlender Leserechte ist **kein Beweis**, dass die Ressource fehlt.

Ohne Übernahme kannst du alternativ die bisherige Datei `check_lp_assets.ps1` verwenden; sie ruft jetzt das neue Werkzeug aus diesem Paket auf.

## 2. Nur echte Abweichungen bearbeiten

Die Ausgabe nennt für jede Umgebung die abweichende Einstellung. Bei identischem Ist-Stand ist **kein Terraform-Change erforderlich**. Bei einer Abweichung zuerst Ursache und Terraform-State prüfen. Keine außerhalb dieses Checkpoints erfundene Änderung ausrollen. Euren Plan/Review-Prozess benutzen, erst TEST, dann die übrigen Umgebungen.

Code-Einstiege: `live/{dev,test,prod}/terragrunt.stack.hcl`, jeweils `storage-assets`, und `appgateway.hcl`. Die öffentliche URL ist nicht einfach der Containername: beispielsweise `/uniglobal/` wird auf den Release-Container abgebildet.

## 3. Eine ungefährliche Testdatei verwenden

Nur nach bestandenem Inventarcheck und aus einem Netz mit Zugriff auf den Storage Private Endpoint:

```powershell
py -3 scripts/lp_assets.py upload-test --env test --campaign uniglobal --output-dir ergebnisse
```

Das fragt ausdrücklich nach `UPLOAD test`, schreibt eine neue 8-KiB-Datei und überschreibt kein Asset. Der Befehl gibt den Pfad zur Datei `upload.json` aus. Den **ganzen Belegordner samt `testdatei.txt`** auf den Rechner für den Abruf mitnehmen.

```powershell
$beleg = Read-Host 'Vollständiger Pfad zur ausgegebenen upload.json'
py -3 scripts/lp_assets.py probe --receipt "$beleg" --network extern
```

`extern` nur angeben, wenn der Test tatsächlich außerhalb des internen Zugangs/VPN läuft. Sonst `intern` verwenden. Die Angabe wird protokolliert, nicht automatisch bewiesen. Geprüft werden echter Inhalt, HTTP 200 und Range-Abruf mit HTTP 206. Eine Loginseite oder Weiterleitung zählt nicht als Erfolg.

Zum Eingrenzen aus dem internen Netz:

```powershell
py -3 scripts/lp_assets.py probe --receipt "$beleg" --network intern --endpoint blob-intern
```

Klappt intern der Blob, aber extern die Asset-Domain nicht, liegt die Lücke wahrscheinlich im vorgeschalteten DNS-/Ingress-/Gateway-Weg. Das ist dann gezielt mit dessen Betreiber zu klären, nicht durch pauschal öffentliche Storage-Netzwerke.

## 4. Ein wirklich großes Medium prüfen

Für ein bereits freigegebenes Medium im passenden Release-Container:

```powershell
$blob = Read-Host 'Vorhandener Blob-Pfad, z.B. videos/film.mp4, ohne Container und ohne URL'
py -3 scripts/lp_assets.py probe-media --env test --campaign uniglobal --blob "$blob" --network extern --min-size-mib 10 --output ergebnisse/medientest-test.json
```

Das prüft Anfang/Ende und Gesamtgröße, nicht das vollständige Abspielen. Zusätzlich im echten Landingpage-Browser prüfen. `--campaign` kennt `uniglobal`, `ve`, `zukunft`. Anschließend entsprechend für dev und prod sowie die tatsächlich benötigten Landingpages prüfen. Produktive Testuploads nur ausdrücklich freigegeben durchführen.

Aufräumen der eigenen Testdatei, wieder aus dem Netz mit Storage-Zugriff:

```powershell
py -3 scripts/lp_assets.py cleanup --receipt "$beleg"
```

Der Befehl verlangt `DELETE test` bzw. die passende Umgebung. Geprüft werden Marker und Dateiversion; fremde oder inzwischen geänderte Dateien werden nicht gelöscht. Soft-Delete-/Versionsreste richten sich weiterhin nach der Storage-Konfiguration.

## Nachricht an Zeljko: nur bei Bedarf als Zwischenstand

> Hi Zeljko, ich habe den Quellcode für DBI-12139 inzwischen abgeglichen. Die Storage- und Asset-Routen sind für dev, test und prod bereits vorgesehen; eine Neuanlage ist daher nicht mein erster Schritt. Ich habe die Prüfwerkzeuge vorbereitet und gleiche als Nächstes den Azure-Ist-Stand ab. Anschließend teste ich den anonymen Zugriff über die Asset-Domains, auch mit einem größeren Medium. Den erfolgreichen Live-Test melde ich dir separat.

Das beschreibt die hier geleistete Vorbereitung, nicht eine bereits erfolgte Azure-Prüfung. Du musst deine ursprüngliche Zusage nicht noch einmal senden.

## Fertig, wenn

- [ ] Azure-Ist-Stand aller drei Umgebungen geprüft; Abweichungen behoben oder konkret dokumentiert.
- [ ] Benötigte Asset-Routen ohne Login erreichbar; Netzwerkstandort und HTTP-Ergebnisse protokolliert.
- [ ] Ein freigegebenes großes Medium und dessen tatsächliche Landingpage erfolgreich getestet.
- [ ] Eigene Testdateien bereinigt und Ergebnisse im Jira dokumentiert.
