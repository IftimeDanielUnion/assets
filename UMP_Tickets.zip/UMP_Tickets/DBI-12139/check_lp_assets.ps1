param(
    [ValidateSet('dev', 'test', 'prod', 'all')]
    [string]$Environment = 'all',
    [string]$RepositoryPath = ''
)
$ErrorActionPreference = 'Stop'
$script = Join-Path $PSScriptRoot 'code\live\scripts\lp_assets.py'
if (-not (Test-Path -LiteralPath $script -PathType Leaf)) {
    throw 'lp_assets.py fehlt. Bitte die gesamte neue ZIP entpacken, nicht nur diese Datei.'
}
$arguments = @($script)
if ($RepositoryPath) {
    $arguments += @('source-check', '--repo', $RepositoryPath, '--output', (Join-Path $PSScriptRoot 'ergebnisse\quellcode.json'))
} else {
    $arguments += @('inventory', '--env', $Environment, '--output', (Join-Path $PSScriptRoot 'ergebnisse\inventar.json'))
}
if (Get-Command py -ErrorAction SilentlyContinue) {
    & py -3 @arguments
} elseif (Get-Command python -ErrorAction SilentlyContinue) {
    & python @arguments
} else {
    throw 'Python 3.10 oder neuer fehlt. Es sind keine zusaetzlichen Python-Pakete noetig.'
}
exit $LASTEXITCODE
