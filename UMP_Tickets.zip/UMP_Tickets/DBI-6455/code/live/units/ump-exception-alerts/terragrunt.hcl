include "root" {
  path = find_in_parent_folders("root.hcl")
}

terragrunt_version_constraint = ">= 1.1"

terraform {
  source = "${get_repo_root()}/modules/ump-exception-alerts"
}

dependency "monitoring" {
  config_path = "${get_terragrunt_dir()}/${values.monitoring_path}"
  # A real plan must read the real existing workspace. Never use a mock during apply.
  mock_outputs = {
    resource_id = "/subscriptions/00000000-0000-0000-0000-000000000000/resourceGroups/validation-only/providers/Microsoft.OperationalInsights/workspaces/validation-only"
  }
  mock_outputs_allowed_terraform_commands = ["validate"]
}

inputs = {
  environment           = values.environment
  location              = values.location
  resource_group_name   = values.resource_group_name
  workspace_resource_id = dependency.monitoring.outputs.resource_id
  enabled               = values.enabled
  email_address         = "ui-team@os-cillation.de"
  tags                  = values.tags
}
