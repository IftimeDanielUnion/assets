# DBI-6455. The provider and HTTP state backend are supplied by live/root.hcl.
# This unit owns alerts only; it does not replace the existing monitoring stack.
variable "environment" {
  type = string
  validation {
    condition     = contains(["dev", "test", "prod"], var.environment)
    error_message = "environment must be dev, test or prod."
  }
}
variable "location" {
  type = string
}
variable "resource_group_name" {
  type = string
}
variable "workspace_resource_id" {
  type = string
  validation {
    condition     = can(regex("(?i)^/subscriptions/[^/]+/resourceGroups/[^/]+/providers/Microsoft.OperationalInsights/workspaces/[^/]+$", var.workspace_resource_id))
    error_message = "Expected the ARM resource ID of the existing Log Analytics workspace, not its customer ID or Application Insights ID."
  }
}
variable "enabled" {
  type    = bool
  default = false
}
variable "email_address" {
  type    = string
  default = "ui-team@os-cillation.de"
  validation {
    condition     = can(regex("^[^ @]+@[^ @]+\\.[^ @]+$", var.email_address))
    error_message = "A valid recipient email address is required."
  }
}
variable "tags" {
  type    = map(string)
  default = {}
}

locals {
  alert_query = <<-KQL
    OTelLogs
    | where SeverityText in~ ("error", "fatal")
    | extend ServiceName = iff(isempty(ServiceName), "unknown-service", ServiceName)
    | project TimeGenerated, ServiceName
  KQL
}

resource "azurerm_monitor_action_group" "osc" {
  name                = "ag-ump-${var.environment}-exceptions"
  resource_group_name = var.resource_group_name
  short_name          = "ump-${var.environment}"
  tags                = var.tags

  email_receiver {
    name                    = "osc-ui-team"
    email_address           = var.email_address
    use_common_alert_schema = true
  }
}

resource "azurerm_monitor_scheduled_query_rules_alert_v2" "exceptions" {
  name                = "ump-${var.environment}-otel-error-fatal"
  display_name        = "UMP ${upper(var.environment)} error/fatal"
  resource_group_name = var.resource_group_name
  location            = var.location
  # OTelLogs lives in Log Analytics. Do not depend on the App Insights resource filter.
  scopes              = [var.workspace_resource_id]
  description         = "DBI-6455: error/fatal in OTelLogs, split by ServiceName. Stateful: one notification per firing, not per log record."
  enabled             = var.enabled
  severity            = 1
  evaluation_frequency = "PT1M"
  window_duration      = "PT5M"
  auto_mitigation_enabled = true
  skip_query_validation   = false
  tags                    = var.tags

  criteria {
    query                   = local.alert_query
    time_aggregation_method = "Count"
    operator                = "GreaterThan"
    threshold               = 0
    dimension {
      name     = "ServiceName"
      operator = "Include"
      values   = ["*"]
    }
    failing_periods {
      minimum_failing_periods_to_trigger_alert = 1
      number_of_evaluation_periods             = 1
    }
  }
  action {
    action_groups = [azurerm_monitor_action_group.osc.id]
  }
}

output "alert_resource_id" {
  value = azurerm_monitor_scheduled_query_rules_alert_v2.exceptions.id
}
output "action_group_resource_id" {
  value = azurerm_monitor_action_group.osc.id
}
output "query" {
  value = local.alert_query
}
