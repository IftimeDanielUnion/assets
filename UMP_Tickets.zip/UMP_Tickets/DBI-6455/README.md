# DBI-6455: Fehlermails aus dem vorhandenen Monitoring

**Checkpoint: vollständiger Infrastruktur-Code plus Integration und CI-Anpassung vorbereitet. Native Terraform-Prüfung und Mailtest stehen aus.** Standalone; kein anderes Jira muss fertig sein.

## Was fertig programmiert ist

Ziel-Repository: **`live`**. Unter `code/live` liegen vollständige Dateien, nicht nur ein Patch:

- eigenes Modul `modules/ump-exception-alerts/main.tf` mit Mail-Empfänger und Fehlerregel;
- lokale Terragrunt-Unit `units/ump-exception-alerts/terragrunt.hcl`;
- die drei vollständigen `live/{dev,test,prod}/terragrunt.stack.hcl` mit zusätzlicher Unit `exception-alerts`;
- `.gitlab-ci.yml`, damit auch spätere Änderungen am lokalen Modul Prüf-/Planjobs auslösen.

Das ergänzt das vorhandene Monitoring in einem eigenen State-Bereich. Keine neue `catalog`-Veröffentlichung nötig, bestehende Monitoring-Ressourcen werden nicht übernommen oder verschoben.

**TEST-Regel: eingeschaltet vorgesehen. DEV/PROD: vorerst ausgeschaltet.** Die Action Groups bzw. deaktivierten Regeln würden beim späteren jeweiligen Apply dennoch angelegt. Hier wurde nichts ausgerollt. Ein Apply des ganzen Stacks kann auch andere ausstehende Änderungen enthalten, deshalb den vollständigen Plan prüfen.

Die Regel liest `OTelLogs` direkt im vorhandenen **Log-Analytics-Workspace**, nicht über den bisherigen fest verdrahteten Application-Insights-Scope. Sie erfasst `error`/`fatal`, trennt nach `ServiceName` und mailt an `ui-team@os-cillation.de`.

## 1. Zuerst echte Logs prüfen

In Azure den zum TEST-Monitoring gehörenden **Log Analytics Workspace**, dann „Logs“ öffnen:

```kusto
OTelLogs
| where TimeGenerated > ago(24h)
| summarize Records = count(), Latest = max(TimeGenerated)
    by ServiceName, SeverityText
| order by Latest desc
```

Erwartung: aktuelle Daten, sinnvolle Service-Namen und passende Severity-Werte. Fehlt die Tabelle oder kommen keine Daten an, ist die vorhandene OTEL-Strecke zuerst zu prüfen. Die neue Regel erfindet keine Datenquelle. Außerdem prüfen, ob außerhalb des IaC bereits eine gleichartige Alarmierung existiert, um doppelte Mails zu vermeiden.

## 2. Vollständige Dateien übernehmen und prüfen

Branch im `live`-Repo: `feat/DBI-6455-exception-alerts`. Übernahme mit `uebernehmen.py` wie in der Haupt-README. Bei abweichenden Originaldateien stoppen und zusammenführen, nicht fremde Änderungen ersetzen.

Im Paketordner kannst du zusätzlich zur lokalen Testsuite die beiden neuen Module isoliert mit dem installierten Terraform prüfen:

```powershell
py -3 .\pruefen.py --terraform
```

Dafür wird Terraform 1.13.x benötigt, im Upload ist 1.13.4 festgelegt. Der Befehl lädt passende Provider in temporäre Ordner und führt `init -backend=false` und `validate` aus. Kein Plan/Apply und kein Azure-Deployment. Ohne Terraform meldet er den fehlenden Prüfschritt ausdrücklich.

Danach euren vorhandenen Feature-Branch-/Merge-Request-Prozess verwenden: Terragrunt-Generierung, Eingabeprüfung, echter TEST-Plan, Review, manuelles Apply. Die neue Unit muss den echten Workspace aus dem bestehenden Monitoring-State lesen; Mock-Werte sind nur bei `validate`, nicht bei `plan`/`apply` erlaubt.

Die alte Datei `monitoring-test.patch` wurde absichtlich durch einen Nicht-Patch-Hinweis ersetzt. **Nicht zusätzlich zur neuen Lösung anwenden.** Sie liegt nur zur sicheren Überschreibung des alten Pakets bei.

## 3. Mit Alex Ende-zu-Ende testen

> Hi Alex, ich habe für DBI-6455 die fehlende Mail-Alarmierung auf dem vorhandenen Monitoring vorbereitet. Die Regel wertet `error`/`fatal` je Service aus und schickt an `ui-team@os-cillation.de`. Nach Prüfung und Bereitstellung in TEST würde ich gern mit dir einen kontrollierten Fehler auslösen und den Mail-Eingang bestätigen. Welchen Testfall können wir dafür verwenden? Danke dir!

Die Regel prüft jede Minute ein Fünf-Minuten-Fenster. Sie ist zustandsbehaftet: **nicht jede einzelne Logzeile erzeugt eine neue Mail**. Pro aktivem Service-Alarm gibt es eine Auslösung; nach Ende des Fehlers kann der Zustand wieder aufgelöst werden. Falls fachlich jede Fehlermeldung einzeln benötigt wird, muss das vorher anders abgestimmt werden.

`ServiceName` steckt in den Alarmdimensionen. Ein frei gestalteter Mail-Betreff mit diesem Wert ist durch die native Action Group **nicht zugesichert**. Das war im Ticket als Wunsch formuliert und muss mit der tatsächlich empfangenen Mail geprüft werden.

## 4. DEV und PROD danach gezielt aktivieren

Nach erfolgreichem TEST dieselben Logs in DEV/PROD prüfen. In der neuen Unit `exception-alerts` der jeweiligen Stackdatei `enabled = true` setzen und separat planen/freigeben. Nicht die vorhandene Unit `monitoring` verändern. Bei zu vielen Fehlalarmen erst die neue Regel deaktivieren, nicht OTEL oder das gesamte Monitoring abschalten.

## Fertig, wenn

- [ ] Echte OTelLogs geprüft, Terraform/CI-Validierung und Plan bestanden.
- [ ] Kontrollierter Fehler löst den richtigen Service-Alarm aus; Mail-Eingang bestätigt.
- [ ] Gewünschte Umgebungen freigegeben und aktiviert; Alarmverhalten abgestimmt.
- [ ] Testergebnis im Jira dokumentiert. Ein grüner Apply allein reicht nicht.
