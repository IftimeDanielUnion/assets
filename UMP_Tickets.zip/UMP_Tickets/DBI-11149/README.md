# DBI-11149: Lukas-SFTP-Verbindung

**Checkpoint: Public Key liegt bei; neuer lesender UMP-Prüfbefehl fertig. Noch kein Gegenstellentest.** Unabhängig von den anderen Jiras. Die externe Anfrage parallel zu DBI-12139 anstoßen.

## Was bereits erledigt ist

Der echte MBO-Export verwendet im hochgeladenen Kern OpenSSH/SFTP. Es wurde deshalb ein neuer Symfony-Befehl geschrieben, der **dieselben fünf UMP-Konfigurationswerte** liest. Er verändert keine Aufträge, erzeugt keine Exportdateien und lädt nichts hoch.

Vollständige Dateien liegen unter `code/unioninvestment/htdocs/src/Console/Command/Diagnostics/`. Ziel-Repository: **`unioninvestment`**. Keine bestehende Exportklasse wird ersetzt. PHP-Syntax und die isolierte Prüflogik wurden lokal getestet; Start im vollständigen UMP-Container noch nicht.

## 1. Diese Mail zuerst an Marc

**An:** Marc Hintz, `hintz@msu.biz`  
**Betreff:** DBI-11149: Lukas PROD, zusätzlichen Public Key prüfen  
**Anhang:** `azure-lukas-sftp-prod.pub` aus diesem Ordner

> Hallo Marc,
>
> ich übernehme DBI-11149 und würde den offenen Lukas-SFTP-Zugang gern direkt mit dir abschließen. Kannst du bitte prüfen, ob der angehängte öffentliche Schlüssel bei euch bereits hinterlegt ist? Falls nicht, bitte zusätzlich hinterlegen; der bisherige Schlüssel soll bestehen bleiben.
>
> Im bisherigen Stand stehen `lukaspartner.msu.biz` und der Benutzer `UI_marketing`. Kannst du Host, Port und Benutzer kurz bestätigen und mir das Zielverzeichnis sowie den aktuellen SSH-Host-Key-Fingerabdruck über unseren abgestimmten Kontaktweg nennen? Ich prüfe danach zunächst nur Anmeldung und Verzeichniszugriff, ohne Dateien zu übertragen.
>
> Danke dir!

Nur den beiliegenden **öffentlichen** Schlüssel anhängen. Er wurde gegen den Fingerabdruck aus dem bisherigen Ticketstand geprüft:

```text
SHA256:dnNfJ61wYm8HJzH+x+DLgIvcREFPbmZUXdMVjJPvXV8
```

Danach nicht warten, sondern an DBI-12139 weiterarbeiten.

## 2. Den Prüfbefehl bereitstellen

Code wie in der Haupt-README in `unioninvestment` übernehmen, prüfen und über euren normalen UMP-Deployment-Weg zunächst in den passenden Testkontext bringen. Das Kopieren auf deinen Laptop allein installiert keinen Befehl auf dem Server. Symfony-Cache/Container über den normalen Deployment-Prozess erneuern.

Auf der UMP-Instanz, im Verzeichnis mit `bin/console`, mit dem tatsächlichen PHP der UMP und als App-Benutzer:

```bash
sudo -u www-data php bin/console app:diagnostics:mbo-sftp
```

Zuerst sicherstellen, dass `php` auf eure freigegebene UMP-PHP-Version zeigt. Das Repository verlangt PHP 8.5; hier war nur eine PHP-8.4-Syntaxprüfung möglich.

Ohne Option zeigt der Befehl Host/Port/Benutzer/Schlüsselpfad/Verzeichnis und den Fingerabdruck des konfigurierten Client-Schlüssels. **Keine Netzwerkverbindung.** Private Schlüsselinhalte werden nicht ausgegeben.

## 3. Anmeldung und Verzeichnis prüfen

Erst wenn Marc die Zuordnung bestätigt hat und der Server-Host-Key unabhängig geprüft und im gültigen `known_hosts` des App-Kontexts vorhanden ist:

```bash
sudo -u www-data php bin/console app:diagnostics:mbo-sftp --connect
```

Der Befehl bricht ab, wenn Host oder Client-Schlüssel nicht zum bestätigten Lukas-Stand passen. Er führt ausschließlich `pwd`, `cd` in das konfigurierte Verzeichnis, `pwd`, `bye` aus. Ein unbekannter Server-Host-Key wird **nicht automatisch akzeptiert**.

Timeout bedeutet eher Netzwerk/Port; `Permission denied` eher Benutzer/Client-Key; `no matching host key type` betrifft den Server-Algorithmus. Client-Key und Server-Host-Key nicht verwechseln.

Nur wenn ausschließlich das im Ticket bekannte alte RSA-Verfahren übrig bleibt und diese Ausnahme abgestimmt ist:

```bash
sudo -u www-data php bin/console app:diagnostics:mbo-sftp --connect --allow-legacy-rsa
```

Das erlaubt RSA/SHA-1 nur für diesen einen Prozess, verändert keine globale SSH-Konfiguration und schaltet die Host-Prüfung nicht ab. Der produktive Export wird dadurch noch nicht automatisch umkonfiguriert.

## 4. Erst danach Anwendungstest mit Alex

> Hi Alex, für DBI-11149 ist ein eigener UMP-Prüfbefehl vorbereitet, der die echten MBO-Verbindungsdaten nutzt, aber keine Aufträge exportiert. Sobald Anmeldung und Verzeichniszugriff funktionieren, brauche ich für die fachliche Abnahme einen von dir freigegebenen Testauftrag bzw. Testablauf. Welchen können wir dafür verwenden? Einen produktiven Export möchte ich nicht als Verbindungstest starten. Danke dir!

**`app:export:mbo` nicht zur Diagnose verwenden.** Der vorhandene Befehl verarbeitet reale Aufträge und überträgt Dateien. Der neue Diagnosebefehl behebt bewusst nicht ungemessene Netzwerk-/Gegenstellenfehler.

## Fertig, wenn

- [ ] Marc hat Key, Ziel und Host-Key bestätigt.
- [ ] Neuer Befehl startet in der tatsächlichen UMP-Laufzeit; Anmeldung und Zielverzeichnis funktionieren.
- [ ] Freigegebener Anwendungstest erfolgreich; eventuell weitere SFTP-Ziele separat geprüft.
- [ ] Ergebnis und verbleibende Firewall-/Kompatibilitätspunkte im Jira dokumentiert.
