<?php

declare(strict_types=1);

namespace App\Console\Command\Diagnostics;

use Symfony\Component\Console\Attribute\AsCommand;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Output\OutputInterface;
use Symfony\Component\Console\Style\SymfonyStyle;
use Symfony\Component\DependencyInjection\ParameterBag\ContainerBagInterface;
use Symfony\Component\Process\Process;
use Throwable;

#[AsCommand(name: 'app:diagnostics:mbo-sftp', description: 'DBI-11149: Read effective MBO settings; optionally test SFTP login and cd, never export.')]
final class MboSftpCheckCommand extends Command
{
    public function __construct(private readonly ContainerBagInterface $parameters)
    {
        parent::__construct();
    }

    protected function configure(): void
    {
        $this->addOption('connect', null, InputOption::VALUE_NONE, 'Actually connect. Default: inspect local settings and key only.')
            ->addOption('expected-host', null, InputOption::VALUE_REQUIRED, 'Independently confirmed destination host.', 'lukaspartner.msu.biz')
            ->addOption('expected-client-fingerprint', null, InputOption::VALUE_REQUIRED, 'Approved client public-key fingerprint.', MboSftpProbe::EXPECTED_CLIENT_FINGERPRINT)
            ->addOption('allow-legacy-rsa', null, InputOption::VALUE_NONE, 'Explicit RSA/SHA-1 exception for this one connection only.');
    }

    protected function execute(InputInterface $input, OutputInterface $output): int
    {
        $io = new SymfonyStyle($input, $output);
        try {
            $config = MboSftpProbe::validate([
                'host' => $this->parameters->get('mboExportServerHost'),
                'port' => $this->parameters->get('mboExportServerPort'),
                'user' => $this->parameters->get('mboExportServerUser'),
                'key' => $this->parameters->get('mboExportServerAuthKeyPath'),
                'directory' => $this->parameters->get('mboExportServerRemoteDir'),
            ]);
            $io->definitionList(...array_map(static fn ($k) => [$k => (string) $config[$k]], array_keys($config)));
            if (!is_file($config['key']) || !is_readable($config['key'])) {
                $io->error('The configured private key is not readable by this OS user. Nothing was connected.');
                return Command::FAILURE;
            }
            // -P '' avoids prompting for a passphrase in a background process.
            $key = new Process(['ssh-keygen', '-y', '-P', '', '-f', $config['key']], timeout: 15);
            $key->run();
            if (!$key->isSuccessful()) {
                $io->error('ssh-keygen could not read the key. Check permissions/key format/passphrase. No key contents are printed.');
                return Command::FAILURE;
            }
            $fingerprint = MboSftpProbe::fingerprint($key->getOutput());
            $io->writeln('Configured CLIENT public-key fingerprint: ' . $fingerprint);
            $io->note('This is not the remote SERVER host-key fingerprint. StrictHostKeyChecking stays enabled.');
            if (!$input->getOption('connect')) {
                $io->success('Local inspection complete. No network connection, no order export.');
                return Command::SUCCESS;
            }
            if (!hash_equals(strtolower((string) $input->getOption('expected-host')), strtolower($config['host']))) {
                $io->error('Configured destination differs from --expected-host. Confirm the correct destination first.');
                return Command::INVALID;
            }
            if (!hash_equals((string) $input->getOption('expected-client-fingerprint'), $fingerprint)) {
                $io->error('Configured private key does not match the approved client public-key fingerprint.');
                return Command::INVALID;
            }
            $legacy = (bool) $input->getOption('allow-legacy-rsa');
            if ($legacy) {
                $io->warning('Explicit one-process RSA/SHA-1 compatibility exception. No global SSH settings are changed.');
            }
            $process = new Process(MboSftpProbe::argv($config, $legacy), timeout: 60);
            $process->setInput(MboSftpProbe::batch($config));
            $process->run();
            $io->write($process->getOutput(), false, OutputInterface::OUTPUT_RAW);
            if (!$process->isSuccessful()) {
                $io->write($process->getErrorOutput(), false, OutputInterface::OUTPUT_RAW);
                $io->error('SFTP login/directory test failed. No remote writes were requested.');
                return Command::FAILURE;
            }
            $io->success('SFTP login and configured target directory succeeded. No upload, no order export.');
            return Command::SUCCESS;
        } catch (Throwable $error) {
            $io->error($error->getMessage());
            return Command::FAILURE;
        }
    }
}
