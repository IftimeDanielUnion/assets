<?php

declare(strict_types=1);

namespace App\Console\Command\Diagnostics;

use InvalidArgumentException;

/** Pure argument construction. Does not connect, export orders or write remote files. */
final class MboSftpProbe
{
    public const EXPECTED_CLIENT_FINGERPRINT = 'SHA256:dnNfJ61wYm8HJzH+x+DLgIvcREFPbmZUXdMVjJPvXV8';

    public static function validate(array $config): array
    {
        foreach (['host', 'user', 'key', 'directory'] as $key) {
            if (!isset($config[$key]) || !is_string($config[$key]) || $config[$key] === ''
                || preg_match('/[\x00-\x1f\x7f]/', $config[$key])) {
                throw new InvalidArgumentException("Invalid or missing MBO setting: {$key}");
            }
        }
        if (!preg_match('/^[A-Za-z0-9][A-Za-z0-9.-]*$/D', $config['host'])
            || !preg_match('/^[A-Za-z0-9_][A-Za-z0-9_.-]*$/D', $config['user'])
            || str_starts_with($config['directory'], '-')) {
            throw new InvalidArgumentException('Invalid host, user or directory.');
        }
        $rawPort = $config['port'] ?? '';
        $config['port'] = ($rawPort === '' || $rawPort === null) ? 22 : filter_var($rawPort, FILTER_VALIDATE_INT);
        if ($config['port'] === false || $config['port'] < 1 || $config['port'] > 65535) {
            throw new InvalidArgumentException('The SFTP port must be between 1 and 65535.');
        }
        return $config;
    }

    public static function argv(array $config, bool $legacyRsa = false): array
    {
        $c = self::validate($config);
        $args = ['sftp', '-b', '-', '-oBatchMode=yes', '-oPasswordAuthentication=no',
            '-oKbdInteractiveAuthentication=no', '-oNumberOfPasswordPrompts=0',
            '-oIdentitiesOnly=yes', '-oIdentityAgent=none', '-oStrictHostKeyChecking=yes',
            '-oConnectTimeout=15', '-oConnectionAttempts=1', '-oServerAliveInterval=10',
            '-oServerAliveCountMax=2', '-i', $c['key'], '-P', (string) $c['port']];
        if ($legacyRsa) {
            // Explicit one-process exception. Does not change ~/.ssh/config or sshd.
            $args[] = '-oHostKeyAlgorithms=+ssh-rsa';
            $args[] = '-oPubkeyAcceptedAlgorithms=+ssh-rsa';
        }
        $args[] = $c['user'] . '@' . $c['host'];
        return $args;
    }

    public static function batch(array $config): string
    {
        $c = self::validate($config);
        $path = str_replace(['\\', '"'], ['\\\\', '\\"'], $c['directory']);
        return "pwd\ncd \"{$path}\"\npwd\nbye\n";
    }

    public static function fingerprint(string $publicKey): string
    {
        $parts = preg_split('/\s+/', trim($publicKey));
        if (count($parts) < 2 || !in_array($parts[0], ['ssh-rsa', 'ssh-ed25519', 'ecdsa-sha2-nistp256', 'ecdsa-sha2-nistp384', 'ecdsa-sha2-nistp521'], true)) {
            throw new InvalidArgumentException('No supported public key returned by ssh-keygen.');
        }
        $blob = base64_decode($parts[1], true);
        if ($blob === false || strlen($blob) < 8) {
            throw new InvalidArgumentException('Invalid public key encoding.');
        }
        return 'SHA256:' . rtrim(base64_encode(hash('sha256', $blob, true)), '=');
    }
}
