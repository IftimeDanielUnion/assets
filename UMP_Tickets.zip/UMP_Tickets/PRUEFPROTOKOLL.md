# Prüfprotokoll und Grenzen

**Erstellt am 01.10.2026.** Dieses Dokument trennt tatsächlich ausgeführte lokale Prüfungen von noch fehlender Laufzeitabnahme. Originalquellen: dein `UMP_repos.zip`, die vier Jira-Exporte in `ump_jiras.zip`, der Screenshot zu DBI-12139 und deine Angabe, dass noch kein Ticket von dir gestartet wurde.

## Tatsächlich ausgeführt

| Prüfung | Ergebnis |
|---|---|
| Python-Testsuite für Asset-Werkzeug, SAML-Prüfung, Übernahmehilfe und Code-Verträge; darin auch PHP-Helfertests | **76 Tests bestanden, keine Fehler, keine übersprungenen Tests.** Azure/HTTP werden in den entsprechenden Tests simuliert. |
| DBI-12139 gegen den tatsächlich extrahierten `live`-Quellcode | **48 Strukturprüfungen über dev/test/prod bestanden.** Keine Terraform-Semantikprüfung. |
| Übernahmehilfe in fünf neu angelegten temporären Git-Repositories mit den jeweiligen Originaldateien | **Alle fünf Ticket-Übernahmen bestanden.** Neue Inhalte bytegenau geprüft; alte Inhalte gesichert; erneuter Aufruf erkennt bereits aktuelle Dateien. |
| Paketmanifest | **14 vollständige Repository-Code-Dateien** einschließlich Original-/Neu-Prüfsummen erfasst und geprüft. |
| PHP-Syntax und isolierte PHP-Prüflogik | Beide neuen PHP-Dateien linten erfolgreich unter **PHP 8.4.23**; keine vollständige Symfony-/PHP-8.5-Anwendungsabnahme. |
| YAML-Parsing | GitLab-CI-Datei, Ansible-Hostvariablen und temporäres Playbook gelesen. Keine native Ansible- oder GitLab-CI-Validierung. |
| Lukas-Public-Key | RSA-Public-Key und erwarteter SHA256-Fingerabdruck geprüft. Kein privater Schlüssel ausgeliefert. |
| Original-/Neu-Diff | Monitoring-Stacks nur um neue Unit ergänzt; CI nur um Auslöser für lokale Moduländerungen ergänzt; Ansible-Hostdatei nur um optionale IdP-Auswahl ergänzt. |

Die Tests und der Runner liegen unter `tests/test_ticketcode.py` und `pruefen.py`. Die Kopiertests wurden zusätzlich gegen Kopien des hochgeladenen Originalstands ausgeführt. Die Ergebniszusammenfassung und Quellcode-Prüfdetails sind in `paket.json` enthalten.

## Bewusst nicht als erledigt ausgegeben

**Kein Terraform-/Terragrunt-Programm war hier installiert.** Deshalb kein natives `terraform validate`, keine Provider-Schemaprüfung, kein Terragrunt-Stack-Generate und kein echter Plan/Apply. Die mitgelieferte Option `pruefen.py --terraform` kann die neuen Module anschließend mit installiertem Terraform isoliert validieren; sie ersetzt noch keinen Plan gegen euren State.

**Kein Ansible-/PowerShell-Programm war hier installiert.** Die Python-Unterprogramme und das YAML wurden lokal geprüft, aber weder das Playbook noch der Windows-Wrapper in ihren tatsächlichen Laufzeiten ausgeführt.

**Keine angemeldete Azure-/UMP-/Lukas-Verbindung lag vor.** Daher keine Azure-Bestandsaufnahme, kein echter Upload/Downloadtest über die Asset-Domain, keine E-Mail, keine SFTP-Anmeldung, kein SAML-Login und keine Event-Grid-Zustellung. Der echte temporäre IdP-Metadatenabruf war hier ebenfalls nicht möglich; es liegt absichtlich keine erfundene XML-Datei bei.

Die Tests beweisen die geprüften lokalen Eigenschaften, nicht die Erfüllung sämtlicher Jira-Akzeptanzkriterien.

## Welche Quellstände verwendet wurden

| Repository | Git-Stand im Upload |
|---|---|
| `live` | `dd42ccc2ffe0344e805fc80f06d9e76eea015ac6` |
| `catalog` | `86bc6125155279f57688a9932717ca065eeb3cd5` |
| `ansible-ump` | `0e0d092f2b4d3f18f4dc0ccaf6b536403e62de81` |
| `ui-producthub` | `eb3e6193adeffda0d8fb4fe4ca34dc7bee4c9bd7` |
| `unioninvestment` | `No .git metadata in supplied archive` |

SHA256 von `UMP_repos.zip`:

```text
4329026693b3707394bf0094ee76d5d3b7efc4a270c7134cd5e963838c4462f8
```

Die vollständigen Dateiprüfsummen stehen in `paket.json`. Der Übernahmehelfer bricht bei einem abweichenden bestehenden Zielstand ab. Das ist wichtig: Ein älterer Upload darf aktuelle Änderungen deiner Kollegen nicht überschreiben.

## Warum die Umsetzung so aussieht

**DBI-12139:** In `live/live/{dev,test,prod}/terragrunt.stack.hcl` existiert `storage-assets`; `appgateway.hcl` enthält die Release-Routen. Im zugehörigen `catalog`-Blob-Modul ist direkter öffentlicher Netzwerkzugriff aus. Deshalb keine doppelte Storage-Anlage und keine pauschale öffentliche Netzwerkfreigabe. Der anonyme externe Abruf bleibt gesondert zu beweisen.

**DBI-6455:** `catalog/modules/log-and-monitor/outputs.tf` liefert unter `resource_id` den Log-Analytics-Workspace. Das bisherige `main.alerts.tf` setzt dagegen Application Insights als Alert-Scope fest. Die neue lokale Unit nutzt bewusst den Workspace und benötigt keine Änderung/verfrühte Neuveröffentlichung des gemeinsamen Katalogs. `live/.gitlab-ci.yml` wurde um Pfade der neuen lokalen Module ergänzt, damit spätere Moduländerungen nicht ohne Planjobs bleiben.

**DBI-11149:** `unioninvestment/htdocs/application_includes/W2P/Export/mbo_export_controller.php` nutzt `Comm\File\sftp_connector`. Dessen OpenSSH-Verwendung steht in `htdocs/includes/Comm/File/class.sftp_connector.php`. Die fünf Parameter kommen aus `etc/config/packages/global.yml`. Der neue Befehl übernimmt diese Konfiguration, aber nicht die auftragsverändernde Exportlogik.

**PB2B-27849:** Die ursprüngliche `ansible-ump/host_vars/ump-app` wählt die IdP-Datei über `mellon_file_stage`. Die zusätzliche, optionale Auswahl erhält das normale Verhalten und ermöglicht eine ausschließlich temporäre Host-Zuordnung. Der neue Ablauf ist nicht in das normale Konfigurationsplaybook importiert. Die aktive Zielinstanz muss separat bestätigt werden.

**DBI-7161:** Der Upload enthält den im Ticket referenzierten vollständigen Schnittstellenvertrag nicht. Deshalb ein nicht eingebundener, freigabepflichtiger Katalogbaustein statt eines erfundenen UMP-Webhook-Verhaltens. Event-Grid-Webhook-Authentifizierung, B2C-Scopes und Azure-RBAC werden nicht gleichgesetzt.

## Umfang des tatsächlich enthaltenen Repository-Codes

| Ticket | Vollständige neue/geänderte Dateien |
|---|---:|
| DBI-12139 | 1 |
| DBI-11149 | 2 |
| DBI-6455 | 6 |
| PB2B-27849 | 3 |
| DBI-7161 | 2 |

Die übrigen Dateien sind eine README pro Ticket, Startanleitung, Tests, Kopier-/Prüfwerkzeug, Manifest, dieses Prüfprotokoll, der Public Key und die beiden bewusst beibehaltenen alten Einstiegspfade. `monitoring-test.patch` ist **absichtlich kein anwendbarer Patch mehr**, damit die alte und die neue Alarmierung nicht versehentlich kombiniert werden.

## Abgeglichene öffentliche Dokumentation

Stand der Recherche: 01.10.2026. Die Dokumentation hilft bei der Konzeption, ersetzt aber keine Prüfung gegen den tatsächlich verwendeten Provider und die UIS-Policies.

- Microsoft: [OTelLogs-Tabellenschema](https://learn.microsoft.com/en-us/azure/azure-monitor/reference/tables/otellogs) und [Logabfrage-Scope](https://learn.microsoft.com/en-us/azure/azure-monitor/logs/scope).
- HashiCorp: [Scheduled Query Rules Alert V2](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/monitor_scheduled_query_rules_alert_v2), [Event Grid Topic](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/eventgrid_topic) und [Event Subscription](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/eventgrid_event_subscription).
- Microsoft: [Event-Grid-Zustellung mit Managed Identity](https://learn.microsoft.com/en-us/azure/event-grid/deliver-events-using-managed-identity) und [geschützte Webhook-Zustellung](https://learn.microsoft.com/en-us/azure/event-grid/secure-webhook-delivery).

**Keine Nachricht wurde verschickt, kein Jira geändert, kein Repository gepusht und keine Infrastruktur bereitgestellt.**
