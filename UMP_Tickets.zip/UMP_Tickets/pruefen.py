#!/usr/bin/env python3
"""Local tests and package hashes. No Azure access. --terraform downloads providers only."""
from __future__ import annotations
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest

BASE = Path(__file__).resolve().parent

def native_terraform() -> list[dict]:
    executable = shutil.which('terraform')
    if not executable:
        return [{'passed': False, 'reason': 'Terraform fehlt. Keine native HCL-/Provider-Validierung ausgeführt.'}]
    version = subprocess.run([executable, 'version', '-json'], capture_output=True, text=True, check=False, timeout=30)
    if version.returncode or not json.loads(version.stdout).get('terraform_version', '').startswith('1.13.'):
        return [{'passed': False, 'reason': 'Bitte die Terraform-1.13-Version des Repositories verwenden (Snapshot: 1.13.4).'}]
    results = []
    for ticket, directory, azapi in [
        ('DBI-6455', 'DBI-6455/code/live/modules/ump-exception-alerts', False),
        ('DBI-7161', 'DBI-7161/code/catalog/modules/producthub-event-grid', True),
    ]:
        with tempfile.TemporaryDirectory(prefix='ump-validate-') as folder:
            work = Path(folder)
            shutil.copyfile(BASE / directory / 'main.tf', work / 'main.tf')
            providers = ['    azurerm = { source = "hashicorp/azurerm", version = "~> 4.63" }']
            if azapi:
                providers.append('    azapi = { source = "Azure/azapi", version = "~> 2.7" }')
            (work / 'providers.tf').write_text('terraform {\n  required_version = "~> 1.13"\n  required_providers {\n' + '\n'.join(providers) + '\n  }\n}\n', encoding='utf-8')
            env = dict(os.environ)
            env['TF_IN_AUTOMATION'] = '1'
            # Do not accidentally use a preconfigured real backend/data directory or CLI arguments.
            for name in list(env):
                if name == 'TF_DATA_DIR' or name.startswith('TF_CLI_ARGS'):
                    del env[name]
            steps = []
            for arguments in [('init', '-backend=false', '-input=false', '-no-color'), ('validate', '-no-color')]:
                run = subprocess.run([executable, *arguments], cwd=work, env=env, text=True, capture_output=True, timeout=300, check=False)
                steps.append({'command': 'terraform ' + ' '.join(arguments), 'exit_code': run.returncode, 'stdout': run.stdout, 'stderr': run.stderr})
                if run.returncode:
                    break
            results.append({'ticket': ticket, 'passed': len(steps) == 2 and all(s['exit_code'] == 0 for s in steps), 'steps': steps})
    return results

def main() -> int:
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument('--terraform', action='store_true', help='Additionally run isolated terraform init/validate if installed; downloads providers, never plan/apply.')
    cli.add_argument('--source', type=Path, help='Optional: run DBI-12139 structural checks against your live repository.')
    cli.add_argument('--output', type=Path, default=BASE / 'ergebnisse' / 'lokale-pruefung.json')
    args = cli.parse_args()
    try:
        manifest = json.loads((BASE / 'paket.json').read_text(encoding='utf-8'))
        hashes = []
        for item in manifest['files']:
            path = BASE / item['package_path']
            ok = path.is_file() and hashlib.sha256(path.read_bytes()).hexdigest() == item['sha256']
            hashes.append({'path': item['package_path'], 'passed': ok})
        suite = unittest.defaultTestLoader.discover(str(BASE / 'tests'), pattern='test_*.py')
        tested = unittest.TextTestRunner(verbosity=2).run(suite)
        report = {'checked_at_utc': datetime.now(timezone.utc).isoformat(), 'python': sys.version.split()[0],
                  'package_files': hashes, 'tests': {'run': tested.testsRun, 'failures': len(tested.failures),
                  'errors': len(tested.errors), 'skipped': len(tested.skipped),
                  'skip_reasons': [reason for _, reason in tested.skipped], 'passed': tested.wasSuccessful()},
                  'azure_or_remote_systems_accessed': False, 'terraform': 'not requested', 'source': 'not requested'}
        passed = all(item['passed'] for item in hashes) and tested.wasSuccessful()
        if args.source:
            source_output = args.output.parent / 'quellcode.json'
            run = subprocess.run([sys.executable, str(BASE/'DBI-12139/code/live/scripts/lp_assets.py'),
                                  'source-check', '--repo', str(args.source.resolve()), '--output', str(source_output.resolve())], check=False)
            report['source'] = {'exit_code': run.returncode, 'report': str(source_output)}
            passed = passed and run.returncode == 0
        if args.terraform:
            report['terraform'] = native_terraform()
            passed = passed and all(item['passed'] for item in report['terraform'])
        report['passed'] = passed
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
        print(('LOKALE PRUEFUNG BESTANDEN: ' if passed else 'PRUEFUNG NICHT BESTANDEN: ') + str(args.output.resolve()))
        print('Kein Deployment, kein echter SFTP-/SAML-/Mailtest. Terraform nur mit --terraform geprüft.')
        return 0 if passed else 2
    except (OSError, ValueError, KeyError, subprocess.SubprocessError) as error:
        print('STOPP: ' + str(error), file=sys.stderr)
        return 2

if __name__ == '__main__':
    raise SystemExit(main())
