"""Lokale Tests ohne Azure-Konto und ohne Netzwerkzugriffe."""
from __future__ import annotations
import argparse
import base64
import hashlib
import importlib.util
import io
import json
import os
import subprocess
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

MODULE = Path(__file__).resolve().parents[1] / "DBI-12139" / "code" / "live" / "scripts" / "lp_assets.py"
spec = importlib.util.spec_from_file_location("lp_assets", MODULE)
lp = importlib.util.module_from_spec(spec)
spec.loader.exec_module(lp)

BLOB = "dbi-12139-check-20261001T100000Z-123456abcdef.txt"


def receipt_at(folder: Path) -> tuple[Path, bytes]:
    data = (b"Synthetic DBI-12139 check\n" * 400)[:lp.SAMPLE_SIZE]
    (folder / "testdatei.txt").write_bytes(data)
    cfg = lp.env_config("dev")
    receipt = {"ticket": "DBI-12139", "environment": "dev", "campaign": "uniglobal",
        "blob": BLOB, "storage_account": cfg["storage_account"], "container": "uniglobal-release-1",
        "sample_file": "testdatei.txt", "sample_sha256": hashlib.sha256(data).hexdigest(),
        "upload_etag": '"etag-one"'}
    path = folder / "upload.json"
    lp.save_json(path, receipt)
    return path, data


def containers():
    names = {"assets": "None", "statuspages": "Blob", "uniglobal-release-1": "Blob", "ve-release-1": "Blob", "zukunft-release-1": "Blob"}
    return [{"name": k, "properties": {"publicAccess": v}} for k, v in names.items()]


class Checks(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.folder = Path(self.tmp.name)
        self.output = io.StringIO()
        self.stdout = patch("sys.stdout", self.output)
        self.stdout.start()

    def tearDown(self):
        self.stdout.stop()
        self.tmp.cleanup()

    def test_config_has_only_ticket_environments(self):
        self.assertEqual(set(lp.load_config()["environments"]), {"dev", "test", "prod"})
        self.assertEqual(len(lp.load_config()["campaigns"]), 3)

    def test_exact_existing_route(self):
        public, internal = lp.urls("test", "ve", BLOB)
        self.assertIn("/VE-Impuls-Junge-Neukunden/", public)
        self.assertIn("/ve-release-1/", internal)
        self.assertNotIn("?", public)

    def test_arbitrary_blob_rejected(self):
        for value in ["actual-video.mp4", "../x", BLOB + "?sig=secret", "https://other.example/x", ""]:
            with self.subTest(value=value), self.assertRaises(lp.TaskError):
                lp.safe_blob_name(value)

    def test_expected_storage_configuration(self):
        checks = lp.storage_checks({"allowBlobPublicAccess": True, "publicNetworkAccess": "Disabled"}, lp.summarize_containers(containers()))
        self.assertTrue(all(c["passed"] for c in checks))

    def test_old_assets_must_stay_private(self):
        values = lp.summarize_containers(containers())
        values[0]["publicAccess"] = "Blob"
        checks = lp.storage_checks({"allowBlobPublicAccess": True, "publicNetworkAccess": "Disabled"}, values)
        self.assertFalse(all(c["passed"] for c in checks))

    def test_listing_permission_is_not_expected(self):
        values = lp.summarize_containers(containers())
        values[2]["publicAccess"] = "Container"
        checks = lp.storage_checks({"allowBlobPublicAccess": True, "publicNetworkAccess": "Disabled"}, values)
        self.assertFalse(all(c["passed"] for c in checks))

    def test_absent_container_not_success(self):
        checks = lp.storage_checks({"allowBlobPublicAccess": True, "publicNetworkAccess": "Disabled"}, [])
        self.assertFalse(all(c["passed"] for c in checks))

    def test_wrong_resource_id_rejected(self):
        with patch.object(lp, "az_json", return_value={"id": "/wrong/resource"}), self.assertRaises(lp.TaskError):
            lp.read_account(lp.env_config("prod"))

    def test_pagination_stays_in_azure_management(self):
        with patch.object(lp, "az_json", return_value={"value": [], "nextLink": "https://other.example/"}), self.assertRaises(lp.TaskError):
            lp.read_containers(lp.env_config("dev"))

    def test_repeated_pagination_rejected(self):
        cfg = lp.env_config("dev")
        url = f"{lp.ARM}{lp.account_id(cfg)}/blobServices/default/containers?api-version={lp.STORAGE_API}"
        with patch.object(lp, "az_json", return_value={"value": [], "nextLink": url}), self.assertRaises(lp.TaskError):
            lp.read_containers(cfg)

    def test_receipt_roundtrip_and_tamper_detection(self):
        path, data = receipt_at(self.folder)
        self.assertEqual(lp.read_receipt(path)[1], data)
        (self.folder / "testdatei.txt").write_bytes(b"X" * lp.SAMPLE_SIZE)
        with self.assertRaises(lp.TaskError): lp.read_receipt(path)

    def test_receipt_cannot_read_arbitrary_file(self):
        path, _ = receipt_at(self.folder)
        value = json.loads(path.read_text())
        value["sample_file"] = "../../private-key"
        lp.save_json(path, value)
        with self.assertRaises(lp.TaskError): lp.read_receipt(path)

    def test_environment_target_tampering_rejected(self):
        path, _ = receipt_at(self.folder)
        value = json.loads(path.read_text())
        value["storage_account"] = "anotheraccount"
        lp.save_json(path, value)
        with self.assertRaises(lp.TaskError): lp.read_receipt(path)

    def test_probe_checks_bytes_and_range(self):
        path, data = receipt_at(self.folder)
        replies = [({"http_status": 200, "headers": {}}, data),
                   ({"http_status": 206, "headers": {"content-range": "bytes 0-1023/8192"}}, data[:1024])]
        args = argparse.Namespace(receipt=path, endpoint="asset-domain", origin=None, network="extern", output=None)
        with patch.object(lp, "http_get", side_effect=replies) as getter:
            self.assertEqual(lp.probe(args), 0)
            self.assertEqual(getter.call_args_list[1].kwargs["byte_range"], "bytes=0-1023")
        report = json.loads(path.with_name("probe-asset-domain-extern.json").read_text())
        self.assertTrue(report["passed"])
        self.assertEqual(report["network_declared_by_operator"], "extern")

    def test_login_html_200_is_not_success(self):
        path, data = receipt_at(self.folder)
        replies = [({"http_status": 200, "headers": {}}, b"<html>Sign in</html>"),
                   ({"http_status": 206, "headers": {"content-range": "bytes 0-1023/8192"}}, data[:1024])]
        args = argparse.Namespace(receipt=path, endpoint="asset-domain", origin=None, network="intern", output=None)
        with patch.object(lp, "http_get", side_effect=replies): self.assertEqual(lp.probe(args), 2)

    def test_range_ignored_is_failure(self):
        path, data = receipt_at(self.folder)
        replies = [({"http_status": 200, "headers": {}}, data), ({"http_status": 200, "headers": {}}, data)]
        args = argparse.Namespace(receipt=path, endpoint="asset-domain", origin=None, network="intern", output=None)
        with patch.object(lp, "http_get", side_effect=replies): self.assertEqual(lp.probe(args), 2)

    def test_optional_cors_requires_matching_origin(self):
        path, data = receipt_at(self.folder)
        replies = [({"http_status": 200, "headers": {}}, data),
                   ({"http_status": 206, "headers": {"content-range": "bytes 0-1023/8192"}}, data[:1024])]
        args = argparse.Namespace(receipt=path, endpoint="asset-domain", origin="https://example.org", network="intern", output=None)
        with patch.object(lp, "http_get", side_effect=replies): self.assertEqual(lp.probe(args), 2)

    def test_no_http_credentials_query_or_fragment(self):
        for url in ["http://example.org/a", "https://user:pass@example.org/a", "https://example.org/a?sig=x", "https://example.org/a#x"]:
            with self.subTest(url=url), self.assertRaises(lp.TaskError): lp.http_get(url)

    def test_http_get_has_no_auth_or_cookies(self):
        class Response:
            code = 200
            headers = {"Content-Type": "text/plain"}
            def __enter__(self): return self
            def __exit__(self, *args): return None
            def read(self, limit): return b"hello"
        class Opener:
            def open(self, request, timeout):
                self.request = request
                return Response()
        opener = Opener()
        with patch.object(lp, "build_opener", return_value=opener):
            info, body = lp.http_get("https://example.org/a", byte_range="bytes=0-1023")
        self.assertEqual(opener.request.get_method(), "GET")
        keys = {k.lower() for k, _ in opener.request.header_items()}
        self.assertNotIn("authorization", keys)
        self.assertNotIn("cookie", keys)
        self.assertEqual(info["http_status"], 200)
        self.assertEqual(body, b"hello")

    def test_no_redirect_following(self):
        self.assertIsNone(lp.NoRedirect().redirect_request(None, None, 302, "Found", {}, "https://example.org/login"))

    def test_azure_cli_environment_does_not_reuse_storage_keys(self):
        result = subprocess.CompletedProcess([], 0, stdout="{}", stderr="")
        with patch.object(lp.shutil, "which", return_value="/usr/bin/az"), patch.object(lp.subprocess, "run", return_value=result) as run:
            with patch.dict(os.environ, {"AZURE_STORAGE_KEY": "secret", "AZURE_STORAGE_SAS_TOKEN": "sig"}):
                lp.az_json(["storage", "account", "show"])
        env = run.call_args.kwargs["env"]
        self.assertNotIn("AZURE_STORAGE_KEY", env)
        self.assertNotIn("AZURE_STORAGE_SAS_TOKEN", env)
        self.assertEqual(env["AZURE_STORAGE_AUTH_MODE"], "login")

    def test_inventory_only_uses_read_commands(self):
        cfg = lp.env_config("dev")
        called = []
        def fake(command):
            called.append(command)
            if command[:3] == ["storage", "account", "show"]:
                return {"id": lp.account_id(cfg), "allowBlobPublicAccess": True, "publicNetworkAccess": "Disabled"}
            if command[:1] == ["rest"]: return {"value": containers()}
            if command[:3] == ["network", "application-gateway", "show"]:
                return gateway_fixture('dev')
            raise AssertionError(command)
        args = argparse.Namespace(env="dev", output=self.folder / "inventory.json")
        with patch.object(lp, "az_json", side_effect=fake): self.assertEqual(lp.inventory(args), 0)
        self.assertEqual(len(called), 3)
        self.assertFalse(any(word in {"create", "update", "delete", "list-keys"} for call in called for word in call))

    def test_inventory_denied_is_not_missing_resource_proof(self):
        args = argparse.Namespace(env="dev", output=self.folder / "inventory.json")
        with patch.object(lp, "az_json", side_effect=lp.TaskError("AuthorizationFailed")):
            self.assertEqual(lp.inventory(args), 2)
        report = json.loads(args.output.read_text())
        self.assertIn("AuthorizationFailed", report["environments"]["dev"]["errors"][0])

    def test_upload_has_nonoverwrite_and_login_guards(self):
        cfg = lp.env_config("dev")
        args = argparse.Namespace(env="dev", campaign="uniglobal", output_dir=self.folder)
        with patch.object(lp, "read_account", return_value={"allowBlobPublicAccess": True}), \
             patch.object(lp, "read_containers", return_value=containers()), patch.object(lp, "confirm") as confirm, \
             patch.object(lp, "az_json", return_value={"etag": '"etag-one"'}) as az:
            self.assertEqual(lp.upload_test(args), 0)
        cmd = az.call_args.args[0]
        self.assertEqual(cmd[cmd.index("--overwrite") + 1], "false")
        self.assertEqual(cmd[cmd.index("--if-none-match") + 1], "*")
        self.assertEqual(cmd[cmd.index("--auth-mode") + 1], "login")
        confirm.assert_called_once_with("UPLOAD", "dev")
        receipts = list(self.folder.rglob("upload.json"))
        self.assertEqual(len(receipts), 1)
        self.assertEqual(len(lp.read_receipt(receipts[0])[1]), lp.SAMPLE_SIZE)

    def test_upload_not_performed_without_container_access(self):
        args = argparse.Namespace(env="dev", campaign="uniglobal", output_dir=self.folder)
        with patch.object(lp, "read_account", return_value={"allowBlobPublicAccess": True}), \
             patch.object(lp, "read_containers", return_value=[]), patch.object(lp, "az_json") as az, \
             self.assertRaises(lp.TaskError): lp.upload_test(args)
        az.assert_not_called()

    def test_cleanup_rejects_unmarked_blob(self):
        path, _ = receipt_at(self.folder)
        with patch.object(lp, "az_json", return_value={"metadata": {}, "properties": {"etag": "one"}}) as az, \
             self.assertRaises(lp.TaskError): lp.cleanup(argparse.Namespace(receipt=path))
        self.assertEqual(az.call_count, 1)

    def test_cleanup_rejects_changed_blob(self):
        path, _ = receipt_at(self.folder)
        blob = {"metadata": {"ticket": "DBI-12139", "synthetic": "true"}, "properties": {"etag": '"etag-changed"'}}
        with patch.object(lp, "az_json", return_value=blob) as az, self.assertRaises(lp.TaskError):
            lp.cleanup(argparse.Namespace(receipt=path))
        self.assertEqual(az.call_count, 1)

    def test_cleanup_is_conditional_on_etag(self):
        path, _ = receipt_at(self.folder)
        blob = {"metadata": {"ticket": "DBI-12139", "synthetic": "true"}, "properties": {"etag": '"etag-one"'}}
        with patch.object(lp, "az_json", side_effect=[blob, None]) as az, patch.object(lp, "confirm") as confirm:
            self.assertEqual(lp.cleanup(argparse.Namespace(receipt=path)), 0)
        command = az.call_args_list[1].args[0]
        self.assertEqual(command[command.index("--if-match") + 1], '"etag-one"')
        confirm.assert_called_once_with("DELETE", "dev")

    def test_noninteractive_confirmation_rejected(self):
        with patch.object(lp.sys.stdin, "isatty", return_value=False), self.assertRaises(lp.TaskError):
            lp.confirm("UPLOAD", "prod")




def gateway_fixture(env='dev'):
    cfg = lp.env_config(env)
    gateway = {'provisioningState': 'Succeeded',
        'httpListeners': [{'name': 'landingassets-private-listener', 'hostNames': [cfg['asset_host']]}],
        'backendAddressPools': [{'name': 'landingassets-backends', 'backendAddresses': [{'fqdn': cfg['storage_account'] + '.blob.core.windows.net'}]}],
        'backendHttpSettingsCollection': [], 'urlPathMaps': [{'name': 'lpa-default-route', 'pathRules': []}],
        'requestRoutingRules': [{'name': 'landingassets-private-route', 'urlPathMap': {'id': '/maps/lpa-default-route'},
                                'httpListener': {'id': '/listeners/landingassets-private-listener'}}]}
    for name, config in lp.load_config()['campaigns'].items():
        gateway['backendHttpSettingsCollection'].append({'name': f'lpa-{name}-settings', 'path': '/' + config['container'] + '/', 'pickHostNameFromBackendAddress': True})
        gateway['urlPathMaps'][0]['pathRules'].append({'name': f'lpa-{name}-route', 'paths': ['/' + config['public_path'] + '/*'],
            'backendHttpSettings': {'id': f'/settings/lpa-{name}-settings'}, 'backendAddressPool': {'id': '/pools/landingassets-backends'}})
    return gateway

ROOT = Path(__file__).resolve().parents[1]

def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

saml = load('saml', ROOT / 'PB2B-27849/code/ansible-ump/scripts/prepare_temporary_saml.py')
importer = load('importer', ROOT / 'uebernehmen.py')

class AssetExtensions(unittest.TestCase):
    def test_complete_gateway_route_checks(self):
        for env in ['dev', 'test', 'prod']:
            self.assertTrue(all(c['passed'] for c in lp.gateway_checks(gateway_fixture(env), lp.env_config(env))))

    def test_gateway_missing_rules_fail(self):
        self.assertFalse(all(c['passed'] for c in lp.gateway_checks({}, lp.env_config('test'))))

    def test_gateway_wrong_container_is_detected(self):
        gateway = gateway_fixture()
        gateway['backendHttpSettingsCollection'][0]['path'] = '/assets/'
        self.assertFalse(all(c['passed'] for c in lp.gateway_checks(gateway, lp.env_config('dev'))))

    def test_gateway_wrong_host_is_detected(self):
        gateway = gateway_fixture()
        gateway['httpListeners'][0]['hostNames'] = ['example.invalid']
        self.assertFalse(all(c['passed'] for c in lp.gateway_checks(gateway, lp.env_config('dev'))))

    def test_hcl_block_quotes_and_comments(self):
        text = 'unit "x" { value = "${local.x}" # }\n nested = { enabled = true } } other = {}'
        self.assertIn('nested = { enabled = true }', lp.block(text, 'unit "x"'))
        self.assertNotIn('other', lp.block(text, 'unit "x"'))

    def test_hcl_block_incomplete_rejected(self):
        with self.assertRaises(lp.TaskError): lp.block('unit "x" {', 'unit "x"')

    def test_media_url_cannot_escape_container(self):
        for invalid in ['../x', '/video.mp4', 'a//b', 'https://evil.invalid/x', 'x?sig=secret', 'a\\b', 'a\nb']:
            with self.subTest(invalid=invalid), self.assertRaises(lp.TaskError): lp.media_url('dev', 've', invalid)

    def test_real_media_url_uses_frontend_path(self):
        url = lp.media_url('test', 've', 'videos/film.mp4')
        self.assertIn('/VE-Impuls-Junge-Neukunden/videos/film.mp4', url)
        self.assertNotIn('ve-release-1', url)

    def test_real_large_media_range_success(self):
        with tempfile.TemporaryDirectory() as temp:
            total = 20 * 1024 * 1024
            replies = [({'http_status': 206, 'headers': {'content-type': 'video/mp4', 'content-range': f'bytes 0-1023/{total}'}}, b'a'*1024),
                       ({'http_status': 206, 'headers': {'content-type': 'video/mp4', 'content-range': f'bytes {total-1024}-{total-1}/{total}'}}, b'z'*1024)]
            args = argparse.Namespace(env='test', campaign='uniglobal', blob='film.mp4', min_size_mib=10, network='extern', output=Path(temp)/'media.json')
            with patch.object(lp, 'http_get', side_effect=replies), patch('sys.stdout', io.StringIO()):
                self.assertEqual(lp.probe_media(args), 0)
            self.assertTrue(json.loads(args.output.read_text())['passed'])

    def test_media_html_200_is_not_success(self):
        with tempfile.TemporaryDirectory() as temp:
            args = argparse.Namespace(env='test', campaign='uniglobal', blob='film.mp4', min_size_mib=10, network='extern', output=Path(temp)/'media.json')
            with patch.object(lp, 'http_get', return_value=({'http_status': 200, 'headers': {'content-type': 'text/html'}}, b'login')), patch('sys.stdout', io.StringIO()):
                self.assertEqual(lp.probe_media(args), 2)


def idp_fixture(policy=None):
    chosen = policy or saml.POLICY
    return f'''<EntityDescriptor xmlns="{saml.NS['md']}" xmlns:ds="{saml.NS['ds']}" entityID="{saml.IDP_ENTITY.replace(saml.POLICY,chosen)}">
      <IDPSSODescriptor protocolSupportEnumeration="urn:oasis:names:tc:SAML:2.0:protocol">
        <KeyDescriptor use="signing"><ds:KeyInfo><ds:X509Data><ds:X509Certificate>Y2VydGlmaWNhdGU=</ds:X509Certificate></ds:X509Data></ds:KeyInfo></KeyDescriptor>
        <SingleSignOnService Binding="urn:oasis:names:tc:SAML:2.0:bindings:HTTP-Redirect" Location="{saml.SSO_URL.replace(saml.POLICY,chosen)}"/>
      </IDPSSODescriptor>
    </EntityDescriptor>'''.encode()

SP_ENTITY = 'https://temporary.example.invalid'
SP_ACS = SP_ENTITY + '/authentication/postResponse'

def sp_fixture():
    return f'<EntityDescriptor xmlns="{saml.NS["md"]}" entityID="{SP_ENTITY}"><SPSSODescriptor><AssertionConsumerService Location="{SP_ACS}"/></SPSSODescriptor></EntityDescriptor>'.encode()

class SamlChecks(unittest.TestCase):
    def test_correct_temporary_metadata(self):
        with patch.object(saml, 'certificate_dates', return_value={'sha256': 'test'}):
            self.assertEqual(saml.verify_idp(idp_fixture())['entity_id'], saml.IDP_ENTITY)

    def test_normal_prod_metadata_is_rejected(self):
        with self.assertRaises(saml.MetadataError): saml.verify_idp(idp_fixture('B2C_1A_signin_saml_ump'))

    def test_wrong_sso_url_is_rejected(self):
        data = idp_fixture().replace(saml.SSO_URL.encode(), b'https://other.example.invalid/sso')
        with self.assertRaises(saml.MetadataError): saml.verify_idp(data)

    def test_dtd_and_entity_are_rejected(self):
        for data in [b'<!DOCTYPE x><x/>', b'<!ENTITY x "content"><x/>']:
            with self.assertRaises(saml.MetadataError): saml.parse(data)

    def test_html_response_is_rejected(self):
        with self.assertRaises(saml.MetadataError): saml.parse(b'<html>Login</html>')

    def test_oversized_xml_is_rejected(self):
        with self.assertRaises(saml.MetadataError): saml.parse(b'x' * (saml.LIMIT + 1))

    def test_expired_metadata_is_rejected(self):
        data = idp_fixture().replace(b'<EntityDescriptor ', b'<EntityDescriptor validUntil="2000-01-01T00:00:00Z" ')
        with self.assertRaises(saml.MetadataError): saml.parse(data)

    def test_no_valid_signing_certificate_is_rejected(self):
        with patch.object(saml, 'certificate_dates', side_effect=saml.MetadataError('expired')), self.assertRaises(saml.MetadataError):
            saml.verify_idp(idp_fixture())

    def test_missing_signing_certificate_is_rejected(self):
        data = idp_fixture().replace(b'use="signing"', b'use="encryption"')
        with self.assertRaises(saml.MetadataError): saml.verify_idp(data)

    def test_sp_exact_match(self):
        self.assertEqual(saml.verify_sp(sp_fixture(), SP_ENTITY, SP_ACS)['acs_urls'], [SP_ACS])

    def test_sp_wrong_callback_rejected(self):
        with self.assertRaises(saml.MetadataError): saml.verify_sp(sp_fixture(), SP_ENTITY, SP_ENTITY + '/wrong')

    def test_sp_wrong_host_rejected(self):
        with self.assertRaises(saml.MetadataError): saml.verify_sp(sp_fixture(), SP_ENTITY, 'https://other.example.invalid/auth')

    def test_approved_target_prepare_creates_only_staged_files(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            (root/'host_vars').mkdir(); (root/'host_vars/ump-app').write_text('existing')
            sp = root/'sp.xml';sp.write_bytes(sp_fixture())
            args = argparse.Namespace(repo=root, host='temporary-ump', entity_id=SP_ENTITY, acs_url=SP_ACS, sp_metadata=sp, replace=False, output=root/'vars.json')
            with patch.object(saml, 'fetch_metadata', return_value=idp_fixture()), patch.object(saml, 'certificate_dates', return_value={'sha256': 'test'}):
                result = saml.prepare(args)
            self.assertEqual(result['status'], 'staged_locally_only')
            self.assertNotIn('temporary_ump_approved', json.loads(args.output.read_text()))
            self.assertEqual((root/'host_vars/ump-app').read_text(), 'existing')
            self.assertTrue((root/'playbooks/configuration/files/app/mellon/prod-temp/idp_metadata_azure.xml').exists())

    def test_invalid_certificate_bytes_rejected_by_openssl(self):
        if not saml.shutil.which('openssl'): self.skipTest('openssl not installed')
        with self.assertRaises(saml.MetadataError): saml.certificate_dates(b'not a certificate')

class ImporterChecks(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.base = Path(self.tmp.name)/'package';self.base.mkdir()
        self.target = Path(self.tmp.name)/'repo';self.target.mkdir()
        (self.base/'new.txt').write_text('new')
        (self.target/'original.txt').write_text('old')
        self.manifest = {'files': [{'ticket':'TEST','package_path':'new.txt','repository_path':'original.txt',
                          'sha256':hashlib.sha256(b'new').hexdigest(), 'original_sha256':hashlib.sha256(b'old').hexdigest()}]}
        self.patch=patch.object(importer,'BASE',self.base);self.patch.start()
        self.stdout=patch('sys.stdout',io.StringIO());self.stdout.start()
    def tearDown(self):
        self.patch.stop();self.stdout.stop();self.tmp.cleanup()
    def test_matching_snapshot_accepted_without_writing(self):
        self.assertEqual(len(importer.inspect('TEST',self.target,self.manifest)),1)
        self.assertEqual((self.target/'original.txt').read_text(),'old')
    def test_newer_working_copy_is_not_overwritten(self):
        (self.target/'original.txt').write_text('colleague change')
        with self.assertRaises(ValueError): importer.inspect('TEST',self.target,self.manifest)
    def test_modified_package_is_rejected(self):
        (self.base/'new.txt').write_text('tampered')
        with self.assertRaises(ValueError): importer.inspect('TEST',self.target,self.manifest)
    def test_already_applied_is_idempotent(self):
        (self.target/'original.txt').write_text('new')
        self.assertEqual(importer.inspect('TEST',self.target,self.manifest),[])
    def test_new_file_never_clobbers_unknown_existing_file(self):
        self.manifest['files'][0]['original_sha256']=None
        with self.assertRaises(ValueError): importer.inspect('TEST',self.target,self.manifest)
    def test_path_traversal_rejected(self):
        self.manifest['files'][0]['repository_path']='../escape.txt'
        with self.assertRaises(ValueError): importer.inspect('TEST',self.target,self.manifest)
    def test_leaf_symlink_rejected(self):
        (self.target/'original.txt').unlink()
        (self.target/'real.txt').write_text('old')
        (self.target/'original.txt').symlink_to(self.target/'real.txt')
        with self.assertRaises(ValueError): importer.inspect('TEST',self.target,self.manifest)

class SourceContractChecks(unittest.TestCase):
    def test_all_monitoring_stacks_use_dedicated_workspace_alert_unit(self):
        for env in ['dev','test','prod']:
            text=(ROOT/f'DBI-6455/code/live/live/{env}/terragrunt.stack.hcl').read_text()
            unit=lp.block(text,'unit "exception-alerts"')
            self.assertIn('"../monitoring"',unit)
            self.assertIn('enabled             = '+('true' if env=='test' else 'false'),unit)
            self.assertNotIn('scheduled_log_alerts',lp.block(text,'unit "monitoring"'))
    def test_monitoring_query_scope_and_stateful_settings(self):
        text=(ROOT/'DBI-6455/code/live/modules/ump-exception-alerts/main.tf').read_text()
        self.assertIn('scopes              = [var.workspace_resource_id]',text)
        self.assertIn('auto_mitigation_enabled = true',text)
        self.assertIn('skip_query_validation   = false',text)
        self.assertIn('SeverityText in~ ("error", "fatal")',text)
        self.assertIn('"ServiceName"',text)
    def test_local_module_changes_trigger_all_five_ci_rules(self):
        text=(ROOT/'DBI-6455/code/live/.gitlab-ci.yml').read_text()
        self.assertEqual(text.count('modules/ump-exception-alerts/**/*'),5)
        self.assertEqual(text.count('units/ump-exception-alerts/**/*'),5)
        self.assertIn('when: manual',text)
    def test_no_mock_during_monitoring_plan_or_apply(self):
        text=(ROOT/'DBI-6455/code/live/units/ump-exception-alerts/terragrunt.hcl').read_text()
        self.assertIn('mock_outputs_allowed_terraform_commands = ["validate"]',text)
    def test_eventgrid_is_opt_in_and_uses_identity_deadletter(self):
        text=(ROOT/'DBI-7161/code/catalog/modules/producthub-event-grid/main.tf').read_text()
        self.assertIn('default     = false',lp.block(text,'variable "approved_for_deployment"'))
        self.assertIn('var.approved_for_deployment',lp.block(text,'resource "azurerm_eventgrid_topic" "producthub"'))
        self.assertIn('dead_letter_identity',text)
        self.assertIn('"EventGrid Data Sender"',text)
        self.assertIn('local_auth_enabled            = false',text)
        self.assertIn('publicAccess = "None"',text)
    def test_normal_mellon_source_has_safe_default(self):
        text=(ROOT/'PB2B-27849/code/ansible-ump/host_vars/ump-app').read_text()
        self.assertIn("mellon_idp_metadata_source | default('files/app/mellon/' ~ mellon_file_stage ~ '/idp_metadata_azure.xml')",text)
    def test_saml_playbook_has_two_target_guards_and_rollback(self):
        text=(ROOT/'PB2B-27849/code/ansible-ump/playbooks/configuration/mellon-temporary.yml').read_text()
        self.assertEqual(text.count('temporary_ump_approved | default(false) | bool'),2)
        self.assertIn('ansible_play_hosts_all | length == 1',text)
        self.assertIn('rescue:',text)
        self.assertIn('backup: true',text)
        self.assertIn('configtest',text)
    def test_sftp_command_uses_real_parameter_names_and_never_exports(self):
        text=(ROOT/'DBI-11149/code/unioninvestment/htdocs/src/Console/Command/Diagnostics/MboSftpCheckCommand.php').read_text()
        for name in ['Host','Port','User','AuthKeyPath','RemoteDir']:
            self.assertIn("get('mboExportServer"+name+"')",text)
        for forbidden in ['mbo_export_controller', 'create_export_files', 'copy_export_files', 'EntityManagerInterface']:
            self.assertNotIn(forbidden,text)

class PhpProbeTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        import shutil
        cls.php=shutil.which('php')
        if not cls.php: raise unittest.SkipTest('PHP not installed; PHP runtime tests not executed')
        cls.file=ROOT/'DBI-11149/code/unioninvestment/htdocs/src/Console/Command/Diagnostics/MboSftpProbe.php'
    def runphp(self,code):
        encoded=json.dumps(str(self.file))
        # Path is passed as a positional argument, never interpolated into PHP code.
        program="require $argv[1]; use App\\Console\\Command\\Diagnostics\\MboSftpProbe as P; "+code
        run=subprocess.run([self.php,'-r',program,str(self.file)],capture_output=True,text=True,check=False)
        self.assertEqual(run.returncode,0,run.stderr)
    def test_default_arguments_pin_key_and_host_verification(self):
        self.runphp("$c=['host'=>'lukaspartner.msu.biz','port'=>'22','user'=>'UI_marketing','key'=>'/key with space','directory'=>'/incoming']; $a=P::argv($c); foreach(['-oBatchMode=yes','-oStrictHostKeyChecking=yes','-oIdentityAgent=none','-oIdentitiesOnly=yes'] as $s) { if(!in_array($s,$a,true)) exit(5); } if(in_array('-oHostKeyAlgorithms=+ssh-rsa',$a,true)) exit(6);")
    def test_batch_is_read_only_and_quotes_paths(self):
        self.runphp("$c=['host'=>'x.test','port'=>'','user'=>'u','key'=>'k','directory'=>'/folder with space']; if(P::batch($c)!==\"pwd\\ncd \\\"/folder with space\\\"\\npwd\\nbye\\n\") exit(5);")
    def test_bad_port_rejected(self):
        self.runphp("foreach(['abc','65536','-1'] as $port) { try { P::validate(['host'=>'x.test','port'=>$port,'user'=>'u','key'=>'k','directory'=>'/']); exit(4); } catch(InvalidArgumentException $e) {} }")
    def test_batch_newline_injection_rejected(self):
        self.runphp("try { P::validate(['host'=>'x.test','user'=>'u','key'=>'k','directory'=>\"/x\\nrm victim\"]); exit(4); } catch(InvalidArgumentException $e) {}")
    def test_host_option_injection_rejected(self):
        self.runphp("try { P::validate(['host'=>'-oProxyCommand=evil','user'=>'u','key'=>'k','directory'=>'/']); exit(4); } catch(InvalidArgumentException $e) {}")
    def test_legacy_rsa_is_explicit_only(self):
        self.runphp("$c=['host'=>'x.test','user'=>'u','key'=>'k','directory'=>'/']; if(!in_array('-oHostKeyAlgorithms=+ssh-rsa',P::argv($c,true),true)) exit(5);")
    def test_public_key_fingerprint_matches_ticket(self):
        key=base64.b64encode((ROOT/'DBI-11149/azure-lukas-sftp-prod.pub').read_bytes()).decode()
        self.runphp("if(P::fingerprint(base64_decode('"+key+"'))!==P::EXPECTED_CLIENT_FINGERPRINT) exit(5);")
    def test_both_php_files_lint(self):
        for file in self.file.parent.glob('*.php'):
            result=subprocess.run([self.php,'-l',str(file)],capture_output=True,text=True,check=False)
            self.assertEqual(result.returncode,0,result.stderr)


if __name__ == "__main__":
    unittest.main(verbosity=2)
