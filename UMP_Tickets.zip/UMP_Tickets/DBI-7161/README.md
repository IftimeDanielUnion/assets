# DBI-7161: ProductHub-Ereignisse an UMP zustellen

**Checkpoint: vollständiger, noch nicht aktivierter Infrastrukturbaustein vorbereitet. Die Anwendungsschnittstelle und deren Freigaben fehlen weiterhin.** Das ist kein schon fertiger Ende-zu-Ende-Flow.

## Was bereits fertig programmiert ist

Ziel-Repository: **`catalog`**. Unter `code/catalog` liegen das vollständige Terraform-Modul `modules/producthub-event-grid/main.tf` und seine Terragrunt-Unit.

Der Baustein enthält ein Event-Grid-Topic, die Senderberechtigung `EventGrid Data Sender`, einen geschützten UMP-Webhook als Ziel, Wiederholungsversuche und eine private Fehlerablage für dauerhaft nicht zustellbare Ereignisse. Die Ablage wird über die Identität des Topics beschrieben, nicht mit frei verteilten Storage-Schlüsseln. Zugriff von Publishern wird auf ausdrücklich bestätigte IPv4-Netze begrenzt.

**Keine Live-Stackdatei bindet diesen Baustein bereits ein.** Zusätzlich verhindert `approved_for_deployment = false` einen versehentlichen Start. Es wurden weder Webhook-Adresse, Entra-Identitäten noch fachliche Eventtypen erfunden. Der Code ist ein konkreter Vorschlag auf Basis von Entra/RBAC; die im Ticket erwähnten B2C-Scopes sind damit nicht stillschweigend als abgestimmt behandelt.

## 1. Diese Entscheidung bei Sinan holen

> Hi Sinan, für DBI-7161 habe ich den Azure-Baustein für Topic, Senderberechtigung, Zustellung und Fehlerablage vorbereitet. Damit wir den richtigen Flow umsetzen, brauche ich noch das aktuelle Konzept und eine Beispielnachricht: Welche UMP-URL soll empfangen, welche Eventtypen sind vorgesehen und welche Umgebung kommt zuerst? Für die technische Absicherung habe ich Entra/RBAC vorgesehen. Kannst du bitte bestätigen, ob das eurem Konzept entspricht, wer Publisher und UMP-Empfänger übernimmt und welche ausgehenden Publisher-IP-Netze freigegeben sind? Die im Ticket verlinkten Konzeptanhänge fehlen im Upload. Danke dir!

Das ist der aktive Blocker. Ein Storage-/Topic-Apply ohne diese Werte würde das Ticket nicht lösen.

## 2. Fehlende Angaben festziehen

Die Schnittstelle muss vor Aktivierung festlegen: Event-Schema und Beispiel, Empfänger-URL, Sender-Service-Principal als **Object ID**, Tenant und Audience der Webhook-App sowie das Verhalten bei erneut zugestellten Ereignissen. B2C-Scopes und Azure-RBAC sind nicht automatisch austauschbar.

Zusätzlich braucht die Webhook-App die für Event Grid vorgesehene Entra-Konfiguration einschließlich `AzureEventGridSecureWebhookSubscriber` und passenden Rechten des Subscription-Erstellers. Diese App-Rollen wurden nicht ohne bekannte App/Graph-Berechtigungen erzeugt.

**Netzwerkentscheidung:** Das Modul verwendet für Event-Grid-Zustellung in die Fehlerablage einen eingeschränkten Storage-Endpunkt mit „Trusted Services“, Managed Identity und ohne anonymen Zugriff. Das ist nicht identisch mit dem privaten LP-Asset-Storage aus DBI-12139 und muss zu euren UIS-Policies passen. Deshalb ist es kein Grund, das öffentliche Netzwerk des LP-Storages zu öffnen oder beide Ablagen zusammenzulegen.

## 3. Was du schon unabhängig prüfen kannst

Code in einen `catalog`-Feature-Branch übernehmen, noch keinen Live-Stack anschließen. Aus dem Paketordner:

```powershell
py -3 .\pruefen.py --terraform
```

Mit lokal installiertem Terraform 1.13.x werden die Provider geladen und das Modul isoliert validiert. Kein Apply. Hier wurde diese native Provider-Validierung mangels Terraform nicht durchgeführt.

Nach bestätigtem Konzept die echten Werte in einer neuen, freigegebenen `live`-Unit hinterlegen, den `catalog`-Stand über euren normalen Versions-/Releaseweg referenzieren und erst dann `approved_for_deployment` setzen. Wenn die Freigabe beim Netzwerk oder der Authentifizierung anders ausfällt, zuerst den Kandidaten anpassen. Nicht die Sperre nur für einen grünen Plan abschalten.

## 4. Nachricht an Alex für die fehlenden Anwendungsteile

> Hi Alex, die Azure-Seite für DBI-7161 ist als noch nicht aktivierter Baustein vorbereitet. Kannst du bitte sagen, ob ProductHub-Publisher und UMP-Webhook schon in einem anderen Branch existieren und wer sie übernimmt? Für den gemeinsamen Test brauche ich ein Beispielereignis, die vorgesehene Verarbeitung und das Verhalten bei doppelter Zustellung. Ohne diesen Vertrag möchte ich keinen Empfänger bauen, der Ereignisse zwar quittiert, aber fachlich nichts tut. Danke dir!

Der Application-Webhook muss Signatur/Token und Audience prüfen, die Event-Grid-Validierung für das vereinbarte Schema korrekt beantworten und ein Ereignis genau einmal fachlich wirksam verarbeiten, auch wenn es erneut ankommt. Der Publisher muss nachweisbar das vereinbarte Event senden. Diese fachlichen Änderungen sind ohne Vertrag nicht seriös ableitbar.

## Fertig, wenn

- [ ] Konzept, Identitäten, Netzwerkweg und App-Zuständigkeiten bestätigt.
- [ ] Terraform-Validierung, echter Plan und freigegebene Bereitstellung erfolgt.
- [ ] ProductHub-Testevent erreicht UMP und bewirkt die erwartete Verarbeitung.
- [ ] Abgelehnte Authentifizierung, dauerhafter Zustellfehler/Fehlerablage und doppelte Zustellung gemeinsam getestet.

Bis dahin bleibt dieses Ticket bewusst am Architektur-/Integrationscheckpoint. Es hängt nicht technisch vom Monitoring- oder Blob-Storage-Ticket ab.
