# DBI-7161. Isolated candidate module, not instantiated by any live stack.
# Provider/backend are supplied by the calling stack, consistent with catalog modules.
# IMPORTANT: this implements a Microsoft Entra/RBAC design, not unverified B2C scopes.
variable "approved_for_deployment" {
  type        = bool
  default     = false
  description = "Set true only after Entra auth, webhook contract and network/policy design are explicitly approved."
}
variable "config" {
  description = "Real approved integration values. No example URLs or invented principals are used as defaults."
  type = object({
    environment             = string
    location                = string
    resource_group_name     = string
    topic_name              = string
    storage_account_name    = string
    event_subscription_name = string
    publisher_object_id     = string
    publisher_ipv4_cidrs     = set(string)
    webhook_url             = string
    webhook_tenant_id       = string
    webhook_app_id_or_uri   = string
    event_schema            = string
    included_event_types    = set(string)
    tags                    = optional(map(string), {})
  })
  validation {
    condition     = contains(["dev", "test", "prod"], var.config.environment)
    error_message = "Use one explicit environment: dev, test or prod."
  }
  validation {
    condition     = can(regex("^[a-z0-9]{3,24}$", var.config.storage_account_name))
    error_message = "Storage name must contain 3-24 lowercase letters/digits."
  }
  validation {
    condition     = length(var.config.publisher_ipv4_cidrs) > 0 && alltrue([for c in var.config.publisher_ipv4_cidrs : can(cidrnetmask(c)) && !endswith(c, "/0")])
    error_message = "Approved publisher IPv4 CIDRs are mandatory; no unrestricted /0 rule."
  }
  validation {
    condition     = can(regex("^https://[A-Za-z0-9.-]+(:443)?/[^?#[:space:]]*$", var.config.webhook_url))
    error_message = "The webhook must be an HTTPS endpoint without credentials, query-string tokens or fragments."
  }
  validation {
    condition     = can(regex("^[0-9a-fA-F]{8}(-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12}$", var.config.publisher_object_id)) && can(regex("^[0-9a-fA-F]{8}(-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12}$", var.config.webhook_tenant_id))
    error_message = "Use actual principal OBJECT ID and webhook tenant GUID, not display names or client secrets."
  }
  validation {
    condition     = contains(["EventGridSchema", "CloudEventSchemaV1_0"], var.config.event_schema) && length(var.config.included_event_types) > 0 && length(trimspace(var.config.webhook_app_id_or_uri)) > 0
    error_message = "Agree a supported schema, non-empty event types and the webhook token audience."
  }
}

resource "azurerm_eventgrid_topic" "producthub" {
  name                          = var.config.topic_name
  location                      = var.config.location
  resource_group_name           = var.config.resource_group_name
  input_schema                  = var.config.event_schema
  public_network_access_enabled = true
  local_auth_enabled            = false
  tags                          = var.config.tags

  identity {
    type = "SystemAssigned"
  }
  dynamic "inbound_ip_rule" {
    for_each = var.config.publisher_ipv4_cidrs
    content {
      ip_mask = inbound_ip_rule.value
      action  = "Allow"
    }
  }
  lifecycle {
    precondition {
      condition     = var.approved_for_deployment
      error_message = "DBI-7161 blocked: obtain approval for the Entra/RBAC design and the trusted-services network path before deployment."
    }
  }
}

resource "azurerm_role_assignment" "publisher" {
  scope                = azurerm_eventgrid_topic.producthub.id
  role_definition_name = "EventGrid Data Sender"
  principal_id         = var.config.publisher_object_id
  principal_type       = "ServicePrincipal"
}

resource "azurerm_storage_account" "dead_letter" {
  name                            = var.config.storage_account_name
  location                        = var.config.location
  resource_group_name             = var.config.resource_group_name
  account_tier                    = "Standard"
  account_replication_type        = var.config.environment == "dev" ? "LRS" : "ZRS"
  account_kind                    = "StorageV2"
  min_tls_version                 = "TLS1_2"
  https_traffic_only_enabled      = true
  allow_nested_items_to_be_public = false
  shared_access_key_enabled       = false
  default_to_oauth_authentication = true
  # Event Grid Basic delivery does not originate in the application's VNet.
  # Selected-network endpoint + trusted services + system identity, NOT anonymous access.
  # This differs from the existing blob-storage-private unit and needs policy approval.
  public_network_access_enabled = true
  network_rules {
    default_action = "Deny"
    bypass         = ["AzureServices"]
  }
  tags = var.config.tags
  lifecycle {
    prevent_destroy = true
    precondition {
      condition     = var.approved_for_deployment
      error_message = "No dead-letter storage deployment before network/policy approval."
    }
  }
}

# ARM control-plane creation works even when the CI runner has no storage data-plane access.
resource "azapi_resource" "dead_letter_container" {
  type      = "Microsoft.Storage/storageAccounts/blobServices/containers@2025-01-01"
  name      = "deadletter"
  parent_id = "${azurerm_storage_account.dead_letter.id}/blobServices/default"
  body = {
    properties = {
      publicAccess = "None"
    }
  }
}

resource "azurerm_role_assignment" "dead_letter_writer" {
  scope                = azapi_resource.dead_letter_container.id
  role_definition_name = "Storage Blob Data Contributor"
  principal_id         = azurerm_eventgrid_topic.producthub.identity[0].principal_id
  principal_type       = "ServicePrincipal"
}

resource "azurerm_eventgrid_event_subscription" "ump" {
  name                  = var.config.event_subscription_name
  scope                 = azurerm_eventgrid_topic.producthub.id
  event_delivery_schema = var.config.event_schema
  included_event_types  = sort(tolist(var.config.included_event_types))

  webhook_endpoint {
    url                            = var.config.webhook_url
    active_directory_tenant_id     = var.config.webhook_tenant_id
    active_directory_app_id_or_uri = var.config.webhook_app_id_or_uri
    max_events_per_batch           = 1
  }
  retry_policy {
    max_delivery_attempts = 30
    event_time_to_live    = 1440
  }
  storage_blob_dead_letter_destination {
    storage_account_id          = azurerm_storage_account.dead_letter.id
    storage_blob_container_name = azapi_resource.dead_letter_container.name
  }
  dead_letter_identity {
    type = "SystemAssigned"
  }
  depends_on = [azurerm_role_assignment.dead_letter_writer]
}

output "topic_endpoint" {
  value = azurerm_eventgrid_topic.producthub.endpoint
}
output "topic_resource_id" {
  value = azurerm_eventgrid_topic.producthub.id
}
output "dead_letter_container_resource_id" {
  value = azapi_resource.dead_letter_container.id
}
output "event_subscription_resource_id" {
  value = azurerm_eventgrid_event_subscription.ump.id
}
