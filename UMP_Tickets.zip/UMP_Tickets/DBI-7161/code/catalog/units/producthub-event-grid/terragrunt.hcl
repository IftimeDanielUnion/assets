include "root" {
  path = find_in_parent_folders("root.hcl")
}
terragrunt_version_constraint = ">= 1.1"
terraform {
  source = "../../modules//producthub-event-grid"
  update_source_with_cas = true
}
dependencies {
  paths = try(values.dependencies_paths, [])
}
inputs = {
  approved_for_deployment = try(values.approved_for_deployment, false)
  config                  = values.config
}
