# DBI-6455: Fehlermails

**Nach 12139. Standalone.** Die OTEL-Strecke soll bereits existieren. Vorbereitet ist Code für die noch offene Mail-Alarmierung, nicht ein neu gebautes Monitoring-System.

## 1. Bestehende Logs und Alarme automatisch lesen

```bash
bash start.sh 6455
```

Standard ist **TEST**. Der Starter verwendet den im Originalcode genannten Workspace `log-ump-test` in `rg-monitoring-test`, führt eine begrenzte Logabfrage aus und sucht vorhandene Regeln mit direktem Workspace-/App-Insights-Scope. Keine Regel wird erstellt und keine Testmail gesendet.

Ergebnis: `ergebnisse/DBI-6455/` mit `STATUS.md`, den technischen Details und der ausgeführten Abfrage. Fehler/Leere werden nicht als erfolgreiche Alarmierung gewertet. Für weitere Umgebungen `--env dev`, `--env prod` oder `--env all` ergänzen.

**Portal-Alternative:** `bash start.sh portal`, Workspace-Link öffnen, **Logs**:

```kusto
OTelLogs
| where TimeGenerated > ago(24h)
| summarize Records = count(), Latest = max(TimeGenerated) by ServiceName, SeverityText
| order by Latest desc
| take 200
```

Danach Azure Monitor > Alerts > Alert rules nach der passenden Subscription filtern. Bereits außerhalb des IaC existierende Regeln beachten, damit keine doppelten Mails entstehen. Die automatische Suche findet direkte Scopes, nicht garantiert jede mögliche Cross-Workspace-Abfrage.

## 2. Vorbereiteten Code übernehmen

```bash
bash start.sh 6455 code
```

Du gibst nötigenfalls einmal dein `live`-Repo an. Separater Worktree, eigener `feat/DBI-6455-ump-checkpoint`-Branch, Originaldatei-Prüfung vor dem Kopieren. Kein Commit/Push.

**Sechs vollständige Dateien:** lokales Alert-Modul, lokale Terragrunt-Unit, drei Stackdateien und angepasste CI. TEST ist zur Aktivierung vorgesehen, DEV/PROD bleiben zunächst deaktiviert. Auch deaktivierte Regeln/Action Groups würden beim späteren jeweiligen Apply angelegt.

Optional, wenn die passende Terraform-Version lokal vorhanden ist:

```bash
bash start.sh 6455 validate
```

Lädt Provider in temporäre Verzeichnisse und prüft nur dieses Modul mit `init -backend=false` und `validate`. Kein State, kein Plan/Apply. Sonst die native Validierung über eure vorhandene CI erledigen.

## 3. Möglichst wenig lokale Einrichtung: eure Pipeline nutzen

Änderungen im Ticket-Worktree prüfen, regulär committen/pushen und den vorhandenen Review-/Plan-/Freigabeweg verwenden. **Kein lokales Apply wird vom Starter gestartet.** `az login` deckt den GitLab-Terraform-State nicht ab; dessen Zugriff und die Katalog-Downloads sind in eurer CI bereits separat vorgesehen. Ein echter Plan braucht den vorhandenen Monitoring-State, keine Mock-Workspace-ID.

Die Pipeline kann mehrere Umgebungen betreffen. Den vollständigen Plan prüfen, nicht nur die neue Regel. Keine bestehenden Monitoring-Ressourcen verschieben. Den alten `monitoring-test.patch` nicht anwenden; der Pfad ist bewusst stillgelegt.

## 4. Nachricht an Alex

> Hi Alex, ich übernehme bei DBI-6455 die noch offene Mail-Alarmierung. Der Code dafür ist vorbereitet; ich prüfe zuerst die vorhandenen TEST-Logs und bereits bestehende Regeln. Nach dem freigegebenen Deployment würde ich mit dir gern einen kontrollierten Fehler erzeugen und den Eingang bei `ui-team@os-cillation.de` bestätigen. Welchen Testfall können wir dafür verwenden? Danke dir!

Die Regel überwacht `error`/`fatal` je `ServiceName`: jede Minute, Fünf-Minuten-Fenster, zustandsbehaftet. **Nicht jede einzelne Logzeile erzeugt eine neue Mail.** `ServiceName` ist Alarmdimension; der gewünschte individuell gestaltete Betreff ist durch native Action Groups nicht zugesichert. Mit der echten Mail abgleichen.

DEV/PROD erst nach erfolgreichem TEST und Freigabe aktivieren. Dafür im jeweiligen neuen `exception-alerts`-Block `enabled = true` setzen, nicht OTEL oder die bestehende Monitoring-Unit verändern.

## Abschluss

- [ ] Echte Logs/Regelbestand geprüft, native Validierung und Plan erfolgreich.
- [ ] Kontrollierter Fehler löst den richtigen Alarm aus, Mail bei Alex bestätigt.
- [ ] Gewünschte Umgebungen freigegeben aktiv, Alarmverhalten dokumentiert.

Quellen im Upload: `live/live/root.hcl`, `live/live/{dev,test,prod}/terragrunt.stack.hcl`, `catalog/modules/log-and-monitor/outputs.tf`. [Microsoft: Log-API](https://learn.microsoft.com/en-us/azure/azure-monitor/logs/api/request-format). Die Abfrage verwendet Entra-Anmeldung über `az rest`, keine zusätzliche CLI-Extension.
