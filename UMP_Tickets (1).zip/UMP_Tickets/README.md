# UMP-Tickets: WSL2 + VS Code

**Dein Arbeitsweg:** Windows 11, VS Code im WSL-Modus, Bash-Terminal, Azure-Portal oder `az login` **in WSL**. Keine Windows-Python- oder PowerShell-Schritte mehr.

**Status:** Code vorbereitet, keine Live-Abnahme. Zeljko hast du DBI-12139 bereits zugesagt. Auf Timo, Marcel und Christoph warten wir für die beschriebenen Schritte nicht.

## Jetzt starten

**Dieses ZIP ist ein vollständiges, eigenständiges Ticketpaket, kein Update zum Darüberkopieren.** Du brauchst keine Dateien aus einem älteren Paket.

Den bisherigen **Paketordner** `UMP_Tickets` zunächst umbenennen, zum Beispiel in `UMP_Tickets_alt`. Dann das neue ZIP am gewünschten Ort frisch entpacken. Dadurch entsteht ein neuer, vollständiger `UMP_Tickets`-Ordner. Nicht zusammenführen und nicht „Dateien im Ziel ersetzen“ wählen.

**Deine echten Repositories bleiben dabei unverändert.** Einen übergeordneten UMP-Arbeitsordner mit Repository-Checkouts, `.git`-Verzeichnissen oder eigenen Dateien nicht ersetzen. Gemeint ist ausschließlich der hier gelieferte Ticketordner.

Falls du bereits Ergebnisse erzeugt hast, bleiben `ergebnisse/` und `lokal.json` im alten Paketordner erhalten. Der neue Ordner funktioniert auch ohne sie; insbesondere alte Upload-Belege bis zur Bereinigung der zugehörigen Testdateien aufbewahren.

Den Paketordner in VS Code öffnen und **„WSL: Reopen Folder in WSL“** wählen. Links unten muss WSL stehen. Im dortigen Bash-Terminal:

```bash
bash start.sh 12139
```

Das prüft direkt den Azure-Bestand für **dev, test und prod**. Falls die CLI-Anmeldung fehlt, bietet es `az login` an. Kein vorheriger Git-Branch nötig, kein Upload, kein Terraform-Apply. Der neueste Ordner unter `ergebnisse/DBI-12139/` enthält die lesbare `STATUS.md` und die technischen Ergebnisse.

**Noch einfacher über das Menü:** `bash start.sh`. Alternativ sind in VS Code unter **Terminal > Run Task** die wichtigsten Aufrufe hinterlegt.

## Paket und Repository-Code sind zwei verschiedene Dinge

| Bereich | Vorgehen |
|---|---|
| **`UMP_Tickets/` mit Anleitungen und Werkzeugen** | Jede Lieferung komplett neu entpacken. Kein Drag & Drop über das alte Paket. |
| **Deine echten Code-Repositories** | Nur bewusst ausgewählte, geprüfte Änderungen eines Tickets übernehmen. Niemals das komplette Ticketpaket in ein Repo ziehen oder den Repo-Ordner ersetzen. |

Unter `<Ticket>/code/<Repository>/` liegen vollständige neue oder geänderte **Einzeldateien**, keine vollständigen Repository-Kopien und keine `.git`-Verzeichnisse. Solche Dateien lassen sich bei einer späteren bewussten Codeübernahme unter Beibehaltung der Unterordnerstruktur kopieren. Vorhandene eigene oder neuere Änderungen zuvor abgleichen und danach `git diff` prüfen. Nur genau diese Repository-Dateien sind mit Drag & Drop gemeint.

Der vorhandene `code`-Befehl bleibt als **optionale, geprüfte Alternative** erhalten: Er bereitet die Änderung in einem separaten Git-Worktree vor. Er wird durch das bloße Entpacken oder den Inventarcheck nicht ausgeführt.

**Für DBI-12139 musst du aktuell nichts ins Repo kopieren.** Das Paket enthält hier Prüfcode, keine neue Storage-/Gateway-Infrastrukturänderung. `bash start.sh 12139` läuft direkt aus diesem Ordner. Ob ein echter Infrastruktur-Change nötig ist, ergibt erst der Azure-Abgleich. Für die anderen Tickets sind bereits Codeänderungen vorbereitet; sie sind nicht ausgerollt oder live abgenommen.

## Die Reihenfolge

| Wann | Ticket | Ein Befehl zum Einstieg | Was danach wirklich noch offen ist |
|---|---|---|---|
| Jetzt | [DBI-12139](DBI-12139/README.md) | `bash start.sh 12139` | Asset-Abruf und echtes großes Medium testen; nur nachgewiesene Abweichungen beheben. |
| Parallel | [DBI-11149](DBI-11149/README.md) | `bash start.sh 11149` | Marc anschreiben; auf echter UMP-Instanz testen, nicht vom Laptop aus abnehmen. |
| Danach | [DBI-6455](DBI-6455/README.md) | `bash start.sh 6455` | Alert-Code prüfen/deployen, mit Alex Testmail bestätigen. |
| Bei Migrationsblocker vorziehen | [PB2B-27849](PB2B-27849/README.md) | `bash start.sh 27849` | Oliver bestätigt temporäre Instanz; Metadaten und Login abnehmen. |
| Zuletzt | [DBI-7161](DBI-7161/README.md) | `bash start.sh 7161` | Sinan/OSC bestätigen Schnittstelle, Identitäten und Netzwerk. |

Das ist ein Arbeitsvorschlag. SFTP und LP-Storage sind im vorliegenden Ticketstand beide Prio 1. Zwischen diesen fünf Tickets ist keine zwingende technische Abhängigkeitskette belegt.

## Was dir der Starter abnimmt

- Bereits bekannte Subscription-, Storage-, Gateway- und Workspace-Namen sind hinterlegt. Jede Azure-Abfrage nennt ihre Subscription ausdrücklich; kein stilles Umschalten auf eine zufällige Default-Subscription.
- Repo-Pfade werden an üblichen Stellen gesucht oder einmal abgefragt. Auch ein eingefügter Windows-Pfad wird für WSL umgerechnet. `lokal.json` merkt sich nur lokale Pfade/öffentliche Zielangaben, keine Tokens oder Passwörter.
- Für Codeübernahmen erstellt `code` einen **separaten Git-Worktree pro Ticket** unter `~/ump-worktrees/`. Dein ursprünglicher Checkout bleibt auf seinem Branch. Vor dem Kopieren werden die Dateien gegen den Upload geprüft und du bestätigst die Ticketnummer. Neuere Änderungen werden nicht blind ersetzt.
- Windows-Zeilenenden (CRLF) und Linux-Zeilenenden (LF) werden beim Kopieren als gleichwertig erkannt. Echte Inhaltsänderungen bleiben geschützt. Die ausgelieferten Code-Dateien verwenden LF.
- Der letzte eigene Asset-Testbeleg wird automatisch wiedergefunden. Kein langes Abschreiben von Belegpfaden.
- Keine automatischen Commits, Pushes, Infrastruktur-Deployments oder Nachrichten. Testuploads und Serverkontakte sind getrennte, ausdrücklich bestätigte Aktionen.

## Azure-Portal statt CLI

```bash
bash start.sh portal
```

Dann `ergebnisse/PORTAL.md` öffnen. Darin stehen direkte Links zu Storage, Gateway und Log Analytics für jede Umgebung. Die Ticket-READMEs nennen, was du dort prüfen sollst. Portal-Prüfungen musst du selbst dokumentieren; der Starter kann deine Klicks nicht sehen.

**Wichtig für deine Umgebung:** `az login` gibt dir keine Netzwerkverbindung zu Private Endpoints und keinen SSH-Zugang. Ein erfolgreicher ARM-Inventarcheck kann deshalb funktionieren, während der Blob-Upload aus WSL an VPN/DNS/Route oder Datenrechten scheitert. Auch das Portal umgeht diese Voraussetzungen beim Blob-Datenzugriff nicht. Nicht deshalb den Storage öffentlich schalten. [Microsoft: Private Endpoints](https://learn.microsoft.com/en-us/azure/storage/common/storage-private-endpoints)

## Voraussetzungen nur bei Bedarf

```bash
bash start.sh setup
```

Der Befehl prüft die Werkzeuge, installiert und aktualisiert aber nichts.

| Für welche Arbeit? | Lokal in WSL erforderlich |
|---|---|
| 12139 prüfen, 6455 Logs lesen | Python 3.10+ und die **Linux-Azure-CLI**. Keine Python-Zusatzpakete. |
| Code isoliert übernehmen | Zusätzlich Git und dein echter Checkout. |
| Terraform-Module lokal validieren | Terraform **1.13.4** gemäß Upload. Alternativ eure vorhandene CI nutzen. |
| Lokale Terragrunt-Pläne | Zusätzlich Terragrunt **1.1.6** gemäß Upload und GitLab-Zugriff auf Katalog/State. |
| SFTP aus der UMP prüfen | Bestehender freigegebener Serverzugang; dort die UMP-PHP-Laufzeit. Kein lokales PHP nötig. |
| SAML vorbereiten / Check-Lauf | OpenSSL; für den Check zusätzlich eure Linux-Ansible-Umgebung, Inventory und Serverzugang. |

Eine normale Portal-Anmeldung ersetzt keine CLI-Anmeldung. Bei Bedarf:

```bash
az login
```

Öffnet sich der Browser nicht, ist `az login --use-device-code` eine dokumentierte Alternative, **sofern eure Anmelderichtlinien sie erlauben**. Keine Tokens aus Windows nach WSL kopieren. [Microsoft: CLI-Anmeldung](https://learn.microsoft.com/en-us/cli/azure/authenticate-azure-cli-interactively)

Fehlt die Linux-CLI, die freigegebene Installation nach [Microsofts Linux-Anleitung](https://learn.microsoft.com/en-us/cli/azure/install-azure-cli-linux?pivots=apt) verwenden. Der Starter lehnt versehentlich gefundene Windows-Executables ab.

**Terraform braucht zusätzlich GitLab-State-Zugang.** Der State liegt laut `live/live/root.hcl` in GitLab-Projekt 3559, nicht in deinem Azure-Login. Für möglichst wenig lokale Einrichtung: Änderungen im Ticket-Worktree prüfen und den vorhandenen GitLab-Plan-/Freigabeprozess nutzen. Keinen produktiven State lokal neu initialisieren und keine Secrets ins Paket schreiben.

## Windows-Dateien und WSL-Repos

Das Paket kann in deinem Windows-Arbeitsordner bleiben. Repositories/Worktrees möglichst im Linux-Dateisystem halten. Der Starter legt neue Worktrees deshalb unter deinem WSL-Home an. Windows-Explorer-Zugriff bekommst du dort mit:

```bash
explorer.exe .
```

Aus einem Linux-Arbeitsordner öffnet `code .` das Projekt in VS Code. [VS Code: WSL](https://code.visualstudio.com/docs/remote/wsl) · [Microsoft: Dateisysteme](https://learn.microsoft.com/en-us/windows/wsl/filesystems)

**WSL-Hostzugang und Azure-Zugang nicht vermischen:** Dass dein Windows-Browser eine interne Seite erreicht, beweist noch nicht, dass WSL denselben VPN-/DNS-Weg hat. TLS-Prüfung und SSH-Host-Key-Prüfung bleiben eingeschaltet.

## Nachsehen und selbst testen

```bash
bash start.sh status
bash start.sh tests
```

Die tatsächlichen lokalen Tests und noch fehlenden Prüfungen stehen in [PRUEFPROTOKOLL.md](PRUEFPROTOKOLL.md). Der alte `.ps1`-Einstieg und der alte Patchpfad sind lediglich Hinweisdateien aus früheren Paketständen. Du brauchst sie nicht. Maßgeblich ist der WSL-Einstieg `bash start.sh`.
