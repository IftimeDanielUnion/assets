#!/usr/bin/env bash
# Run from the WSL terminal in VS Code. Calling through bash needs no chmod.
set -euo pipefail
ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)"
if ! command -v python3 >/dev/null 2>&1; then
  printf '%s\n' 'Python 3 fehlt in WSL. Installiere python3 über eure freigegebene Linux-Paketquelle.' >&2
  exit 2
fi
if ! python3 -c 'import sys; sys.exit(0 if sys.version_info >= (3, 10) and sys.platform.startswith("linux") else 1)'; then
  printf '%s\n' 'Bitte in WSL mit Linux-Python 3.10 oder neuer starten, nicht in PowerShell oder Git Bash.' >&2
  exit 2
fi
export PYTHONDONTWRITEBYTECODE=1
export PYTHONUNBUFFERED=1
exec python3 "$ROOT/start.py" "$@"
