#!/usr/bin/env python3
"""Safely copy one ticket's complete files to its repository. Default: preview only."""
from __future__ import annotations
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys

BASE = Path(__file__).resolve().parent

def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()

def digest_lf(path: Path) -> str:
    """Compare Windows CRLF and Linux LF without ignoring real content changes."""
    return hashlib.sha256(path.read_bytes().replace(b'\r\n', b'\n')).hexdigest()

def matches(path: Path, raw_hash: str | None, lf_hash: str | None = None) -> bool:
    return digest(path) == raw_hash or (lf_hash is not None and digest_lf(path) == lf_hash)

def inspect(ticket: str, target: Path, manifest: dict) -> list[tuple[Path, Path, bool]]:
    target = target.resolve()
    if not target.is_dir():
        raise ValueError('Zielordner existiert nicht.')
    files = [f for f in manifest['files'] if f['ticket'] == ticket]
    if not files:
        raise ValueError('Unbekanntes Ticket oder keine Code-Dateien.')
    actions = []
    for entry in files:
        source = (BASE / entry['package_path']).resolve()
        dest = (target / entry['repository_path']).resolve()
        if not source.is_relative_to(BASE) or not dest.is_relative_to(target):
            raise ValueError('Unerwarteter Pfad oder Symlink außerhalb des Repositorys.')
        # Refuse symlink leaves even if they happen to resolve inside the repository.
        raw = target / entry['repository_path']
        if raw.is_symlink():
            raise ValueError('Keine Symlink-Ziele überschreiben: ' + str(raw))
        if not matches(source, entry['sha256'], entry.get('lf_sha256')):
            raise ValueError('Paketdatei nach Erstellung geändert: ' + str(source))
        exists = dest.exists()
        if exists and not dest.is_file():
            raise ValueError('Ziel ist keine reguläre Datei: ' + str(dest))
        if exists and matches(dest, entry['sha256'], entry.get('lf_sha256')):
            print('BEREITS AKTUELL: ' + entry['repository_path'])
            continue
        if entry['original_sha256'] is None:
            if exists:
                raise ValueError('Neue Zieldatei existiert bereits mit anderem Inhalt: ' + str(dest))
        elif not exists or not matches(dest, entry['original_sha256'], entry.get('original_lf_sha256')):
            raise ValueError('Ziel weicht vom geprüften Upload ab. Nicht blind ersetzen: ' + str(dest))
        print(('ERSETZEN: ' if exists else 'NEU: ') + entry['repository_path'])
        actions.append((source, dest, exists))
    return actions

def git(root: Path, *arguments: str) -> str:
    result = subprocess.run(['git', '-C', str(root), *arguments], capture_output=True, text=True, check=False)
    if result.returncode:
        raise ValueError(result.stderr.strip() or 'Git-Prüfung fehlgeschlagen.')
    return result.stdout.strip()

def apply(target: Path, ticket: str, actions: list) -> None:
    if not actions:
        return
    top = Path(git(target, 'rev-parse', '--show-toplevel')).resolve()
    if top != target.resolve():
        raise ValueError('Bitte exakt den Repository-Stamm als Ziel wählen, keinen Unterordner.')
    if git(target, 'status', '--porcelain'):
        raise ValueError('Git-Checkout ist nicht sauber. Eigene Änderungen zuerst committen oder separat sichern.')
    if not sys.stdin.isatty() or input(f"Zum Ersetzen exakt '{ticket}' eingeben: ").strip() != ticket:
        raise ValueError('Nicht bestätigt. Nichts kopiert.')
    # Detect modifications that happened while confirmation was being entered.
    manifest = json.loads((BASE / 'paket.json').read_text(encoding='utf-8'))
    refreshed = inspect(ticket, target, manifest)
    if refreshed != actions or git(target, 'status', '--porcelain'):
        raise ValueError('Dateien haben sich während der Bestätigung geändert. Vorgang erneut prüfen.')
    git_dir = Path(git(target, 'rev-parse', '--absolute-git-dir'))
    backup = git_dir / 'ump-ticket-backups' / (ticket + '-' + datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ'))
    backup.mkdir(parents=True, exist_ok=False)
    done = []
    try:
        for source, dest, exists in actions:
            if exists:
                saved = backup / dest.relative_to(target)
                saved.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(dest, saved)
            dest.parent.mkdir(parents=True, exist_ok=True)
            temp = dest.with_name(dest.name + '.ump-new')
            if temp.exists():
                raise ValueError('Temporäre Datei existiert bereits: ' + str(temp))
            try:
                shutil.copyfile(source, temp)
                temp.replace(dest)
            finally:
                temp.unlink(missing_ok=True)
            done.append((dest, exists))
    except BaseException:
        for dest, existed in reversed(done):
            if existed:
                shutil.copy2(backup / dest.relative_to(target), dest)
            else:
                dest.unlink(missing_ok=True)
        raise
    print('Kopiert. Kein Commit, Push oder Deployment ausgeführt.')
    print('Sicherung ersetzter Dateien: ' + str(backup))
    print('Jetzt git diff und git status im Ziel prüfen.')

def main() -> int:
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument('--ticket', required=True)
    cli.add_argument('--ziel', type=Path, required=True, help='Root of the single repository mentioned in the ticket README.')
    cli.add_argument('--anwenden', action='store_true')
    args = cli.parse_args()
    try:
        target = args.ziel.resolve()
        manifest = json.loads((BASE / 'paket.json').read_text(encoding='utf-8'))
        changes = inspect(args.ticket, target, manifest)
        if args.anwenden:
            apply(target, args.ticket, changes)
        else:
            print('VORSCHAU. Nichts kopiert. Erst nach Prüfung erneut mit --anwenden aufrufen.')
        return 0
    except (OSError, ValueError, KeyError, subprocess.SubprocessError) as error:
        print('STOPP: ' + str(error), file=sys.stderr)
        return 2

if __name__ == '__main__':
    raise SystemExit(main())
