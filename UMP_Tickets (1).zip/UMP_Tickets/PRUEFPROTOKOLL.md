# Prüfprotokoll: WSL2-Paket

**Stand: 01.10.2026.** Angepasst für Windows 11 mit VS Code Remote WSL, Bash und Linux-Azure-CLI. Das Paket wurde hier unter Linux geprüft, **nicht auf einem echten Windows-11-/WSL2-Rechner und nicht gegen eure Live-Systeme**.

## Tatsächlich ausgeführte Prüfungen

| Prüfung | Ergebnis |
|---|---|
| Gesamte lokale Testsuite | **136 Tests bestanden, 0 Fehler, 0 übersprungen.** Enthält die bisherigen 76 Tests und 60 zusätzliche WSL-/Starter-Tests. |
| Asset-Quellcodeabgleich gegen den hochgeladenen `live`-Stand | **48 Strukturprüfungen** über dev/test/prod bestanden. Keine Terraform-Semantikprüfung. |
| Vollständige Codeübernahme aller fünf Tickets | In **fünf temporären echten Git-Repositories/Worktrees** getestet; alle 14 Repository-Dateien bytegenau übernommen. Ursprünglicher Branch und Checkout unverändert, zweiter Aufruf idempotent. |
| Windows-/Linux-Zeilenenden | CRLF- und LF-Dateien als inhaltlich gleich erkannt; echte Änderungen weiterhin abgelehnt. Sowohl isoliert getestet als auch mit den vollständigen Dateien aus dem Upload. |
| Paketintegrität | Prüfsummen von **14 Repository-Code-Dateien und 13 Starter-/Hilfsdateien** geprüft. Original-Hashes und LF-Vergleichshashes stehen in `paket.json`. |
| Bash/Python/VS Code | `bash -n`, Python-Syntax, Start-/Hilfsbefehle sowie JSON-Struktur der VS-Code-Aufgaben geprüft. |
| PHP | Die beiden neuen PHP-Dateien und isolierte Prüflogik unter **PHP 8.4.23** geprüft. Kein vollständiger Symfony-Lauf in der verlangten PHP-8.5-Anwendung. |
| YAML | GitLab-CI, Ansible-Hostdatei und temporäres Playbook sicher geparst. Keine native Ansible-/GitLab-CI-Validierung. |
| Public Key | Beiliegender RSA-Public-Key gegen erwarteten SHA256-Fingerprint geprüft. Kein privater Schlüssel beigefügt. |

Testumgebung: Python 3.13.5, Linux. Die exakte Python-Version des Laufs und die Ergebnisdaten stehen zusätzlich in `paket.json`.

## Was die neuen Tests abdecken

Windows-Pfade mit Leerzeichen, WSL-UNC-Pfade und falsche Distributionen; Ablehnung versehentlicher Windows-CLI-Executables; fehlende Anmeldung; keine Token-Ausgabe; Subscription-Zuordnung; all-Environment-Asset-Inventar und Monitoring-Abfrage mit simulierten Antworten; leere/partielle Ergebnisse und Lesefehler; sichere Wiederverwendung eigener Upload-Belege; getrennte Git-Worktrees; SSH-Zielquotierung/Host-Key-Prüfung; SAML-Zielvorbereitung; keine automatische Infrastrukturänderung.

**Azure, HTTP und Remote-SSH wurden dabei simuliert.** Eine grüne Testsuite beweist diese lokalen Eigenschaften, keine Jira-Abnahme.

## Bewusst noch nicht ausgeführt

- Kein echter `az login`, keine Azure-Bestandsaufnahme, kein Testupload, kein Asset-Abruf und keine Mail.
- Keine Verbindung zu UMP/Lukas, kein SFTP-Anwendungstest und kein SAML-Login.
- Kein nativer Terraform-/Terragrunt-/Ansible-Lauf und kein echter Plan/Apply. Die Programme waren hier nicht installiert; der versuchte Terraform-Download scheiterte an der DNS-/Netzbeschränkung dieser Testumgebung. Es wurde deshalb **kein** Provider-Validate als erfolgreich ausgegeben.
- Kein tatsächlicher VS-Code-Task-Lauf in WSL2. Getestet sind Bash-/Python-Aufruf und Task-Konfiguration unter Linux.
- Keine Nachricht verschickt, kein Jira verändert, nichts committed/gepusht oder bereitgestellt.

`bash start.sh 6455 validate` bzw. `bash start.sh 7161 validate` führt bei installiertem passendem Terraform eine isolierte native Modulprüfung aus. Dafür werden Provider geladen, aber kein produktiver State verwendet. Das ersetzt weiterhin keinen Plan mit euren realen Abhängigkeiten.

## Wichtige Anpassungen gegenüber dem vorigen Paket

**Eine Bedienung:** `bash start.sh` ist der gemeinsame Einstieg. Die vollständigen Repository-Dateien bleiben erhalten. Die fünf Ticket-READMEs sind auf WSL-Befehle und den Portal-Alternativweg umgestellt.

**Kein unnötiger Git-Schritt für 12139:** Der vorhandene Azure-Aufbau kann unmittelbar aus dem Paket gelesen werden. Erst eine nachgewiesene Abweichung rechtfertigt eine Infrastrukturänderung. Ein Prüfskript muss dafür nicht erst eingecheckt oder deployed werden.

**Windows-Zeilenenden waren ein realer Kopierblocker:** Beispielsweise enthält die hochgeladene `live/live/test/terragrunt.stack.hcl` CRLF, derselbe Git-HEAD aber LF. Der alte reine Bytevergleich hätte einen passenden WSL-Checkout abgelehnt. Jetzt wird ausschließlich CRLF zu LF normalisiert; Leerzeichen, Inhalte und sonstige Änderungen werden nicht ignoriert. Der Kopierhelfer bleibt gegen fremde Änderungen abgesichert.

**Getrennte Authentifizierung und Netze:** Linux-CLI-Anmeldung, GitLab-State-Zugriff, Blob-Datenrechte/VPN/DNS und UMP-Serverzugang sind getrennte Voraussetzungen. Der Starter versucht nicht, eines davon durch Kopieren von Tokens/Schlüsseln oder Öffnen von Netzwerken zu ersetzen.

**SAML-Check aus WSL:** Der Starter verwendet ein ausdrücklich angegebenes Inventory und setzt `ANSIBLE_CONFIG` sowie aktivierte SSH-Host-Key-Prüfung. Diese Einstellungen werden auch im vorbereiteten späteren Deployment-Befehl angegeben.

## Unveränderte fachliche Checkpoints

| Ticket | Stand nach dieser WSL-Anpassung |
|---|---|
| DBI-12139 | Infrastruktur im Snapshot vorhanden; echter Bestand und anonyme Erreichbarkeit offen. |
| DBI-11149 | Diagnosecode/Public Key vorbereitet; Gegenstelle und echter UMP-Test offen. |
| DBI-6455 | Alert-Code vorbereitet; Logprüfung, nativer Plan, Deployment und Testmail offen. |
| PB2B-27849 | Temporärer Ablauf vorbereitet; bestätigte Instanz und Live-Abnahme offen. |
| DBI-7161 | Nicht aktivierter Infrastrukturentwurf; Schnittstelle, Identitäten und Integration offen. |

Die WSL-Anpassung ändert die Infrastruktur-/Anwendungslogik der 14 zuvor vorbereiteten Repository-Dateien nicht. Bei diesen Dateien wurden lediglich Windows-Zeilenenden auf LF vereinheitlicht. Neu entwickelt sind der WSL-Starter und seine unterstützenden Prüf-/Kopierfunktionen.

## Quellen und verwendeter Stand

Originalquellen: `UMP_repos.zip`, die vier Jira-Exporte in `ump_jiras.zip`, die Screenshots zu DBI-12139 und deine Angaben zum Arbeitsstand. SHA256 und die Git-Stände der ursprünglichen Repositories stehen unverändert in `paket.json`.

Wichtige Originaldateien für diese Anpassung: `live/live/root.hcl` (GitLab-HTTP-State, Provider), `.terraform-version` (1.13.4), `.terragrunt-version` (1.1.6), `live/{dev,test,prod}/terragrunt.stack.hcl` (Ressourcennamen), `ansible-ump/ansible.cfg` (bisheriges Default-Inventory und Host-Key-Einstellung).

Abgeglichene offizielle Dokumentation, Recherche am 01.10.2026:

- [VS Code: Entwicklung in WSL](https://code.visualstudio.com/docs/remote/wsl) und [Microsoft: Windows-/WSL-Dateisysteme](https://learn.microsoft.com/en-us/windows/wsl/filesystems).
- [Azure CLI: interaktive Anmeldung](https://learn.microsoft.com/en-us/cli/azure/authenticate-azure-cli-interactively) und [Linux-Installation](https://learn.microsoft.com/en-us/cli/azure/install-azure-cli-linux?pivots=apt).
- [Log Analytics: API-Zugriff und Authentifizierung](https://learn.microsoft.com/en-us/azure/azure-monitor/logs/api/access-api) und [Abfrageformat](https://learn.microsoft.com/en-us/azure/azure-monitor/logs/api/request-format). Das Skript verwendet den neuen API-Host mit dem dokumentierten Token-Resource-Wert.
- [Scheduled Query Rules: List by Subscription, API 2021-08-01](https://learn.microsoft.com/rest/api/monitor/scheduledqueryrule-2021-08-01/scheduled-query-rules/list-by-subscription).
- [Azure Storage: Private Endpoints](https://learn.microsoft.com/en-us/azure/storage/common/storage-private-endpoints).

Bei geänderten UIS-Policies, Ressourcen oder Schnittstellen den echten Ist-Stand prüfen. Die Namen im Paket stammen aus dem Upload, nicht aus einer aktuellen Live-Abfrage.

## Paketübergabe: frischer vollständiger Ordner

Die Hauptanleitung wurde auf vollständiges Neu-Entpacken statt Zusammenführen umgestellt. Paketordner und echte Repositories sind ausdrücklich getrennt. Die 14 im Manifest aufgeführten Repository-Dateien und alle Werkzeuge sind gegenüber dem zuvor gelieferten WSL-Paket unverändert. Für diese reine Dokumentationsänderung wurden ZIP-Integrität, Vollständigkeit und die SHA-256-Werte aller 14 Repository-Dateien geprüft. Es wurden keine weiteren Live-Tests oder Deployments ausgeführt.
