# DBI-11149: Lukas-SFTP

**Parallel zu 12139 anstoßen.** Standalone, aber Schlüsselhinterlegung und Serverzugang sind echte externe Voraussetzungen. Der Diagnosecode behebt den Fehler nicht automatisch.

## 1. Schlüssel prüfen und Marc schreiben

```bash
bash start.sh 11149
```

Prüft lokal den beiliegenden **öffentlichen** Schlüssel. Keine Verbindung zu Lukas oder UMP. Diese Mail kannst du anschließend senden:

**An:** Marc Hintz, `hintz@msu.biz`  
**Betreff:** DBI-11149: zusätzlichen Public Key für Lukas PROD prüfen  
**Anhang:** `DBI-11149/azure-lukas-sftp-prod.pub`

> Hallo Marc,
>
> ich übernehme gerade DBI-11149 und würde den offenen Lukas-SFTP-Zugang gern mit dir abschließen. Kannst du bitte prüfen, ob der angehängte öffentliche Schlüssel bereits hinterlegt ist? Falls nicht, bitte zusätzlich hinterlegen; der bisherige Schlüssel soll bestehen bleiben.
>
> Im bisherigen Stand stehen `lukaspartner.msu.biz` und `UI_marketing`. Kannst du bitte Host, Port, Benutzer und Zielverzeichnis bestätigen und mir den aktuellen SSH-Host-Key-Fingerabdruck über unseren abgestimmten Kontaktweg nennen? Danach prüfe ich zunächst nur Anmeldung und Verzeichniszugriff, ohne Dateien zu übertragen.
>
> Danke dir!

Danach an 12139 weiterarbeiten, nicht auf die Antwort warten. **Keine privaten Schlüssel verschicken oder aus dem UMP-Server nach WSL kopieren.**

## 2. Diagnosecode bereitstellen

```bash
bash start.sh 11149 code
```

Der Starter fragt nötigenfalls einmal nach deinem `unioninvestment`-Checkout und kopiert die beiden vollständigen PHP-Dateien in einen separaten Ticket-Worktree. Das ist noch kein Deployment. Änderungen prüfen und über euren normalen UMP-Prozess bereitstellen. Die vollständige Anwendung wurde hier nicht gestartet; im Upload verlangt sie PHP 8.5.

## 3. Von WSL aus die echte UMP-Instanz prüfen

Nur mit bereits vorhandenem freigegebenem SSH-Zugang und installiertem Diagnosebefehl:

```bash
bash start.sh 11149 server
```

Fragt nach **UMP-SSH-Alias**, dortigem App-Verzeichnis mit `bin/console` und dortigem PHP. Diese Angaben werden für den nächsten Aufruf gemerkt. Nach deiner Zielbestätigung führt es auf der UMP als `www-data` aus:

```bash
php bin/console app:diagnostics:mbo-sftp
```

Der App-Befehl zeigt nur die tatsächlich konfigurierten Verbindungswerte und den Client-Key-Fingerprint. Er öffnet dabei keine Verbindung zu Lukas. Lokales PHP in WSL ist hierfür nicht nötig.

Erst nach Marcs Bestätigung und unabhängig geprüftem Lukas-Host-Key im App-`known_hosts`:

```bash
bash start.sh 11149 connect
```

Das führt denselben Befehl mit `--connect` auf UMP aus. Nur anmelden, `pwd`, `cd`, `pwd`, `bye`; kein Upload, kein Auftrag. Der Admin-SSH-Host-Key und der SFTP-Gegenstellen-Host-Key bleiben geprüft. `az login` ersetzt keinen dieser Zugänge. Ohne direkten SSH-Weg denselben App-Befehl über euren freigegebenen UMP-/Bastion-/Betriebszugang ausführen.

**Nicht `app:export:mbo` zum bloßen Verbindungstest verwenden:** Dieser Befehl kann echte Aufträge bearbeiten und Dateien übertragen. Alte RSA-Verfahren nicht pauschal aktivieren; eine ausdrücklich freigegebene Ausnahme ist im Diagnosecode separat vorgesehen, nicht als Starter-Default.

## 4. Anwendungstest mit Alex

Erst wenn Anmeldung und Zielverzeichnis tatsächlich funktionieren:

> Hi Alex, die reine Lukas-SFTP-Anmeldung und der Zugriff auf das Zielverzeichnis funktionieren jetzt aus der UMP-Instanz. Für die fachliche Abnahme würde ich gern einen freigegebenen Testauftrag verwenden, ohne einen produktiven Export als Test anzustoßen. Welchen Testfall können wir dafür nehmen? Danke dir!

## Abschluss

- [ ] Schlüssel und Host-Key bestätigt.
- [ ] Anmeldung/Verzeichnis aus dem echten UMP-App-Kontext erfolgreich.
- [ ] Sicherer Anwendungstest durchgeführt, Ergebnis und verbleibende Ausnahmen im Jira dokumentiert.

Quellen: Jira DBI-11149 im Upload; `unioninvestment/htdocs/application_includes/W2P/Export/mbo_export_controller.php`, `htdocs/includes/Comm/File/class.sftp_connector.php`, `etc/config/packages/global.yml`. Der zusätzliche Code liegt vollständig unter `code/unioninvestment/htdocs/src/Console/Command/Diagnostics/`.
