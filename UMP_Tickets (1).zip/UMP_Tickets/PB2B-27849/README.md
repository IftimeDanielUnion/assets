# PB2B-27849: temporärer SAML-Login

**Bei blockierten Migrationstests vorziehen.** Kein anderes Jira muss zuerst fertig sein. Die tatsächliche temporäre Instanz muss aber eindeutig bestätigt werden. Eine Portal-/CLI-Anmeldung allein ist weder SAML-Test noch Ansible-/Serverzugang.

## 1. Nachricht an Oliver

> Hi Oliver, ich übernehme PB2B-27849. Laut bisherigem Stand wurde die temporäre App bereits angelegt. Damit ich gezielt die richtige Instanz prüfe, brauche ich bitte den konkreten Ansible-Zielhost, die öffentliche UMP-URL, Entity-ID und ACS-/Rücksprungadresse. Soll weiterhin `B2C_1A_signin_saml_ump_tmp` verwendet werden? Blockiert das aktuell eure Migrationstests? Danke dir!

Nicht auf Verdacht den normalen PROD-Login ändern und keine zweite App anlegen.

## 2. Code isoliert übernehmen

```bash
bash start.sh 27849 code
```

Ziel ist dein `ansible-ump`-Checkout. Der separate Ticket-Worktree liegt im **Linux-Dateisystem unter `~/ump-worktrees/`**, nicht unter `/mnt/c`. Enthalten: Metadatenprüfer, temporäres Ansible-Playbook mit Zielprüfung/Backup/Rücknahme und optionale IdP-Dateiauswahl mit unverändertem normalen Default.

## 3. Nach Olivers Antwort lokal vorbereiten

Von der bestätigten temporären Instanz brauchst du eine lesende Kopie der öffentlichen SP-Metadatendatei:

```text
/etc/apache2/mellon/ump-app_metadata.xml
```

Kein privater Schlüssel. Nutze euren bestehenden freigegebenen Server-/Bastion-/Ansible-Weg für diese Kopie. Ein Zugang wird nicht aus dem Azure-Login abgeleitet.

Danach:

```bash
bash start.sh 27849 prepare
```

Der Starter fragt die bestätigten Angaben einmal auf Deutsch ab, merkt sie sich lokal, ruft den Metadatenprüfer auf und legt den Ergebnisbeleg an. Echte IdP-Metadaten werden von der im Ticket genannten temporären Policy bezogen. Bei falscher Zuordnung oder ungültigen Metadaten stoppt er. **Noch keine Serverkonfiguration wird übernommen.**

## 4. Gezielter Ansible-Check aus WSL

Wenn Ansible und der freigegebene Serverzugang in WSL vorhanden sind:

```bash
bash start.sh 27849 dry-run
```

Fragt einmal nach dem **bestätigten Inventory**, nicht nach dem lokalen Repo-Default. Du bestätigst den konkreten Zielhost. Führt Syntaxprüfung und `--check --diff` aus. Der Starter setzt `ANSIBLE_CONFIG` ausdrücklich und aktiviert die SSH-Host-Key-Prüfung, auch wenn der alte Repo-Default sie deaktiviert. Ein noch unbekannter SSH-Host-Key muss vorher über euren normalen Vertrauensweg bestätigt werden.

Ansible kann für die Prüfung temporäre Helfer auf die Zielinstanz übertragen; die produktive Metadatendatei wird im Check-Modus nicht ersetzt. Die neue `STATUS.md` enthält danach den **fertig ausgefüllten Deployment-Befehl**. Diesen erst nach Review und Freigabe in derselben WSL-/Ansible-Umgebung ausführen. Ohne lokale Ansible-Erreichbarkeit den vorbereiteten Stand über euren bestehenden Ansible-/Betriebsprozess ausrollen, keine alternative Verbindung improvisieren.

## 5. Login und Rückbau

Mit freigegebenem Benutzer den temporären Login bis zur richtigen UMP-Instanz testen. Normalen Login separat gegenprüfen. Apache-Configtest allein beweist keinen funktionierenden SAML-Login.

Die spezielle `mellon_idp_metadata_source` nur für den bestätigten temporären Host im normalen Konfigurationsweg hinterlegen. Sonst könnte ein späterer Standardlauf die alte Auswahl wiederherstellen. Nie global für PROD setzen.

**Nur nach erfolgreichem echten Test an Oliver:**

> Hi Oliver, der Login der bestätigten temporären UMP-Instanz ist erfolgreich getestet. Den regulären Login habe ich ebenfalls gegengeprüft. Ich dokumentiere die Zuordnung im Jira. Wann soll die temporäre App samt Sonderkonfiguration wieder zurückgebaut werden? Danke dir!

## Abschluss

- [ ] Ziel/Policy/Entity/ACS unabhängig bestätigt.
- [ ] Metadaten, Ansible-Check und freigegebenes Deployment erfolgreich.
- [ ] Tatsächlicher Login funktioniert, normaler Login unverändert.
- [ ] Dauerhafte temporäre Hostzuordnung und Rückbau abgestimmt.

Quellen: Jira PB2B-27849; `ansible-ump/ansible.cfg`, `host_vars/ump-app` und vorhandene Mellon-Konfiguration. Kein echter Metadatenabruf oder Login wurde hier als erledigt behauptet.
