# DBI-12139: Landingpage-Assets

**Erster Arbeitsschritt. Standalone.** Die Storage-/Container-/Gateway-Definitionen sind bereits im Original-Repo vorhanden. Unbekannt ist der echte Azure- und Erreichbarkeitsstand. Deshalb zuerst prüfen, nicht noch einmal Infrastruktur anlegen.

## 1. Diesen einen Befehl starten

Im WSL-Terminal des Paketordners:

```bash
bash start.sh 12139
```

Prüft dev/test/prod, fragt bei fehlender Anmeldung nach `az login` und schreibt eine verständliche `STATUS.md` unter `ergebnisse/DBI-12139/`. Du musst keinen Prüfcode ins Repo kopieren oder committen. Ein automatisch gefundener aktueller `live`-Checkout wird zusätzlich strukturell abgeglichen. Optional den Pfad einmal selbst angeben:

```bash
read -r -p 'Pfad zu deinem live-Repo: ' REPO
bash start.sh 12139 --repo "$REPO"
```

**Ergebnis lesen:** Ein Berechtigungs-/Netzfehler beweist keine fehlende Ressource. Wenn die Werte passen, ist noch kein Terraform-Change nötig. Bei Abweichungen zuerst mit State/Plan vergleichen; keine öffentliche Netzwerkfreigabe als schnelle „Reparatur“.

## 2. Den tatsächlichen Abruf prüfen

Wenn der Inventarcheck passt und WSL den Storage über euren VPN-/Private-Endpoint-Weg erreicht:

```bash
bash start.sh 12139 upload
bash start.sh 12139 probe
```

Standard ist **TEST / uniglobal**. Der Upload verlangt `UPLOAD test`, erzeugt nur eine neue synthetische 8-KiB-Datei und überschreibt kein Asset. Der Abruf findet den eigenen Beleg automatisch. Er prüft den Inhalt und den Range-Abruf ohne Login. Du gibst an, ob du intern, extern oder an einem unbekannten Netzstandort prüfst. **WSL mit Firmen-VPN zählt nicht automatisch als externer Test.**

Zur Eingrenzung: direkter Blob-Abruf aus dem erreichbaren internen Netz:

```bash
bash start.sh 12139 probe --endpoint blob-intern --network intern
```

Ein wirklich großes, freigegebenes Medium separat prüfen. Der Starter fragt dessen relativen Blob-Pfad ab; keine Datei wird verändert:

```bash
bash start.sh 12139 medium
```

Er lädt nur Anfang/Ende, nicht den ganzen Film. Danach in der echten Landingpage im Browser prüfen. Für andere Umgebungen `--env dev` bzw. `--env prod` ergänzen; andere Kampagnen: `--campaign ve` oder `--campaign zukunft`. Produktive Testuploads brauchen die entsprechende Freigabe. Ein erfolgreicher TEST-Abruf ist kein Nachweis für DEV/PROD.

Eigene Testdatei anschließend entfernen, wieder aus dem erreichbaren Netz:

```bash
bash start.sh 12139 cleanup
```

Das verlangt nochmals eine Bestätigung und löscht nur den markierten, unveränderten eigenen Testblob. Für einen älteren Beleg `--receipt` mit dessen Pfad verwenden. Belege stehen zusammen mit der Testdatei unter `ergebnisse/DBI-12139/`; bei einem Test von einem anderen Rechner den gesamten Belegordner mitnehmen.

## Portal-Alternative

`bash start.sh portal`, dann `ergebnisse/PORTAL.md` öffnen. Im Storage **Konfiguration**, **Netzwerk** und **Container** prüfen; im Gateway Listener/Regeln und Backend ansehen. Release-Container sind für anonymes Blob-Lesen vorgesehen, aber Storage-Netzzugang und Gateway-Listener im Snapshot privat. Der allgemeine Container `assets` bleibt privat. Die externe Veröffentlichung muss getrennt funktionieren.

Der öffentliche Pfad ist nicht gleich dem Containernamen: `/uniglobal/` wird beispielsweise auf `uniglobal-release-1` abgebildet. Deshalb einen konkreten Assetpfad testen, nicht nur die Domain-Wurzel. [Azure-Private-Endpoint-Grundlagen](https://learn.microsoft.com/en-us/azure/storage/common/storage-private-endpoints)

## Nachrichten

**Zeljko musst du deine Zusage nicht noch einmal schicken.** Nur wenn du einen Zwischenstand geben möchtest, der jetzt schon stimmt:

> Hi Zeljko, ich habe den Quellcode für DBI-12139 abgeglichen. Der grundlegende Aufbau für dev, test und prod ist bereits vorgesehen. Als Nächstes prüfe ich den tatsächlichen Azure-Stand und den anonymen Abruf der Assets. Erst danach lässt sich sagen, ob noch eine Infrastrukturänderung nötig ist. Ich melde dir das Ergebnis der Prüfung separat.

**Wenn dir ein freigegebenes großes Medium fehlt, an Alex Köster:**

> Hi Alex, für DBI-12139 möchte ich neben dem technischen Zugriff auch ein echtes großes Landingpage-Medium prüfen. Kannst du mir dafür bitte eine freigegebene Asset-URL und die zugehörige Landingpage nennen, möglichst zuerst auf TEST? Ich möchte dafür keine produktiven Inhalte verändern. Danke dir!

## Abschluss

- [ ] Inventar aller drei Umgebungen bestätigt; echte Abweichungen behoben oder benannt.
- [ ] Benötigte Assetpfade anonym erreichbar, tatsächlicher Teststandort dokumentiert.
- [ ] Großes Medium und echte Landingpage geprüft; eigene Testblobs bereinigt.
- [ ] Ergebnis im Jira eingetragen, nicht nur „Storage existiert“.

**Code bleibt dabei:** `code/live/scripts/lp_assets.py`. Übernahme optional mit `bash start.sh 12139 code`. Quellen im Original: `live/live/{dev,test,prod}/terragrunt.stack.hcl`, `appgateway.hcl`, `catalog/modules/blob-storage-private/`. Hier wurde keine neue Storage-Infrastruktur gebaut.
