# Compatibility notice: keeps the old filename so Windows drag-and-drop replaces it.
Write-Host 'Dieses Paket verwendet jetzt WSL. Im VS-Code-WSL-Terminal aus dem Ordner UMP_Tickets starten:'
Write-Host 'bash start.sh 12139'
exit 2
