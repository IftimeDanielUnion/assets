# DBI-7161: ProductHub -> Event Grid -> UMP

**Zuletzt, sofern kein akuter Blocker gemeldet wird.** Kein anderes Ticket muss technisch zuerst fertig sein. Die Schnittstelle und Zuständigkeiten fehlen aber noch. Der Code ist ein Infrastrukturvorschlag, kein bereits funktionsfähiger Gesamtflow.

## 1. Nachricht an Sinan

> Hi Sinan, ich bereite DBI-7161 vor. Ein Azure-Baustein für Topic, Senderberechtigung, Zustellung und Fehlerablage liegt vor, ist aber noch nicht eingebunden. Für die richtige Integration brauche ich bitte das aktuelle Konzept, eine Beispielnachricht, die UMP-Empfänger-URL und die erste Zielumgebung. Kannst du außerdem bestätigen, wer Publisher und UMP-Empfänger übernimmt, welche Identitäten vorgesehen sind und welche Publisher-IP-Netze freigegeben werden sollen? Der aktuelle Entwurf verwendet Entra/RBAC; die im Ticket erwähnten B2C-Scopes möchte ich nicht ungeprüft damit gleichsetzen. Danke dir!

**Für fehlende Anwendungsteile an Alex:**

> Hi Alex, gibt es für DBI-7161 bereits einen ProductHub-Publisher und einen UMP-Webhook in einem anderen Branch? Falls nicht, wer übernimmt die Anwendungsteile? Für den gemeinsamen Test brauche ich das Event-Schema, die vorgesehene fachliche Verarbeitung und das Verhalten bei doppelter Zustellung. Danke dir!

Während du wartest, die höher priorisierten Tickets bearbeiten.

## 2. Was du ohne diese Antwort schon tun kannst

```bash
bash start.sh 7161 code
```

Nimmt die beiden vollständigen Dateien in einen eigenen `catalog`-Worktree auf. Keine Änderung eines Live-Stacks. Optional bei vorhandenem Terraform:

```bash
bash start.sh 7161 validate
```

Isolierte Modulprüfung mit Providerdownload, ohne State/Plan/Apply. Sonst eure native CI-Prüfung verwenden.

## 3. Was schon im Code steckt

Topic, `EventGrid Data Sender`, geschützter UMP-Webhook, Wiederholungen und private Fehlerablage mit Managed Identity. Ausgehende Publisher-Netze müssen ausdrücklich angegeben werden. `approved_for_deployment = false` verhindert unbeabsichtigtes Starten. **Nicht nur für einen grünen Plan abschalten.**

Der Storage für fehlgeschlagene Events verwendet einen eingeschränkten Netzweg mit Trusted Services. Das ist eine freizugebende Architekturentscheidung, nicht der LP-Storage aus 12139. Beide Ablagen nicht zusammenlegen und nicht deshalb den privaten Asset-Storage öffnen.

## 4. Erst nach bestätigtem Vertrag weiter

Echte Sender-Object-ID, Webhook-Tenant/Audience, Event-Schema, URL, App-Rollen und Netzwerkfreigaben in der vorgesehenen Integration hinterlegen. Dann Katalog veröffentlichen/referenzieren, Live-Unit anschließen, Plan prüfen und freigegeben ausrollen. `az login` alleine richtet weder die App-Rollen noch den GitLab-State-Zugang ein.

Der ProductHub muss ein echtes Event senden, UMP muss es authentifiziert empfangen und fachlich korrekt verarbeiten. Wiederholte Zustellung darf keine doppelte fachliche Wirkung erzeugen. Genau diese Fachlogik kann ohne Vertrag nicht durch einen allgemeinen HTTP-200-Webhook ersetzt werden.

## Abschluss

- [ ] Schnittstelle, Identitäten, Netz und Zuständigkeiten bestätigt.
- [ ] Native Validierung, Plan und freigegebene Bereitstellung erfolgreich.
- [ ] Echtes Testevent fachlich verarbeitet.
- [ ] Unberechtigter Zugriff, dauerhafter Fehler/Fehlerablage und doppelte Zustellung getestet.

Quellen: Jira DBI-7161 und `catalog`-/`live`-Snapshot. Der verlinkte `eventhub`-Code und die Konzeptanhänge waren nicht im Upload. Event Hubs und Event Grid sind nicht derselbe Dienst. Modulcode: `code/catalog/modules/producthub-event-grid/main.tf` und zugehörige Unit.
