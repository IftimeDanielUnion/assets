#!/usr/bin/env bash

set -Eeuo pipefail
trap cleanup SIGINT SIGTERM ERR EXIT

script_name="UMP Virtual Machine Setup"
script_short="VMS"
script_version="0.1.0"

apt_sources_cmd=./nexusreposources.sh
user_mgnt_cmd=./usermanagement.sh
qualys_cmd=./qualysproxy.sh

print_version () {
  printf '%s (%s) :: v%s\n\n' "$script_name" "$script_short" "$script_version"
}

msg() {
  echo >&1 -e "${script_short}: ${1-}"
}

usage() {
  msg "Usage: $0 [-u <username:ssh-key,...>] -s <apt-source,...> -t <nexus-token>"
  exit
}

die() {
  local msg="$1"
  local code=${2-1} # default exit status 1
  echo >&2 -e "${script_short}: ${msg}"
  exit "$code"
}

cleanup() {
  trap - SIGINT SIGTERM ERR EXIT
  # do whatever you have to do to clean the mess
}

parse_params() {
  user_list=""
  source_list=""
  token=""

  while getopts ":hu:s:t:" opt; do

    case $opt in
      u)
        user_list=${OPTARG}
        ;;
      s)
        source_list=${OPTARG}
        ;;
      t)
        token=${OPTARG}
        ;;
      h)
        usage
        ;;
      :)
        die "Error: Option -${OPTARG} requires an argument."
        ;;
      ?)
        die "Error: Invalid option -${OPTARG}."
        ;;
    esac
  done

  # Check whether required params were set
  if [[ -z "$source_list" || -z "$token" ]]; then
    msg "Error: Missing one or more required parameters."
    usage
  fi
}

print_version

parse_params "$@"

$apt_sources_cmd -s "${source_list}" -t "${token}"
$user_mgnt_cmd -u "${user_list}"
$qualys_cmd

echo
echo
msg "END"

exit 0;
