#!/usr/bin/env bash

set -Eeuo pipefail
trap cleanup SIGINT SIGTERM ERR EXIT

script_name="UMP Admin User Management"
script_short="AUM"
script_version="0.2.0"

print_version () {
  printf '%s (%s) :: v%s\n\n' "$script_name" "$script_short" "$script_version"
}

msg() {
  echo >&1 -e "  ${script_short}: ${1-}"
}

usage() {
  echo "Usage: $0 -u <username:ssh-key,...>"
  exit
}

die() {
  local msg=$1
  local code=${2-1} # default exit status 1
  echo >&2 -e "${script_short}: ${msg}"
  exit "$code"
}

cleanup() {
  trap - SIGINT SIGTERM ERR EXIT
  # do whatever you have to do to clean the mess
}

add () {
  msg "Create new user '$1'";
  adduser --disabled-password --gecos "" "$1";
}

remove () {
  deluser --quiet --remove-home --backup-to $backupdir "$1"
}

parse_params() {
  user_list=""
   while getopts ":hu:" opt; do

    case $opt in
      u)
        user_list="${OPTARG}"
        ;;
      h)
        usage
        ;;
      :)
        die "Error: Option -${OPTARG} requires an argument."
        ;;
      ?)
        die "Error: Invalid option -${OPTARG}."
        ;;
    esac
  done
}

init_user_files () {
  tmpdir="/tmp/usrmgmt"
  rm -rf $tmpdir
  mkdir -p $tmpdir
  backupdir="/var/backups/usrmgmt"
  mkdir -p $backupdir

  # requested users (might be empty if inbound is empty)
  newusers="$tmpdir/newusers"
  > $newusers

  # Split input and extract usernames and passwords
  IFS=',' read -ra user_entries <<< "$user_list"
  for entry in "${user_entries[@]}"; do
    # extract username und ssh-key (at the ':')
    username="${entry%%:*}"
    ssh_key="${entry#*:}"

    echo "$username" >> "$newusers"

    user_dir="$tmpdir/$username"
    mkdir -p "$user_dir"
    echo "$ssh_key" > "$user_dir/authorized_keys"

  done

  msg "- Requested named users"
  cat $newusers
  echo

  # existing users
  oldusers="$tmpdir/oldusers"

  msg "- Existing named users"
  awk -F: '{if ($1 ~ /ee...../) print $1}' /etc/passwd | tee $oldusers
  echo

  # obsolete users
  delusers="$tmpdir/obsoleteusers"
  comm -13 <(sort $newusers) <(sort $oldusers) | tee $delusers

  # Clear the existing sudoers (or create)
  sudoers="/etc/sudoers.d/99-named-users"
  echo "# Created by $(print_version) on $(date)" > $sudoers
  echo "" >> $sudoers
  chmod 0440 $sudoers
}

process_named_users () {
  while read -r usr || [ -n "$usr" ]
  do
    msg "Process User '$usr' >>>"

    # check if user exists and create if not
    id -u $usr >/dev/null 2>&1 || add "$usr"
    cd "/home/$usr"

    msg "Add to group sudo"
    usermod -a -G sudo "$usr"

    msg "Add SSH Key"
    mkdir -p .ssh
    cp -f "$tmpdir/$usr/authorized_keys" .ssh/authorized_keys
    chown -R "$usr":"$usr" .ssh
    chmod 0700 .ssh
    chmod 0600 .ssh/authorized_keys

    # Add to sudoers.d
    echo "# Rules for $usr" >> $sudoers
    echo "$usr ALL=(ALL) NOPASSWD:ALL" >> $sudoers
    echo "" >> $sudoers

    msg "<<< done '$usr'"
  done < $newusers
}

delete_obsolete_users () {
  while read -r usr || [ -n "$usr" ]
  do
    msg "Deleting User '$usr' >>>"
    remove $usr
    msg "<<< done"
  done < $delusers
}

### Execute the script

echo
print_version

parse_params "$@"
init_user_files

msg "-== Adding/Updating named Users ==-"

process_named_users


msg "-== Deleting obsolete Users ==-"

delete_obsolete_users

msg "END"
exit 0;
