#!/usr/bin/env bash

set -Eeuo pipefail
trap cleanup SIGINT SIGTERM ERR EXIT

script_name="UMP Nexus Repo Sources"
script_short="NxRS"
script_version="0.1.0"

print_version () {
  printf '%s (%s) :: v%s\n\n' "$script_name" "$script_short" "$script_version"
}

msg() {
  echo >&1 -e "  ${script_short}: ${1-}"
}

usage() {
  msg "Usage: $0 -s <apt-source,...> -t <nexus-token>"
  exit
}

die() {
  local msg=$1
  local code=${2-1} # default exit status 1
  echo >&2 -e "${script_short}: ${msg}"
  exit "$code"
}

cleanup() {
  trap - SIGINT SIGTERM ERR EXIT
  # do whatever you have to do to clean the mess
}

parse_params() {
  source_list=""
  token=""
  target_filename="10-nexus-repos.list"

  while getopts ":hs:t:" opt; do

    case $opt in
      s)
        source_list=${OPTARG}
        ;;
      t)
        token=${OPTARG}
        ;;
      h)
        usage
        ;;
      :)
        die "Error: Option -${OPTARG} requires an argument."
        ;;
      ?)
        die "Error: Invalid option -${OPTARG}."
        ;;
    esac
  done

  # Check whether required params were set
  if [[ -z "$source_list" || -z "$token" ]]; then
    msg "Error: Missing one or more required parameters."
    usage
  fi
}

write_sources() {
  local target_file="/etc/apt/sources.list.d/$target_filename"
  local sources_file="/root/apt-sources.list"
  local i=0

  > "$sources_file"

  IFS='|' read -ra apt_sources <<< "$source_list"
  for entry in "${apt_sources[@]}"; do
    echo "$entry" >> $sources_file
    i=$((i+1))
  done


  msg "Overwriting sources file $target_file with $i new sources"
  mv "$sources_file" "$target_file"
  chown root:root "$target_file"
  chmod 0644 "$target_file"
}

write_token() {
  local target_file="/etc/apt/auth.conf.d/nexus-union.conf"

  > "$target_file"

  msg "Overwriting file $target_file with new token"
  chown root:root "$target_file"
  chmod 0600 "$target_file"

  echo "$token" > "$target_file"

}

### Execute the script

echo
print_version
parse_params "$@"

write_sources
write_token

msg "END"
exit 0;
