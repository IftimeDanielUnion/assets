#!/usr/bin/env bash

set -Eeuo pipefail
trap cleanup SIGINT SIGTERM ERR EXIT

script_name="UMP Qualys Update"
script_short="QU"
script_version="0.2.0"

print_version () {
  printf '%s (%s) :: v%s\n\n' "$script_name" "$script_short" "$script_version"
}

msg() {
  echo >&1 -e "  ${script_short}: ${1-}"
}

die() {
  local msg=$1
  local code=${2-1} # default exit status 1
  echo >&2 -e "${script_short}: ${msg}"
  exit "$code"
}

cleanup() {
  trap - SIGINT SIGTERM ERR EXIT
  # do whatever you have to do to clean the mess
}

enable_defender () {
  # this is enabling realtime protection in the MS Defender service
  local rtp_enabled=$(mdatp health --field real_time_protection_enabled | tr -d '[:space:]')

  if [ "$rtp_enabled" = "false" ]; then
    msg "Realtime Protection is not enabled. Going to ..."

    mdatp config real-time-protection --value enabled

    mdatp health | grep -i real

  else
    msg "Realtime Protection is up and running."
  fi
}

update_qualys_proxy () {
  local config_file="/etc/default/qualys-cloud-agent"
  local qualys_setting="qualys_https_proxy="
  local qualys_line="${qualys_setting}http://proxy.qualysplatform.prod.azure.union-investment.de:8080"

  local current_line="$(grep ${qualys_setting} ${config_file})"
  msg "Check config ${config_file}\n"
  if [ $current_line != $qualys_line ]; then

    msg "Found outdated setting: '${current_line}'"
    msg "Required setting: ${qualys_line}"

    sed -Ei.bak "s,^${qualys_setting}.*,${qualys_line}," "${config_file}"

    msg "Settings updated. Restarting service"

    systemctl restart qualys-cloud-agent
    systemctl status qualys-cloud-agent
  else
    msg "Config for proxy is up to date"
  fi
}

### Execute the script

echo
print_version

update_qualys_proxy
enable_defender

msg "END"
exit 0;
