###
##  Stack for the production environment
###
locals {
  environment  = "prod"
  subscription = read_terragrunt_config("subscription.hcl").locals

  # catalog version
  tg_catalog_uri     = "https://gitlab.apps.union-investment.de/ump_legacy/infrastructure/catalog.git"
  tg_catalog_name    = "ump_legacy:catalog"
  tg_catalog_version = "v0.13.0"

  ## Base Configuration ##
  env_first_letter = substr(local.environment, 0, 1)
  location         = "swedencentral"
  prefix           = "ump"
  tags = {
    deployment_type          = "terraform"
    environment              = local.environment
    terraform_module_catalog = local.tg_catalog_name
  }

  availability_zones = {
    primary   = 1
    secondary = 2
  }
  dns_zone = {
    name                = "unionmarketingplattform.prod.azure.union-investment.de"
    resource_group_name = "rg-unionmarketingplattform-prod-managed-resources"
  }
  private_endpoints_network_settings = {
    resource_group_name = "rg-unionmarketingplattform-prod-networking"
    subnet_name         = "default_d3644e8a"
    vnet_name           = "vnet-unionmarketingplattform-prod-swc-01"
  }
  private_endpoints_network_settings_virtual_machines = {
    resource_group_name = "rg-unionmarketingplattform-prod-networking"
    subnet_name         = "vms_d3644e8a"
    vnet_name           = "vnet-unionmarketingplattform-prod-swc-01"
  }

  ## Application Gateway ##
  gw_config    = read_terragrunt_config("appgateway.hcl").inputs
  waf_policies = read_terragrunt_config("appgateway-policies.hcl").inputs

  ## VM Management ##
  vm_admin_username   = "bruce"
  vm_script_container = "vminitscripts"
  vm_user_file        = read_terragrunt_config("virtual-machine-users.hcl").locals
  vm_user_list        = local.vm_user_file.user_list
  vm_user_admin = {
    username        = local.vm_admin_username
    authorized_keys = local.vm_user_file.key_list
  }
  vm_static_ips = {
    config       = "172.28.63.36",
    elastic      = "172.28.63.37",
    file2image   = "172.28.63.38",
    filme        = "172.28.63.39",
    landingpages = "172.28.63.40",
    migration    = "172.28.63.50", # this is temporary until after the go-live
    producthub   = "172.28.63.41",
    reportinghub = "172.28.63.42",
    ump          = "172.28.63.43",
  }

  ## Entra Groups ##
  entra_groups = {
    admins = {
      name = "App.UMP.PROD.Azure.Administrator"
      oid  = "e8af3815-5821-4a23-b3b3-33a2aa31652a"
    }
    developers = {
      name = "App.UMP.PROD.Azure.Developer"
      oid  = "5b134d34-3932-4741-bbee-4041627a19d4"
    }
    moveit = {
      name = "App.UMP.PROD.MoveIT.Admin"
      oid  = "ba2004fa-529c-4747-a1d7-152f3f252448"
    }
  }
  ## Resource Group Names ##
  rg_apps_name = "rg-${local.prefix}-apps-${local.environment}"
  rg_core_name = "rg-corecomponents-${local.environment}"
  rg_data_name = "rg-${local.prefix}-data-${local.environment}"
  rg_elan_name = "rg-elanders-${local.environment}"
  rg_moni_name = "rg-monitoring-${local.environment}"
  rg_move_name = "rg-moveit-${local.environment}"
}

# Stacks first, then units. All alphabetically sorted

stack "appgw" {
  source = "git::${local.tg_catalog_uri}//stacks/application-gateway?ref=${local.tg_catalog_version}"
  path   = "appgw"

  values = {
    environment                        = local.environment
    location                           = local.location
    private_dns_zone                   = local.dns_zone
    private_endpoints_network_settings = local.private_endpoints_network_settings
    subscription_id                    = local.subscription.subscription_id
    tags                               = local.tags

    ## Values of the environment's application gateway (building block)
    application_gateway_settings = {

      name               = "appgw-80cdf05bda4199c9"
      resource_group     = "rg-unionmarketingplattform-prod-networking-appgateways"
      private_ip_address = "172.28.70.106"
      subnet_name        = "appgw"

      # configurations
      capacity = {
        min_capacity = 2
        max_capacity = 2
      }
      gateway_wafpolicy_name = "gatewaydefault" # a valid map-key in 'appgateway-policies.hcl'
    }
    ## objects from appgateway.hcl and appgateway-policies.hcl
    application_gateway_config = local.gw_config.application_gateway_config
    policies                   = local.waf_policies.policies

    ## optional stuff
    dns_records_enabled = true

  }
}

stack "backup-solution" {
  source = "git::${local.tg_catalog_uri}//stacks/backup-solution?ref=${local.tg_catalog_version}"
  path   = "backup-solution"

  values = {
    environment                        = local.environment
    location                           = local.location
    private_endpoints_network_settings = local.private_endpoints_network_settings
    site_recovery_enabled              = true
    tags                               = local.tags

    virtual_machine_backup_policies = {
      appsrv = {
        name                           = "AppServerPolicy"
        time                           = "23:00"
        retention                      = 14
        instant_restore_retention_days = 3
      }
    }
  }
}

unit "db-config" {
  source = "git::${local.tg_catalog_uri}//units/mysql-with-sqlauth?ref=${local.tg_catalog_version}"
  path   = "db-config"

  values = {
    availability_zone                  = local.availability_zones.primary
    environment                        = local.environment
    failover_zone                      = local.availability_zones.secondary
    location                           = local.location
    component_name                     = "configdb"
    prefix                             = local.prefix
    private_endpoints_network_settings = local.private_endpoints_network_settings
    resource_group_name                = local.rg_data_name
    tags                               = local.tags

    maintenance_window = null # not defined yet
    server_sizing = {
      name = "Standard_D2ads_v5"
      tier = "GeneralPurpose"
      storage = {
        size = 20
      }
    }

    # Dependency paths
    monitoring_path = "../monitoring"
    keyvault_path   = "../keyvault-internal"

    dependencies_paths = ["../resourcegroup-data"]
  }
}

unit "db-landing" {
  source = "git::${local.tg_catalog_uri}//units/mysql-with-sqlauth?ref=${local.tg_catalog_version}"
  path   = "db-landing"

  values = {
    availability_zone                  = local.availability_zones.primary
    environment                        = local.environment
    failover_zone                      = local.availability_zones.secondary
    location                           = local.location
    component_name                     = "landingpagesdb"
    prefix                             = local.prefix
    private_endpoints_network_settings = local.private_endpoints_network_settings
    resource_group_name                = local.rg_data_name
    tags                               = local.tags

    maintenance_window = null # not defined yet
    server_sizing = {
      name = "Standard_D2ads_v5"
      tier = "GeneralPurpose"
      storage = {
        size = 20
      }
    }

    # Dependency paths
    monitoring_path = "../monitoring"
    keyvault_path   = "../keyvault-internal"

    dependencies_paths = ["../resourcegroup-data"]
  }
}

unit "db-producthub" {
  source = "git::${local.tg_catalog_uri}//units/mysql-with-sqlauth?ref=${local.tg_catalog_version}"
  path   = "db-producthub"

  values = {
    availability_zone                  = local.availability_zones.primary
    environment                        = local.environment
    failover_zone                      = local.availability_zones.secondary
    location                           = local.location
    component_name                     = "phubdb"
    prefix                             = local.prefix
    private_endpoints_network_settings = local.private_endpoints_network_settings
    resource_group_name                = local.rg_data_name
    tags                               = local.tags

    maintenance_window = null # not defined yet
    server_sizing = {
      name = "Standard_D2ads_v5"
      tier = "GeneralPurpose"
      storage = {
        size = 20
      }
    }

    # Dependency paths
    monitoring_path = "../monitoring"
    keyvault_path   = "../keyvault-internal"

    dependencies_paths = ["../resourcegroup-data"]
  }
}

unit "db-ump" {
  source = "git::${local.tg_catalog_uri}//units/mysql-with-sqlauth?ref=${local.tg_catalog_version}"
  path   = "db-ump"

  values = {
    availability_zone                  = local.availability_zones.primary
    environment                        = local.environment
    failover_zone                      = local.availability_zones.secondary
    location                           = local.location
    component_name                     = "umpdb"
    prefix                             = local.prefix
    private_endpoints_network_settings = local.private_endpoints_network_settings
    resource_group_name                = local.rg_data_name
    tags                               = local.tags

    maintenance_window = null # not defined yet
    server_sizing = {
      name = "Standard_D2ads_v5"
      tier = "GeneralPurpose"
      storage = {
        size = 20
      }
    }
    server_parameters = {
      "sql_mode" = "ERROR_FOR_DIVISION_BY_ZERO,ONLY_FULL_GROUP_BY"
    }

    # Dependency paths
    monitoring_path = "../monitoring"
    keyvault_path   = "../keyvault-internal"

    dependencies_paths = ["../resourcegroup-data"]
  }
}

unit "identity-vms" {
  source = "git::${local.tg_catalog_uri}//units/managed-identity?ref=${local.tg_catalog_version}"
  path   = "identity-vms"

  values = {
    component_name        = "vmidentity"
    environment           = local.environment
    location              = local.location
    name                  = "uai-virtualmachines-${local.environment}"
    prefix                = local.prefix
    resource_group_name   = local.rg_core_name
    tags                  = local.tags
    wait_until_assignable = true

    dependencies_paths = ["../resourcegroup-core"]
  }
}

unit "keyvault-elanders" {
  source = "git::${local.tg_catalog_uri}//units/keyvault-private?ref=${local.tg_catalog_version}"
  path   = "keyvault-elanders"

  values = {
    component_name                     = "secrets-elanders"
    environment                        = local.environment
    location                           = local.location
    prefix                             = local.prefix
    private_endpoints_network_settings = local.private_endpoints_network_settings
    resource_group_name                = local.rg_elan_name
    soft_delete_retention_days         = 14
    role_assignments = {
      group-administrators = {
        principal_id         = local.entra_groups.admins.oid # i.e. App.UMP.PROD.Azure.Administrator
        role_definition_name = "Key Vault Secrets User"
        description          = "Group ${local.entra_groups.admins.name} has 'Secret User' permission"
        principal_type       = "Group"
      }
    }

    tags = merge(local.tags, {
      component = "secrets-elanders",
      purpose   = "Service Principals & DBs"
    })

    # Dependency paths
    monitoring_path = "../monitoring"

    dependencies_paths = ["../resourcegroup-elanders"]
  }

}

unit "keyvault-moveit" {
  source = "git::${local.tg_catalog_uri}//units/keyvault-private?ref=${local.tg_catalog_version}"
  path   = "keyvault-moveit"

  values = {
    component_name                     = "secrets-moveit"
    environment                        = local.environment
    location                           = local.location
    prefix                             = local.prefix
    private_endpoints_network_settings = local.private_endpoints_network_settings
    resource_group_name                = local.rg_move_name
    soft_delete_retention_days         = 14
    role_assignments = {
      group-administrators = {
        principal_id         = local.entra_groups.moveit.oid # i.e. App.UMP.PROD.MoveIT.Admin
        role_definition_name = "Key Vault Secrets User"
        description          = "Group ${local.entra_groups.moveit.name} has 'Secret User' permission"
        principal_type       = "Group"
      }
    }

    tags = merge(local.tags, {
      component = "secrets-moveit",
      purpose   = "Storage Account Keys"
    })

    # Dependency paths
    monitoring_path = "../monitoring"

    dependencies_paths = ["../resourcegroup-moveit"]
  }

}

unit "keyvault-internal" {
  source = "git::${local.tg_catalog_uri}//units/keyvault-private?ref=${local.tg_catalog_version}"
  path   = "keyvault-internal"

  values = {
    component_name                     = "secrets-internal"
    environment                        = local.environment
    location                           = local.location
    prefix                             = local.prefix
    private_endpoints_network_settings = local.private_endpoints_network_settings
    resource_group_name                = local.rg_core_name
    soft_delete_retention_days         = 14
    tags = merge(local.tags, {
      component = "secrets-internal"
    })

    # Dependency paths
    monitoring_path = "../monitoring"

    dependencies_paths = ["../resourcegroup-core"]
  }

}

unit "monitoring" {
  source = "git::${local.tg_catalog_uri}//units/log-and-monitor?ref=${local.tg_catalog_version}"
  path   = "monitoring"

  values = {
    application_insights_enabled = true
    component_name               = "monitoring"
    environment                  = local.environment
    location                     = local.location
    name                         = "log-ump-${local.environment}"
    prefix                       = local.prefix
    resource_group_name          = local.rg_moni_name
    tags                         = local.tags

    dependencies_paths = ["../resourcegroup-monitor"]
  }
}

unit "otel-logging" {
  source = "git::${local.tg_catalog_uri}//units/open-telemetry-log?ref=${local.tg_catalog_version}"
  path   = "otel-logging"

  values = {
    environment         = local.environment
    location            = local.location
    name                = "otel-logging-${local.environment}"
    resource_group_name = local.rg_moni_name
    tags                = local.tags

    # Dependency paths
    identity_path   = "../identity-vms"
    monitoring_path = "../monitoring"

    dependencies_paths = ["../resourcegroup-monitor"]
  }
}

unit "rbac-identity-vms-on-kv-appgw" {
  source = "git::${local.tg_catalog_uri}//units/rbac-on-keyvault?ref=${local.tg_catalog_version}"
  path   = "rbac-identity-vms-on-kv-appgw"

  values = {
    role_assignments = {
      vms_secret_user = {
        role_definition_name = "Key Vault Secrets User"
        description          = "User Assigned Identity of VMs is Secrets User to load certificates"
      }
    }

    # Dependency paths
    identity_path = "../identity-vms"
    keyvault_path = "../appgw/.terragrunt-stack/keyvault"
  }
}

## APP components
unit "resourcegroup-apps" {
  source = "git::${local.tg_catalog_uri}//units/resource-group-with-name?ref=${local.tg_catalog_version}"
  path   = "resourcegroup-apps"

  values = {
    location = local.location
    name     = local.rg_apps_name
    tags     = local.tags
  }
}

## CORE components
unit "resourcegroup-core" {
  source = "git::${local.tg_catalog_uri}//units/resource-group-with-name?ref=${local.tg_catalog_version}"
  path   = "resourcegroup-core"

  values = {
    location = local.location
    name     = local.rg_core_name
    tags = merge(local.tags, {
      terraform_module_catalog = "${local.tg_catalog_name}:${local.tg_catalog_version}"
      }
    )
  }
}

## DATA components
unit "resourcegroup-data" {
  source = "git::${local.tg_catalog_uri}//units/resource-group-with-name?ref=${local.tg_catalog_version}"
  path   = "resourcegroup-data"

  values = {
    location = local.location
    name     = local.rg_data_name
    tags     = local.tags
  }
}

## ELANDERS components
unit "resourcegroup-elanders" {
  source = "git::${local.tg_catalog_uri}//units/resource-group-with-name?ref=${local.tg_catalog_version}"
  path   = "resourcegroup-elanders"

  values = {
    location = local.location
    name     = local.rg_elan_name
    tags     = local.tags
  }
}

## MONITORING components
unit "resourcegroup-monitor" {
  source = "git::${local.tg_catalog_uri}//units/resource-group-with-name?ref=${local.tg_catalog_version}"
  path   = "resourcegroup-monitor"

  values = {
    location = local.location
    name     = local.rg_moni_name
    tags     = local.tags
  }
}

## MOVEIT components
unit "resourcegroup-moveit" {
  source = "git::${local.tg_catalog_uri}//units/resource-group-with-name?ref=${local.tg_catalog_version}"
  path   = "resourcegroup-moveit"

  values = {
    location = local.location
    name     = local.rg_move_name
    tags     = local.tags
  }
}

unit "storage-assets" {
  source = "git::${local.tg_catalog_uri}//units/blob-storage-private?ref=${local.tg_catalog_version}"
  path   = "storage-assets"

  values = {
    anonymous_access_enabled           = true
    component_name                     = "lpassets"
    data_scanner_enabled               = true
    location                           = local.location
    environment                        = local.environment
    prefix                             = local.prefix
    private_endpoints_network_settings = local.private_endpoints_network_settings
    resource_group_name                = local.rg_core_name
    tags                               = local.tags

    blob_properties = {
      versioning_enabled = true
    }
    containers = {
      assets = {
        name = "assets"
      }
      statuspages = {
        anonymous_access_enabled = true
        name                     = "statuspages"
      }
      lp-uniglobal-r1 = {
        anonymous_access_enabled = true
        name                     = "uniglobal-release-1"
        identity_role            = "Storage Blob Data Reader"
        principal_id             = local.entra_groups.admins.oid # i.e. App.UMP.PROD.Azure.Administrator
      }
      lp-ve-r1 = {
        anonymous_access_enabled = true
        name                     = "ve-release-1"
        identity_role            = "Storage Blob Data Reader"
        principal_id             = local.entra_groups.admins.oid # i.e. App.UMP.PROD.Azure.Administrator
      }
      lp-zukunft-r1 = {
        anonymous_access_enabled = true
        name                     = "zukunft-release-1"
        identity_role            = "Storage Blob Data Reader"
        principal_id             = local.entra_groups.admins.oid # i.e. App.UMP.PROD.Azure.Administrator
      }
    }

    # Dependency paths
    dependencies_paths = ["../resourcegroup-core"]
  }
}

unit "storage-moveit" {
  source = "git::${local.tg_catalog_uri}//units/blob-storage-private?ref=${local.tg_catalog_version}"
  path   = "storage-moveit"

  values = {
    component_name                     = "moveit"
    data_scanner_enabled               = true
    environment                        = local.environment
    location                           = local.location
    prefix                             = local.prefix
    private_endpoints_network_settings = local.private_endpoints_network_settings
    resource_group_name                = local.rg_move_name
    shared_access_key_enabled          = true # this is required to allow moveit automation access to this blob store
    tags                               = local.tags

    blob_properties = { # this should move to unit
      container_delete_retention_policy = {
        days = 14
      }
      delete_retention_policy = {
        days = 14
      }
    }

    containers = {
      moveit = {
        name          = "moveit"
        identity_role = "Storage Blob Data Reader"
        principal_id  = local.entra_groups.admins.oid # i.e. App.UMP.PROD.Azure.Administrator
      }
    }

    # Dependency paths
    monitoring_path = "../monitoring"

    dependencies_paths = ["../resourcegroup-moveit"]
  }
}

unit "storage-scripts" {
  source = "git::${local.tg_catalog_uri}//units/blob-storage-private?ref=${local.tg_catalog_version}"
  path   = "storage-scripts"

  values = {
    component_name                     = "scriptstore"
    data_scanner_enabled               = true
    location                           = local.location
    environment                        = local.environment
    prefix                             = local.prefix
    private_endpoints_network_settings = local.private_endpoints_network_settings
    resource_group_name                = local.rg_core_name
    tags                               = local.tags

    blobs = { # upload the scripts to storage
      for f in fileset("${get_repo_root()}/scripts/", "*.sh") : (replace(f, ".sh", "")) => {
        name      = f
        container = local.vm_script_container
        file_path = "${get_repo_root()}/scripts/${f}"
      }
    }
    containers = {
      (local.vm_script_container) = {
        name          = local.vm_script_container
        identity_role = "Storage Blob Data Reader"
      }
    }

    # Dependency paths
    identity_path      = "../identity-vms"
    dependencies_paths = ["../resourcegroup-core"]
  }
}

unit "storage-shared" {
  source = "git::${local.tg_catalog_uri}//units/blob-storage-private?ref=${local.tg_catalog_version}"
  path   = "storage-shared"

  values = {
    component_name                     = "exchange"
    data_scanner_enabled               = true
    environment                        = local.environment
    location                           = local.location
    prefix                             = local.prefix
    private_endpoints_network_settings = local.private_endpoints_network_settings
    resource_group_name                = local.rg_elan_name
    tags                               = local.tags

    blob_properties = { # this should move to unit
      container_delete_retention_policy = {
        days = 14
      }
      delete_retention_policy = {
        days = 14
      }
    }

    containers = {
      printdata = {
        name          = "printdata"
        identity_role = "Storage Blob Data Reader"
        principal_id  = local.entra_groups.admins.oid # i.e. App.UMP.PROD.Azure.Administrator
      }
      ## Temporary during migration
      fileshare = {
        name          = "fileshare"
        identity_role = "Storage Blob Data Reader"
        principal_id  = local.entra_groups.admins.oid # i.e. App.UMP.PROD.Azure.Administrator
      }
    }

    # Dependency paths
    monitoring_path = "../monitoring"

    dependencies_paths = ["../resourcegroup-elanders"]
  }
}

unit "vm-config" {

  source = "git::${local.tg_catalog_uri}//units/virtual-machine-ubuntu?ref=${local.tg_catalog_version}"
  path   = "vm-config"

  values = {
    admin                              = local.vm_user_admin
    admin_additional_users             = local.vm_user_list
    availability_zone                  = local.availability_zones.secondary
    certificates                       = ["icinga-internal-certificate", "sui-internal-certificate"]
    component_name                     = "configvm"
    dns_zone                           = local.dns_zone
    environment                        = local.environment
    gateway_pool_name                  = "config-backends"
    hostname                           = "umpl${local.env_first_letter}config01"
    location                           = local.location
    prefix                             = local.prefix
    private_endpoints_network_settings = local.private_endpoints_network_settings_virtual_machines
    private_ip_address                 = local.vm_static_ips.config
    resource_group_name                = local.rg_apps_name
    scripts_container                  = local.vm_script_container
    tags                               = local.tags
    ubuntu_image_version               = "2.0.37"
    vm_size                            = "D4as_v5"

    data_disk = {
      size_gb = 150
    }

    # Dependency paths
    gateway_path          = "../appgw/.terragrunt-stack/appgateway"
    identity_path         = "../identity-vms"
    keyvault4certs_path   = "../appgw/.terragrunt-stack/keyvault"
    keyvault4scripts_path = "../keyvault-internal"
    storage_path          = "../storage-scripts"

    dependencies_paths = ["../resourcegroup-apps"]
  }

}

unit "vm-config-backup" {
  source = "git::${local.tg_catalog_uri}//units/virtual-machine-backup?ref=${local.tg_catalog_version}"
  path   = "backup-for-configvm"

  values = {
    recovery_vault_path   = "../backup-solution/recoveryvault"
    recovery_vault_policy = "appsrv"
    vm_path               = "../vm-config"
  }
}

unit "vm-config-replica" {
  source = "git::${local.tg_catalog_uri}//units/virtual-machine-replica?ref=${local.tg_catalog_version}"
  path   = "replica-for-configvm"

  values = {
    failover_zone    = local.availability_zones.primary
    network_settings = local.private_endpoints_network_settings_virtual_machines

    recovery_vault_path = "../backup-solution/recoveryvault"
    vm_path             = "../vm-config"
  }
}

unit "vm-elasticsearch" {

  source = "git::${local.tg_catalog_uri}//units/virtual-machine-ubuntu?ref=${local.tg_catalog_version}"
  path   = "vm-elasticsearch"

  values = {
    admin                              = local.vm_user_admin
    admin_additional_users             = local.vm_user_list
    availability_zone                  = local.availability_zones.primary
    certificates                       = ["elastic-internal-certificate"]
    component_name                     = "elasticsearchvm"
    dns_name                           = "elastic"
    dns_zone                           = local.dns_zone
    environment                        = local.environment
    hostname                           = "umpl${local.env_first_letter}elastic01"
    location                           = local.location
    prefix                             = local.prefix
    private_endpoints_network_settings = local.private_endpoints_network_settings_virtual_machines
    private_ip_address                 = local.vm_static_ips.elastic
    resource_group_name                = local.rg_apps_name
    scripts_container                  = local.vm_script_container
    tags                               = local.tags
    ubuntu_image_version               = "2.0.37"
    vm_size                            = "E2as_v5"

    data_disk = {
      size_gb = 100
    }

    # Dependency paths
    gateway_path          = "../appgw/.terragrunt-stack/appgateway"
    identity_path         = "../identity-vms"
    keyvault4certs_path   = "../appgw/.terragrunt-stack/keyvault"
    keyvault4scripts_path = "../keyvault-internal"
    storage_path          = "../storage-scripts"

    dependencies_paths = ["../resourcegroup-apps"]
  }

}

unit "vm-elasticsearch-backup" {
  source = "git::${local.tg_catalog_uri}//units/virtual-machine-backup?ref=${local.tg_catalog_version}"
  path   = "backup-for-elasticsearchvm"

  values = {
    recovery_vault_path   = "../backup-solution/recoveryvault"
    recovery_vault_policy = "appsrv"
    vm_path               = "../vm-elasticsearch"
  }
}

unit "vm-elasticsearch-replica" {
  source = "git::${local.tg_catalog_uri}//units/virtual-machine-replica?ref=${local.tg_catalog_version}"
  path   = "replica-for-elasticsearchvm"

  values = {
    failover_zone    = local.availability_zones.secondary
    network_settings = local.private_endpoints_network_settings_virtual_machines

    recovery_vault_path = "../backup-solution/recoveryvault"
    vm_path             = "../vm-elasticsearch"
  }
}

unit "vm-file2image" {

  source = "git::${local.tg_catalog_uri}//units/virtual-machine-ubuntu?ref=${local.tg_catalog_version}"
  path   = "vm-file2image"

  values = {
    admin                              = local.vm_user_admin
    admin_additional_users             = local.vm_user_list
    availability_zone                  = local.availability_zones.primary
    certificates                       = ["file2img-internal-certificate"]
    component_name                     = "file2imagevm"
    dns_zone                           = local.dns_zone
    environment                        = local.environment
    gateway_pool_name                  = "file2image-backends"
    hostname                           = "umpl${local.env_first_letter}file2image01"
    location                           = local.location
    prefix                             = local.prefix
    private_endpoints_network_settings = local.private_endpoints_network_settings_virtual_machines
    private_ip_address                 = local.vm_static_ips.file2image
    resource_group_name                = local.rg_apps_name
    scripts_container                  = local.vm_script_container
    tags                               = local.tags
    ubuntu_image_version               = "2.0.37"
    vm_size                            = "D4as_v5"

    data_disk = {
      size_gb = 100
    }

    # Dependency paths
    gateway_path          = "../appgw/.terragrunt-stack/appgateway"
    identity_path         = "../identity-vms"
    keyvault4certs_path   = "../appgw/.terragrunt-stack/keyvault"
    keyvault4scripts_path = "../keyvault-internal"
    storage_path          = "../storage-scripts"

    dependencies_paths = ["../resourcegroup-apps"]
  }

}

unit "vm-file2image-backup" {
  source = "git::${local.tg_catalog_uri}//units/virtual-machine-backup?ref=${local.tg_catalog_version}"
  path   = "backup-for-file2imagevm"

  values = {
    recovery_vault_path   = "../backup-solution/recoveryvault"
    recovery_vault_policy = "appsrv"
    vm_path               = "../vm-file2image"
  }
}

unit "vm-file2image-replica" {
  source = "git::${local.tg_catalog_uri}//units/virtual-machine-replica?ref=${local.tg_catalog_version}"
  path   = "replica-for-file2imagevm"

  values = {
    failover_zone    = local.availability_zones.secondary
    network_settings = local.private_endpoints_network_settings_virtual_machines

    recovery_vault_path = "../backup-solution/recoveryvault"
    vm_path             = "../vm-file2image"
  }
}

unit "vm-filme" {

  source = "git::${local.tg_catalog_uri}//units/virtual-machine-ubuntu?ref=${local.tg_catalog_version}"
  path   = "vm-filme"

  values = {
    admin                              = local.vm_user_admin
    admin_additional_users             = local.vm_user_list
    availability_zone                  = local.availability_zones.primary
    certificates                       = ["filme-internal-certificate"]
    component_name                     = "filmevm"
    dns_zone                           = local.dns_zone
    environment                        = local.environment
    gateway_pool_name                  = "filme-backends"
    hostname                           = "umpl${local.env_first_letter}filme01"
    location                           = local.location
    prefix                             = local.prefix
    private_endpoints_network_settings = local.private_endpoints_network_settings_virtual_machines
    private_ip_address                 = local.vm_static_ips.filme
    resource_group_name                = local.rg_apps_name
    scripts_container                  = local.vm_script_container
    tags                               = local.tags
    ubuntu_image_version               = "2.0.37"
    vm_size                            = "D4as_v5"

    data_disk = {
      size_gb = 100
    }

    # Dependency paths
    gateway_path          = "../appgw/.terragrunt-stack/appgateway"
    identity_path         = "../identity-vms"
    keyvault4certs_path   = "../appgw/.terragrunt-stack/keyvault"
    keyvault4scripts_path = "../keyvault-internal"
    storage_path          = "../storage-scripts"

    dependencies_paths = ["../resourcegroup-apps"]
  }

}

unit "vm-filme-backup" {
  source = "git::${local.tg_catalog_uri}//units/virtual-machine-backup?ref=${local.tg_catalog_version}"
  path   = "backup-for-filmevm"

  values = {
    recovery_vault_path   = "../backup-solution/recoveryvault"
    recovery_vault_policy = "appsrv"
    vm_path               = "../vm-filme"
  }
}

unit "vm-filme-replica" {
  source = "git::${local.tg_catalog_uri}//units/virtual-machine-replica?ref=${local.tg_catalog_version}"
  path   = "replica-for-filmevm"

  values = {
    failover_zone    = local.availability_zones.secondary
    network_settings = local.private_endpoints_network_settings_virtual_machines

    recovery_vault_path = "../backup-solution/recoveryvault"
    vm_path             = "../vm-filme"
  }
}

unit "vm-landingpages" {

  source = "git::${local.tg_catalog_uri}//units/virtual-machine-ubuntu?ref=${local.tg_catalog_version}"
  path   = "vm-landingpages"

  values = {
    admin                              = local.vm_user_admin
    admin_additional_users             = local.vm_user_list
    availability_zone                  = local.availability_zones.primary
    certificates                       = ["landingtool-internal-certificate"]
    component_name                     = "landingpagesvm"
    dns_zone                           = local.dns_zone
    environment                        = local.environment
    gateway_pool_name                  = "landingpages-backends"
    hostname                           = "umpl${local.env_first_letter}landing01"
    location                           = local.location
    prefix                             = local.prefix
    private_endpoints_network_settings = local.private_endpoints_network_settings_virtual_machines
    private_ip_address                 = local.vm_static_ips.landingpages
    resource_group_name                = local.rg_apps_name
    scripts_container                  = local.vm_script_container
    tags                               = local.tags
    ubuntu_image_version               = "2.0.37"
    vm_size                            = "B2as_v2"

    data_disk = {
      size_gb = 100
    }

    # Dependency paths
    gateway_path          = "../appgw/.terragrunt-stack/appgateway"
    identity_path         = "../identity-vms"
    keyvault4certs_path   = "../appgw/.terragrunt-stack/keyvault"
    keyvault4scripts_path = "../keyvault-internal"
    storage_path          = "../storage-scripts"

    dependencies_paths = ["../resourcegroup-apps"]
  }

}

unit "vm-landingpages-backup" {
  source = "git::${local.tg_catalog_uri}//units/virtual-machine-backup?ref=${local.tg_catalog_version}"
  path   = "backup-for-landingpagesvm"

  values = {
    recovery_vault_path   = "../backup-solution/recoveryvault"
    recovery_vault_policy = "appsrv"
    vm_path               = "../vm-landingpages"
  }
}

unit "vm-landingpages-replica" {
  source = "git::${local.tg_catalog_uri}//units/virtual-machine-replica?ref=${local.tg_catalog_version}"
  path   = "replica-for-landingpagesvm"

  values = {
    failover_zone    = local.availability_zones.secondary
    network_settings = local.private_endpoints_network_settings_virtual_machines

    recovery_vault_path = "../backup-solution/recoveryvault"
    vm_path             = "../vm-landingpages"
  }
}

unit "vm-migration" {

  source = "git::${local.tg_catalog_uri}//units/virtual-machine-ubuntu?ref=${local.tg_catalog_version}"
  path   = "vm-migration"

  values = {
    admin                              = local.vm_user_admin
    admin_additional_users             = local.vm_user_list
    availability_zone                  = local.availability_zones.primary
    component_name                     = "migrationvm"
    dns_zone                           = local.dns_zone
    environment                        = local.environment
    hostname                           = "umpl${local.env_first_letter}migration01"
    location                           = local.location
    os_disk_storage_type               = "Standard_LRS"
    prefix                             = local.prefix
    private_endpoints_network_settings = local.private_endpoints_network_settings_virtual_machines
    private_ip_address                 = local.vm_static_ips.migration
    resource_group_name                = local.rg_apps_name
    scripts_container                  = local.vm_script_container
    tags                               = local.tags
    ubuntu_image_version               = "2.0.37"
    vm_size                            = "B2ls_v2"

    data_disk = {
      size_gb = 500
    }

    # Dependency paths
    identity_path         = "../identity-vms"
    keyvault4scripts_path = "../keyvault-internal"
    storage_path          = "../storage-scripts"

    dependencies_paths = ["../resourcegroup-apps"]
  }

}

unit "vm-migration-backup" {
  source = "git::${local.tg_catalog_uri}//units/virtual-machine-backup?ref=${local.tg_catalog_version}"
  path   = "backup-for-migrationvm"

  values = {
    recovery_vault_path   = "../backup-solution/recoveryvault"
    recovery_vault_policy = "appsrv"
    vm_path               = "../vm-migration"
  }
}

unit "vm-producthub" {

  source = "git::${local.tg_catalog_uri}//units/virtual-machine-ubuntu?ref=${local.tg_catalog_version}"
  path   = "vm-producthub"

  values = {
    admin                              = local.vm_user_admin
    admin_additional_users             = local.vm_user_list
    availability_zone                  = local.availability_zones.primary
    certificates                       = ["werbemittelkatalog-internal-certificate"]
    component_name                     = "phubvm"
    dns_zone                           = local.dns_zone
    environment                        = local.environment
    gateway_pool_name                  = "producthub-backends"
    hostname                           = "umpl${local.env_first_letter}phub01"
    location                           = local.location
    prefix                             = local.prefix
    private_endpoints_network_settings = local.private_endpoints_network_settings_virtual_machines
    private_ip_address                 = local.vm_static_ips.producthub
    resource_group_name                = local.rg_apps_name
    scripts_container                  = local.vm_script_container
    tags                               = local.tags
    ubuntu_image_version               = "2.0.37"
    vm_size                            = "D4as_v5"

    data_disk = {
      size_gb = 300
    }

    # Dependency paths
    gateway_path          = "../appgw/.terragrunt-stack/appgateway"
    identity_path         = "../identity-vms"
    keyvault4certs_path   = "../appgw/.terragrunt-stack/keyvault"
    keyvault4scripts_path = "../keyvault-internal"
    storage_path          = "../storage-scripts"

    dependencies_paths = ["../resourcegroup-apps"]
  }

}

unit "vm-producthub-backup" {
  source = "git::${local.tg_catalog_uri}//units/virtual-machine-backup?ref=${local.tg_catalog_version}"
  path   = "backup-for-producthubvm"

  values = {
    recovery_vault_path   = "../backup-solution/recoveryvault"
    recovery_vault_policy = "appsrv"
    vm_path               = "../vm-producthub"
  }
}

unit "vm-producthub-replica" {
  source = "git::${local.tg_catalog_uri}//units/virtual-machine-replica?ref=${local.tg_catalog_version}"
  path   = "replica-for-producthubvm"

  values = {
    failover_zone    = local.availability_zones.secondary
    network_settings = local.private_endpoints_network_settings_virtual_machines

    recovery_vault_path = "../backup-solution/recoveryvault"
    vm_path             = "../vm-producthub"
  }
}

unit "vm-reportinghub" {

  source = "git::${local.tg_catalog_uri}//units/virtual-machine-ubuntu?ref=${local.tg_catalog_version}"
  path   = "vm-reportinghub"

  values = {
    admin                              = local.vm_user_admin
    admin_additional_users             = local.vm_user_list
    availability_zone                  = local.availability_zones.primary
    certificates                       = ["reporting-internal-certificate"]
    component_name                     = "reportingvm"
    dns_zone                           = local.dns_zone
    environment                        = local.environment
    gateway_pool_name                  = "reportinghub-backends"
    hostname                           = "umpl${local.env_first_letter}reporting01"
    location                           = local.location
    prefix                             = local.prefix
    private_endpoints_network_settings = local.private_endpoints_network_settings_virtual_machines
    private_ip_address                 = local.vm_static_ips.reportinghub
    resource_group_name                = local.rg_apps_name
    scripts_container                  = local.vm_script_container
    tags                               = local.tags
    ubuntu_image_version               = "2.0.37"
    vm_size                            = "D2as_v5"

    data_disk = {
      size_gb = 100
    }

    # Dependency paths
    gateway_path          = "../appgw/.terragrunt-stack/appgateway"
    identity_path         = "../identity-vms"
    keyvault4certs_path   = "../appgw/.terragrunt-stack/keyvault"
    keyvault4scripts_path = "../keyvault-internal"
    storage_path          = "../storage-scripts"

    dependencies_paths = ["../resourcegroup-apps"]
  }

}

unit "vm-reportinghub-backup" {
  source = "git::${local.tg_catalog_uri}//units/virtual-machine-backup?ref=${local.tg_catalog_version}"
  path   = "backup-for-reportingvm"

  values = {
    recovery_vault_path   = "../backup-solution/recoveryvault"
    recovery_vault_policy = "appsrv"
    vm_path               = "../vm-reportinghub"
  }
}

unit "vm-reportinghub-replica" {
  source = "git::${local.tg_catalog_uri}//units/virtual-machine-replica?ref=${local.tg_catalog_version}"
  path   = "replica-for-reportingvm"

  values = {
    failover_zone    = local.availability_zones.secondary
    network_settings = local.private_endpoints_network_settings_virtual_machines

    recovery_vault_path = "../backup-solution/recoveryvault"
    vm_path             = "../vm-reportinghub"
  }
}

unit "vm-ump" {

  source = "git::${local.tg_catalog_uri}//units/virtual-machine-ubuntu?ref=${local.tg_catalog_version}"
  path   = "vm-ump"

  values = {
    admin                              = local.vm_user_admin
    admin_additional_users             = local.vm_user_list
    availability_zone                  = local.availability_zones.primary
    certificates                       = ["ump-internal-certificate", "setupbox-internal-certificate"]
    component_name                     = "umpvm"
    dns_zone                           = local.dns_zone
    environment                        = local.environment
    gateway_pool_name                  = "ump-backends"
    hostname                           = "umpl${local.env_first_letter}app01"
    location                           = local.location
    prefix                             = local.prefix
    private_endpoints_network_settings = local.private_endpoints_network_settings_virtual_machines
    private_ip_address                 = local.vm_static_ips.ump
    resource_group_name                = local.rg_apps_name
    scripts_container                  = local.vm_script_container
    tags                               = local.tags
    ubuntu_image_version               = "2.0.37"
    vm_size                            = "E4as_v5"

    data_disk = {
      size_gb = 300
    }

    # Dependency paths
    gateway_path          = "../appgw/.terragrunt-stack/appgateway"
    identity_path         = "../identity-vms"
    keyvault4certs_path   = "../appgw/.terragrunt-stack/keyvault"
    keyvault4scripts_path = "../keyvault-internal"
    storage_path          = "../storage-scripts"

    dependencies_paths = ["../resourcegroup-apps"]
  }

}

unit "vm-ump-backup" {
  source = "git::${local.tg_catalog_uri}//units/virtual-machine-backup?ref=${local.tg_catalog_version}"
  path   = "backup-for-umpvm"

  values = {
    recovery_vault_path   = "../backup-solution/recoveryvault"
    recovery_vault_policy = "appsrv"
    vm_path               = "../vm-ump"
  }
}

unit "vm-ump-replica" {
  source = "git::${local.tg_catalog_uri}//units/virtual-machine-replica?ref=${local.tg_catalog_version}"
  path   = "replica-for-umpvm"

  values = {
    failover_zone    = local.availability_zones.secondary
    network_settings = local.private_endpoints_network_settings_virtual_machines

    recovery_vault_path = "../backup-solution/recoveryvault"
    vm_path             = "../vm-ump"
  }
}
