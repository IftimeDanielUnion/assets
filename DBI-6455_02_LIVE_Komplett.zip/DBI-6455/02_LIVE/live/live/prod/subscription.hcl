## Environment definition
## Required to access the subscription_id in root.hcl (for the azure provider).
locals {
  subscription    = "S_UNIONMARKETINGPLATTFORM_PROD"
  subscription_id = "f8b0b9a0-4f58-4fd3-a504-1a21a87a6ae3"
}
