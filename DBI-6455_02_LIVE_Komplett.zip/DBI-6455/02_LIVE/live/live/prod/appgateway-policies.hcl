###
##  This file contains WAF Policy definitions.
##  The policies can be used in configuration of application gateway listeners or path routes
##  by passing the map key like 'gatewaydefault' in the field 'firewall_policy' of a listener
##  or a url_path_map_configurations.path_rules object
##
##  This file can be included as a terragrunt config file.
###
locals {
  ## Known IPs of external systems/vendors
  custom_rule_content_ip_addresses = {
    elanders_service = "178.15.161.4"
    elanders_storage = "178.15.161.34"
    inxmail_one      = "93.191.162.0/24"
    inxmail_two      = "93.191.164.0/24"
    inxmail_three    = "147.93.208.0/24"
    inxmail_four     = "147.93.209.0/24"
    osc              = "94.79.177.42"
  }

  custom_rule_storage_ip_restrictions = {
    action    = "Block"
    enabled   = true
    name      = "AccessRestrictions"
    priority  = "100"
    rule_type = "MatchRule"
    match_conditions = [
      {
        match_variables = [{
          variable_name = "RemoteAddr"
        }]
        operator           = "IPMatch"
        negation_condition = true
        match_values = [
          local.custom_rule_content_ip_addresses.elanders_storage
        ]
      }
    ]
  }
  custom_rule_ump_ip_restrictions = {
    action    = "Block"
    enabled   = true
    name      = "AccessRestrictions"
    priority  = "100"
    rule_type = "MatchRule"
    match_conditions = [
      {
        match_variables = [{
          variable_name = "RemoteAddr"
        }]
        operator           = "IPMatch"
        negation_condition = true
        match_values = [
          local.custom_rule_content_ip_addresses.elanders_service,
          local.custom_rule_content_ip_addresses.inxmail_one,
          local.custom_rule_content_ip_addresses.inxmail_two,
          local.custom_rule_content_ip_addresses.inxmail_three,
          local.custom_rule_content_ip_addresses.inxmail_four,
          local.custom_rule_content_ip_addresses.osc,
        ]
      }
    ]
  }

  ## Map of exclusions concerning the Bot Manager Rule Set 1.1
  exclusions_bot_rules = {
    header-useragent = {
      match_variable          = "RequestHeaderNames"
      selector_match_operator = "Equals"
      selector                = "User-Agent"
      excluded_rule_set = {
        type    = "Microsoft_BotManagerRuleSet"
        version = "1.1"
        rule_group = [{
          rule_group_name = "UnknownBots"
          excluded_rules  = ["300300"]
        }]
      }
    }
  }

  ## All common exclusions used for UMP listeners (internal and external)
  exclusions_ump_common = merge(
    local.exclusions_bot_rules,
    {
      args-campaignnames = {
        match_variable          = "RequestArgNames"
        selector_match_operator = "Equals"
        selector                = "campaignNames"
        excluded_rule_set = {
          type    = "OWASP"
          version = "3.2"
          rule_group = [{
            rule_group_name = "REQUEST-933-APPLICATION-ATTACK-PHP"
            excluded_rules  = ["933210"]
          }]
        }
      }
      args-content = {
        match_variable          = "RequestArgNames"
        selector_match_operator = "Equals"
        selector                = "content"
        excluded_rule_set = {
          type    = "OWASP"
          version = "3.2"
          rule_group = [{
            rule_group_name = "REQUEST-941-APPLICATION-ATTACK-XSS"
            excluded_rules = [
              "941100",
              "941150",
              "941160",
              "941320",
              "941330",
              "941340",
            ]
          }]
        }
      }
      args-description = {
        match_variable          = "RequestArgNames"
        selector_match_operator = "Equals"
        selector                = "description"
        excluded_rule_set = {
          type    = "OWASP"
          version = "3.2"
          rule_group = [{
            rule_group_name = "REQUEST-941-APPLICATION-ATTACK-XSS"
            excluded_rules = [
              "941100",
              "941150",
              "941160",
              "941320",
              "941330",
              "941340",
            ]
          }]
        }
      }
      args-newsletter = {
        match_variable          = "RequestArgNames"
        selector_match_operator = "StartsWith"
        selector                = "nl_"
        excluded_rule_set = {
          type    = "OWASP"
          version = "3.2"
          rule_group = [
            {
              rule_group_name = "REQUEST-921-PROTOCOL-ATTACK"
              excluded_rules  = ["921130"]
            },
            {
              rule_group_name = "REQUEST-941-APPLICATION-ATTACK-XSS"
              excluded_rules = [
                "941100",
                "941150",
                "941160",
                "941320",
                "941330",
                "941340",
              ]
            },
          ]
        }
      }
      args-object = {
        match_variable          = "RequestArgNames"
        selector_match_operator = "StartsWith"
        selector                = "object"
        excluded_rule_set = {
          type    = "OWASP"
          version = "3.2"
          rule_group = [
            {
              rule_group_name = "REQUEST-933-APPLICATION-ATTACK-PHP"
              excluded_rules  = ["933210"]
            }
          ]
        }
      }
      args-templatecontent = {
        match_variable          = "RequestArgNames"
        selector_match_operator = "Equals"
        selector                = "template_content"
        excluded_rule_set = {
          type    = "OWASP"
          version = "3.2"
          rule_group = [
            {
              rule_group_name = "REQUEST-932-APPLICATION-ATTACK-RCE"
              excluded_rules  = ["932105"]
            },
            {
              rule_group_name = "REQUEST-941-APPLICATION-ATTACK-XSS"
              excluded_rules = [
                "941100",
                "941150",
                "941160",
                "941320",
                "941330",
                "941340",
              ]
            },
          ]
        }
      }
    }
  )

  ## common overrides for internal listeners
  overrides_internals_commons = {
    PROTO-920-disable = {
      rule_set        = "OWASP"
      rule_group_name = "REQUEST-920-PROTOCOL-ENFORCEMENT"
      rules = [
        { id = "920170" },
        { id = "920230" },
        { id = "920300" },
      ]
    }
    RFI-931-log-only = {
      rule_set        = "OWASP"
      rule_group_name = "REQUEST-931-APPLICATION-ATTACK-RFI"
      rules = [
        {
          id      = "931100"
          enabled = true
          action  = "Log"
        },
        {
          id      = "931110"
          enabled = true
          action  = "Log"
        },
        {
          id      = "931120"
          enabled = true
          action  = "Log"
        },
        {
          id      = "931130"
          enabled = true
          action  = "Log"
        },
      ]
    }
    PHP-933-log-only = {
      rule_set        = "OWASP"
      rule_group_name = "REQUEST-933-APPLICATION-ATTACK-PHP"
      rules = [{
        id      = "933210"
        enabled = true
        action  = "Log"
      }]
    }
    XSS-941-disable = {
      rule_set        = "OWASP"
      rule_group_name = "REQUEST-941-APPLICATION-ATTACK-XSS"
      rules = [

        { id = "941100" },
        { id = "941150" },
        { id = "941160" },
        { id = "941320" },
        { id = "941330" },
        { id = "941340" },
      ]
    }
    SQLI-942-disable = {
      rule_set        = "OWASP"
      rule_group_name = "REQUEST-942-APPLICATION-ATTACK-SQLI"
    }
  }

  ## All common overrides used for UMP listeners (internal and external)
  overrides_ump_commons = {
    PROTO-920-disable = {
      rule_set        = "OWASP"
      rule_group_name = "REQUEST-920-PROTOCOL-ENFORCEMENT"
      rules = [
        { id = "920300" },
      ]
    }
    RFI-931-log-only = {
      rule_set        = "OWASP"
      rule_group_name = "REQUEST-931-APPLICATION-ATTACK-RFI"
      rules = [{
        id      = "931130"
        enabled = true
        action  = "Log"
      }]
    }
    SQLI-942-disable = {
      rule_set        = "OWASP"
      rule_group_name = "REQUEST-942-APPLICATION-ATTACK-SQLI"
      rules = [
        { id = "942110" },
        { id = "942130" },
        { id = "942200" },
        { id = "942210" },
        { id = "942260" },
        { id = "942300" },
        { id = "942330" },
        { id = "942340" },
        { id = "942370" },
        { id = "942430" },
        { id = "942440" },
        { id = "942450" },
      ]
    }
  }
}

inputs = {
  policies = {
    ## the general policy! It will be attached to the application gateway
    gatewaydefault = {
      enabled       = true
      firewall_mode = "Prevention"
      exclusions_for_managed_rules = {
        cookies-session = {
          match_variable          = "RequestCookieNames"
          selector_match_operator = "EndsWith"
          selector                = "session"
          excluded_rule_set = {
            type    = "OWASP"
            version = "3.2"
            rule_group = [
              {
                rule_group_name = "REQUEST-942-APPLICATION-ATTACK-SQLI"
              }
            ]
          }
        }
        cookies-xsrftoken = {
          match_variable          = "RequestCookieNames"
          selector_match_operator = "Equals"
          selector                = "XSRF-TOKEN"
          excluded_rule_set = {
            type    = "OWASP"
            version = "3.2"
            rule_group = [
              {
                rule_group_name = "REQUEST-942-APPLICATION-ATTACK-SQLI"
              }
            ]
          }
        }
      }
    }

    file2image = {
      enabled                          = true
      firewall_mode                    = "Prevention"
      max_request_body_size_in_kb      = 2000
      request_body_inspect_limit_in_kb = 2000
      request_body_enforcement         = false
      overrides_for_managed_rules      = local.overrides_internals_commons
    }

    ## UI Filme (internal only, for public fall back to gatewaydefault)
    filme = {
      enabled                          = true
      firewall_mode                    = "Prevention"
      max_request_body_size_in_kb      = 2000
      request_body_inspect_limit_in_kb = 2000
      request_body_enforcement         = false
      exclusions_for_managed_rules = {
        args-commands = { ## i.e. the ffmpeg cmd-line
          match_variable          = "RequestArgNames"
          selector_match_operator = "Contains"
          selector                = "commands"
          excluded_rule_set = {
            type    = "OWASP"
            version = "3.2"
            rule_group = [
              {
                rule_group_name = "REQUEST-920-PROTOCOL-ENFORCEMENT"
                excluded_rules  = ["920230"]
              },
              {
                rule_group_name = "REQUEST-932-APPLICATION-ATTACK-RCE"
                excluded_rules = [
                  "932105",
                  "932115"
                ]
              },
              {
                rule_group_name = "REQUEST-941-APPLICATION-ATTACK-XSS"
                excluded_rules  = ["941330", "941340"]
              },
              {
                rule_group_name = "REQUEST-942-APPLICATION-ATTACK-SQLI" # sqli is the least problem of that argument
              }
            ]
          }
        }
      }
      overrides_for_managed_rules = local.overrides_internals_commons
    }

    ## Icinga Web Monitoring
    icingaweb = {
      enabled       = true
      firewall_mode = "Prevention"
    }

    ## Landing Assets
    landingassets = {
      enabled       = true
      firewall_mode = "Prevention"
      custom_rules = {
        method_get_only = {
          action    = "Block"
          enabled   = true
          name      = "BlockOtherThanHttpGet"
          priority  = "10"
          rule_type = "MatchRule"
          match_conditions = [
            {
              match_variables = [{
                variable_name = "RequestMethod"
              }]
              operator           = "Equal"
              negation_condition = true
              match_values       = ["GET"]
            }
          ]
        }
        query_disallowed = {
          action    = "Block"
          enabled   = true
          name      = "BlockIfContainsQueryString"
          priority  = "20"
          rule_type = "MatchRule"
          match_conditions = [
            {
              match_variables = [{
                variable_name = "QueryString"
              }]
              operator           = "Regex"
              negation_condition = true
              match_values       = ["^$"]
            }
          ]
        }
      }
    }

    ## Landing Page Tool (internal only, for public fall back to gatewaydefault)
    landingpages = { ## THIS is OBSOLETE. Must be removed, once not associated with Listener anymore
      enabled                          = true
      firewall_mode                    = "Prevention"
      max_request_body_size_in_kb      = 2000
      request_body_inspect_limit_in_kb = 2000
      request_body_enforcement         = false
      exclusions_for_managed_rules = merge(
        local.exclusions_bot_rules,
        {}
      )
      overrides_for_managed_rules = local.overrides_internals_commons
    }
    landingpagetool = {
      enabled                          = true
      firewall_mode                    = "Prevention"
      max_request_body_size_in_kb      = 2000
      request_body_inspect_limit_in_kb = 2000
      request_body_enforcement         = false
      exclusions_for_managed_rules = merge(
        local.exclusions_bot_rules,
        {}
      )
      overrides_for_managed_rules = local.overrides_internals_commons
    }

    ## Product Hub (Werbemittelkatalog)
    producthub = {
      enabled                          = true
      firewall_mode                    = "Prevention"
      file_upload_limit_in_mb          = 300
      max_request_body_size_in_kb      = 2000
      request_body_inspect_limit_in_kb = 2000
      request_body_enforcement         = false
      exclusions_for_managed_rules = merge(
        local.exclusions_bot_rules,
        {}
      )
      overrides_for_managed_rules = local.overrides_internals_commons
    }

    ## Reporting Hub
    reportinghub = {
      enabled                          = true
      firewall_mode                    = "Prevention"
      max_request_body_size_in_kb      = 2000
      request_body_inspect_limit_in_kb = 2000
      request_body_enforcement         = false
      exclusions_for_managed_rules = merge(
        local.exclusions_bot_rules,
        {}
      )
      overrides_for_managed_rules = local.overrides_internals_commons
    }

    ## Semaphore UI
    semaphoreui = {
      enabled                     = true
      firewall_mode               = "Prevention"
      overrides_for_managed_rules = local.overrides_internals_commons
    }

    ## setupbox
    setupbox = {
      enabled                          = true
      firewall_mode                    = "Prevention"
      file_upload_limit_in_mb          = 2000
      max_request_body_size_in_kb      = 2000
      request_body_inspect_limit_in_kb = 2000
      request_body_enforcement         = false
      exclusions_for_managed_rules = merge(
        local.exclusions_bot_rules,
        {
          args-print_object_description = {
            match_variable          = "RequestArgNames"
            selector_match_operator = "Contains"
            selector                = "print_object"
            excluded_rule_set = {
              type    = "OWASP"
              version = "3.2"
              rule_group = [
                {
                  rule_group_name = "REQUEST-941-APPLICATION-ATTACK-XSS"
                  excluded_rules = [
                    "941150",
                    "941320"
                  ]
                },
              ]
            }
          }
        }
      )
      overrides_for_managed_rules = local.overrides_internals_commons
    }

    ## UMP public
    ump-public = {
      enabled       = true
      firewall_mode = "Prevention"
      custom_rules = {
        iprestrictions = local.custom_rule_ump_ip_restrictions
      }
      exclusions_for_managed_rules = local.exclusions_ump_common
      overrides_for_managed_rules  = local.overrides_ump_commons
    }

    ## UMP internal
    ump = {
      enabled                          = true
      firewall_mode                    = "Prevention"
      file_upload_limit_in_mb          = 4000
      max_request_body_size_in_kb      = 2000
      request_body_inspect_limit_in_kb = 2000
      request_body_enforcement         = false
      exclusions_for_managed_rules = merge(
        local.exclusions_ump_common,
        {
          header-contenttype = {
            match_variable          = "RequestHeaderNames"
            selector_match_operator = "Equals"
            selector                = "content-type"
            excluded_rule_set = {
              type    = "OWASP"
              version = "3.2"
              rule_group = [{
                rule_group_name = "REQUEST-920-PROTOCOL-ENFORCEMENT"
                excluded_rules  = ["920420"]
              }]
            }
          }
        }
      )
      overrides_for_managed_rules = local.overrides_ump_commons
    }

    ## UMP Print Data Storage Account
    umpstorage = {
      enabled       = true
      firewall_mode = "Prevention"
      custom_rules = {
        iprestrictions = local.custom_rule_storage_ip_restrictions
      }
    }
  }
}
