locals {
  ### Routings ###
  # order of objects is according to their dependencies, not their names. Object values are sorted alphabetically.

  # !! the stack 'appgateway' will automatically create dns entries for each host_name of a private listener within the private_dns_zone!!
  listeners = {
    file2image_private_listener = {
      certificate_secret = "file2img-internal-certificate"
      firewall_policy    = "file2image"
      host_names         = ["file2img.unionmarketingplattform.test.azure.union-investment.de"]
      name               = "file2image-private"
      type               = "private"
    }
    filme_private_listener = {
      certificate_secret = "filme-internal-certificate"
      firewall_policy    = "filme"
      host_names         = ["filme.test.apps.union-investment.de"]
      name               = "filme-private"
      type               = "private"
    }
    icingaweb_private_listener = {
      certificate_secret = "icinga-internal-certificate"
      firewall_policy    = "icingaweb"
      host_names         = ["icingaweb.unionmarketingplattform.test.azure.union-investment.de"]
      name               = "icingaweb-private"
      type               = "private"
    }
    landingassets_private_listener = {
      certificate_secret = "landing-internal-certificate"
      firewall_policy    = "landingassets"
      host_names         = ["landing-assets.test.apps.union-investment.de"]
      name               = "landingassets-private"
      type               = "private"
    }
    landingpages_private_listener = {
      certificate_secret = "landing-internal-certificate"
      host_names         = ["landing.test.apps.union-investment.de"]
      name               = "landingpages-private"
      type               = "private"
    }
    landingpagetool_private_listener = {
      certificate_secret = "landingtool-internal-certificate"
      firewall_policy    = "landingpagetool"
      host_names         = ["landing.unionmarketingplattform.test.azure.union-investment.de"]
      name               = "landingtool-private"
      type               = "private"
    }
    producthub_private_listener = {
      certificate_secret = "werbemittelkatalog-internal-certificate"
      firewall_policy    = "producthub"
      host_names         = ["werbemittelkatalog-test.union-investment.de"]
      name               = "producthub-private"
      type               = "private"
    }
    reportinghub_private_listener = {
      certificate_secret = "reporting-internal-certificate"
      firewall_policy    = "reportinghub"
      host_names         = ["reporting.unionmarketingplattform.test.azure.union-investment.de"]
      name               = "reportinghub-private"
      type               = "private"
    }
    semaphoreui_private_listener = {
      certificate_secret = "sui-internal-certificate"
      firewall_policy    = "semaphoreui"
      host_names         = ["sui.unionmarketingplattform.test.azure.union-investment.de"]
      name               = "semaphoreui-private"
      type               = "private"
    }
    setupbox_private_listener = {
      certificate_secret = "setupbox-internal-certificate"
      firewall_policy    = "setupbox"
      host_names         = ["setupbox.unionmarketingplattform.test.azure.union-investment.de"]
      name               = "setupbox-private"
      type               = "private"
    }
    ump_private_listener = {
      certificate_secret = "ump-internal-certificate"
      firewall_policy    = "ump"
      host_names         = ["ump.test.apps.union-investment.de"]
      name               = "ump-private"
      type               = "private"
    }
    umpstorage_public_listener = {
      certificate_secret = "umpstorage-apps-certificate"
      firewall_policy    = "umpstorage"
      host_names         = ["umpstorage.test.apps.union-investment.de"]
      name               = "umpstorage-public"
      type               = "public"
    }
  }

  probe_configurations = {
    landing_probe = {
      name                = "landingpages-probe"
      host                = local.listeners.landingpagetool_private_listener.host_names[0]
      interval            = 30
      timeout             = 30
      unhealthy_threshold = 3
      protocol            = "Https"
      path                = "/"
      match = {
        status_code = ["200-399", "404"]
      }
    }
    setupbox_probe = {
      name                                      = "setupbox-probe"
      interval                                  = 30
      timeout                                   = 30
      unhealthy_threshold                       = 3
      protocol                                  = "Https"
      path                                      = "/auth/login"
      pick_host_name_from_backend_http_settings = true
    }
    storage_account_probe = {
      name                                      = "storage-account-probe"
      interval                                  = 30
      timeout                                   = 30
      unhealthy_threshold                       = 3
      protocol                                  = "Https"
      path                                      = "/"
      pick_host_name_from_backend_http_settings = true
      match = {
        status_code = ["200-400"]
      }
    }
    vm_backend_probe = {
      name                                      = "vm-backend-probe"
      interval                                  = 30
      timeout                                   = 30
      unhealthy_threshold                       = 3
      protocol                                  = "Https"
      path                                      = "/"
      pick_host_name_from_backend_http_settings = true
      match = {
        status_code = ["200-399", "403"]
      }
    }
  }

  backend_http_settings = {
    file2image_settings = {
      host_name                      = local.listeners.file2image_private_listener.host_names[0]
      name                           = "file2image-settings"
      probe_name                     = local.probe_configurations.vm_backend_probe.name
      trusted_root_certificate_names = ["UI-RootCA-v02"]
    }
    filme_settings = {
      host_name                      = local.listeners.filme_private_listener.host_names[0]
      name                           = "filme-settings"
      probe_name                     = local.probe_configurations.vm_backend_probe.name
      request_timeout                = 90
      trusted_root_certificate_names = ["UI-RootCA-v02"]
    }
    icingaweb_settings = {
      host_name                      = local.listeners.icingaweb_private_listener.host_names[0]
      name                           = "icingaweb-settings"
      probe_name                     = local.probe_configurations.vm_backend_probe.name
      request_timeout                = 15
      trusted_root_certificate_names = ["UI-RootCA-v02"]
    }
    ## Landing Page Assets. These settings are used in path-based-routing and the respective path
    ## found in routing is fully replaced with the one in the backend setting. So, e.g. /uniglobal/* matches
    ## and '/uniglobal' is stripped from the request uri and replaced with what the backend setting delivers.
    ## For each landingpage a dedicated asset container exists and for each a backend setting.
    ## This also allows the switch containers from one release to the other
    landingassets_default_settings = {
      ## default-settings do reroute any non-matching request to a page and include the original path as query-string.
      ## This will be blocked by the firewall-policy (because query string) and result in 403, thus never reaching the
      ## storage account and avoiding blob-transactions.
      name                                = "lpa-default-settings"
      pick_host_name_from_backend_address = true
      path                                = "/statuspages/404.html?"
      probe_name                          = local.probe_configurations.storage_account_probe.name
      request_timeout                     = 1
    }
    landingassets_uniglobal_settings = {
      name                                = "lpa-uniglobal-settings"
      pick_host_name_from_backend_address = true
      path                                = "/uniglobal-release-1/"
      probe_name                          = local.probe_configurations.storage_account_probe.name
      request_timeout                     = 1
    }
    landingassets_ve_settings = {
      name                                = "lpa-ve-settings"
      pick_host_name_from_backend_address = true
      path                                = "/ve-release-1/"
      probe_name                          = local.probe_configurations.storage_account_probe.name
      request_timeout                     = 1
    }
    landingassets_zukunft_settings = {
      name                                = "lpa-zukunft-settings"
      pick_host_name_from_backend_address = true
      path                                = "/zukunft-release-1/"
      probe_name                          = local.probe_configurations.storage_account_probe.name
      request_timeout                     = 1
    }
    ## Landing Pages. The externally available domains routing against the backend which delivers content
    ## based on the selected template.
    ## Backend will always respond with the landing page tool certificate, hence the SNI_NAME.
    landingpages_settings = {
      name                           = "landingpages-settings"
      probe_name                     = local.probe_configurations.landing_probe.name
      request_timeout                = 15
      sni_name                       = local.listeners.landingpagetool_private_listener.host_names[0]
      trusted_root_certificate_names = ["UI-RootCA-v02"]
    }
    ## Landing Page Tool. The internal service used by UMP to create/deploy and configure landing pages.
    landingpagetool_settings = {
      name                           = "landingtool-settings"
      probe_name                     = local.probe_configurations.landing_probe.name
      request_timeout                = 15
      trusted_root_certificate_names = ["UI-RootCA-v02"]
    }
    producthub_settings = {
      host_name                      = local.listeners.producthub_private_listener.host_names[0]
      name                           = "producthub-settings"
      probe_name                     = local.probe_configurations.vm_backend_probe.name
      request_timeout                = 30
      trusted_root_certificate_names = ["UI-RootCA-v02"]
    }
    reportinghub_settings = {
      host_name                      = local.listeners.reportinghub_private_listener.host_names[0]
      name                           = "reportinghub-settings"
      probe_name                     = local.probe_configurations.vm_backend_probe.name
      request_timeout                = 90
      trusted_root_certificate_names = ["UI-RootCA-v02"]
    }
    sempahoreui_settings = {
      host_name                      = local.listeners.semaphoreui_private_listener.host_names[0]
      name                           = "sempahoreui-settings"
      probe_name                     = local.probe_configurations.vm_backend_probe.name
      trusted_root_certificate_names = ["UI-RootCA-v02"]
    }
    setupbox_settings = {
      host_name                      = local.listeners.setupbox_private_listener.host_names[0]
      name                           = "setupbox-settings"
      probe_name                     = local.probe_configurations.setupbox_probe.name
      request_timeout                = 90
      trusted_root_certificate_names = ["UI-RootCA-v02"]
    }
    ump_settings = {
      host_name                      = local.listeners.ump_private_listener.host_names[0]
      name                           = "ump-settings"
      probe_name                     = local.probe_configurations.vm_backend_probe.name
      request_timeout                = 180
      trusted_root_certificate_names = ["UI-RootCA-v02"]
    }
    umpstorage_settings = {
      name                                = "umpstorage-settings"
      pick_host_name_from_backend_address = true
      probe_name                          = local.probe_configurations.storage_account_probe.name
      request_timeout                     = 1
    }
  }

  backend_address_pools = {
    config_pool = {
      name = "config-backends"
    }
    file2image_pool = {
      name = "file2image-backends"
    }
    filme_pool = {
      name = "filme-backends"
    }
    landingassets_pool = {
      name  = "landingassets-backends"
      fqdns = ["stumptestlpassetsjjh3lzn.blob.core.windows.net"]
    }
    landingpages_pool = {
      name = "landingpages-backends"
    }
    producthub_pool = {
      name = "producthub-backends"
    }
    reportinghub_pool = {
      name = "reportinghub-backends"
    }
    ump_pool = {
      name = "ump-backends"
    }
    umpstorage_pool = {
      name  = "umpstorage-backends"
      fqdns = ["stumptestexchangen6q6ajf.blob.core.windows.net"]
    }
  }

  url_path_map_configurations = {
    ## Landing Assets Routing. Each path corresponds with a Landing Page (e.g. uniglobal) and a dedicated backend setting
    landing_assets_path_based = {
      cors_rewrite_enabled               = true
      default_backend_address_pool_name  = local.backend_address_pools.landingassets_pool.name
      default_backend_http_settings_name = local.backend_http_settings.landingassets_default_settings.name
      name                               = "lpa-default-route"

      path_rules = {
        lpa_uniglobal = {
          backend_address_pool_name  = local.backend_address_pools.landingassets_pool.name
          backend_http_settings_name = local.backend_http_settings.landingassets_uniglobal_settings.name
          name                       = "lpa-uniglobal-route"
          paths                      = ["/uniglobal/*"]
        }
        lpa_ve = {
          backend_address_pool_name  = local.backend_address_pools.landingassets_pool.name
          backend_http_settings_name = local.backend_http_settings.landingassets_ve_settings.name
          name                       = "lpa-ve-route"
          paths                      = ["/VE-Impuls-Junge-Neukunden/*"]
        }
        lpa_zukunft = {
          backend_address_pool_name  = local.backend_address_pools.landingassets_pool.name
          backend_http_settings_name = local.backend_http_settings.landingassets_zukunft_settings.name
          name                       = "lpa-zukunft-route"
          paths                      = ["/zukunft-2026/*"]
        }
      }
    }
  }

  request_routing_rules = {
    file2image_private_route = {
      backend_address_pool_name  = local.backend_address_pools.file2image_pool.name
      backend_http_settings_name = local.backend_http_settings.file2image_settings.name
      http_listener_name         = local.listeners.file2image_private_listener.name
      name                       = "file2image-private-route"
      rule_type                  = "Basic"

      priority = 2900
    }
    filme_private_route = {
      backend_address_pool_name  = local.backend_address_pools.filme_pool.name
      backend_http_settings_name = local.backend_http_settings.filme_settings.name
      http_listener_name         = local.listeners.filme_private_listener.name
      name                       = "filme-private-route"
      rule_type                  = "Basic"

      priority = 2700
    }
    icingaweb_private_route = {
      backend_address_pool_name  = local.backend_address_pools.config_pool.name
      backend_http_settings_name = local.backend_http_settings.icingaweb_settings.name
      http_listener_name         = local.listeners.icingaweb_private_listener.name
      name                       = "icingaweb-private-route"
      rule_type                  = "Basic"

      priority = 2100
    }
    landingassets_private_route = {
      http_listener_name = local.listeners.landingassets_private_listener.name
      name               = "landingassets-private-route"
      rule_type          = "PathBasedRouting"
      url_path_map_name  = local.url_path_map_configurations.landing_assets_path_based.name

      priority = 2005
    }
    landingpages_private_route = {
      backend_address_pool_name  = local.backend_address_pools.landingpages_pool.name
      backend_http_settings_name = local.backend_http_settings.landingpages_settings.name
      http_listener_name         = local.listeners.landingpages_private_listener.name
      name                       = "landingpages-private-route"
      rule_type                  = "Basic"

      priority = 1010
    }
    landingpagetool_private_route = {
      backend_address_pool_name  = local.backend_address_pools.landingpages_pool.name
      backend_http_settings_name = local.backend_http_settings.landingpagetool_settings.name
      http_listener_name         = local.listeners.landingpagetool_private_listener.name
      name                       = "landingpagetool-private-route"
      rule_type                  = "Basic"

      priority = 2500
    }
    producthub_private_route = {
      backend_address_pool_name  = local.backend_address_pools.producthub_pool.name
      backend_http_settings_name = local.backend_http_settings.producthub_settings.name
      http_listener_name         = local.listeners.producthub_private_listener.name
      name                       = "producthub-private-route"
      rule_type                  = "Basic"

      priority = 2200
    }
    reportinghub_private_route = {
      backend_address_pool_name  = local.backend_address_pools.reportinghub_pool.name
      backend_http_settings_name = local.backend_http_settings.reportinghub_settings.name
      http_listener_name         = local.listeners.reportinghub_private_listener.name
      name                       = "reportinghub-private-route"
      rule_type                  = "Basic"

      priority = 2800
    }
    semaphore_private_route = {
      backend_address_pool_name  = local.backend_address_pools.config_pool.name
      backend_http_settings_name = local.backend_http_settings.sempahoreui_settings.name
      http_listener_name         = local.listeners.semaphoreui_private_listener.name
      name                       = "semaphoreui-private-route"
      rule_type                  = "Basic"

      priority = 2400
    }
    setupbox_private_route = {
      backend_address_pool_name  = local.backend_address_pools.ump_pool.name
      backend_http_settings_name = local.backend_http_settings.setupbox_settings.name
      http_listener_name         = local.listeners.setupbox_private_listener.name
      name                       = "setupbox-private-route"
      rule_type                  = "Basic"

      priority = 2600
    }
    ump_private_route = {
      backend_address_pool_name  = local.backend_address_pools.ump_pool.name
      backend_http_settings_name = local.backend_http_settings.ump_settings.name
      http_listener_name         = local.listeners.ump_private_listener.name
      name                       = "ump-private-route"
      rule_type                  = "Basic"

      priority = 2300
    }
    umpstorage_route = {
      backend_address_pool_name  = local.backend_address_pools.umpstorage_pool.name
      backend_http_settings_name = local.backend_http_settings.umpstorage_settings.name
      http_listener_name         = local.listeners.umpstorage_public_listener.name
      name                       = "umpstorage-route"
      rule_type                  = "Basic"

      priority = 1500
    }
  }

}

inputs = {
  application_gateway_config = {
    backend_address_pools       = local.backend_address_pools
    backend_http_settings       = local.backend_http_settings
    listeners                   = local.listeners
    probe_configurations        = local.probe_configurations
    request_routing_rules       = local.request_routing_rules
    url_path_map_configurations = local.url_path_map_configurations
  }
}
