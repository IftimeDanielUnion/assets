## Environment definition
## Required to access the subscription_id in root.hcl (for the azure provider).
locals {
  subscription    = "S_UNIONMARKETINGPLATTFORM_TEST"
  subscription_id = "4cc30493-9746-4edb-a404-1aad8388c81c"
}
