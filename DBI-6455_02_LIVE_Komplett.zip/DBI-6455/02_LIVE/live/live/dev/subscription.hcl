## Environment definition
## Required to access the subscription_id in root.hcl (for the azure provider).
locals {
  subscription    = "S_UNIONMARKETINGPLATTFORM_DEV"
  subscription_id = "daa58c0d-c970-4aac-886a-c88e3c8eb620"
}
