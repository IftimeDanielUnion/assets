locals {
  # Load environment-level variables
  subscription_vars = read_terragrunt_config(find_in_parent_folders("subscription.hcl")).locals

  # Create a basic tag definition
  tags = {
    backend_state = "gitlab:${local.backend_state_name}"
  }

  ## Backend Definition using internal Gitlab terraform state. The state of each unit will be kept separate
  #  Creates a name from the path like dev.app-gateway.keyvault-internal. If path includes folder .terragrunt-stack it is ignored
  backend_state_name    = replace(replace(path_relative_to_include(), "//.terragrunt-stack//", "/"), "/\\//", ".")
  backend_ci_api_v4_url = "https://gitlab.apps.union-investment.de/api/v4"
  backend_project       = "3559" # i.e. Project /ump_legacy/infrastructure/live
  backend_address       = "${local.backend_ci_api_v4_url}/projects/${local.backend_project}/terraform/state/${local.backend_state_name}"
}

# Generate an AzureRM provider block
generate "provider" {
  path      = "provider.tf"
  if_exists = "overwrite_terragrunt"
  contents  = <<EOF
terraform {
  required_version = "~> 1.13"
  required_providers {
    azapi = {
      source  = "azure/azapi"
      version = "~> 2.7"
    }
    azurerm = {
      source = "hashicorp/azurerm"
      version = "~>4.63"
    }
  }
}

provider "azurerm" {
  storage_use_azuread = true
  subscription_id = "${local.subscription_vars.subscription_id}"
  features {
    resource_group {
      prevent_deletion_if_contains_resources = false
    }
  }
}
EOF
}

remote_state {
  backend = "http"
  generate = {
    path      = "backend.tf"
    if_exists = "overwrite"
  }
  config = {
    address        = "${local.backend_address}"
    lock_address   = "${local.backend_address}/lock"
    unlock_address = "${local.backend_address}/lock"
    lock_method    = "POST"
    unlock_method  = "DELETE"
    retry_wait_min = "5"
  }
}

# ---------------------------------------------------------------------------------------------------------------------
# GLOBAL PARAMETERS
# These inputs apply to all configurations in this subfolder. This file is automatically merged into the child
# `terragrunt.hcl` config via the include 'root' block.
# Do not over-use and avoid 'magic' appearances of input variables in the target module
# ---------------------------------------------------------------------------------------------------------------------
inputs = {}
