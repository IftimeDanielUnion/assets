# DBI-6455: Nur noch Schritt 02 im live-Repo

## Stand und Inhalt

**01 ist im hochgeladenen Catalog-Code umgesetzt.** Die beiden Moduldateien entsprechen dem vorbereiteten LAW-Umbau; die bestehende Unit reicht die Alert-Einstellungen bereits weiter. Du musst dort keine weiteren Dateien ändern. Ob der Catalog-MR schon freigegeben und gemerged ist, belegt der Branch-Export nicht.

**02 fehlt im hochgeladenen live/main und ist in diesem Paket fertig vorbereitet.** Unter `02_LIVE/live/` liegt der vollständige Repository-Root aus deinem aktuellen Upload, ohne `.git`. Es sind keine Dateifragmente und keine Skripte enthalten.

Nur diese zwei Dateien unterscheiden sich vom hochgeladenen `main`:

```text
live/test/terragrunt.stack.hcl    geändert, vollständige Datei
live/test/exception-alerts.hcl   neu, vollständige Datei
```

Die TEST-Monitoring-Unit verwendet den echten Catalog-Commit `94343286e555a4e8384b49cfd2b825e6ed9bb79d`. Er ist bereits eingetragen. Alle anderen Units bleiben auf ihren bisherigen Versionen. DEV, PROD, Gateway-Konfiguration und `.gitlab-ci.yml` bleiben bytegleich zu deinem Upload.

**Voraussetzung für den Rollout:** Catalog-Änderung freigeben/mergen und den referenzierten Commit in GitLab verfügbar halten. Bei einem Squash-Merge den alten Catalog-Featurebranch nicht ungeprüft löschen: Der gepinnte ursprüngliche Commit muss über einen Branch oder Tag erreichbar bleiben. Ein normaler Merge, der den Commit in `main` erhält, erfüllt das ebenfalls. Keine erneute Umsetzung von Schritt 01 nötig.

## 1. Originales live-Repo vorbereiten

Öffne dein **originales `live`-Repository** in VS Code und dessen WSL-Terminal. Nicht im entpackten Paket Git ausführen. Führe die Blöcke nacheinander aus und stoppe bei Fehlern.

```bash
cd "$(git rev-parse --show-toplevel)"
git remote -v
git status --short
```

`origin` muss auf `ump_legacy/infrastructure/live` zeigen. Bei offenen Änderungen zuerst stoppen und diese sichern; die Anleitung löscht keine eigene Arbeit.

```bash
git fetch origin --prune && git switch main && git pull --ff-only origin main
```

Einmal prüfen, ob `main` seit deinem Upload noch unverändert ist. Das ist wichtig, weil du gleich einen vollständigen Repository-Root kopierst:

```bash
git diff --exit-code c79db92fcd3f160e774ad7a984d1c8d3c99719cb HEAD --
```

**Keine Ausgabe und Exitcode 0:** weiter. Bei Unterschieden oder unbekanntem Commit nicht darüberkopieren, sonst könnten neuere Änderungen verloren gehen. Dann muss das Paket auf den neueren Stand angepasst werden, nicht deine Datei von Hand.

```bash
git switch -c feat/DBI-6455-test-law-alerts
explorer.exe .
```

Der letzte Befehl öffnet direkt den richtigen Zielordner im Windows-Explorer.

## 2. Kompletten Root-Inhalt kopieren

Öffne im entpackten Paket **`DBI-6455/02_LIVE/live/`**. Markiere darin den gesamten Inhalt mit **Strg+A** und ziehe ihn in den eben geöffneten Original-Repo-Root. **Dateien im Ziel ersetzen** auswählen. Es wird keine `.git`-Historie mitgeliefert oder ersetzt.

Im Ziel liegt danach weiterhin `.gitlab-ci.yml` direkt neben dem Unterordner `live`. Kopiere nicht den äußeren Paket-/Repo-Ordner als zusätzlichen Unterordner hinein.

```text
Git-relativ richtig: live/test/terragrunt.stack.hcl
Git-relativ falsch:  live/live/test/terragrunt.stack.hcl
```

## 3. Prüfen, committen und pushen

```bash
git status --short
git diff --check
git diff -- live/test/terragrunt.stack.hcl
```

Erwartet sind nur die geänderte TEST-Stackdatei und die neue `exception-alerts.hcl`. Die Stackdatei hat **5 hinzugefügte und 1 entfernte Zeile**, nicht hunderte neue Zeilen. Keine Änderungen in DEV, PROD oder CI.

Wenn das passt:

```bash
git add .
git diff --cached --check
git diff --cached --stat
```

Erwarteter Umfang: **2 Dateien, 56 hinzugefügte und 1 entfernte Zeile**. Bei zusätzlichen Dateien nicht committen.

```bash
git commit -m "DBI-6455: configure TEST OTel email alerts via catalog" && git push -u origin feat/DBI-6455-test-law-alerts
```

## 4. Neuer live-MR

**Branch:** `feat/DBI-6455-test-law-alerts` nach `main`. **Reviewer:** Timo. Nicht den verworfenen alten MR !52 reaktivieren.

**Titel:** `DBI-6455: TEST-Alarmierung über bestehenden Monitoring-Baustein`

**Beschreibung zum Kopieren:**

> Bindet die TEST-Alarmierung in den bestehenden log-and-monitor-Baustein ein. Nur die Monitoring-Unit wird auf den Catalog-Commit 94343286e555a4e8384b49cfd2b825e6ed9bb79d gepinnt. Konfiguriert werden eine Action Group für ui-team@os-cillation.de und eine LAW-basierte Log-Alert-Regel für error/fatal in OTelLogs, aufgeteilt nach ServiceName. Prüfung jede Minute mit fünf Minuten Zeitfenster und automatischer Auflösung. DEV, PROD, übrige Units und CI bleiben unverändert. Voraussetzung ist die freigegebene Catalog-Änderung. Nach Review folgen TEST-Plan, manueller Apply und End-to-End-Test einschließlich Mail-Eingang.

## 5. Danach: Plan, manueller Apply und Test

Die vorhandene Pipeline berücksichtigt Änderungen unter `live/test/` bereits. `checkTestEnvironment` läuft nach der vorhandenen Konfiguration in der Featurebranch-Pipeline, `planTestEnvironment` in der MR-Pipeline.

Prüfe vor dem Merge den TEST-Plan. Für diese Änderung werden bei bislang fehlender Alarmierung **eine Action Group und eine Log-Alert-Regel** im vorhandenen Monitoring-State erwartet. Kein neuer LAW, kein Ersatz und keine Löschung von vorhandener Infrastruktur. Bei bereits vorhandener gleichwertiger Alarmierung oder anderen ausstehenden Änderungen zuerst klären, statt diese unbeabsichtigt mitzurollen.

Nach dem Merge den **neuen `planTestEnvironment` auf main** prüfen und in derselben Pipeline **`applyTestEnvironment` manuell starten**, mit dem gespeicherten Plan. Kein PROD-Apply und nicht auf planloses Anwenden umstellen.

Erwartete Namen:

```text
Action Group: log-ump-test-mag-osc-exceptions
Log-Alert:    ump-test-otel-error-fatal
Scope:        log-ump-test
```

Mit Alex einen kontrollierten Anwendungsfehler erzeugen und bestätigen lassen, dass er in `OTelLogs` ankommt, den Alert auslöst und die Mail bei `ui-team@os-cillation.de` eingeht. Anschließend die Alarmauflösung prüfen. Erst dann ist **TEST abgenommen**, nicht automatisch ein noch benötigter PROD-Rollout. Der ServiceName wird als Dimension ausgewertet; ein bestimmter Mail-Betreff wird nicht zugesichert.

## Prüfstand und Quellen

Basis ist ausschließlich dein neuer Upload `test.zip`: `live-main.zip` mit Archiv-Commit `c79db92fcd3f160e774ad7a984d1c8d3c99719cb` und `catalog-feat-DBI-6455-law-alerts.zip` mit Archiv-Commit `94343286e555a4e8384b49cfd2b825e6ed9bb79d`.

Zehn lokale Prüfungen bestanden: Catalog-Umbau, Weitergabe der Maps, echte Commit-Referenz, unveränderte Monitoring-Abhängigkeiten, Konfigurationswerte, exakter Datei-/Blockvergleich, korrekte Ordnerstruktur sowie vollständiges Überkopieren und Committen in einem temporären Git-Repository. Der Kopiertest erzeugte genau die zwei oben genannten Änderungen und erhielt die vorhandene Git-Historie.

**Keine native Terraform-/Terragrunt-Validierung, kein Azure-Plan, kein Deployment und kein Mail-Test hier ausgeführt.** Die Binärdateien waren lokal nicht vorhanden und konnten nicht heruntergeladen werden. Die Prüfungen ersetzen daher nicht eure Pipeline und Abnahme. GitLab und Azure wurden nicht verändert.

Technische Referenzen: [Terragrunt-Quellen und Commit-Pinning](https://terragrunt.gruntwork.io/docs/features/units/), [Git-Quellen für Terraform-Module](https://developer.hashicorp.com/terraform/language/modules/configuration).
