# MBPortal und Infrastruktur nach GitLab: Startpaket


## Neu: technische Anleitung zu State und GitLab

Öffne **[Technik/Technik_State_Terragrunt_GitLab.md](Technik/Technik_State_Terragrunt_GitLab.md)**.

Dort stehen die Zusammenhänge von Terraform, Terragrunt und Azure-State, die vorhandenen Backend-Adressen, Versionen, Rechte, DEV-Prüfschritte, Plan/Apply, Umschaltung und Rückfallverfahren. Der State soll zunächst in Azure Storage bleiben.

Der Ordner **[Technik](Technik/README.md)** enthält außerdem Originalfundstellen, ein aus dem Quellcode abgeleitetes State-Inventar und einen optionalen Metadaten-Prüfhelfer. Es wurden keine Azure-Abfragen oder Deployments ausgeführt. Die Skripttests liefen ausschließlich lokal mit simulierten Antworten.

---


**Für Daniel Iftime | Stand: 27.10.2026**

Hier ist die zuletzt besprochene Anleitung zusammen mit den vorbereiteten Anträgen, dem Infrastruktur-Jira-Ticket, dem bedingten Firewall-Change und den technischen Fundstellen gebündelt. Der Chat wird zum Lesen nicht benötigt.

**Status:** Arbeitsunterlagen und Kopiertexte, keine bereits erledigten Bestellungen. Es wurden keine Tickets, Gruppen, Requests oder Changes angelegt und keine Pipelines oder Deployments ausgeführt. Repositorybefunde beziehen sich auf die gelieferten Dateien, nicht auf eine bestätigte Live-Konfiguration.

## 1. Zuerst hier anfangen

| Du möchtest ... | Öffne ... |
|---|---|
| Den Ablauf verstehen und die Anträge ausfüllen | [Anträge und Vorgehen](Marktbearbeitungsplattform_Infra_Antraege_und_Vorgehen.md) |
| Das Infrastruktur-Ticket in Jira anlegen | [Jira-Vorlage mit kopierbarem Jira-Wiki-Codeblock](Jira_Marktbearbeitungsplattform_Infra_GitLab.md) |
| Eine Aussage oder technische Fundstelle prüfen | [Quellenprüfung mit Dateipfaden und Originalauszügen](Marktbearbeitungsplattform_Infra_Quellenpruefung.md) |
| Das vorgegebene Zielbild ansehen | [Release-Governance als Bild](Vorlagen_Originale/Zielbild_Release_Governance.png) |
| Originalformulare vergleichen | [Übersicht der Originalvorlagen](Vorlagen_Originale/README.md) |

Die drei Arbeitsdokumente sind die zuletzt vorbereiteten Fassungen. Ältere, teilweise doppelte Pakete sind nicht noch einmal enthalten.

## 2. Was für uns festgelegt ist

Der gewünschte Name für die neue Infrastrukturgruppe lautet **`marktbearbeitungsplattform-infra`**. Sie soll eine eigenständige Top-Level-Gruppe werden, keine Untergruppe des bestehenden Anwendungsbereichs. Die Anwendungen bleiben unter **`marktbearbeitungsplattform`**.

```text
GitLab
├── marktbearbeitungsplattform                 bestehende Apps-Gruppe
│   ├── bestehende Anwendungen
│   ├── cicd/templates/pipeline-templates      Anwendungstemplates
│   └── MBPortal-Anwendungsrepositories        genaue Zielpfade abstimmen
│
└── marktbearbeitungsplattform-infra           neue Infra-Gruppe
    └── ui-mb-infrastructure                  Zielprojekt für Infra-Code
```

**Geplanter Infrastruktur-Projektpfad:**

```text
marktbearbeitungsplattform-infra/ui-mb-infrastructure
```

Eine Gruppe organisiert Projekte und Berechtigungen. Das Projekt enthält das Repository. Ein neuer GitLab-Gruppenname bedeutet keine neue Azure-Subscription und keinen Neubau der laufenden Ressourcen.

Die genaue Platzierung von Portal-Frontend und Backend innerhalb der Apps-Gruppe ist mit dem Entwicklerteam abzustimmen. `mbportal-dashboard` bleibt ein separates Projekt. Auch vorhandene `mashub`-Projekte werden nicht allein wegen ihres Namens als identische Zielrepos behandelt oder überschrieben.

Die Trennung folgt den gelieferten internen Vorgaben. Das Zielbild und die Originalanleitung liegen unter `Vorlagen_Originale/`; die Zuordnung ist in der Quellenprüfung unter M01/M02 dokumentiert.

## 3. Welches Ticket brauchen wir?

**Anwendungen:** DBI-6605 existiert bereits für die Migration von MBPortal-Frontend und Backend. APIM ist dort ausdrücklich ausgenommen. Kein zweites gleichartiges Anwendungsticket anlegen.

**Infrastruktur:** Eine eigene Story anlegen und mit DBI-6605 verknüpfen:

> ui-mb-infrastructure von Azure DevOps nach GitLab migrieren

Die vollständige Beschreibung steht in der Jira-Datei im Codeblock. Dort sind Anforderungen, technische Hinweise, Abnahmekriterien und vorgeschlagene Unteraufgaben vorbereitet. Sprint, Priorität und Schätzung werden im Team festgelegt.

| Vorgang | Zweck |
|---|---|
| Jira-Story | Arbeit planen, zuweisen und abnehmen. |
| ServiceNow-Request | Gruppe, Nexus-Ablage oder Azure-Anbindung bereitstellen lassen. |
| Change | Eine konkrete technische Änderung genehmigen und umsetzen lassen. |

Ein Jira-Ticket ersetzt nicht die erforderlichen Bestellungen oder Changes.

## 4. Diese vorhandenen Teile nicht doppelt bestellen

### Bestehende Azure-Anbindung

In `Global-Settings/Workloads/workloads.d/marktbearbeitung.yml` steht bereits eine Integration für `MARKTBEARBEITUNG` mit der GitLab-Gruppe `5614` (Marktbearbeitungsplattform).

**Die bestehende Anbindung erhalten.** Die neue Infra-Gruppe erhält eine eigene numerische Group ID. Diese neue ID kommt später in den Azure-Integrationsantrag. Nicht `5614`, keine Projekt-ID und keine Managed-Identity-Object-ID übernehmen. Nachweis: Quellenprüfung Q01.

### Bestehende Firewallregel

In `Firewall-Rules/rules/workloads/marktbearbeitung.yml` ist `Allow Access from DeliveryPipeline (GitLab)` definiert: Quelle `#WL_DELIVERYPIPELINE_PROD`, Ziele Marktbearbeitung DEV/TEST/PROD, TCP 443 und 5432.

**Das ist ein Quellbefund, noch kein Live-Nachweis.** Zuerst prüfen lassen, ob der vorgesehene Runner und die benötigten Ziele bereits erreichbar sind. Nur eine tatsächlich festgestellte Lücke als zusätzlichen Change beantragen. Nachweis: Quellenprüfung Q03.

Das Originalbeispiel UI-CHG-0093595 gehört zu DIGITALASSETHUB. Dessen Netze, Subscriptions, Zuständigkeiten, Freigaben und Termine gelten nicht automatisch für Marktbearbeitung.

## 5. Deine nächsten Schritte

- [ ] **Infrastruktur-Story anlegen:** Den Jira-Wiki-Codeblock aus der Jira-Datei verwenden und die Story mit DBI-6605 verknüpfen.
- [ ] **DVOS-Abstimmung:** Namen und separate Top-Level-Gruppe bestätigen; vorhandene Onboardingteile zur Wiederverwendung prüfen. Eine kopierbare Nachricht an DVOS/CIS steht am Ende der Antragsdatei.
- [ ] **Namespace-Antrag vorbereiten:** Vertreter benennen; formelle Verantwortung und Application-Service-Zuordnung bestätigen.
- [ ] **Namespace bestellen:** `marktbearbeitungsplattform-infra`, privat, eigenständige Top-Level-Gruppe. Beschreibung und Begründung stehen in der Antragsdatei.
- [ ] **Neue Group ID dokumentieren:** Erst nach tatsächlicher Anlage der Gruppe verfügbar.
- [ ] **Zugriffe und Azure-Anbindung vervollständigen:** Neue Group ID verwenden; bestehende Apps-Anbindung erhalten. UAM, technisches Konto, Nexus und Werkzeugimage nur bei Bedarf ergänzen.
- [ ] **Netzwerk prüfen:** Vorhandene Freischaltung bestätigen; bei einer Lücke den vorbereiteten Delta-Change konkretisieren.
- [ ] **Repository und Pipeline übernehmen:** Historie und State-Zuordnung erhalten. Zunächst einen begrenzten DEV-Plan ohne Apply prüfen.
- [ ] **Kontrolliert umschalten:** DEV abnehmen, danach TEST/PROD mit den vorgesehenen Freigaben. Keine parallelen schreibenden Deployments aus Azure DevOps und GitLab.

**Für den ersten Namespace-Antrag offen:** benannter Vertreter sowie formelle Bestätigung von Verantwortlichem und Application Service. `AS Marktbearbeitung Produktion` ist ein aus dem Code abgeleiteter Suchvorschlag, keine bereits bestätigte Auswahl für den umgebungsübergreifenden Namespace.

## 6. Was für die technische Umsetzung wichtig bleibt

Die Details mit Fundstellen stehen in den Arbeitsdokumenten:

- Bestehende Azure-Ressourcen, Terraform-State-Backends, Container, State-Keys und relative Pfade zunächst erhalten. Kein Ressourcenimport allein wegen des CI-Wechsels.
- Das `tgtf`-Template muss zur tatsächlichen Terragrunt-Modulstruktur passen. Plan und Apply müssen eindeutig an denselben geprüften Stand gebunden werden.
- Werkzeugversionen kontrolliert festlegen. Beim Pipelinewechsel nicht unbemerkt gleichzeitig Terraform, Provider oder Terragrunt aktualisieren.
- App Settings und Frontendkonfiguration bleiben eine abgestimmte Schnittstelle zwischen Infrastruktur und Anwendungsauslieferung.
- Die Anwendungstemplates aus `pipeline-templates-release.zip` sind inzwischen geliefert. Sie enthalten Deploymentjobs und weitere Includes; die vollständige Umsetzung der gewünschten Build-/Deploymenttrennung ist damit noch nicht automatisch nachgewiesen.
- APIM-Migration, Service-Bus-Berechtigungsumbau und SMTP-Befund bleiben getrennt nachvollziehbare Arbeitspakete.

## 7. Umfang dieses ZIP

Enthalten sind die aktuellen Arbeitsunterlagen und die relevanten Originalvorlagen. Nicht enthalten sind die großen Quellcodearchive, persönliche Ausbildungsunterlagen, Zugangsdaten oder Terraform-States. Die technischen Originalauszüge sind bereits in der Quellenprüfung enthalten.

**Lesereihenfolge:** Diese README, danach die Antragsdatei. Das Jira-Ticket ist separat direkt kopierbar; die Quellenprüfung ist zum Nachschlagen gedacht.
