# Marktbearbeitungsplattform: Quellenprüfung für Infrastruktur-Onboarding

**Stand: 27.10.2026.** Nur die gelieferten Archive und Formulare wurden geprüft. Keine Live-Abfragen an GitLab, Azure, Nexus oder ServiceNow; keine Anträge, Changes, Tickets oder Pipelines angelegt oder ausgeführt. Zeilennummern beziehen sich auf die jeweiligen gelieferten Dateien. Die Analyse führt keine Secret-Werte auf.

## Vorlagen und ihre Rolle

| Kennung | Quelle | Verwendeter Inhalt |
|---|---|---|
| F01 | `Gitlab Migration.zip` > `GitLab_ Anlage eines Namespace - Employee Center.pdf`, S. 1–3 | Tatsächliche Felder: Betroffene Person, Bereichsname, Application Service, Verantwortlicher, Vertreter, Beschreibung, Sichtbarkeit, Begründung. |
| F02 | Gleiches Archiv > `Nexus Repository Manager_ Anlage eines Namespace - Employee Center.pdf`, S. 1–3 | Bereichsname, Service, Verantwortliche, Artifact type(s), optionale ACR-Sync-Zuordnung, Begründung. |
| F03 | Gleiches Archiv > `Azure GitLab Integration - Anlegen - Employee Center.pdf`, S. 1–2 | Auswahl einer Azure-Subscription aus dem Workload, GitLab Group ID, zusätzliche API-Berechtigungen. Die Formbeschreibung sagt, dass eine Entra-ID-Identität bereitgestellt und deren Credentials automatisch als GitLab-CI-Variablen hinterlegt werden. |
| F04 | Gleiches Archiv > `change_request.pdf`, S. 1–4 | Abgeschlossener Beispiel-Change UI-CHG-0093595 für DIGITALASSETHUB: Kategorie Netz/Firewall, EPG-basierte Regeln, Implementierungs-/Rollback-/Prüffelder. S. 5–9: fremde Konflikte, Freigaben und Abschlussdaten, nicht übernommen. |
| M01 | `Gitlab Migration_1577e3f0dab04b57bb97152292e8d9b1-271026-0909-2320.pdf`, S. 1–3 | Getrennte Infra-Gruppe, Nexus, Onboardingschritte 0–10. |
| M02 | `Zukunftsdesign.html`, Abschnitt Regeln und Diagramm; gleiches Zielbild im Upload | Zwei Top-Level-Gruppen, Vier-Augen-Prinzip, ServiceNow-Gate, unveränderliche Releases. |
| J01 | `DBI-6605.doc`, Beschreibung | Bestehendes Epic für Portal-Frontend/Backend; APIM separat. |
| J02 | `DBI-8123.doc`, Beschreibung | Vorlage für die Jira-Beschreibungsstruktur, nicht für fremde fachliche Inhalte oder Statusfelder. |

## Fundstellen aus dem Code

### Q01: Bestehende GitLab-Anbindung und vorhandene npm-Ablage

Datei: `source/Global-Settings/Workloads/workloads.d/marktbearbeitung.yml`  
SHA-256: `096b23747c22f647b9c1ba8da408869fa62567ecf9a6689b9308229ee5899c1d`

```text
15:   deployments:
16:     - type: artifact_store
17:       # UI-TSK-0098602
18:       name: marktbearbeitung
19:       settings:
20:         format: npm
21: 
22:     - type: terraform_module
23:       name: ggroup-marktbp
24:       settings:
25:         source: spacelift.io/union-investment/azure-integration/gitlab
26:         version: ~> 0.1.1
27:         variables:
28:           azureWorkloadNames:
29:             - MARKTBEARBEITUNG
30:           gitLabGroup: 5614 # Marktbearbeitungsplattform
31: 
```

**Einordnung:** Die konfigurierte Integration betrifft Gruppe 5614 (Kommentar: Marktbearbeitungsplattform). Das ist nicht die noch anzulegende Infra-Gruppe. Die bestehende Anbindung nicht ersetzen. Eine vorhandene npm-Ablage beweist keinen vorhandenen Docker-Namespace für die neue Infra-Gruppe.

### Q02: ServiceNow-Zuordnung des Workloads

Datei: `source/Global-Settings/Workloads/workloads.d/marktbearbeitung.yml`  
SHA-256: `096b23747c22f647b9c1ba8da408869fa62567ecf9a6689b9308229ee5899c1d`

```text
33:     - dev:
34:         service_now:
35:           application_service: 'AS Marktbearbeitung Entwicklung'
36:           tso_ms_supplier_name: 'TSO tAB MARKTBEARBEITUNG Entwicklung'
37:           assignment_group: 'Cloud-IIM-CIS-TAB-PRV'
38:         enabled: true
39:         type: azure
```

```text
565:     - test:
566:         service_now:
567:           application_service: 'AS Marktbearbeitung Test'
568:           tso_ms_supplier_name: 'TSO tAB MARKTBEARBEITUNG Test'
569:           assignment_group: 'Cloud-IIM-CIS-TAB-PRV'
570:         enabled: true
571:         type: azure
```

```text
1015:     - prod:
1016:         service_now:
1017:           application_service: 'AS Marktbearbeitung Produktion'
1018:           tso_ms_supplier_name: 'TSO tAB MARKTBEARBEITUNG Produktion'
1019:           assignment_group: 'Cloud-IIM-CIS-TAB-PRV'
1020:         enabled: true
1021:         type: azure
```

**Einordnung:** Namen sind aus dem Quellstand bekannt; aktuelle CMDB-Auswahl und Zuordnung für den Namespace durch DVOS/Serviceverantwortliche bestätigen. Die aufgeführte assignment_group ist keine automatisch bestätigte Change-Koordinatorgruppe.

### Q03: Vorhandene GitLab-Runner-Firewallregel

Datei: `source/Firewall-Rules/rules/workloads/marktbearbeitung.yml`  
SHA-256: `642843ae87a3f524c5a962855861f49953b22646058a4c1ba57c347691b2722c`

```text
168: # Cross Stage - Network
169: - name: 'Workload-MARKTBEARBEITUNG-Cross-Stage'
170:   desc: 'This rule collection contains all cross stage network rules for the MARKTBEARBEITUNG Workload'
171:   stages:
172:     - 'nonprd'
173:     - 'prd'
174:   firewalls:
175:     - 'fw-hub-dev-01'
176:     - 'fw-hub-test-01'
177:     - 'fw-hub-prod-01'
178:   type: 'network'
179:   action: 'Allow'
180:   prio: 2881
181:   rules:
182:     - name: 'Allow Access to Nonprod Subscriptions for Self-Hosted Agents'
183:       desc: 'UI-CHG-0036830'
184:       src:
185:         - '#WLDT_MARKTBEARBEITUNG_PROD_azdo-agent'
186:       dst:
187:         - '#WL_MARKTBEARBEITUNG_DEV'
188:         - '#WL_MARKTBEARBEITUNG_TEST'
189:       ports:
190:         - '443'
191:         - '5432'
192:       protocols:
193:         - 'TCP'
194: 
195:     - name: 'Allow Access from DeliveryPipeline (GitLab)'
196:       desc: 'UI-CHG-0041528, UI-CHG-0041934, UI-CHG-0054560'
197:       src:
198:         - '#WL_DELIVERYPIPELINE_PROD'
199:       dst:
200:         - '#WL_MARKTBEARBEITUNG_DEV'
201:         - '#WL_MARKTBEARBEITUNG_TEST'
202:         - '#WL_MARKTBEARBEITUNG_PROD'
203:       ports:
204:         - '443'
205:         - '5432'
206:       protocols:
207:         - 'TCP'
```

**Einordnung:** Der Quellstand enthält bereits DeliveryPipeline -> Marktbearbeitung DEV/TEST/PROD auf TCP 443 und 5432. Live-Regeln, Runner-Zuordnung, Tag-/EPG-Auflösung, Routing und DNS sind nicht überprüft. Kein pauschaler Neuantrag oder zusätzliche Portfreigabe daraus ableiten.

### Q04: DEV: Subscription und State-Backend

Datei: `source/ui-mb-infrastructure/environment/dev/env.hcl`  
SHA-256: `1410bc2db35ffb860fe55dac8409b5f8a79430abd2e78894245e4bd44a2cb453`

```text
1: locals {
2:   backend_container_name       = "terraform-state"
3:   backend_storage_account_name = "sawd514852ab080b6472"
4:   backend_resource_group_name  = "rg-marktbearbeitung-dev-managed-resources"
5: 
6:   workload        = "MARKTBEARBEITUNG"
7:   environment     = "dev"
8:   subscription_id = "6289fbfa-0b84-4f9e-8250-684455e9bb1a"
9: 
10:   tags = {
11:     environment = local.environment
12:   }
13: }
14: 
15: inputs = {
16:   location                          = "swedencentral"
17:   vnet_name                         = "vnet-marktbearbeitung-dev-swc-01"
18:   vnet_resource_group_name          = "rg-marktbearbeitung-dev-networking"
19:   vnet_subnet_name                  = "default"
20:   # vnet_subnet_name_privateendpoints wird NICHT global gesetzt!
21:   # Stattdessen wird es app-spezifisch in den jeweiligen App-Templates definiert,
22:   # damit bestehende Apps (VBST, Mashub, etc.) im default Subnet bleiben.
23:   vnet_subnet_name_appgw            = "AppGatewaySubnet"
24:   vnet_subnet_name_functionapp      = "functionapp"
```

**Einordnung:** Konfigurationsstand, kein Live-Inventar.

### Q05: TEST: Subscription und State-Backend

Datei: `source/ui-mb-infrastructure/environment/test/env.hcl`  
SHA-256: `d12ff1890e85b7f7be8e88f8c78cf3ad180e6c51b5d16b9d932a925a369c8486`

```text
1: locals {
2:   backend_container_name       = "terraform-state"
3:   backend_storage_account_name = "sawd345ade3fb4f39a5a"
4:   backend_resource_group_name  = "rg-marktbearbeitung-test-managed-resources"
5: 
6:   workload        = "MARKTBEARBEITUNG"
7:   environment     = "test"
8:   subscription_id = "d98221c3-b24d-4770-a9a3-3716667d7353"
9: 
10:   tags = {
11:     environment = local.environment
12:   }
13: }
14: 
15: inputs = {
16:   location                     = "swedencentral"
17:   vnet_name                    = "vnet-marktbearbeitung-test-swc-01"
18:   vnet_resource_group_name     = "rg-marktbearbeitung-test-networking"
19:   vnet_subnet_name             = "default"
20:   vnet_subnet_name_appgw       = "appgw"
21:   vnet_subnet_name_functionapp = "functionapp"
```

**Einordnung:** Konfigurationsstand, kein Live-Inventar.

### Q06: PROD: Subscription und State-Backend

Datei: `source/ui-mb-infrastructure/environment/prod/env.hcl`  
SHA-256: `cf7dda5d55865863f85b22afcc9eadddf37c8b94e0ca5b1a318b40f4421ffeb1`

```text
1: locals {
2:   backend_container_name       = "terraform-state"
3:   backend_storage_account_name = "sawde3af87e25f0be60c"
4:   backend_resource_group_name  = "rg-marktbearbeitung-prod-managed-resources"
5: 
6:   workload        = "MARKTBEARBEITUNG"
7:   environment     = "prod"
8:   subscription_id = "a6c520e0-a1af-4c4c-82f0-8482ff82ecd8"
9: 
10:   tags = {
11:     environment = local.environment
12:   }
13: }
14: 
15: inputs = {
16:   location                     = "swedencentral"
17:   vnet_name                    = "vnet-marktbearbeitung-prod-swc-01"
18:   vnet_resource_group_name     = "rg-marktbearbeitung-prod-networking"
19:   vnet_subnet_name             = "default"
20:   vnet_subnet_name_appgw       = "appgw"
21:   vnet_subnet_name_functionapp = "functionapp"
```

**Einordnung:** Konfigurationsstand, kein Live-Inventar.

### Q07: State-Key bleibt abhängig vom relativen Verzeichnis

Datei: `source/ui-mb-infrastructure/environment/root.hcl`  
SHA-256: `2d8fd07de6960d330a4bfa925dd87fdaf8114123a067be325be2b0cef3e820d5`

```text
26: # Generate an AzureRM provider block
27: generate "provider" {
28:   path      = "provider.tf"
29:   if_exists = "overwrite_terragrunt"
30:   contents  = <<EOF
31: terraform {
32:   required_version = "~> 1.13"
33:   required_providers {
34:     azurerm = {
35:       source = "hashicorp/azurerm"
36:       version = "~>4.64"
37:     }
38:   }
```

```text
53: remote_state {
54:   backend = "azurerm"
55:   generate = {
56:     path      = "backend.tf"
57:     if_exists = "overwrite"
58:   }
59:   config = {
60:     subscription_id      = "${local.subscription_id}"
61:     key                  = "${path_relative_to_include()}/terraform.tfstate"
62:     resource_group_name  = local.environment_vars.locals.backend_resource_group_name
63:     storage_account_name = local.environment_vars.locals.backend_storage_account_name
64:     container_name       = local.environment_vars.locals.backend_container_name
65:   }
```

**Einordnung:** Backendwerte und Verzeichnisstruktur beim CI-Wechsel beibehalten. Keine neue Ressourcenanlage und kein Import bereits im State verwalteter Ressourcen allein aufgrund des Repositorywechsels.

### Q08: Bestehende Anwendungsauswahl in der Infrastruktur

Datei: `source/ui-mb-infrastructure/ci/templates/steps.setup.yml`  
SHA-256: `7e257946c3c6427216e2646ff7cc5819025b858ccaa1f5f3c9c169896fa85cdb`

```text
27:         case $APP in
28:           'All' ) appDir=$(echo ".")
29:                   echo "Request App 'All'"; ;;
30: 
31:           'IW Beratungsunterstützung' ) appDir=$(echo "applications/beratungsunterstuetzung")
32:                                         echo "Process App 'IW Beratungsunterstützung' in dir $appDir"; ;;
33:           'IW Marktbearbeitung' ) appDir=$(echo "applications/marktbearbeitung")
34:                                   echo "Process App 'IW Marktbearbeitung' in dir $appDir"; ;;
35:           'MB Portal' ) appDir=$(echo "applications/mashub")
36:                         echo "Process App 'MB Portal' in dir $appDir"; ;;
37:           'Plattform' ) appDir=$(echo "applications/plattform")
38:                         echo "Process App 'Plattform' in dir $appDir"; ;;
39:           'Verbundschnittstelle' )  appDir=$(echo "applications/verbundintegration")
40:                                     echo "Process App 'Verbundschnittstelle' in dir $appDir"; ;;
41:           'IM Action Hub' )  appDir=$(echo "applications/im-action-hub")
42:                              echo "Process App 'IM Action Hub' in dir $appDir"; ;;
43:           'UBA-Anbindung' )  appDir=$(echo "applications/uba-anbindung")
44:                              echo "Process App 'UBA-Anbindung' in dir $appDir"; ;;
45: 
46:           * ) echo "##vso[task.logissue type=error;]Unexpected value for parameter \"application\"";
```

```text
55:   - task: Bash@3
56:     displayName: "Directory Setup"
57:     inputs:
58:       targetType: "inline"
59:       script: |
60:         terragruntBaseDir=$(echo "environment")
61:         terragruntWorkingDir=$(echo "${{ parameters.environment }}/$(APP_SELECTION)" | tr "[:upper:]" "[:lower:]")
62:         # terragruntAppStackDir=$(echo "$(APP_SELECTION)" | tr "[:upper:]" "[:lower:]")
63:         terragruntConfigDir=$(echo "$terragruntBaseDir/$terragruntWorkingDir")
64:         if [[ -d "$terragruntConfigDir" ]]
65:           then
66:             echo "Initialize Terragrunt in directory (PIPE_BASE_DIR): $terragruntBaseDir"
67:             echo "Use Terragrunt Config in directory (PIPE_WORKING_DIR): $terragruntWorkingDir"
68:             # echo "Process App-Stack in directory (PIPE_STACK_DIR): $terragruntAppStackDir"
69:             echo "##vso[task.setvariable variable=PIPE_BASE_DIR;]${terragruntBaseDir}"
70:             echo "##vso[task.setvariable variable=PIPE_WORKING_DIR;]${terragruntWorkingDir}"
71:             # echo "##vso[task.setvariable variable=PIPE_STACK_DIR;]${terragruntAppStackDir}"
```

**Einordnung:** MB Portal entspricht applications/mashub. Das Gesamt-Repository enthält weitere Anwendungen. Der erste Pilot soll nicht automatisch den All-Scope verwenden.

### Q09: Anwendungstemplates verwenden Blueprint 16.1.0 und deployen Functions

Datei: `pipelines/pipeline-templates-release/templates/java-azure-function.yml`  
SHA-256: `4fa1e921f28f898982fa050e57935093c820174d0ad198e2eb9faa28bf15735e`

```text
1: include:
2:   - project: pws-blueprint/blueprint
3:     ref: &blueprint-version 16.1.0
4:     file: workflow/workflow.yml
5:   - project: pws-blueprint/blueprint
6:     ref: *blueprint-version
7:     file: context/azure-context.yml
8:   - project: pws-blueprint/blueprint
9:     ref: *blueprint-version
10:     file: recipes/versioning-recipe.yml
11:   - project: pws-blueprint/blueprint
12:     ref: *blueprint-version
13:     file: recipes/maven-recipe.yml
14:   - project: pws-blueprint/blueprint
15:     ref: *blueprint-version
16:     file: recipes/sast-recipe.yml
17:   - project: pws-blueprint/blueprint
18:     ref: *blueprint-version
19:     file: recipes/badge-recipe.yml
20:   - project: pws-blueprint/blueprint
21:     ref: *blueprint-version
22:     file: recipes/documentation-recipe.yml
23:   - template: Jobs/Dependency-Scanning.gitlab-ci.yml
24:   - template: Jobs/SAST.gitlab-ci.yml
25:   - local: '/templates/includes/deployment.yml'
```

```text
27: variables:
28:   AZURE_CLI_VERSION: 2.80.0
29: 
30:   # Workflow Recipe
31:   DEVELOPMENT_DEPLOYMENT_ENABLED: "yes"
32:   INTEGRATION_DEPLOYMENT_ENABLED: "yes"
33:   TEST_DEPLOYMENT_ENABLED: "no"
34:   # Disable enforce project settings so we can have per-branch squash commit settings
35:   GITLAB_PROJECTS_DEFAULTS_ENABLED: "no"
36: 
37:   REGION: "swedencentral"
38:   JAVA_VERSION: "21"
39: 
40:   # Maven image
41:   MAVEN_CONTAINER_IMAGE: image-prod.nexus.apps.union-investment.de/pws-blueprint/helpers/maven-base-image/eclipse-temurin-21:2.6.0
42:   FUNCTION_APP_ZIP_IDENTIFIER: azure-functions
43: 
44:   CONFLUENCE_ASCIIDOC_ROOT_FOLDER: documentation
45: 
```

```text
107: .deployment:
108:   image: image-external.nexus.apps.union-investment.de/azure-cli:$AZURE_CLI_VERSION
109:   cache:
110:     - key: ${CI_COMMIT_REF_SLUG}-${CI_PIPELINE_IID}-build-artifacts-maven
111:       paths:
112:         - $MAVEN_BUILD_ARTIFACTS_PATH
113:       policy: pull
114:   script:
115:     - |
116:       shopt -s globstar
117:       fileToDeploy=($MAVEN_BUILD_ARTIFACTS_PATH/$MAVEN_ARTIFACT_NAME-*-$FUNCTION_APP_ZIP_IDENTIFIER.zip)
118:       shopt -u globstar || true
119:       if [[ ${#fileToDeploy[@]} -eq 1 ]]; then
120:         echo "will deploy ${fileToDeploy[0]}"
121:       else
122:         echo "Fehler: Es wurde keine oder mehr als eine Datei gefunden!"
123:         exit 1
124:       fi
125:       echo "Verwende Subscription-ID: $SUBSCRIPTION_ID"
126:       az login --service-principal --username $ARM_CLIENT_ID --password $ARM_CLIENT_SECRET --tenant $ARM_TENANT_ID
127:       resource_id=$(az functionapp list --subscription "$SUBSCRIPTION_ID" --query "[?tags.discovery_key=='$DISCOVERY_KEY'].id | [0]" -o tsv)
128:       if [[ -z "$resource_id" ]]; then
129:         echo "Fehler: Keine Function App mit discovery_key=$DISCOVERY_KEY gefunden!"
130:         exit 1
131:       fi
132:       echo "Function App resource id: $resource_id"
133:       APP_NAME=${resource_id##*/}
134:       RESOURCE_GROUP=$(az functionapp list --subscription "$SUBSCRIPTION_ID" --query "[?tags.discovery_key=='$DISCOVERY_KEY'].resourceGroup | [0]" -o tsv)
135:       echo "Function App Name: $APP_NAME"
136:       echo "Resource Group: $RESOURCE_GROUP"
137:       az functionapp config appsettings set --name $APP_NAME --resource-group $RESOURCE_GROUP --subscription $SUBSCRIPTION_ID  --settings @$APPSETTINGS_FILE
138:       az functionapp deployment source config-zip --name "$APP_NAME" --resource-group "$RESOURCE_GROUP" --subscription "$SUBSCRIPTION_ID" --src "${fileToDeploy[0]}"
139:       az functionapp update --name "$APP_NAME" --resource-group "$RESOURCE_GROUP" --subscription "$SUBSCRIPTION_ID" --set tags.version=$VERSION
```

**Einordnung:** Das zuvor fehlende Anwendungstemplate ist geliefert. pws-blueprint/blueprint 16.1.0 liegt nicht bei. Diese Jobs führen Azure-Login, App-Settings-Änderung und ZIP-Deployment aus; der Zielprozess Build-Gruppe nur bis Nexus ist damit nicht allein erfüllt.

### Q10: Deploymentregeln im neuen Anwendungstemplate

Datei: `pipelines/pipeline-templates-release/templates/includes/deployment.yml`  
SHA-256: `b04c159d6586bf3ae0e1fa8ec3c2d633020f2e41a7be53adeabd8e8dfcd53334`

```text
1: variables:
2:   DEVELOPMENT_DEPLOYMENT_ENABLED: "yes"
3:   INTEGRATION_DEPLOYMENT_ENABLED: "yes"
4:   TEST_DEPLOYMENT_ENABLED: "no"
5: 
6: deploy:dev:
7:   extends: .deployment
8:   stage: deployment
9:   rules:
10:     - if: '$ENVIRONMENT == "integration"'
11:       variables:
12:         ENVIRONMENT: "development"
13:     - if: $ENVIRONMENT == "development" || $ENVIRONMENT == "integration"
14:       when: manual
15:     - when: never
16:   environment: $ENVIRONMENT
17: 
18: 
19: deploy:stage:
20:   extends: .deployment
21:   stage: deployment
22:   rules:
23:     - if: $ENVIRONMENT && $ENVIRONMENT == "staging"
24:       when: manual
25:     - when: never
26:   environment: $ENVIRONMENT
27: 
28: deploy:prod:
29:   extends: .deployment
30:   stage: deployment
31:   rules:
32:     - if: $ENVIRONMENT && $ENVIRONMENT == "production"
33:     - when: never
34:   environment: $ENVIRONMENT
```

**Einordnung:** Der lokale PROD-Job enthält keine when: manual-Zeile. Ein ServiceNow-Aufruf ist in dieser Datei nicht enthalten. Aussagen über weitere Gates setzen den Blueprint und die tatsächlichen Projekteinstellungen voraus.

### Q11: Frontend: nachträgliche Konfiguration und Deployment

Datei: `pipelines/pipeline-templates-release/templates/npm-frontend.yml`  
SHA-256: `00cdd46297e1ae5a04e35543c6e3e00ca731bf9c0ea48cd70d5613c90528bf6e`

```text
119: prepare-config:
120:   image: alpine:latest
121:   stage: pre-deployment
122:   rules:
123:     - if: $ENVIRONMENT && $ENVIRONMENT != "none"
124:   environment: $ENVIRONMENT
125:   script:
126:     - apk add --no-cache gettext
127:     - envsubst < $CONFIG_PATH > $CONFIG_PATH.tmp
128:     - mv $CONFIG_PATH.tmp $CONFIG_PATH
129:     - cp staticwebapp.config.json $NPM_BUILD_ARTIFACTS_PATH/${NPM_PROJECT_NAME}/browser/
130:   variables:
131:     CONFIG_PATH: $NPM_BUILD_ARTIFACTS_PATH/${NPM_PROJECT_NAME}/browser/assets/config.js
132:   cache:
133:     key: ${CI_COMMIT_REF_SLUG}-${CI_PIPELINE_IID}-build-artifacts-npm
134:     paths:
135:       - $NPM_BUILD_ARTIFACTS_PATH
136:     policy: pull-push
137: 
138: .deployment:
139:   image: mcr.microsoft.com/appsvc/staticappsclient:stable
140:   cache:
141:     - key: ${CI_COMMIT_REF_SLUG}-${CI_PIPELINE_IID}-build-artifacts-npm
142:       paths:
143:         - $NPM_BUILD_ARTIFACTS_PATH
144:       policy: pull
145:   script:
146:     - /bin/staticsites/StaticSitesClient upload --verbose --app $NPM_BUILD_ARTIFACTS_PATH/${NPM_PROJECT_NAME}/browser --deploymentProvider GitLab --skipAppBuild true --apiToken $SWA_DEPLOYMENT_TOKEN
```

**Einordnung:** Umgebungskonfiguration wird mit envsubst in das Build-Verzeichnis geschrieben. Für den gewünschten Digest-/Releaseprozess muss zwischen Anwendungspaket und Umgebungskonfiguration eindeutig unterschieden werden; keine ungeprüfte Freigabe unveränderlicher Deployments daraus ableiten.

### Q12: Infrastrukturtemplate: Werkzeugimage und Modulaufruf

Datei: `tgtf/tgtf-main/tg-plan.yml`  
SHA-256: `b242253be68e9b00443726a18d0df5393e170fac7054feaa7e8ac703f32572a9`

```text
20: variables:
21:   GITLAB_RUNNER_TAG: "azure"
22: 
23: terragrunt_plan:
24:   # Ueber Resource Group sicherstellen das nur ein Job gleichzeitig läuft
25:   resource_group: $[[ inputs.environment ]]
26:   stage: plan-$[[ inputs.environment ]]
27:   image:
28:     name: image-dev.nexus.apps.union-investment.de/$CI_PROJECT_ROOT_NAMESPACE/oci:1.0.0
29:     entrypoint: [""]
30:   tags:
31:     # Auswahl des entsprechenden Gitlab Runners
32:     - $GITLAB_RUNNER_TAG
33:   environment:
34:     name: $[[ inputs.environment ]]
35:   script: |
```

```text
69:     BASE_DIR="environment"
70: 
71:     if [ -d "$BASE_DIR/development" ] && [ -d "$BASE_DIR/staging" ] && [ -d "$BASE_DIR/production" ]; then
72:       echo "Using full environment folder names (development, staging, production)"
73:       case "$ENVIRONMENT" in
74:         development) ENV_SHORT="development" ;;
75:         staging)     ENV_SHORT="staging" ;;
76:         production)  ENV_SHORT="production" ;;
77:         *)
78:           echo "Unknown environment!"
79:           exit 1
80:           ;;
81:       esac
82: 
83:     elif [ -d "$BASE_DIR/dev" ] && [ -d "$BASE_DIR/test" ] && [ -d "$BASE_DIR/prod" ]; then
84:       echo "Using short environment folder names (dev, test, prod)"
85:       case "$ENVIRONMENT" in
86:         development) ENV_SHORT="dev" ;;
87:         staging)     ENV_SHORT="test" ;;
88:         production)  ENV_SHORT="prod" ;;
89:         *)
90:           echo "Unknown environment!"
91:           exit 1
92:           ;;
93:       esac
94: 
95:     else
96:       echo "Neither full nor short environment folders found in $BASE_DIR"
97:       exit 1
98:     fi
99: 
100:     echo "Using environment folder: $BASE_DIR/$ENV_SHORT"
101: 
102:     cd "$BASE_DIR/$ENV_SHORT" || {
103:       printf "unknown environment folder %s\n" "$ENV_SHORT"
104:       exit 1
105:     }
106: 
107:     export TG_PROVIDER_CACHE=1
108: 
109:     echo "Namespace is $NS. Running single terragrunt plan."
110:     terragrunt plan
```

**Einordnung:** Der Root-Namespace bestimmt den OCI-Imagepfad. Mit marktbearbeitungsplattform-infra wird ein entsprechender Nexus-Imagepfad erwartet. Für den Namespace wird im Standardpfad ein einzelner terragrunt plan im Umgebungsverzeichnis ausgeführt, nicht der bisherige Modulverbund.

### Q13: Infrastrukturtemplate: Apply

Datei: `tgtf/tgtf-main/tg-apply.yml`  
SHA-256: `1e39439b76fb561621a84fec2041a8e5125a0a17a7dcef2e2569914ffe061f98`

```text
13: terragrunt_apply:
14:   stage: apply-$[[ inputs.environment ]]
15:   image:
16:     name: image-dev.nexus.apps.union-investment.de/$CI_PROJECT_ROOT_NAMESPACE/oci:1.0.0
17:     entrypoint: [""]
18:   environment:
19:     name: $[[ inputs.environment ]]
20:   tags:
21:     - $GITLAB_RUNNER_TAG
22:   script: |
23:     ENVIRONMENT="$[[ inputs.environment ]]"
24:     NS="$CI_PROJECT_ROOT_NAMESPACE"
25:     BASE_DIR="environment"
```

```text
56:     if all_dirs_exist "$BASE_DIR" development staging production; then
57:       ENV_SHORT="$ENVIRONMENT"
58:     elif all_dirs_exist "$BASE_DIR" dev test prod; then
59:       case "$ENVIRONMENT" in
60:         development) ENV_SHORT="dev" ;;
61:         staging)     ENV_SHORT="test" ;;
62:         production)  ENV_SHORT="prod" ;;
63:         *) echo "Unknown environment!"; exit 1 ;;
64:       esac
65:     else
66:       echo "Neither full nor short environment folders found in $BASE_DIR"
67:       exit 1
68:     fi
69: 
70:     cd "$BASE_DIR/$ENV_SHORT" || { printf "unknown environment folder %s\n" "$ENV_SHORT"; exit 1; }
71:     export TG_PROVIDER_CACHE=1
72:     terragrunt apply --auto-approve
73:   rules:
74:     - if: '$CI_PIPELINE_SOURCE == "web" && $DEPLOY_ENVIRONMENT == "staging" && $CI_COMMIT_BRANCH =~ /^(main|master)$/'
75:       when: manual
76:     - if: '$CI_PIPELINE_SOURCE == "web" && $DEPLOY_ENVIRONMENT == "staging" && $CI_COMMIT_TAG'
77:       when: manual
78:     - if: '$CI_PIPELINE_SOURCE == "web" && $DEPLOY_ENVIRONMENT == "production" && $CI_COMMIT_BRANCH =~ /^(main|master)$/'
79:       when: manual
80:     - if: '$CI_PIPELINE_SOURCE == "web" && $DEPLOY_ENVIRONMENT == "production" && $CI_COMMIT_TAG'
81:       when: manual
82:     - if: '$DEPLOY_ENVIRONMENT == "development"'
83:       when: manual
84:     - when: never
85:   allow_failure: false
86:   needs:
87:     - terragrunt_plan
```

**Einordnung:** Das Template ruft apply --auto-approve ohne übernommene gespeicherte Plandatei auf. needs sichert hier die Jobabhängigkeit, ist aber keine Übergabe derselben Plandatei. Die Zielumgebung und der State sind vor jedem ersten Lauf abzugleichen.

### Q14: README-Beispiele stimmen nicht vollständig mit Archivpfaden überein

Datei: `pipelines/pipeline-templates-release/README.md`  
SHA-256: `a67f7467f281f9f86b89d67cb805a9503814096451681f4a35ac778caed393bd`

```text
16: ```yaml filename=.gitlab-ci.yml
17: include:
18:   - project: marktbearbeitungsplattform/cicd/templates/java-function-template
19:     ref: 'v1.0.0'
20:     file: java-azure-function.yml
21: 
22: variables:
23:   DISCOVERY_KEY: func-bff-api
24:   MAVEN_ARTIFACT_GROUP: de.unioninvestment.marktbearbeitungsplattform.investmentwelt
25:   MAVEN_ARTIFACT_NAME: iw-bff-api
```

```text
111: The pipeline can be included using one of the version tags.
112: e.G. like this
113: 
114: ```yaml filename=.gitlab-ci.yml
115: include:
116:   - project: marktbearbeitungsplattform/cicd/templates/pipeline-templates
117:     ref: 'v1.0.0'
118:     file: npm-frontend.yml
119: 
120: variables:
121:   ENABLE_PLAYWRIGHT: yes
122: ```
123: 
124: For the Deployment to work you must specify the "SWA_DEPLOYMENT_TOKEN" variable in your CI/CD variables
125: 
```

**Einordnung:** Das README nennt beim Java-Beispiel ein anderes Templateprojekt. Der npm-Beispielpfad ist ohne templates/-Präfix angegeben. Maßgeblich sind die tatsächlichen Dateien und der bestätigte Git-Ref, nicht der ZIP-Dateiname release.

