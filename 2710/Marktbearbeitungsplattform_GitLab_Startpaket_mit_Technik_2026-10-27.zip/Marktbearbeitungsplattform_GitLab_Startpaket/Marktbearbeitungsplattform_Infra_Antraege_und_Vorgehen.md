# GitLab-Migration: Infrastruktur der Marktbearbeitungsplattform

**Stand: 27.10.2026.** Arbeitsunterlage für Daniel Iftime. Die Texte sind vorbereitet, nicht in Jira, ServiceNow oder UAM eingereicht. Keine Pipeline und kein Deployment wurden ausgeführt.

**Festgelegter gewünschter Gruppenname:** `marktbearbeitungsplattform-infra`.

## 1. So wird die Struktur aufgebaut

Nicht beide Bereiche in dieselbe Top-Level-Gruppe legen. Die Anwendungen bleiben im vorhandenen Bereich; die Infrastruktur erhält daneben eine eigenständige Gruppe mit eigenen Berechtigungen. Dies entspricht eurer Migrationsanleitung und dem gelieferten Zukunftsdesign. [M01, M02]

```text
GitLab
├── marktbearbeitungsplattform                     bestehende Top-Level-Gruppe
│   ├── cicd/templates/pipeline-templates           vorhandener Templatebereich
│   └── team-mandalorian/mb-portal                  vorhandene Anwendungsgruppe
│       ├── mbportal-dashboard                     bestehendes Projekt
│       ├── mbportal-frontend                      Zielvorschlag, noch abzugleichen
│       └── mbportal-backend                       Zielvorschlag, noch abzugleichen
│
└── marktbearbeitungsplattform-infra                neue Top-Level-Gruppe
    └── ui-mb-infrastructure                       Zielprojekt für Infrastrukturcode
```

Die Platzierung von Frontend und Backend ist ein Vorschlag zur Abstimmung mit dem Entwicklerteam. Die sichtbaren `mashub-frontend`-/`mashub-backend`-Projekte werden nicht allein wegen des Namens als identische MBPortal-Zielrepos behandelt und nicht überschrieben. Das Dashboard bleibt eigenständig.

**Begriffe:** Die Gruppe ist der organisatorische Bereich mit Berechtigungen. Das Projekt enthält das eigentliche Git-Repository. Der Azure-Workload bleibt `MARKTBEARBEITUNG`: Ein neuer GitLab-Name erstellt weder einen neuen Azure-Workload noch neue Subscriptions.

Quelle der Infrastruktur laut Git-Remote im gelieferten Archiv:

```text
dev.azure.com/Union-Investment/Marktbearbeitung/_git/ui-mb-infrastructure
```

Geplantes Ziel:

```text
gitlab.apps.union-investment.de/marktbearbeitungsplattform-infra/ui-mb-infrastructure
```

DEV, TEST und PROD bleiben zunächst im vorhandenen Repository unter `environment/dev`, `environment/test` und `environment/prod`. Dafür sind nicht automatisch drei GitLab-Gruppen oder drei neue State-Backends nötig. [Q04–Q08]

## 2. Welche Tickets und Bestellungen wir brauchen

| Vorgang | Zweck | Vorgehen |
|---|---|---|
| **Neue Jira-Story für Infrastruktur** | Deine Arbeit an Onboarding, Repository, Pipeline, State, Freigaben und Umschaltung koordinieren. | [Kopiervorlage in Jira-Wiki-Syntax](Jira_Marktbearbeitungsplattform_Infra_GitLab.md) anlegen und mit DBI-6605 verknüpfen. |
| **DBI-6605** | Bereits vorhandene Migration von MBPortal-Frontend/Backend. | Kein zweites Anwendungsticket erfinden. Infrastrukturabhängigkeiten dort verlinken. APIM ist ausdrücklich separat. |
| **GitLab-Namespace-Request** | Die eigenständige Infra-Gruppe anlegen lassen. | Formular aus Abschnitt 5. |
| **UAM / technisches Konto / Nexus** | Benötigte Rollen und das Werkzeugimage bereitstellen. | Nur fehlende Bestandteile bestellen; bestehende Konten/Ablagen prüfen. |
| **Azure-GitLab-Integration** | Die neue Infra-Gruppe mit dem bestehenden Azure-Workload verbinden. | Nach Anlage mit der neuen GitLab Group ID beantragen. |
| **Firewall-Change** | Fehlende Netzwerkwege ermöglichen. | Nur nachgewiesene Lücken ändern. Es existiert bereits eine passende Regel im Quellstand. |
| **Spätere TEST-/PROD-Freigaben** | Genehmigung der tatsächlichen Auslieferung nach Zielprozess. | Ein Onboarding- oder Firewall-Change ist keine pauschale Freigabe aller späteren Deployments. |

Die Jira-Story steuert die Arbeit. Die ServiceNow-Requests liefern Plattformleistungen. Ein Change genehmigt eine konkrete technische Änderung. Diese Vorgänge ersetzen sich nicht gegenseitig.

## 3. Was bereits vorhanden ist und nicht doppelt bestellt werden sollte

### Bestehende Azure-Anbindung der Apps-Gruppe

In `Global-Settings/Workloads/workloads.d/marktbearbeitung.yml`, Zeilen 22–30, steht bereits eine GitLab-Azure-Integration für `MARKTBEARBEITUNG` mit `gitLabGroup: 5614` und dem Kommentar `Marktbearbeitungsplattform`. [Q01]

**Folgerung:** Die bestehende Anbindung live bestätigen und erhalten. Für `marktbearbeitungsplattform-infra` wird eine zusätzliche, getrennt berechtigte Anbindung mit deren neuer Gruppen-ID benötigt. Nicht einfach 5614 in der bestehenden Konfiguration ersetzen. Die neue Group ID ist auch keine Project ID, Client ID oder Object ID.

### Bestehende Runner-Firewallregel

In `Firewall-Rules/rules/workloads/marktbearbeitung.yml`, Zeilen 195–207, ist bereits konfiguriert: [Q03]

| Quelle im Infrastrukturcode | Ziele im Infrastrukturcode | Konfigurierte Ports |
|---|---|---|
| `#WL_DELIVERYPIPELINE_PROD` | `#WL_MARKTBEARBEITUNG_DEV`, `#WL_MARKTBEARBEITUNG_TEST`, `#WL_MARKTBEARBEITUNG_PROD` | TCP 443 und 5432 |

Referenzierte Changes: `UI-CHG-0041528`, `UI-CHG-0041934`, `UI-CHG-0054560`.

Das belegt den Quellstand, nicht die aktuelle Ausführung der Regel. CIS/IIM-IBA muss prüfen, ob der konkret verwendete Runner in dieser Quellgruppe liegt, die nötigen privaten Ziele umfasst sind und Routing/DNS funktionieren. Sind die erforderlichen Verbindungen bereits wirksam, ist für diesen Zweck kein weiterer Freischaltungs-Change nötig.

**Die Aliase `#WL_...` sind nicht ungeprüft als ServiceNow-EPG-Namen einzutragen.** Ihre aktuelle Auflösung muss bestätigt werden. Der vorhandene Port 5432 ist kein Auftrag, neue Datenbankzugriffe freizuschalten.

### Vorhandene Artefaktablagen und jetzt gelieferte Templates

Global-Settings enthält bereits eine npm-Ablage `marktbearbeitung`. Das neue Anwendungstemplate referenziert außerdem bestehende Marktbearbeitungsplattform-Werkzeugimages. Diese Ablagen nicht löschen oder durch einen neuen Infra-Namespace ersetzen. [Q01, Q09–Q11]

`pipeline-templates-release.zip` liegt jetzt vor. Das früher fehlende Anwendungstemplate ist damit geliefert. Es bindet noch `pws-blueprint/blueprint` bei Ref `16.1.0` ein; dessen Inhalt und aktuelle geschützte Projekteinstellungen liegen nicht vor. Das ist ein späterer Pipelineprüfpunkt, kein Grund, den Namespace-Antrag aufzuschieben.

## 4. Deine konkrete Reihenfolge

| Schritt | Aktion | Ergebnis |
|---|---|---|
| **1** | Infrastruktur-Jira-Story vorbereiten/anlegen und DVOS kurz zur vorhandenen Apps-Gruppe plus neuer Infra-Gruppe abstimmen. | Ein gemeinsamer Auftrag und keine widersprüchliche Gruppenanlage. |
| **2** | Namespace-Antrag stellen. Application Service, Verantwortlichen und Vertreter vor dem Absenden bestätigen. | Private Top-Level-Gruppe `marktbearbeitungsplattform-infra` samt neuer Group ID. |
| **3** | UAM-Zugriffe, vorhandenes technisches CICD-Konto und Nexus-/OCI-Image prüfen; nur Lücken bestellen. | Leserechte auf Templates und ein nutzbares Infra-Werkzeugimage. |
| **4** | Azure-Integration für die neue Gruppe beantragen; vorhandene Runner-Netzwerkwege prüfen lassen. | Azure-Zugriff und nachgewiesene Erreichbarkeit. Nur bei Lücken separater Firewall-Change. |
| **5** | Zielprojekt `ui-mb-infrastructure` kontrolliert mit Git-Historie befüllen; Pipeline angepasst und zunächst ohne Apply aktivieren. | Richtiger Quellstand und begrenzter DEV-Plan gegen den bisherigen State. |
| **6** | DEV abnehmen, danach TEST/PROD mit den vorgesehenen Freigaben umstellen. | Pro Scope/Umgebung genau ein schreibender Auslieferungsweg und dokumentierter Rückfallweg. |

**Jetzt direkt machbar:** Jira-Beschreibung und Namespace-Antrag vorbereiten. Du musst dafür noch keine vollständige GitLab-Pipeline schreiben und keine Azure-Ressourcen verändern.

## 5. Formular: GitLab – Anlage eines Namespace

**Quelle:** mitgeliefertes gleichnamiges PDF, Seite 2; die Pflichtfeldliste steht auf Seite 3. [F01]

[Formular öffnen](https://servicenow.union-investment.de/esc?id=sc_cat_item&table=sc_cat_item&sys_id=4bc5e56f3bbba610596e2e2a85e45a17)

| Formularfeld | Eintrag für uns |
|---|---|
| Anrufer / Betroffene Person | Iftime, Daniel (UIS) |
| **Bereichsname** | **`marktbearbeitungsplattform-infra`** |
| **Application Service** | Vorschlag aus dem Repo: `AS Marktbearbeitung Produktion`. Vor Absenden die Zuordnung dieses umgebungsübergreifenden Namespace im CMDB-Auswahlfeld bestätigen. |
| **Verantwortlicher** | Vorschlag: Iftime, Daniel (UIS), entsprechend deiner genannten Gesamtverantwortung. Formelle Namespace-Verantwortung bestätigen. |
| **Vertreter** | **Noch zu benennen.** Julian oder Christoph nicht ohne bestätigte Stellvertretung eintragen. |
| Beschreibung | Kopiertext unten. |
| Sichtbarkeit | Privat. |
| **Begründung** | Kopiertext unten. |

Die Checkbox „Kein Application Service vorhanden“ nicht verwenden, nur weil die Auswahl noch unklar ist. Für den Workload sind Servicezuordnungen im Code vorhanden. [Q02]

**Beschreibung:**

```text
Bitte eine eigenständige private Top-Level-Gruppe mit dem Pfad marktbearbeitungsplattform-infra anlegen. Sie darf keine Untergruppe von marktbearbeitungsplattform sein.

Die Gruppe dient der Verwaltung und kontrollierten Auslieferung des bestehenden Azure-Infrastrukturcodes für den Workload MARKTBEARBEITUNG in DEV, TEST und PROD. Vorgesehenes erstes Projekt ist ui-mb-infrastructure.

Die vorhandene Anwendungsgruppe marktbearbeitungsplattform und ihre Projekte bleiben bestehen. Bitte die neue GitLab Group ID und das zugehörige UAM-Berechtigungsmodul nach Bereitstellung mitteilen.
```

**Begründung:**

```text
Migration des Infrastruktur-Repositories ui-mb-infrastructure und seiner Terraform-/Terragrunt-Pipelines von Azure DevOps nach GitLab. Gemäß interner GitLab-Migrationsvorgabe und Release-Zielbild werden Anwendungs-Builds und Infrastruktur-/Deploymentrechte in getrennten Top-Level-Gruppen geführt.

Die bestehende Apps-Gruppe wird weiterverwendet. Für TEST und PROD sind Vier-Augen-Prüfung, geschützte Auslieferung und der vorgesehene ServiceNow-Change-Abgleich umzusetzen. Die Infrastrukturmigration wird in einer eigenen Jira-Story mit Bezug zu DBI-6605 verfolgt.
```

Ein Gruppenrequest garantiert nicht automatisch die Anlage des Projekts. Nach Bereitstellung `ui-mb-infrastructure` mit dem zuständigen Maintainer anlegen beziehungsweise anlegen lassen. Das Ziel vor der Übertragung auf vorhandene Inhalte und aktive Pipelines prüfen.

## 6. UAM, technischer Account und Nexus

### UAM gemäß der mitgelieferten Anleitung

Die Anleitung nennt für DevOps die UAM-Berechtigung „Administrator“ für den eigenen Namespace, für Entwickler „Maintainer“ im Apps-Bereich und „Developer“ im Infrastruktur-Bereich. Zusätzlich werden GitLab-Lizenz und Leserecht auf `web-portale-templates` genannt. Das beschreibt den internen Bestellkatalog, keine Anforderung globaler Administratorrechte auf der gesamten GitLab-Instanz. [M01, S. 2]

Den nach Namespace-Anlage tatsächlich angebotenen UAM-Modulnamen verwenden. Benannte Prüfer und die erforderlichen Merge-/Deploymentrechte gesondert mit dem Vier-Augen-Modell abstimmen; Entwickler-Mitgliedschaft allein bedeutet keine PROD-Freigabe.

Die Anleitung nennt außerdem ein technisches Konto nach `<Workload>-CICD`, **sofern nicht vorhanden**. Für den bestehenden Workload wäre `MARKTBEARBEITUNG-CICD` ein Namensvorschlag, kein bereits nachgewiesener Account. Vor Neuanlage prüfen, ob das Konto beziehungsweise ein zugelassenes vorhandenes Konto genutzt werden kann.

**Nicht verwechseln:** Das technische Konto insbesondere für Artefaktzugriffe, die durch den Azure-Integrationsrequest bereitgestellte Entra-Identität und die Laufzeit-Managed-Identities der Anwendungen sind unterschiedliche Rollen. Keine Credentials bestehender Anwendungen manuell in die neue Gruppe kopieren.

### Nexus-Formular: nur bestellen, falls die passende OCI-Ablage fehlt

**Quelle:** mitgeliefertes Nexus-Formular, Seite 2. [F02]

[Formular öffnen](https://servicenow.union-investment.de/esc?id=sc_cat_item&sys_id=8a42bfd7ebd6ba94e2ddf3d7cad0cd6c&table=sc_cat_item&searchTerm=nexus)

| Formularfeld | Eintrag / Entscheidung |
|---|---|
| Anrufer / Betroffene Person | Iftime, Daniel (UIS) |
| Bereichsname | **Vorschlag `marktbearbeitungsplattform-infra`**, passend zum Root-Namespace, aus dem das gelieferte tgtf-Template den Imagepfad ableitet. Bestehende geeignete Ablage zuerst mit DVOS/Nexus prüfen. |
| Application Service | Vorschlag `AS Marktbearbeitung Produktion`, Zuordnung im CMDB-Auswahlfeld bestätigen. |
| Verantwortlicher / Vertreter | Wie beim bestätigten Namespace-Antrag; Vertreter noch offen. |
| Beschreibung / Begründung | Kopiertexte unten. |
| Artifact type(s) | **docker** für das Infrastruktur-Werkzeugimage. Maven/npm/raw nicht pauschal für diesen Infra-Antrag mitbestellen. |
| ACR-Sync (Azure Workload Name) | Zunächst leer lassen, solange kein konkreter Sync-Bedarf bestätigt ist. Das Feld ist im vorliegenden Formular optional. |

**Beschreibung:**

```text
Docker-/OCI-Namespace für das freigegebene Terraform-/Terragrunt-Werkzeugimage der GitLab-Gruppe marktbearbeitungsplattform-infra.

Bitte prüfen, ob bereits eine geeignete Ablage mit den erforderlichen Berechtigungen existiert. Das gelieferte tgtf-Template leitet den Imagepfad vom GitLab-Root-Namespace ab. Für die neue Gruppe ist daher ein passender Imagepfad bereitzustellen oder eine freigegebene Templateanpassung abzustimmen.

Bestehende Marktbearbeitungsplattform-/Marktbearbeitung-Artefaktablagen bleiben unverändert.
```

**Begründung:**

```text
Die Infrastrukturpipeline für ui-mb-infrastructure benötigt ein zugelassenes, versioniertes und vom GitLab-Runner abrufbares Werkzeugimage. Dieses wird für die Migration von Azure DevOps nach GitLab benötigt. Die Bestellung betrifft das Infrastruktur-Werkzeugimage, nicht eine Umstellung der MBPortal-Anwendungen auf Containerbetrieb.
```

Der derzeit vom Template abgeleitete Imagepfad wäre:

```text
image-dev.nexus.apps.union-investment.de/marktbearbeitungsplattform-infra/oci:1.0.0
```

Das ist ein **erwarteter Pfad aus dem Template**, kein Nachweis, dass das Image existiert oder bereits freigegeben ist. Der konkrete Release-/Digeststand und Terraform-/Terragrunt-Versionen müssen vor Nutzung festgelegt werden. [Q12]

Die dokumentierten Variablen `OCI_USERNAME_<PRODUKT>` und `OCI_PASSWORD_<PRODUKT>` gehören ausschließlich in die vorgesehenen geschützten CI-Einstellungen. Keine Werte in Jira, Antragsbeschreibung, ZIP oder Chat schreiben. Die konkreten Variablennamen müssen zu den von DVOS eingerichteten Imagejobs passen. [M01, S. 2]

## 7. Formular: Azure GitLab Integration – Anlegen

**Quelle:** mitgeliefertes Formular, Seiten 1–2. Es sagt ausdrücklich, dass für die GitLab-Gruppe eine Entra-ID-Identität bestellt und deren Credentials automatisch als GitLab-CI-Variablen hinterlegt werden. Es nennt nicht deren tatsächliche Rollen, Variablenscopes oder Secret-Rotation. [F03]

[Formular öffnen](https://servicenow.union-investment.de/esc?id=sc_cat_item&table=sc_cat_item&sys_id=8c3e5c332bf14714fe90fe44ce91bf96)

**Erst nach Bereitstellung der neuen Gruppe absenden.**

| Formularfeld | Eintrag |
|---|---|
| Anrufer / Betroffene Person | Iftime, Daniel (UIS) |
| **Wähle eine Azure Subscription aus dem Workload** | Die DEV-Subscription mit ID `6289fbfa-0b84-4f9e-8250-684455e9bb1a` aus dem bestehenden Workload `MARKTBEARBEITUNG` auswählen und gegen die CMDB/Azure-Anzeige bestätigen. |
| **GitLab Group ID** | Die **neu erstellte numerische ID von `marktbearbeitungsplattform-infra`**. Noch nicht bekannt. Nicht 5614 und nicht die Project ID verwenden. |
| Zusätzliche API Berechtigungen benötigt | Nicht pauschal auswählen. Nur konkret erforderliche und abgestimmte Zusatzberechtigungen anfordern. |
| Anlage | Folgenden Begleittext beifügen. Das Formular zeigt kein separates Freitext-Beschreibungsfeld, aber die Möglichkeit für Anlagen. |

**Begleittext:**

```text
Zusätzliche GitLab-Azure-Anbindung für die neue Top-Level-Gruppe marktbearbeitungsplattform-infra an den bestehenden Azure-Workload MARKTBEARBEITUNG.

Zielprojekt: marktbearbeitungsplattform-infra/ui-mb-infrastructure.
Die neue Gruppen-ID ist im Formular angegeben.

Die bestehende GitLab-Azure-Anbindung für Gruppe 5614 (Marktbearbeitungsplattform, laut Global-Settings) soll erhalten bleiben. Es handelt sich nicht um einen Ersatz dieser Anbindung und nicht um einen neuen Azure-Workload.

Benötigte Umgebungen im vorhandenen Infrastrukturcode:
DEV: 6289fbfa-0b84-4f9e-8250-684455e9bb1a
TEST: d98221c3-b24d-4770-a9a3-3716667d7353
PROD: a6c520e0-a1af-4c4c-82f0-8482ff82ecd8

Bitte bestätigen, ob die Auswahl einer Subscription in diesem Request die Anbindung des gesamten Workloads abdeckt oder ob weitere Freigaben/Requests erforderlich sind.

Benötigt werden die für die freigegebenen Infrastruktur-Scopes erforderlichen Ressourcen- und State-Zugriffe sowie die erforderliche Delegation für enthaltene Rollenzuweisungen. Keine pauschalen tenantweiten Zusatzberechtigungen.

Bitte mitteilen: bereitgestellte Identität, Berechtigungsscope, vorgesehene CI-Variablennamen/-Scopes und Betriebszuständigkeit einschließlich Rotation. TEST-/PROD-Zugriffe müssen mit geschützten Zweigen/Umgebungen und dem vorgesehenen Freigabeverfahren vereinbar sein.
```

Die Subscription-IDs stammen aus `ui-mb-infrastructure/environment/<env>/env.hcl`. Sie sind bekannte Konfigurationswerte, noch kein erneuter Live-Abgleich. Das Formular fordert eine Auswahl aus dem Workload; es rechtfertigt nicht automatisch drei identische Requests. [Q04–Q06]

### Bekannte Service- und State-Zuordnung

| Umgebung | Application Service im Quellstand | State-Storage / Ressourcengruppe |
|---|---|---|
| DEV | `AS Marktbearbeitung Entwicklung` | `sawd514852ab080b6472` / `rg-marktbearbeitung-dev-managed-resources` |
| TEST | `AS Marktbearbeitung Test` | `sawd345ade3fb4f39a5a` / `rg-marktbearbeitung-test-managed-resources` |
| PROD | `AS Marktbearbeitung Produktion` | `sawde3af87e25f0be60c` / `rg-marktbearbeitung-prod-managed-resources` |

Container jeweils `terraform-state`. Diese Backends und der pfadabhängige State-Key bleiben bei der Migration erhalten. Der aus Global-Settings bekannte TSO-Name lautet je Umgebung `TSO tAB MARKTBEARBEITUNG Entwicklung`, `... Test`, `... Produktion`; die CMDB-Auswahl für den konkreten Auftrag bestätigen. [Q02, Q04–Q07]

## 8. Firewall: Beispiel-Change korrekt für uns anpassen

### Zuerst prüfen, dann gegebenenfalls bestellen

`UI-CHG-0093595` ist ein **abgeschlossener Beispiel-Change für DIGITALASSETHUB**, nicht unser neuer Change. Seine Zielnetze, Subscriptions, Servicezuordnung, Personen, alten Termine, Bewertungen und Genehmigungen werden nicht übernommen. [F04]

Vor einer Änderung CIS/IIM-IBA um Abgleich der bereits vorhandenen Regel aus Abschnitt 3 bitten. Zu prüfen sind der konkrete Runner, seine Quellzuordnung, die tatsächlich benötigten privaten Endpunkte, Namensauflösung und Verbindungen. Erst eine belegte Lücke wird zum Änderungsauftrag.

### Feldzuordnung für einen erforderlichen Delta-Change

| Feld aus dem Beispiel | Vorschlag für uns |
|---|---|
| Angefordert von / Ansprechpartner | Iftime, Daniel (UIS). |
| Change Kategorie / Subkategorie | Netz / Firewall, wie in der bereitgestellten Vorlage. |
| Titel | `[AZURE][CORE-FIREWALL][Anpassung][MARKTBEARBEITUNG][DEV/TEST/PROD][GitLab Runner: erforderliche Dataplane-Freigaben ergänzen]` |
| Application Service | `AS Marktbearbeitung Produktion` als aus dem Repo bekannter Ausgangswert; tatsächlich betroffene Umgebungen/Services passend zuordnen lassen. |
| Technical Service Offering | Aus dem Repo: `TSO tAB MARKTBEARBEITUNG Produktion`. Verantwortlichen bestätigen lassen; betroffene Firewall-CIs gesondert zuordnen. |
| Quell-AS | Im Beispiel `AS GITLab Pipeline Produktion`; nur übernehmen, wenn dies auch den vorgesehenen Runner repräsentiert. |
| Ziel-AS | Marktbearbeitung, nicht Digital Asset Hub. |
| Typ/Modell, Risiko, Auswirkung, Koordinator, Zuweisungsgruppe | Mit zuständiger Change-/Firewall-Stelle festlegen. Nicht fremde Werte als genehmigt übernehmen. |
| Geplante Termine | Neu abstimmen. Die Vorlage nennt Start in drei Tagen und ein siebentägiges Fenster; deren aktuelle Gültigkeit bestätigen, keine alten Termine verwenden. |
| Genehmigung, Status, Abschluss | Neu erzeugter Vorgang. Niemals „Genehmigt“, „Geschlossen“ oder fremde Abschlussnotizen kopieren. |

### Begründung / Beschreibung zum Kopieren

```text
Für die Migration von ui-mb-infrastructure nach GitLab muss der vorgesehene GitLab-Runner auf die für Terraform/Terragrunt erforderlichen privaten Ressourcen des bestehenden Azure-Workloads MARKTBEARBEITUNG zugreifen können.

Die neue GitLab-Top-Level-Gruppe ist marktbearbeitungsplattform-infra. Der Azure-Workload und seine Subscriptions bleiben unverändert.

Im gelieferten Firewall-Rules-Stand ist bereits folgende Regel enthalten:
Datei: rules/workloads/marktbearbeitung.yml
Regel: Allow Access from DeliveryPipeline (GitLab)
Quelle: #WL_DELIVERYPIPELINE_PROD
Ziele: #WL_MARKTBEARBEITUNG_DEV, #WL_MARKTBEARBEITUNG_TEST, #WL_MARKTBEARBEITUNG_PROD
Ports: TCP 443 und 5432
Referenzen: UI-CHG-0041528, UI-CHG-0041934, UI-CHG-0054560

Bitte vorhandene Regeln, Quell-/Zielzuordnungen und die private DNS-/Netzwerkerreichbarkeit mit dem aktuellen Runner abgleichen. Beantragt wird ausschließlich die in der beigefügten Test-/Zielmatrix nachgewiesene, freigegebene Ergänzung. Keine doppelte Freischaltung und keine automatische Übernahme der DigitalAssetHub-EPGs oder IP-Bereiche aus UI-CHG-0093595.

DEV-Subscription: 6289fbfa-0b84-4f9e-8250-684455e9bb1a
TEST-Subscription: d98221c3-b24d-4770-a9a3-3716667d7353
PROD-Subscription: a6c520e0-a1af-4c4c-82f0-8482ff82ecd8

State-Storage, Key Vault, App Configuration und weitere tatsächliche Terraform-/Deploymentziele sind anhand des ausgewählten Scopes zu berücksichtigen. Zusätzliche Ports oder Datenbankzugriffe nur bei konkret belegtem Bedarf.

Ansprechpartner: Daniel Iftime.
```

**Stopppunkt vor Einreichung:** Die Beschreibung allein ersetzt nicht die technische Regelmatrix. Für jede tatsächliche Lücke müssen bestätigte Quelle/EPG, Ziel/EPG oder FQDN/IP, Umgebung, Port/Protokoll und Zweck beigefügt sein. Diese Live-Zuordnung ist noch offen. Ist keine Lücke vorhanden, keinen „Anlage“-Change erzeugen.

### Implementierungsplan

```text
1. Aktuellen Runner und bestehende Quell-/Ziel-EPGs beziehungsweise die Auflösung der Workload-Aliase bestätigen.
2. Bestehende Regeln und Testbefunde gegen die freigegebene Zielmatrix prüfen.
3. Nur die erforderlichen Ergänzungen im Repository Firewall-Rules vorbereiten und über den zuständigen Review-/Changeprozess umsetzen.
4. Pipelinevalidierung und Umsetzungsergebnis prüfen.
5. Erreichbarkeit aus dem tatsächlichen Runner zu den vereinbarten Zielen nachweisen; bei Fehltests Netzwerk-/DNS- und Berechtigungsursachen getrennt eingrenzen.
6. Ergebnis, betroffene Regel und zugehörigen Request/Change im Infrastruktur-Jira dokumentieren.
```

### Risiko- und Auswirkungsanalyse

```text
Es handelt sich um vorbereitende Netzwerkzugriffe für die GitLab-Migration, nicht um ein Anwendungsdeployment. Eine Unterbrechung der bestehenden Anwendung wird nicht beabsichtigt. Die Änderung erweitert jedoch Zugriffsmöglichkeiten; fehlerhafte Quell-/Zielzuordnungen oder zu breite Freigaben sind deshalb ausdrücklich zu prüfen.

Risiko und Auswirkung werden durch die zuständigen Stellen bewertet. Bestehende Regeln werden nicht pauschal entfernt oder ersetzt. Der bisherige Azure-DevOps-Auslieferungsweg bleibt bis zur abgestimmten Umschaltung erhalten.
```

### Backout-/Rollback-Plan und Nachweis

```text
Bei unerwarteten Auswirkungen die neu eingeführte Regeländerung über den vorgesehenen Firewall-Rules-Review-/Deploymentprozess zurücknehmen. Nur den Delta-Umfang dieses Changes entfernen; vorbestehende Freigaben erhalten.

Anschließend Regeln und Erreichbarkeit erneut prüfen. Kein pauschales Zurückspielen eines alten Terraform-States. Validierung der Pipeline allein gilt nicht als nachgewiesener Rollbacktest; durchgeführte Tests und offene Einschränkungen dokumentieren.
```

### Qualitätssicherung vor und nach dem Change

```text
Vorher: Quelle, Ziele, EPG-/Alias-Auflösung, Ports, Zweck und erforderlichen Scope fachlich/technisch prüfen; bestehende Regeln abgleichen und fehlgeschlagene Verbindungen dokumentieren.

Nachher: CI/CD-Ergebnis und wirksame Azure-Regeln kontrollieren; DNS-, Netzwerk-/TLS- und erforderliche autorisierte Lesezugriffe aus dem vorgesehenen Runner prüfen. State-Zugriff und ein begrenzter DEV-Plan sind getrennte Abnahmeschritte. Es werden keine TEST-/PROD-Applies allein zur Prüfung der Freischaltung ausgeführt.
```

## 9. Vor der Pipelineumsetzung noch zu berücksichtigen

Diese Befunde blockieren nicht den Namespace-Antrag, sind aber Teil der technischen Umsetzung:

| Befund | Konsequenz |
|---|---|
| `tgtf` ruft für unseren Namespace ein einzelnes `terragrunt plan` im Umgebungsordner auf. | Anpassung an die bestehenden verschachtelten Units, `applications/mashub` und Abhängigkeiten erforderlich. [Q08, Q12] |
| `tgtf`-Apply übernimmt keine gespeicherte Plandatei. | Plan-/Apply-Bindung und Schutz vor konkurrierenden Ausführungen umsetzen. [Q13] |
| Das neue Anwendungstemplate enthält selbst Azure-Deployments. | Nicht ungeprüft als Umsetzung von „Build-Gruppe endet bei Nexus“ übernehmen. Verantwortungsgrenze zum geschützten Deployment mit dem Entwicklerteam festlegen. [Q09–Q11] |
| Der lokale `deploy:prod`-Job hat keine `when: manual`-Zeile; hier ist kein ServiceNow-Prüfaufruf enthalten. | Gesamte aufgelöste Pipeline, Blueprint und tatsächliche Freigaben prüfen. Kein Beleg, dass der komplette Live-Prozess ohne Gates läuft. [Q10] |
| Der Java-Template-Default ist Java 21; README-Beispiele nennen teilweise abweichende Pfade. | Nicht automatisch den bisherigen Anwendungs-/Runtime-Stand ändern; reale Templatepfade, kompatible Versionen und Ref bestätigen. [Q09, Q14] |
| Für die neue Root-Gruppe ändert sich der abgeleitete OCI-Imagepfad. | Image-Ablage und Pull-Berechtigung vor dem ersten Runnerjob prüfen. [Q12] |

Ein ZIP mit dem Namen `release` belegt keinen bestimmten freigegebenen Git-Tag oder Commit. Das bereits gelieferte Template muss nicht erneut angefordert werden; für reproduzierbare Includes ist noch der konkret verwendete Ref zu bestätigen.

## 10. Was du jetzt noch intern klären musst

**Für den Namespace-Antrag:** formeller Verantwortlicher, benannter Vertreter und die passende CMDB-Auswahl. Als bekannte Ausgangswerte sind Daniel Iftime und `AS Marktbearbeitung Produktion` eingetragen. Der Vertreter ist nicht aus den Unterlagen ableitbar.

**Nach Namespace-Anlage:** neue numerische Group ID, bereitgestelltes UAM-Modul, bestätigte Azure-Anbindung und freigegebenes Werkzeugimage. Diese Werte müssen entstehen beziehungsweise bestätigt werden und werden nicht erfunden.

**Für einen eventuellen Firewall-Change:** konkreter Runner, Live-EPG-/Alias-Zuordnung, tatsächliche Zielmatrix und die festgestellte Lücke. Die vorhandene Regel zuerst prüfen.

### Kurze Nachricht an DVOS/CIS zum Kopieren

```text
Hallo zusammen,

wir bereiten die Migration des bestehenden Infrastruktur-Repositories ui-mb-infrastructure von Azure DevOps nach GitLab vor. Die Anwendungen bleiben in der vorhandenen Top-Level-Gruppe marktbearbeitungsplattform. Für die Infrastruktur ist die eigenständige private Top-Level-Gruppe marktbearbeitungsplattform-infra mit dem Projekt ui-mb-infrastructure vorgesehen.

Im gelieferten Global-Settings-Stand ist für MARKTBEARBEITUNG bereits die GitLab-Gruppe 5614 angebunden. In Firewall-Rules besteht außerdem bereits „Allow Access from DeliveryPipeline (GitLab)“ zu DEV/TEST/PROD. Wir möchten diese Bestände zuerst bestätigen und keine doppelten Bestellungen auslösen.

Bitte stimmt mit uns das Onboarding ab: zusätzliche Azure-Anbindung der neuen Infra-Gruppe, UAM-Rollen/technisches Konto, passendes Nexus-Werkzeugimage und aktuell dafür vorgesehene Runner-/Netzwerkzuordnung. Die bestehenden States und Azure-Ressourcen sollen unverändert weiterverwaltet werden.

Die Anwendungsmigration läuft im Kontext DBI-6605; die Infrastruktur erhält eine eigene verknüpfte Jira-Story. Die Namespace- und Integrationsformulare bereiten wir dafür vor.

Viele Grüße
Daniel
```

## Quellen und Status

- [Jira-Kopiervorlage](Jira_Marktbearbeitungsplattform_Infra_GitLab.md)
- [Quellenprüfung mit konkreten Dateien und Zeilennummern](Marktbearbeitungsplattform_Infra_Quellenpruefung.md)
- **F01–F04:** Formulare und Beispiel-Change aus `Gitlab Migration.zip`, insbesondere Formular-Pflichtfelder sowie Change-Seiten 1–4.
- **M01:** interne GitLab-Migrationsanleitung vom 27.10.2026, Seiten 1–3. Die dort genannte zentrale Frist Q2/2027 ersetzt nicht eure zuvor genannte interne Planung bis Ende 2026.
- **M02:** geliefertes Release-Governance-Zielbild, insbesondere getrennte Top-Level-Gruppen, Vier-Augen-Prinzip und Change-Gate.
- **Q01–Q14:** geprüfte Quellstellen aus den Archiven. Keine Livebestätigung.

Die Feldwerte sind anhand der Quellen vorbelegt oder ausdrücklich als Vorschlag/offen markiert. Keine fremden Genehmigungen, Endpunktgruppen, IP-Bereiche oder Abschlussinformationen wurden für Marktbearbeitung als gültig übernommen.
