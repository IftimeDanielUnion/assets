# Jira-Vorlage: Infrastrukturmigration nach GitLab

**Status:** Entwurf. Kein Ticket wurde angelegt und keine Migration ausgeführt.

| Feld | Vorschlag |
|---|---|
| Projekt | DBI / Domain Business Intelligence |
| Vorgangstyp | Story, entsprechend der bereitgestellten Vorlage |
| Verantwortlicher für die Umsetzung | Iftime, Daniel (UIS) |
| Komponente | DBI_Team_MAN |
| Label | SD_MB_DevOps, sofern für diese Story im Team verwendet |
| Verknüpfung | „hängt zusammen mit“ DBI-6605; kein neues Ticket für die Anwendungsentwicklung |
| Sprint / Priorität / Schätzung | Im Refinement festlegen; keine Werte aus dem fremden Beispiel übernehmen |
| Ziel | Abschluss bis Ende 2026 gemäß der im Gespräch genannten Planung; konkrete Etappen mit dem Team planen |

## Zusammenfassung

```text
ui-mb-infrastructure von Azure DevOps nach GitLab migrieren
```

## Beschreibung zum Kopieren: Jira-Wiki-Syntax

```jira
h3. Als Infrastrukturverantwortlicher möchte ich das Repository ui-mb-infrastructure und seine Terraform-/Terragrunt-Pipelines von Azure DevOps nach GitLab migrieren, damit die Azure-Infrastruktur der Marktbearbeitung über den vorgesehenen GitLab-Prozess verwaltet wird.

h3. Ziel und Abgrenzung
* Neue, eigenständige Top-Level-Gruppe: {{marktbearbeitungsplattform-infra}}.
* Zielprojekt: {{marktbearbeitungsplattform-infra/ui-mb-infrastructure}}.
* Die vorhandene Anwendungsgruppe {{marktbearbeitungsplattform}} bleibt bestehen. Kein Verschieben oder Umbenennen ihrer Projekte durch diese Story.
* Übernahme des Infrastruktur-Repositories mit Historie, Branches, Tags und bestehender Verzeichnisstruktur. Erster Ausführungsscope: MB-Portal unter {{environment/<dev|test|prod>/applications/mashub}} einschließlich der benötigten gemeinsamen Abhängigkeiten.
* Weitere im Repository enthaltene Anwendungen werden nicht unbeabsichtigt durch einen „All“-Lauf verändert. Ihre Umstellung wird ausdrücklich abgestimmt.
* Anwendungscode, Anwendungs-Buildpipelines und deren Anpassungen werden in DBI-6605 koordiniert. APIM, Service-Bus-Rechtekonzept und SMTP-Anpassungen sind nicht Bestandteil dieser Story.

h3. Offene Punkte
* Namespace-Verantwortlicher und Vertreter sowie die CMDB-Zuordnung verbindlich bestätigen.
* Neue GitLab Group ID, zugelassene Runner, Werkzeugimage und Azure-Berechtigungen feststellen.
* Vorhandene GitLab-Integration für Gruppe 5614 und vorhandene DeliveryPipeline-Firewallregeln live abgleichen; keine doppelten Bestellungen oder Ersatz der bestehenden Anbindung.
* Falls ein zusätzlicher Netzwerk-Change erforderlich ist: nur die nachgewiesene Lücke beantragen und die neue Change-Nummer verknüpfen.
* Verbindlichen Template-Ref, Freigabeverfahren und Rückfallzuständigkeit mit DVOS/CIS und Entwicklerteam abstimmen.

h3. Vorbedingungen
* DVOS-Onboarding und erforderliche Service Requests/UAM-Berechtigungen sind bestätigt.
* Ein freigegebenes, vom vorgesehenen Runner erreichbares Terraform-/Terragrunt-Werkzeugimage liegt vor.
* Die zusätzliche Azure-Anbindung ist der neuen Infra-Gruppe zugeordnet. Benötigte Rechte für State, Ressourcen und die im Scope enthaltenen Rollenzuweisungen sind bestätigt.
* Runner-Netzwerk, DNS und benötigte private Endpunkte sind geprüft.

h3. Anforderungen
# Namespace und Zielprojekt anlegen lassen; bestehende Apps-Gruppe und deren Azure-Integration unverändert erhalten.
# Repository kontrolliert übertragen und Quell-/Zielstände vergleichen. Keine Secrets, States oder lokalen Caches neu in Git aufnehmen.
# Pipeline auf Basis des freigegebenen {{web-portale-templates/pipelines/tgtf}}-Stands an die bestehende Modulstruktur, Anwendungsauswahl und Abhängigkeiten anpassen.
# Azure-State-Backends, Container, State-Keys und relative Pfade beibehalten. Kein Backendumzug und kein Ressourcenimport allein aufgrund des CI-Wechsels.
# Werkzeug-/Provider-Versionen kontrolliert festlegen. Keine unbemerkten Versions-Upgrades durch ein neu gebautes CI-Image.
# Zunächst einen begrenzten DEV-Plan ohne Apply ausführen und mit dem bisherigen Verfahren vergleichen. Vorhandenen Drift separat bewerten.
# Plan und Apply an denselben Commit, Scope und gespeicherten Plan binden. Schreibende Ausführungen pro State koordinieren; keine gleichzeitigen Applies aus Azure DevOps und GitLab.
# TEST/PROD über geschützte Zweige/Umgebungen, Vier-Augen-Prüfung und den vorgesehenen ServiceNow-Change-Abgleich absichern. Merge und Deployment nur durch dafür benannte Berechtigte; keine Selbstfreigabe.
# Schnittstelle zu den Anwendungspipelines dokumentieren: Ressourcen, Discovery-Keys und Zuständigkeit für App Settings bleiben eindeutig. Geschützte Deploymentrechte dürfen nicht durch einen ungeprüften Buildjob umgangen werden.
# Umstellung je Scope/Umgebung abnehmen; anschließend nur den ersetzten Azure-DevOps-Auslieferungsweg deaktivieren. Nicht migrierte Scopes bleiben unberührt.

h3. Fehlerhandling
* Bei falscher State-Zuordnung, fehlendem Zugriff, unerwarteten Löschungen/Ersetzungen oder unklarer Scope-Auswahl abbrechen.
* Bei fehlendem oder ungültigem Change beziehungsweise nicht erfüllter Freigabe kein TEST-/PROD-Apply.
* Bei fehlendem oder veraltetem Plan neu planen und erneut prüfen; kein unbemerkter Wechsel auf ein ungeprüftes Apply.
* Rückfall: GitLab-Auslieferung für den betroffenen Scope stoppen und den bisherigen Azure-DevOps-Weg nach Prüfung wieder aktivieren. Weiterhin denselben aktuellen State verwenden; keinen alten State blind zurückspielen.

h3. Server-Log / Audit-Log / Business-Log
* Commit, Pipeline-ID, Scope, Umgebung, Werkzeugversionen, Plan, Review/Change und Ausführung nachvollziehbar dokumentieren.
* Zugriff und Aufbewahrung für Plandateien/Logs begrenzen; keine Secret-Werte veröffentlichen.
* Keine zusätzlichen fachlichen Business-Logs erforderlich.

h3. Technische Hinweise
* State-Konfiguration: {{ui-mb-infrastructure/environment/root.hcl}} und {{environment/<env>/env.hcl}}.
* Bestehende Scope-Auswahl: {{ui-mb-infrastructure/ci/templates/steps.setup.yml}}; „MB Portal“ entspricht {{applications/mashub}}.
* Das gelieferte tgtf-Template führt im Standardpfad einen einzelnen Terragrunt-Aufruf im Umgebungsverzeichnis aus. Die bestehende verschachtelte Modulverarbeitung muss übernommen werden.
* Vorhandene GitLab-Anbindung: {{Global-Settings/Workloads/workloads.d/marktbearbeitung.yml}}, Gruppe {{5614}}. Für die neue Infra-Gruppe wird deren eigene ID benötigt.
* Vorhandene Runner-Regel: {{Firewall-Rules/rules/workloads/marktbearbeitung.yml}}, „Allow Access from DeliveryPipeline (GitLab)“. Ein zusätzlicher Change ist nur bei einer bestätigten Lücke nötig.
* Die im Antrag beschriebene neue Infra-Gruppe ist kein neuer Azure-Workload. Der bestehende Workload heißt {{MARKTBEARBEITUNG}}.

h3. UX/UI
Nicht betroffen.

h3. Feature Toggle
Kein fachlicher Toggle. Pipeline- und Umgebungsschalter dienen der kontrollierten Umstellung.

h3. Akzeptanzkriterien
# Infra-Gruppe und Zielprojekt sind vorhanden; Rollen und Zugriffe sind dokumentiert.
# Repository-Historie und maßgebliche Quell-/Zielstände wurden abgeglichen.
# Benötigte Azure-, Nexus-, Runner- und State-Zugriffe sind erfolgreich nachgewiesen.
# Der geprüfte DEV-Plan verwendet die bisherigen State-Backends und zeigt keine durch den CI-Umzug verursachte Neuerstellung, Löschung oder Ersetzung bestehender Ressourcen.
# Plan-/Apply-Bindung, Scope-Begrenzung und Schutz vor konkurrierenden Schreibzugriffen sind nachgewiesen.
# Ein nicht autorisierter beziehungsweise nicht genehmigter TEST-/PROD-Lauf wird verhindert; ein freigegebener Lauf ist nachvollziehbar erfolgreich.
# Die vereinbarten Umgebungen/Scopes sind abgenommen. Azure DevOps deployt dort nicht mehr parallel.
# Betriebsdokumentation, Verantwortlichkeiten und Rückfallverfahren sind übergeben; zugehörige Requests/Changes und DBI-6605 sind verknüpft.
```

## Sinnvolle Unteraufgaben

1. DVOS-Abstimmung, Namespace, UAM und Azure-Anbindung.
2. Nexus/Werkzeugimage und vorhandene Runner-Netzwerkfreigaben prüfen.
3. Repository und Historie übertragen, State-/Scope-Zuordnung sichern.
4. GitLab-Plan/Apply-Pipeline anpassen und validieren.
5. DEV abnehmen.
6. Freigaben und kontrollierte Umstellung TEST/PROD.
7. Ersetzte Azure-DevOps-Jobs stilllegen und Betrieb übergeben.

**Grundlagen:** bereitgestellte Jira-Struktur aus DBI-8123, bestehendes Epic DBI-6605, Migrationsanleitung vom 27.10.2026, Zukunftsdesign und überprüfte Quellstände. Technische Fundstellen: [Quellenprüfung](Marktbearbeitungsplattform_Infra_Quellenpruefung.md), insbesondere Q01–Q08 und Q12–Q13. Der genaue Sprint, die Priorität und eine formelle Epic-Zuordnung bleiben Teamentscheidungen.
