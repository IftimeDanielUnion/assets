# Technische Ergänzung zum GitLab-Startpaket

**Zuerst `Technik_State_Terragrunt_GitLab.md` öffnen.**

Die Anleitung erklärt State, Backend, Terraform, Terragrunt, Runner, Identitäten und Plan/Apply anhand eurer vorhandenen Infrastruktur. Sie enthält konkrete DEV-Prüfschritte, eine Umschaltreihenfolge und einen Rückfallweg.

## Kernentscheidung

Der bestehende State bleibt zunächst in Azure Storage. Wir ändern den Ausführungsweg von Azure DevOps nach GitLab. Die vorhandenen Ressourcen werden deshalb nicht automatisch neu angelegt oder erneut importiert.

## Dateien

- `Technik_State_Terragrunt_GitLab.md`: vollständige Anleitung, mit eindeutig getrennten Quellbefunden und Empfehlungen.
- `Quellen_Originalauszuege.md`: 19 nummerierte Quellenblöcke, Dateipfade, Zeilen und SHA-256.
- `state-inventar-aus-quellstand.json`: bekannte Backendwerte und 64 aus dem Code abgeleitete MBPortal-State-Keys; keine Azure-Liveinventur.
- `state_metadaten_pruefen.py`: optionaler Prüfhelfer. Standardmäßig nur offline; ausschließlich mit `--azure` liest er Azure-Metadaten. Er führt weder Terraform noch Azure-Schreiboperationen aus.
- `tests/test_state_metadaten.py`: lokale Tests mit simulierten CLI-Ergebnissen.

## Prüfhelfer verwenden

Voraussetzung: Python 3.10 oder neuer. Die Dateien im selben Ordner belassen. Die Beispiele verwenden `python3`; unter Windows ist je nach Installation `py -3` oder `python` verfügbar.

```bash
# Kein Netzwerkzugriff, nur bekannte Quellkonfiguration anzeigen:
python3 state_metadaten_pruefen.py --env dev --unit identity

# Erst nach interner Freigabe und vorhandener Azure-CLI-Anmeldung:
python3 state_metadaten_pruefen.py --env dev --unit identity --azure
```

Ein erfolgreicher Metadatencheck beweist keine State-Inhaltsprüfung, keine Schreibrechte und keinen erfolgreichen Terraform-Plan. Eine Prüfung mit deinem Benutzerkonto beweist nicht die Berechtigung des GitLab-Runners.

## Teststatus

Am 27.10.2026 wurden **12 lokale automatisierte Tests erfolgreich ausgeführt**. Geprüft wurden unter anderem der Umgebungs-/Unit-Scope, das Offlineverhalten, die zulässigen Leseaufrufe, der Umgang mit Fehlern und die Vermeidung von Storage-Key-Overrides. Azure-Antworten wurden simuliert. Die Bash-Blöcke der Anleitung wurden auf Syntax geprüft.

```bash
python3 -m unittest discover -s tests -v
```

Es wurde kein Terraform installiert oder ausgeführt, keine Verbindung zu eurem Azure/GitLab hergestellt und nichts produktiv verändert. Die Anleitung ist noch keine fertig konfigurierte GitLab-Pipeline. Dafür müssen der tatsächliche Runner, die Plattformanmeldung, die Providerauflösung und die Freigabeschritte bestätigt sein.
