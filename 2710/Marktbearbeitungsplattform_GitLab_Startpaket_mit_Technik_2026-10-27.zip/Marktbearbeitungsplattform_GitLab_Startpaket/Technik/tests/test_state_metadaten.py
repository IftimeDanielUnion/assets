import contextlib
import io
import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch, Mock
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import state_metadaten_pruefen as checker

class MetadataTests(unittest.TestCase):
    def target(self):
        return checker.load_target(checker.DEFAULT_MANIFEST, 'dev', 'identity')

    def test_source_inventory(self):
        data=json.loads(checker.DEFAULT_MANIFEST.read_text())
        self.assertEqual(len(data['units']),64)
        for env,count in [('dev',21),('test',21),('prod',22)]:
            self.assertEqual(sum(u['environment']==env for u in data['units']),count)
        self.assertFalse(data['state_keys_verified_in_azure'])

    def test_target_key(self):
        self.assertEqual(self.target()['blob_key'],'dev/applications/mashub/identity/terraform.tfstate')

    def test_reject_unknown_unit(self):
        with self.assertRaises(checker.CheckError):
            checker.load_target(checker.DEFAULT_MANIFEST,'dev','../../prod')

    def test_prod_specific_unit(self):
        checker.load_target(checker.DEFAULT_MANIFEST,'prod','keyvault-aadb2c')
        with self.assertRaises(checker.CheckError):
            checker.load_target(checker.DEFAULT_MANIFEST,'dev','keyvault-aadb2c')

    def test_storage_secrets_removed(self):
        with patch.dict(checker.os.environ,{'AZURE_STORAGE_KEY':'secret','AZURE_STORAGE_SAS_TOKEN':'secret'}):
            self.assertNotIn('AZURE_STORAGE_KEY',checker.clean_azure_env())
            self.assertNotIn('AZURE_STORAGE_SAS_TOKEN',checker.clean_azure_env())

    def test_offline_does_not_call_cli(self):
        with patch.object(checker,'run_az_json') as cli, contextlib.redirect_stdout(io.StringIO()) as output:
            self.assertEqual(checker.main(['--env','dev']),0)
            cli.assert_not_called()
        self.assertEqual(json.loads(output.getvalue())['mode'],'offline-source-inventory')

    def test_valid_metadata(self):
        t=self.target()
        fake=[{'subscription_id':t['subscription_id'],'state':'Enabled','tenant_id':'test'},
              {'id':f'/subscriptions/{t["subscription_id"]}/resourceGroups/{t["resource_group_name"]}/providers/Microsoft.Storage/storageAccounts/{t["storage_account_name"]}'},
              {'name':t['blob_key'],'size':20,'etag':'test'}]
        with patch.object(checker,'run_az_json',side_effect=fake) as cli:
            checker.inspect_azure(t)
            calls=[c.args[0] for c in cli.call_args_list]
            self.assertEqual([c[:3] for c in calls],[['account','show','--subscription'],['storage','account','show'],['storage','blob','show']])
            self.assertIn('login',calls[2])

    def test_wrong_subscription_blocks(self):
        with patch.object(checker,'run_az_json',return_value={'subscription_id':'wrong','state':'Enabled'}) as cli:
            with self.assertRaises(checker.CheckError):checker.inspect_azure(self.target())
            self.assertEqual(cli.call_count,1)

    def test_stderr_not_leaked(self):
        result=Mock(returncode=1,stderr='AuthorizationFailed SECRET-DO-NOT-PRINT',stdout='')
        with patch.object(checker.shutil,'which',return_value='/usr/bin/az'),patch.object(checker.subprocess,'run',return_value=result):
            with self.assertRaises(checker.CheckError) as exc:checker.run_az_json(['account','show'],'Test')
            self.assertNotIn('SECRET',str(exc.exception))

    def test_output_not_overwritten(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'report.json';p.write_text('original')
            with contextlib.redirect_stderr(io.StringIO()),patch.object(checker,'inspect_azure') as cli:
                self.assertEqual(checker.main(['--env','dev','--azure','--output',str(p)]),1)
                cli.assert_not_called()
            self.assertEqual(p.read_text(),'original')

    def test_missing_az(self):
        with patch.object(checker.shutil,'which',return_value=None):
            with self.assertRaises(checker.CheckError):checker.run_az_json(['account','show'],'Test')

    def test_invalid_cli_json(self):
        with patch.object(checker.shutil,'which',return_value='/usr/bin/az'),patch.object(checker.subprocess,'run',return_value=Mock(returncode=0,stdout='not json')):
            with self.assertRaises(checker.CheckError):checker.run_az_json(['account','show'],'Test')

if __name__ == '__main__':unittest.main()
