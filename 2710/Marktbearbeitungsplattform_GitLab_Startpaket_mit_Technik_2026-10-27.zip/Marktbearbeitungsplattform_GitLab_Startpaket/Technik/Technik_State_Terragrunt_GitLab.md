# Marktbearbeitungsplattform: State, Terraform, Terragrunt und GitLab verstehen

**Technische Arbeitsanleitung für Daniel Iftime**  
**Stand: 27.10.2026**  
**Vorgesehenes Zielprojekt:** `marktbearbeitungsplattform-infra/ui-mb-infrastructure`

> **Die Kernentscheidung: Wir wechseln zunächst Repository und Pipeline, nicht den Speicherort des Terraform-States.** Der vorhandene State bleibt in Azure Storage. Der GitLab-Runner soll dieselben Ressourcen über dieselben State-Adressen weiterverwalten. Es werden dafür weder neue Azure-Subscriptions benötigt noch alle Ressourcen erneut importiert.

Diese Aussage ist der **empfohlene Migrationsweg** auf Grundlage eurer vorhandenen Backend-Konfiguration, kein bereits durchgeführter Umzug. Vor der Umschaltung müssen Quellstand, tatsächlich verwendeter State und Pipelineidentität abgeglichen werden. [S01–S04; W01]

## Lesereihenfolge

Für das Verständnis zuerst **1–5** lesen. Für die Vorbereitung **6–10**. Die praktische Umstellung und Fehlerbehandlung stehen in **11–15**. **16** ist die Abnahmecheckliste; **17–18** enthalten offene Punkte, Paketinhalt und Quellen.

### Was in dieser Anleitung welchen Status hat

- **Quellbefund [Sxx]:** direkt aus den von dir gelieferten Repository-Dateien gelesen. Das beweist nicht den aktuellen Azure-Bestand.
- **Technische Erklärung [Wxx]:** ergänzend anhand offizieller Terraform-, Terragrunt-, Microsoft- und GitLab-Dokumentation geprüft.
- **Vorgehensvorschlag:** für eure Migration abgeleitete Empfehlung, noch keine genehmigte interne Umsetzung.

Es wurden keine Azure- oder internen GitLab-Abfragen, keine Terraform-Kommandos und keine Deployments ausgeführt. Das optionale Metadaten-Prüfprogramm wurde lokal mit simulierten CLI-Antworten getestet, nicht gegen eure Cloud. Die Befehle in diesem Dokument sind Anleitungen für später freigegebene Prüfungen.

---

## 1. Was genau migriert wird

### Bisher und nach dem Wechsel

```text
BISHER
Azure-DevOps-Repository
    -> Azure-DevOps-Pipeline
    -> Build-Agent mit Terraform/Terragrunt
       |-> Azure Storage: vorhandene State-Blobs
       |-> Azure APIs: vorhandene Ressourcen

ZIEL
GitLab-Projekt marktbearbeitungsplattform-infra/ui-mb-infrastructure
    -> GitLab-Pipeline
    -> GitLab-Runner mit Terraform/Terragrunt
       |-> Azure Storage: dieselben State-Blobs
       |-> Azure APIs: dieselben Ressourcen
```

**Die GitLab-Gruppe speichert euren Code. Sie ist nicht automatisch der neue Speicherort des States.** Ein GitLab-Runner ist zunächst nur der Rechner beziehungsweise Container, der eure Befehle ausführt. Das konfigurierte Backend entscheidet, wo Terraform den State ablegt. Euer Code nennt dafür `azurerm`, nicht ein GitLab-HTTP-Backend. [S01; W01]

| Bestandteil | Beim ersten Umzug ändern? | Vorgehensvorschlag |
|---|---|---|
| Git-Hosting | Ja | Code und Historie nach GitLab übernehmen; vorhandenes Ziel vorher prüfen. |
| Pipeline-Definition | Ja | Azure-DevOps-Tasks in den abgestimmten GitLab-Ablauf überführen. |
| Runner und Anmeldung | Ja | Freigegebener GitLab-Runner und zugehörige Azure-Deploymentidentität. |
| Azure-Subscriptions und Ressourcen | Nein, nicht wegen des CI-Wechsels | Vorhandenen Bestand weiterverwenden. |
| State-Storage, Container und Blob-Key | Nein | Bestehende Adressen bestätigen und erhalten. |
| Interne Terragrunt-Verzeichnisse | Zunächst nein | Insbesondere `environment/.../applications/mashub/...` erhalten. |
| Terraform-/Terragrunt-Versionen | Zunächst nein | Versionen aus eurem Bestand nutzen, keinen gleichzeitigen Toolwechsel erzwingen. |
| Provider-/Modulversionen | Nicht ungeplant | Tatsächlich zuletzt verwendete Auflösung feststellen und reproduzieren. |
| Anwendungspakete und App Settings | Separater Auslieferungsteil | Mit dem Entwicklerteam abstimmen; nicht durch den State-Umzug ersetzt. |

Die neue Namespace-Anbindung und eine eventuelle Korrektur von Berechtigungen sind reale Änderungen. Sie werden separat beantragt. Dass die Anwendungsressourcen zunächst gleich bleiben sollen, bedeutet nicht, dass keinerlei Onboardingarbeit erforderlich ist.

## 2. Was der State eigentlich ist

Terraform arbeitet mit drei unterschiedlichen Dingen:

| Begriff | Bedeutung | Beispiel bei euch |
|---|---|---|
| **Konfiguration** | Beschreibt den gewünschten Aufbau. | `.tf`-Module und `.hcl`-Umgebungsdateien im Repo. |
| **Reale Ressourcen** | Der tatsächlich in Azure vorhandene Bestand. | Function App, Service-Bus-Namespace, PostgreSQL-Server. |
| **State** | Ordnet Terraform-Ressourcenadressen konkreten Azure-Objekten zu und hält bekannte Eigenschaften und Outputs fest. | Ein `terraform.tfstate`-Blob für eine Terragrunt-Unit. |

Ohne die richtige Zuordnung erkennt Terraform nicht allein anhand eines ähnlichen Namens, dass eine vorhandene Ressource bereits zu dieser Konfiguration gehört. Ein falscher oder leerer State kann deshalb einen Plan mit vielen Neuanlagen erzeugen, obwohl die Ressourcen in Azure schon existieren. **Dann abbrechen, nicht bestätigen.** [W02]

Eine vereinfachte Zuordnung ist:

```text
Ressourcenadresse innerhalb eines Terraform-Moduls
    -> konkrete Azure Resource ID
    -> zuletzt bekannte Attribute und Outputs
```

Das ist eine Erklärung des Modells, kein Auszug aus eurem echten State.

**Der State ist kein Datenbankbackup und kein Backup aller Dateien einer Anwendung.** Eine Wiederherstellung des State-Blobs stellt keine gelöschten Geschäftsdaten wieder her. Ebenso bedeutet ein Git-Revert nicht, dass Daten oder Infrastruktur automatisch zurückgesetzt werden.

State-Dateien können Geheimnisse enthalten. Sie gehören nicht in Git, Jira, Teams oder einen allgemeinen Chat-Anhang. Das gilt auch dann, wenn einzelne Terraform-Werte als `sensitive` markiert sind: Diese Markierung ist nicht gleichbedeutend mit dem Entfernen des Wertes aus State oder Plan. [W09]

## 3. Wo eure States laut Repository liegen

### 3.1 Backend-Konfiguration

Datei: **`ui-mb-infrastructure/environment/root.hcl`, Zeilen 53–65**.

Der relevante Ausschnitt ist:

```hcl
remote_state {
  backend = "azurerm"
  generate = {
    path      = "backend.tf"
    if_exists = "overwrite"
  }
  config = {
    subscription_id      = "${local.subscription_id}"
    key                  = "${path_relative_to_include()}/terraform.tfstate"
    resource_group_name  = local.environment_vars.locals.backend_resource_group_name
    storage_account_name = local.environment_vars.locals.backend_storage_account_name
    container_name       = local.environment_vars.locals.backend_container_name
  }
}
```

Die Werte kommen aus der jeweiligen `environment/<umgebung>/env.hcl`. [S01–S04]

| Umgebung | Storage Account | Resource Group des Backends | Container |
|---|---|---|---|
| DEV | `sawd514852ab080b6472` | `rg-marktbearbeitung-dev-managed-resources` | `terraform-state` |
| TEST | `sawd345ade3fb4f39a5a` | `rg-marktbearbeitung-test-managed-resources` | `terraform-state` |
| PROD | `sawde3af87e25f0be60c` | `rg-marktbearbeitung-prod-managed-resources` | `terraform-state` |

Die dazugehörigen Subscription-IDs im Quellstand:

```text
DEV   6289fbfa-0b84-4f9e-8250-684455e9bb1a
TEST  d98221c3-b24d-4770-a9a3-3716667d7353
PROD  a6c520e0-a1af-4c4c-82f0-8482ff82ecd8
```

**Das sind bekannte Konfigurationswerte, keine von mir durchgeführten Live-Prüfungen.** Vor dem ersten GitLab-Plan mit den effektiven Backendwerten der zuletzt erfolgreichen Azure-DevOps-Ausführung vergleichen.

### 3.2 Es gibt nicht einen einzigen MBPortal-State

Im gelieferten Infrastrukturrepo enthält der Bereich `mashub`:

| Umgebung | Terragrunt-Units im Bereich `mashub` | Alle Units der jeweiligen Umgebung im Repo |
|---|---:|---:|
| DEV | 21 | 60 |
| TEST | 21 | 60 |
| PROD | 22 | 61 |

Jede dieser Units ist hier mit einem eigenen erwarteten State-Key verbunden. Beispiele: `identity`, `monitoring`, `database`, `service-bus`, `sales-portal-api`, `sales-portal`, `integration-services` und `app-config`. In PROD kommt `keyvault-aadb2c` hinzu. **64 Quellkonfigurationen bedeuten nicht, dass ich 64 existierende Azure-Blobs gezählt habe.** [S19]

Für Standard-Workspace-Nutzung ergeben sich aus Root-Include und Verzeichnisstruktur beispielsweise:

```text
DEV-Identity:
dev/applications/mashub/identity/terraform.tfstate

DEV-Service-Bus:
dev/applications/mashub/service-bus/terraform.tfstate

PROD-Portal-Backend:
prod/applications/mashub/sales-portal-api/terraform.tfstate
```

Diese Keys sind aus dem Code abgeleitet. Vor Benutzung in Azure beziehungsweise der initialisierten bisherigen Pipeline bestätigen. Alle 64 Ableitungen sind im beigefügten `state-inventar-aus-quellstand.json` enthalten. [S01, S05, S19; W11]

### 3.3 Was eine eindeutige State-Adresse ausmacht

Für die Übergabe dokumentieren wir pro Unit:

```text
Azure-Cloud / Tenant / Subscription
+ Storage Account
+ Container
+ effektiver Blob-Key
+ verwendeter Terraform-Workspace
```

Der GitLab-Gruppenname und der Repositoryname sind keine Bestandteile eures aktuellen Key-Ausdrucks. Der **relative Pfad zur eingebundenen `environment/root.hcl`** ist dagegen wesentlich. [S01; W11]

**Beispiel:** Das Repository kann künftig unter `marktbearbeitungsplattform-infra/ui-mb-infrastructure` liegen. Solange der interne Aufbau und die Include-Auflösung erhalten bleiben, ändert allein der neue Git-Pfad euren berechneten Key nicht.

Dagegen würde eine Umbenennung von `applications/mashub` in `applications/mb-portal` den berechneten Key ändern. Deshalb den historischen Namen `mashub` im Infrastrukturcode beim CI-Wechsel beibehalten. Die sichtbaren GitLab-Projekte `mashub-backend` und `mashub-frontend` sind nicht allein aufgrund dieses ähnlichen Namens automatisch das Ziel der hier betrachteten MBPortal-Quellen.

**Workspaces:** Die gelieferten Pipelines zeigen keine explizite Workspace-Umschaltung. Das ist kein Beweis für die tatsächliche Laufzeitkonfiguration. Einen gesetzten `TF_WORKSPACE` und den bisherigen Workspace prüfen. Keinen neuen Workspace `dev` anlegen, nur weil die Umgebung DEV heißt. Ein anderer Workspace kann einen anderen State auswählen. [W03]

## 4. Wie Terraform und Terragrunt bei euch zusammenspielen

### 4.1 Die Dateien haben unterschiedliche Aufgaben

```text
ui-mb-infrastructure/
├── modules/                         Terraform-Bausteine
│   ├── servicebus/
│   └── functionapp/
├── environment/
│   ├── .terraform-version           1.13.4
│   ├── .terragrunt-version          0.92.1
│   ├── root.hcl                     Provider und State-Backend
│   ├── _apps/mashub/                Gemeinsame Unit-Konfiguration
│   │   └── service-bus.hcl
│   ├── dev/
│   │   ├── env.hcl                  DEV-Subscription und State-Speicher
│   │   └── applications/mashub/
│   │       ├── app.hcl
│   │       ├── identity/terragrunt.hcl
│   │       └── service-bus/terragrunt.hcl
│   ├── test/
│   └── prod/
└── ci/                              Bisherige Azure-DevOps-Pipelines
```

Das ist eine verkürzte Darstellung des gelieferten Bestands. Die Unit bindet die Root-Konfiguration und die appbezogene Konfiguration ein. Terragrunt bereitet daraus Terraform-Aufrufe vor; Terraform verwendet Provider für die Azure-APIs. Der Ordner `modules/servicebus` wird beispielsweise über `_apps/mashub/service-bus.hcl` verwendet. [S01, S05–S07, S12–S13]

**Nicht im beliebigen `modules/`-Ordner Terraform starten:** Dann fehlen möglicherweise die vorgesehenen Inputs, generierten Providerdateien und vor allem die richtige Backendzuordnung. Der Einstieg für einen konkreten Bestand ist die entsprechende Terragrunt-Unit.

### 4.2 Abhängigkeiten sind keine Reihenfolge nach Dateiname

Eure Service-Bus-Unit benötigt Outputs von:

```text
identity --------------\
datenprodukt-identity --+-> service-bus
monitoring ------------/
```

Die Outputs enthalten beispielsweise Principal-IDs und Monitoring-Ressourcen-IDs. Terragrunt kann Abhängigkeiten berücksichtigen und hierfür Outputs anderer Units lesen. Daher braucht die neue Ausführungsidentität gegebenenfalls auch Zugriff auf diese abhängigen States. [S06; W17]

Im Quellstand gibt es `mock_outputs`. Das sind Ersatzwerte, keine produktiven Ressourcen. **Ein Plan mit Ersatz-IDs beweist keine erfolgreiche Übernahme.** Bei einem erwarteten bestehenden Bestand muss geklärt sein, dass echte State-Outputs gelesen wurden. Fehlenden State-Zugriff nicht durch neue Mocks kaschieren.

Die bisherige Pipeline ordnet „MB Portal“ dem Verzeichnis `applications/mashub` zu und nutzt Mehrmodul-Aufrufe mit `--queue-exclude-external`. Dieses Verhalten muss bewusst nachgebildet werden. Ein Umstieg auf `All` würde auch Infrastruktur anderer Anwendungen erfassen. [S07–S08]

### 4.3 Vier Dateien/Mechanismen, die man nicht verwechseln darf

| Begriff | Zweck | Umgang bei der Migration |
|---|---|---|
| `terraform.tfstate` in Azure | Dauerhafte Zuordnung zum Ressourcenbestand | Erhalten und schützen. |
| `.terraform/` | Lokale Backend-/Provider-Initialisierung | Auf neuem Runner neu initialisieren; nicht als State-Backup behandeln. |
| `.terragrunt-cache/` | Lokaler Arbeitsbereich für Module und generierte Dateien | Nicht als verbindlichen gemeinsamen State migrieren. |
| `.terraform.lock.hcl` | Gewählte Provider-Versionen und Prüfsummen | Reproduzierbar bereitstellen; nicht mit einer State-Sperre verwechseln. |

**Besonderer Quellbefund:** Eure `.gitignore` ignoriert `.terraform.lock.hcl`; im Archiv liegen keine solchen Lockdateien. `root.hcl` erlaubt Terraform `~> 1.13` und AzureRM `~> 4.64`, während die Tooldateien Terraform **1.13.4** und Terragrunt **0.92.1** festlegen. Die Constraints sind keine vollständige Aufzeichnung der zuletzt verwendeten Provider-Versionen. [S01, S11–S13]

**Vorgehensvorschlag:** Die zuletzt erfolgreich verwendeten Provider-Auflösungen und Lockdateien aus dem bisherigen Ausführungsprozess sichern beziehungsweise rekonstruieren und kontrolliert versionieren. Nicht erst auf dem neuen Runner die neueste zulässige Version wählen und diesen Unterschied als reine CI-Migration behandeln. Ein vorläufiger Erhalt der bisherigen Provider-Auflösung ist wichtiger als ein gleichzeitiges Upgrade. Die Provider-Lockdatei fixiert nicht zugleich alle externen Modulversionen; deren Quellen und Versionen zusätzlich festhalten. [W08]

## 5. Was `init`, `plan` und `apply` tun

| Schritt | Was passiert technisch? | Erwartung bei eurem Wechsel |
|---|---|---|
| `init` | Backend verbinden, Module und Provider vorbereiten, lokale Arbeitsdaten anlegen. | Mit derselben Backendadresse initialisieren. Keine unbegründete State-Migration bestätigen. |
| `plan` | Bestand lesen, mit Code/State vergleichen und geplante Aktionen ermitteln. | Keine durch den CI-Wechsel verursachten Anlegungen, Löschungen oder Ersetzungen. |
| `apply` | Einen Plan umsetzen und State nachführen. | Nur freigegebenen Plan ausführen, wenn die Prüfungen abgeschlossen sind. |

Ein normaler Plan setzt seine vorgeschlagenen Ressourcenänderungen noch nicht um. **Ein kompletter Terragrunt-/Pipeline-Lauf ist deshalb trotzdem nicht automatisch frei von Seiteneffekten:** Hooks, Skripte, Initialisierung und lokale Schreibvorgänge müssen mitbetrachtet werden. Terraform kann außerdem eine Backend-Sperre benötigen. Ein erster Plan ist kein Anlass, ungeprüften Code mit produktiven Zugangsdaten auszuführen. [W04–W06, W16]

### `init` ist nicht gleich „alles neu anlegen“

Ein frischer GitLab-Runner hat zunächst keine lokale Backend-Initialisierung. Er darf trotzdem auf den vorhandenen Remote-State zugreifen. Dafür braucht er die passende Konfiguration, Anmeldung, Berechtigung und Netzwerkverbindung. Ein erneutes `init` ist regulär; ein `apply` auf einen versehentlich neuen leeren State wäre das Problem. [W05]

| Option/Vorgang | Bedeutung | Für den bloßen CI-Wechsel? |
|---|---|---|
| Normales `init` | Arbeitsverzeichnis für das konfigurierte Backend initialisieren. | Ja, nach Backend-/Versionsprüfung. |
| `init -reconfigure` | Gespeicherte lokale Backendzuordnung neu einlesen, ohne State zu migrieren. | Nur bei bewusst erklärter lokaler Konfigurationsabweichung. Nicht als Mittel gegen einen unbekannten Statepfad. |
| `init -migrate-state` | State bei einem Backendwechsel übertragen. | Nicht vorgesehen, solange Account/Container/Key/Workspace erhalten bleiben. |
| `init -upgrade` | Zulässige neuere Abhängigkeiten auswählen. | Nicht als Standard beim ersten Migrationslauf. |
| `import` | Bereits vorhandene, bisher hier nicht verwaltete Ressource zuordnen. | Nicht erneut für Ressourcen, die schon im richtigen State stehen. |

Die Optionen `-reconfigure` und `-migrate-state` sind unterschiedliche Verfahren. Wenn Terraform einen Backendwechsel meldet, erst die Ursache und die effektiven Adressen klären. Nicht automatisiert einen der Schalter hinzufügen, bis die Fehlermeldung verschwindet. [W05]

## 6. Sperren: Warum zwei funktionierende Pipelines gefährlich sein können

Das AzureRM-Backend unterstützt Sperren über Azure Blob Storage. Terraform verwendet dabei eine Lease, um konkurrierende Änderungen am selben State zu verhindern. Eine zweite Ausführung kann warten oder mit einem Lockfehler abbrechen. [W01, W15]

**Diese Sperre ersetzt keine geordnete Umschaltung.** Sie schützt einen State während einer Operation, nicht sämtliche unabhängigen State-Blobs einer ganzen Anwendung. Sie verhindert auch nicht, dass zwei unterschiedliche Pipelines nacheinander verschiedene Code-Stände anwenden.

Deshalb empfehlen wir drei Ebenen:

| Ebene | Schutz |
|---|---|
| Terraform-Backend | Gleichzeitige Zugriffe auf denselben State koordinieren. |
| GitLab-Pipeline | Über eine vereinbarte `resource_group` schreibende Jobs auf überlappende Ziele serialisieren. |
| Umschaltverfahren | Azure DevOps und GitLab dürfen nicht gleichzeitig als unabhängige schreibende Autoritäten aktiv bleiben. |

GitLab-Resource-Groups koordinieren Jobs im jeweiligen Projekt. Sie sperren nicht automatisch Azure-DevOps-Jobs oder Ausführungen aus anderen GitLab-Projekten. Für eure Mehr-Unit-Umgebung ist zunächst eine grobe Serialisierung pro Umgebung einfacher zu prüfen als viele überlappende App-Sperren. [W14]

**Bei Lockfehlern:** Laufende Jobs und deren Besitzer prüfen, gegebenenfalls warten. Weder `-lock=false` noch `force-unlock` oder das Brechen einer Blob-Lease als normale Fehlerbehebung verwenden. Eine verwaiste Sperre wird nur nach bestätigtem Ende aller beteiligten Ausführungen gezielt aufgehoben. [W04]

Ein ausstehender manueller Review hält normalerweise keine Terraform-Sperre bis zum späteren Apply fest. Ändert sich der State zwischenzeitlich, muss ein gespeicherter Plan gegebenenfalls neu erzeugt und erneut freigegeben werden. GitLab-Serialisierung pro Job allein hält die gesamte Wartephase nicht automatisch exklusiv.

## 7. Welche Zugänge der GitLab-Runner benötigt

### 7.1 Drei Identitäten unterscheiden

| Identität | Aufgabe |
|---|---|
| Dein Benutzerkonto | GitLab bedienen, freigegebene Diagnose durchführen, Änderungen reviewen beziehungsweise beantragen. |
| Pipelineidentität | Terraform, Azure CLI und Deploymentjobs unter klar definierten Berechtigungen ausführen. |
| Laufzeitidentität der Anwendung | Einer bereits laufenden Function App Zugriff auf Service Bus, Storage und andere Dienste geben. |

Die früher von dir gelieferten Action-Hub-Managed-Identity-IDs sind Laufzeitidentitäten. Sie sind kein Nachweis für die zukünftige Infra-Pipelineanmeldung. Ebenso ist eine GitLab-Group-ID keine Azure-Client-ID und keine Principal-ID.

### 7.2 Backendzugriff und Ressourcenverwaltung sind getrennt

| Zugriff | Wofür? | Was geprüft werden muss |
|---|---|---|
| State-Datenebene | State lesen/schreiben und sperren. | Passende Blob-Rechte beziehungsweise bestätigtes Authentifizierungsverfahren auf dem bestehenden Backend. |
| Azure-Managementebene | Ressourcen lesen, erstellen und verändern. | Für die jeweiligen Terraform-Ressourcen notwendige Rollen und Scopes. |
| Weitere Datenebenen | Beispielsweise Key Vault, Storage oder App Configuration durch die Provider lesen. | Welche Module solche Aufrufe im Plan/Apply tatsächlich durchführen. |
| Rollenverwaltung | Rollenzuweisungen anlegen. | Gesonderte Berechtigung beziehungsweise delegierte Bedingungen, nicht einfach voraussetzen. |
| Netzwerk | Dienste tatsächlich erreichen. | DNS, Routing, Firewall und private Endpunkte vom echten Runner aus. |

Eine Managementrolle allein ist nicht automatisch ein Entra-basierter Blob-Datenzugriff. Für einen simplen Metadatenlesetest genügt eine passende Leseberechtigung; der Terraformbetrieb benötigt darüber hinaus unter anderem Schreib-/Lease-Fähigkeit. Microsoft trennt diese Ebenen ausdrücklich. [W13]

### 7.3 Ein konkreter Fallstrick in eurer Konfiguration

In eurem **Provider** steht:

```hcl
provider "azurerm" {
  storage_use_azuread = true
}
```

Im **Backend** ist dagegen kein explizites `use_azuread_auth` enthalten. Das sind getrennte Konfigurationen. Aus dem Providerwert folgt nicht, wie der Statezugriff authentifiziert wird. Umgebungsvariablen oder zusätzliche Backendargumente können das Laufzeitverhalten beeinflussen. [S01]

Die alte Pipeline exportiert `ARM_CLIENT_ID`, `ARM_CLIENT_SECRET`, `ARM_SUBSCRIPTION_ID` und `ARM_TENANT_ID` aus ihrer Service Connection. Diese Variablen werden nicht durch einen Git-Push nach GitLab übertragen. Der neue Authentifizierungsweg muss mit der zentral bereitgestellten Azure-GitLab-Integration übereinstimmen. [S08–S09]

Für Entra-basierten Backendzugriff kennt Terraform `use_azuread_auth` beziehungsweise `ARM_USE_AZUREAD`. Die offizielle Backenddokumentation nennt `Storage Blob Data Contributor` am Container als empfohlene Datenrolle. Bei Key-Lookup oder zusätzlichen Endpoint-Abfragen gelten andere Anforderungen. **Kein ungeprüfter Wechsel auf OIDC, Access Keys oder eine pauschale Owner-Rolle:** zuerst den tatsächlich bereitgestellten Weg feststellen. [W01]

### 7.4 Der Statezugang selbst ist schützenswert

Alle im selben Container lesbaren States können vertrauliche Informationen mehrerer Anwendungen enthalten. Ein Verzeichnisprefix wie `dev/applications/mashub` ist für sich allein kein Beweis einer Berechtigungsgrenze. Die effektiven Rollen prüfen und Credentials für TEST/PROD nicht beliebigen ungeprüften Feature-Branch-Jobs verfügbar machen.

Daraus folgt für das Zielbild: Nicht nur der manuelle Apply-Button, sondern auch Pipelinecode, Inputs, Includes, Statezugriff und Variablen müssen geschützt werden. Das ist ein Umsetzungsvorschlag aus eurer verlangten Trennung von Build und Infra, kein Nachweis bereits vorhandener GitLab-Einstellungen.

## 8. Vor dem ersten Terraform-Aufruf: den Bestand nur lesen

### 8.1 Im Azure Portal

Für DEV den Account **`sawd514852ab080b6472`** in der oben genannten Subscription suchen. Unter **Datenspeicher / Container → `terraform-state`** die erwarteten Blobnamen kontrollieren, beispielsweise:

```text
dev/applications/mashub/identity/terraform.tfstate
```

Wenn Account, Container oder Blob fehlt: nicht automatisch neu anlegen. Erst mit der bisherigen Pipeline vergleichen, ob Subscription, Konto, Workspace, effektiver Key und Berechtigung stimmen. Ein nicht sichtbares Objekt kann auch ein Rechte- oder Netzwerkproblem sein.

Nur Metadaten erfassen: Name, Größe, Änderungszeit, ETag, gegebenenfalls Versions-ID und Leasezustand. Das bestätigt die Existenz des Objekts, **nicht** die Richtigkeit des kompletten Stateinhalts.

### 8.2 Optional: mit Azure CLI dieselben Blobmetadaten lesen

Voraussetzung: freigegebene Azure-CLI-Anmeldung und Zugriff vom verwendeten Rechner. Folgender Aufruf liest nur Metadaten des bekannten DEV-Identity-Blobs und verlangt ausdrücklich die angemeldete Entra-Identität. [W12]

```bash
az storage blob show \
  --subscription 6289fbfa-0b84-4f9e-8250-684455e9bb1a \
  --account-name sawd514852ab080b6472 \
  --container-name terraform-state \
  --name dev/applications/mashub/identity/terraform.tfstate \
  --auth-mode login \
  --query '{name:name,size:properties.contentLength,etag:properties.etag,lastModified:properties.lastModified,lease:properties.lease}' \
  --only-show-errors \
  --output json
```

Ein erfolgreicher Aufruf mit deinem persönlichen Konto beweist noch keinen erfolgreichen Zugriff der Pipelineidentität. Den späteren Runnerzugriff getrennt prüfen. Storage-Keys nicht als Ausweichlösung abrufen, nur um einen fehlgeschlagenen Test grün zu bekommen.

### 8.3 Das mitgelieferte Prüfprogramm

Im Technikordner liegen `state_metadaten_pruefen.py` und `state-inventar-aus-quellstand.json` nebeneinander. Es benötigt Python 3.10 oder neuer. Ohne `--azure` erfolgt **keine** Netzwerkabfrage:

```bash
python3 state_metadaten_pruefen.py --env dev --unit identity
```

Nach Freigabe und vorhandener Azure-CLI-Anmeldung kann derselbe Check Metadaten aus Azure lesen:

```bash
python3 state_metadaten_pruefen.py --env dev --unit identity --azure
```

Das Programm ruft dann ausschließlich `az account show`, `az storage account show` und `az storage blob show` auf. Es verwendet keine Storage-Keys, lädt keinen Stateinhalt herunter, startet kein Terraform und ändert weder Ressourcen noch Leases. Bei falscher Subscription, falscher Ressourcen-ID, fehlendem Blob oder Fehler bricht es ab.

Für den Storage-Account-Abgleich benötigt es zusätzlich Management-Leserechte. Ein Fehler an dieser Stelle beweist nicht automatisch fehlende Blob-Datenrechte. Die Meldung unterscheidet die Prüfschritte.

Optional einen lokalen Bericht speichern:

```bash
python3 state_metadaten_pruefen.py --env dev --unit identity --azure \
  --output statecheck-dev-identity.json
```

Vorhandene Berichte werden nicht überschrieben. Auch ein positiver Bericht ist nur ein **Metadaten-Nachweis**. State-Lineage, serial, Ressourcenzuordnung, Workspace sowie Lock- und Schreibrechte werden damit nicht geprüft.

## 9. Die technische Ausgangsbasis festhalten

Bevor Terraform aus GitLab läuft, mit dem bisherigen Betreiber beziehungsweise dem letzten erfolgreichen Azure-DevOps-Lauf folgende Baseline festhalten:

| Nachweis | Warum erforderlich? |
|---|---|
| Aktiver Git-Commit je Umstellung | Das alte Archiv kann hinter dem inzwischen produktiven Code zurückliegen. |
| Terraform 1.13.4 / Terragrunt 0.92.1 oder nachgewiesene aktive Nachfolger | Keine unbemerkte Änderung durch ein anderes Werkzeugimage. |
| Tatsächliche Provider- und externe Modulversionen | Constraints und fehlende Lockdateien reichen dafür nicht. |
| Backendadresse und Workspace je Unit | Neuer und alter Runner müssen denselben Bestand treffen. |
| Erwartete Ressourcenadressen und wichtige nicht geheime IDs | Verhindert die Verwechslung mit einem fremden oder leeren State. |
| State-Lineage und serial, soweit im freigegebenen Diagnoseprozess erfasst | Identität beziehungsweise Fortschritt des States dokumentieren. Nicht dafür komplette States im Ticket veröffentlichen. |
| Bestandsschutz / Backupverfahren | Wiederherstellung eines beschädigten States muss organisatorisch und technisch geklärt sein. |
| Laufende oder geplante Jobs | Keine konkurrierenden Applies, Driftläufe oder Wartungsjobs übersehen. |

**Sicherung:** Vor der schreibenden Übernahme einen konsistenten Wiederherstellungspunkt für die betroffenen States vereinbaren. Blobversionierung oder geschützte Sicherungen können dabei helfen. Ob sie auf euren drei Accounts aktiviert sind, ist aus den gelieferten Dateien nicht nachgewiesen. Azure-Blobversionierung muss tatsächlich eingerichtet sein; sie ist keine automatische Folgerung aus der Verwendung von Azure Storage. [W18]

Die Sicherung soll im freigegebenen, zugriffsgeschützten Speicher bleiben. Nicht `terraform state pull` ausführen und die komplette Ausgabe in einen allgemeinen Pipeline-Log oder dieses Chatfenster kopieren.

## 10. Der erste DEV-Plan

### Voraussetzungen

Zunächst müssen Baseline, Workspace, Backend, Netzwerk, Identität, Inputs und tatsächlich verwendete Providerauflösung geklärt sein. Das Beispiel dient der Prüfung einer **einzelnen vorhandenen Unit**, nicht dem automatischen Ausrollen der gesamten Plattform.

Als kleinen Einstieg kann die DEV-Identity-Unit geprüft werden. Bei euch ist sie über denselben Root-Include und ein eigenes Modul angebunden. Sie ist dennoch eine echte Azure-Ressource; Änderungen daran werden nicht automatisch angewendet. [S05]

### Schritt A: Versionen und den richtigen Ordner prüfen

Die folgenden Befehle sind für Bash auf einem freigegebenen Arbeitsrechner beziehungsweise Runner gedacht. Einstieg ist die Wurzel des passenden `ui-mb-infrastructure`-Checkouts.

```bash
terraform version
terragrunt --version

cat environment/.terraform-version
cat environment/.terragrunt-version

git rev-parse HEAD

test -f environment/dev/applications/mashub/identity/terragrunt.hcl
```

Erwartung aus dem Archiv: Terraform **1.13.4**, Terragrunt **0.92.1**. Andere tatsächlich freigegebene Produktivversionen nicht anhand dieser alten Datei zurückstufen, sondern die Unterschiede zuerst klären.

### Schritt B: Eine vorhandene Unit initialisieren und zuordnen

Nach der Freigabe für den Initialisierungsschritt:

```bash
cd environment/dev/applications/mashub/identity

terragrunt run -- init -input=false
terragrunt run -- workspace show
terragrunt run -- state list
```

Hier wird die vorhandene Umgebungskonfiguration genutzt. Bei Backendwechsel-Meldung, unerwartetem Workspace oder leerer Ressourcenliste abbrechen und Ursache prüfen. Keine automatische Neuanlage eines Workspaces, keine Imports und kein Apply anschließen. Die erwarteten Ressourcenadressen vorher aus der bisherigen Ausführung kennen.

Die Syntax orientiert sich am im Repository eingesetzten `terragrunt run` und an der offiziellen Referenz. Terragrunt-Aufrufe wurden hier nicht gegen euer installiertes 0.92.1 ausgeführt. Die konkrete Version und deren CLI im Runner prüfen, statt neuere Dokumentationsbeispiele ungeprüft zu übernehmen. [S08, S12–S13; W10]

### Schritt C: Nur planen und Exitcode auswerten

Im selben Unit-Verzeichnis und mit geklärten Inputs:

```bash
set -euo pipefail
umask 077
PLAN_DIR="$(mktemp -d "${TMPDIR:-/tmp}/mbportal-dev-identity-plan.XXXXXX")"

set +e
terragrunt run -- plan \
  -input=false \
  -lock-timeout=5m \
  -detailed-exitcode \
  -out="$PLAN_DIR/tfplan"
PLAN_EXIT=$?
set -e

case "$PLAN_EXIT" in
  0) printf 'Keine Unterschiede im Plan. Geschuetzter lokaler Planordner: %s\n' "$PLAN_DIR" ;;
  2) printf 'Unterschiede erkannt. NICHT anwenden; Planordner: %s\n' "$PLAN_DIR" ;;
  *) printf 'Plan fehlgeschlagen (Exitcode %s). Nicht fortsetzen.\n' "$PLAN_EXIT" >&2; exit "$PLAN_EXIT" ;;
esac
```

Bei `-detailed-exitcode` bedeutet 0: keine Änderungen, 2: Unterschiede, 1: Fehler. Ein Exitcode 2 ist kein normaler technischer Fehlschlag, aber auch keine Freigabe. Beim reinen Plattformwechsel müssen Unterschiede erklärt und ausdrücklich entschieden werden. [W06]

Die Plandatei kann sensible Werte enthalten. Sie bleibt im geschützten temporären Verzeichnis und wird nicht ins Git-Repository kopiert. Für den späteren Pipelinebetrieb benötigen wir einen kontrollierten Artefakttransport; dieses lokale Beispiel ist noch keine komplette GitLab-Pipeline.

**In dieser Anleitung gibt es bewusst keinen direkt anschließenden Apply-Block.** Der erste Nachweis ist ein korrekt zugeordneter, überprüfter Plan. Ein Apply gehört später hinter die vereinbarten Freigaben.

## 11. Von einer Unit zum vollständigen MBPortal-Stack

Nach dem erfolgreichen Einzeltest wird der bestätigte MBPortal-Scope geprüft:

```text
environment/dev/applications/mashub
```

Dort liegen mehrere Units unterhalb des Verzeichnisses. Die alte Pipeline verwendet bereits `terragrunt run --all` und speichert Pläne mit `--out-dir`. Die MBPortal-Deploymentpipeline setzt `doPublishPlan` standardmäßig auf `true`; der spätere Apply setzt bei aktivierter Nutzung `TG_OUT_DIR` auf den heruntergeladenen Planordner. Der Pfad zur Nutzung gespeicherter Pläne ist also im bisherigen Code angelegt. [S08–S10]

### Warum das gelieferte `tgtf` noch nicht unverändert passt

| Fund im gelieferten Standardtemplate | Notwendige Entscheidung für eure Migration |
|---|---|
| Standardaufruf eines einzelnen Plans direkt in `environment/dev` | Euren Mehr-Unit-Scope und die Abhängigkeitsreihenfolge abbilden. |
| Apply als `terragrunt apply --auto-approve` ohne übergebenen gespeicherten Plan | Ausschließlich die überprüften Pläne wiederverwenden, nicht ungeprüft neu planen. |
| `resource_group` im Planjob, nicht entsprechend im Applyjob | Auch schreibende Jobs gegen überlappende States koordinieren. |
| Werkzeugimage wird aus Top-Level-Namespace abgeleitet | Passendes Image für `marktbearbeitungsplattform-infra` tatsächlich bereitstellen. |
| Terraform/Terragrunt im Werkzeugimage dynamisch ermittelt | Versionen passend zur Baseline festlegen. |
| `snowctl` im Image, aber kein Genehmigungsaufruf in den beiden Jobs | ServiceNow-Gate separat implementieren beziehungsweise das freigegebene zentrale Verfahren verwenden. |

Das sind Quellbefunde aus `tg-plan.yml`, `tg-apply.yml` und dem OCI-Dockerfile, keine Aussagen über zusätzliche unbekannte zentrale Policies. [S16–S18]

### Der technische Vertrag zwischen Plan und Apply

Der spätere GitLab-Ablauf muss zu jeder Freigabe festhalten:

```text
Commit + Umgebung + definierte Units
+ Terraform-/Terragrunt-/Provider-/Modulstände
+ Backendadressen und Workspace
+ erforderlicher Konfigurationsstand
+ gespeicherte native Pläne mit Prüfsummen
+ zugehörige Genehmigung / Change
```

Das ist ein vorgeschlagenes Freigabemanifest, keine bereits vorhandene Datei. Plan und Apply müssen aus derselben freigegebenen Lieferung stammen. Ein beliebiges „letztes erfolgreiches“ Planartefakt aus einem anderen Branch ist nicht ausreichend.

Bei Mehr-Unit-Ausführung dient der Planordner der Zuordnung der Pläne zu den Units. Scope und Verzeichnisaufbau müssen bei Plan und Apply gleich sein. Fehlende Pläne dürfen nicht durch einen stillen Wechsel auf automatisches Plan+Apply umgangen werden. Die aktuellen Terragrunt-Dokumente beschreiben die Verwendung von `--out-dir`; eure konkrete CLI-Version und getrennte Runner-Arbeitsverzeichnisse müssen zusätzlich getestet werden. [W10]

**Ein Plan kann nicht von DEV nach PROD befördert werden.** Jede Umgebung hat eigene Inputs, Ressourcen und States. Was unverändert über Umgebungen weitergereicht werden kann, ist ein genehmigtes Anwendungspaket. Infrastrukturpläne müssen je Umgebung erzeugt und geprüft werden.

Ein Terraform-Apply mit gespeicherter Plandatei führt diesen Plan aus, statt einen neuen interaktiven Plan zur Freigabe vorzulegen. Deshalb sind die vorgelagerten Kontrollschritte so wichtig. Nach einer relevanten Zustandsänderung oder bei einem als veraltet zurückgewiesenen Plan wird neu geplant und erneut geprüft. [W07]

## 12. Was bei der Infrastrukturmigration nicht untergehen darf

### Anwendungskonfiguration ist nicht vollständig im Infrastruktur-State

Das Function-App-Modul ignoriert im Lifecycle Änderungen an `app_settings`. Die Anwendungspipelines verwalten diesen Teil bislang separat. Eine erfolgreiche Infrastrukturpipeline beweist daher nicht, dass Backendpakete, Function-App-Settings, Frontendkonfiguration und App-Configuration-Imports bereits aus GitLab funktionieren. [S14]

Mit dem Entwicklerteam festhalten, welcher geschützte Deploymentweg diese Aufgaben übernimmt. Die bestehende Anwendungsmigration und dein Infrastruktur-Ticket hängen zusammen, haben aber unterschiedliche Abnahmekriterien.

### Drift-Erkennung mit übernehmen

Es gibt bereits eine eigene Driftpipeline. Im gelieferten Stand plant sie bei automatischen Läufen TEST/PROD und bei manuellen Läufen alle Umgebungen, jeweils über den kompletten Umgebungsbereich. Sie exportiert Plan-/Logartefakte und kann Teams benachrichtigen. [S15]

Nach der Umschaltung müssen Zeitplan, Scope, Benachrichtigung und Logschutz weiterhin geregelt sein. Kein automatisches Apply als vermeintliche „Driftreparatur“ hinzufügen. JSON-Pläne und vollständige Logs besonders auf vertrauliche Inhalte und die Zugriffsberechtigungen prüfen.

### Die neue Infra-Gruppe ist keine neue Umgebung

Ihr braucht nicht einen neuen Azure-State pro GitLab-Branch. Feature-Branches beschreiben vorgeschlagene Änderungen am vorhandenen Ziel. Ob und wie DEV automatisch ausgerollt werden darf, ist eine Freigabe- und Pipelinefrage. TEST/PROD bleiben nach eurem Zielbild geschützt und changepflichtig. Die konkrete Umsetzung ist erst nach Prüfung der bereitgestellten Plattformintegration verbindlich.

## 13. Umstellung: Schritt für Schritt

| Phase | Konkrete Arbeit | Freigabekriterium |
|---|---|---|
| **1. Inventar bestätigen** | Aktiven Code, Scope, Stateadressen, Workspace und Abhängigkeiten erfassen. | Alt und Neu beziehen sich auf denselben Bestand; keine ungeklärten Abweichungen. |
| **2. Zugriff vorbereiten** | GitLab-Gruppe, Pipelineidentität, Runner, Netzwerk und Werkzeuge bereitstellen. | Metadaten und erforderliche Abhängigkeiten vom richtigen Runner aus erreichbar. |
| **3. Baseline sichern** | Wiederherstellungspunkt, Versionen und bisherige Planergebnisse dokumentieren. | Kein ungeklärter Providerwechsel; Restoreverfahren bekannt. |
| **4. Einzel-Unit prüfen** | DEV-Unit initialisieren, Statezuordnung lesen, Plan ohne Apply. | Kein versehentlich leerer State und keine unbeabsichtigte Neuerstellung. |
| **5. DEV-Scope prüfen** | Alle vereinbarten `mashub`-Units mit derselben Baseline planen. | Unterschiede vollständig erklärt; keine Mocks als Bestandsnachweis. |
| **6. DEV-Schreibzuständigkeit umschalten** | Alte DEV-Auslieferung für diesen Scope sperren, laufende Jobs beenden lassen; freigegebener GitLab-Ablauf übernimmt. | Genau ein aktiver schreibender Auslieferungsweg. |
| **7. TEST und PROD** | Pro Umgebung denselben Nachweis wiederholen; Change, Review und Environment-Schranke aktiv. | Genehmigte umgebungsspezifische Pläne, bestätigter Betrieb und Rückfallweg. |
| **8. Nacharbeiten** | Ersetzte Trigger/Zeiten/Accounts aufräumen; Betrieb und Driftprüfung übergeben. | Kein unkontrollierter alter Applypfad bleibt zurück. |

**Keinen Test-Änderungsbedarf künstlich erzeugen.** Beim reinen CI-Wechsel kann ein korrektes Ergebnis gerade sein, dass nichts an Azure geändert werden muss. Ein zusätzliches Testtag oder eine Ressourcenerneuerung ist keine Voraussetzung, um eine korrekt angebundene Pipeline nachzuweisen.

Falls mehrere Anwendungen weiter aus demselben alten Infrastrukturrepo ausgerollt werden, deren Jobs nicht pauschal deaktivieren. Die Zuständigkeit je Scope dokumentieren. Ein alter `All`-Job, der weiterhin `mashub` einschließt, würde jedoch die neue Abgrenzung umgehen und muss angepasst oder gesperrt werden.

## 14. Fehlerbilder und Rückfallweg

### Häufige Meldungen richtig einordnen

| Beobachtung | Mögliche Ursache | Richtige erste Reaktion |
|---|---|---|
| Sehr viele `+ create`, obwohl alles existiert | Falscher Key/Workspace/Account, leere oder nicht gelesene Statebasis | Apply sperren; effektive Backendadresse mit Altbestand vergleichen. |
| Blob-/Container-404 | Falsche Adresse oder nicht vorhandenes Objekt | Nicht automatisch anlegen; bestehenden Pipelinezugriff nachvollziehen. |
| 403 / AuthorizationFailed | Rollen, Authentifizierungsmodus, Netzwerk oder falsche Identität | Daten- und Managementebene getrennt prüfen. |
| `listKeys` nicht erlaubt | Backend versucht möglicherweise Key-Lookup statt des vorgesehenen Entra-Zugangs | Authentifizierungsweg prüfen; nicht sofort mehr Rechte vergeben. |
| Timeout / DNS-Fehler | Runner erreicht private Endpunkte oder Namensauflösung nicht | Vom tatsächlichen Runner testen, nicht nur vom eigenen Laptop. |
| State lock / Lease-Konflikt | Andere Ausführung aktiv oder Sperre verwaist | Besitzer und Jobs feststellen; kein blindes Entsperren. |
| `No configuration files` | Falsches Arbeitsverzeichnis / falscher Einzelaufruf | Richtige Unit beziehungsweise Mehr-Unit-Scope verwenden. |
| Providerfehler oder unerwartete Änderungen | Abweichende Provider-/Modul-/Toolauflösung | Baseline und Lockdateien vergleichen. |
| Mock-IDs oder fehlende Dependency-Outputs | Abhängiger State fehlt, ist unlesbar oder hat andere Outputs | Bestand/Abhängigkeiten reparieren, nicht Ersatzwerte als Erfolg akzeptieren. |
| Gespeicherter Plan veraltet | State wurde seit Planerstellung geändert | Neu planen und erneut freigeben. |

Das sind Diagnosehypothesen, keine automatische Aussage über euren produktiven Fehlerfall.

### Rückfall vor dem ersten GitLab-Apply

GitLab-Schreibjobs deaktiviert lassen beziehungsweise sperren. Den bisherigen freigegebenen Auslieferungsweg weiterverwenden. Es gibt keinen Grund, wegen eines gescheiterten GitLab-Builds oder -Plans einen alten State einzuspielen. Bei unveränderter Backendnutzung bleibt der bisherige Bestand maßgeblich.

### Rückfall nach einem erfolgreichen Apply

Ein CI-Rückfall ist zuerst eine Änderung der **Ausführungsverantwortung**, nicht eine Wiederherstellung alter Zustandsdateien. Den neuesten gültigen State erhalten. Azure DevOps darf nur wieder übernehmen, wenn Code, Werkzeuge, Inputs und Berechtigungen zum aktuellen Bestand passen und GitLab nicht mehr parallel schreibt.

Eine tatsächliche Rücknahme von Infrastrukturänderungen benötigt einen neuen geprüften Plan auf Basis des aktuellen States. Nicht einfach den alten Code und eine alte Statekopie gleichzeitig zurückspielen.

### Fehler mitten im Apply

Mehrere Units bilden keine gemeinsame Datenbanktransaktion. Einige Ressourcen beziehungsweise Units können bereits geändert worden sein. Jobs stoppen beziehungsweise geordnet auslaufen lassen, den aktuellsten gültigen State und die Logs schützen und feststellen, was tatsächlich umgesetzt wurde.

Scheitert das Speichern des States nach Ressourcenänderungen, kann Terraform lokal Wiederherstellungsdaten ausgeben beziehungsweise ablegen. Solche Dateien wie `errored.tfstate` sind hochsensibel und müssen über den freigegebenen Wiederherstellungsprozess gesichert werden. Nicht beim Bereinigen eines Runners ungeprüft löschen und nicht mit einem manuellen Upload über den Remote-State schreiben. Ein Eingriff über `state push` ist eine gesonderte Reparatur mit Sicherheitsprüfungen, keine Routine der Migration. [W19–W20]

**Merksatz: Ein alter State macht eine bereits geänderte Azure-Ressource nicht wieder alt.** Eine State-Wiederherstellung ist ein gezielter Reparaturfall, kein normaler Deployment-Rollback.

## 15. Wann doch eine echte State-Migration nötig wäre

Eine echte State-Migration wäre ein eigener Arbeitsschritt, wenn ihr später beispielsweise:

- das Storagekonto, den Container oder den Backendtyp ersetzt;
- die pfadabhängige Unit-Struktur verändert;
- Ressourcen auf neue Root-Module/States verteilt oder Terraform-Adressen refaktoriert.

Dann braucht es eine gesonderte Planung für Sperrung, Sicherung, neue Adressen, konsistente Ressourcenzuordnung und Validierung. **Das nicht beiläufig während des GitLab-Onboardings mit erledigen.**

Davon zu unterscheiden ist **DBI-10553**: Bereits existierende Service-Bus-Queues, die bisher von Anwendungen und nicht von Terraform angelegt wurden, müssen gegebenenfalls erstmals in eine Terraform-Verwaltung übernommen werden. Dieser Import kann für diese Story notwendig sein. Er ist aber kein Argument, alle bereits verwalteten Infrastrukturressourcen für den GitLab-Wechsel neu zu importieren.

## 16. Abnahmecheckliste für eure Infrastruktur-Story

```text
[ ] Neuer Projektpfad und Zuständigkeiten bestätigt.
[ ] Aktiver Code-/Branch-/Commitstand aus Azure DevOps übernommen.
[ ] Interne Terragrunt-Pfade und Backendadressen nicht unbeabsichtigt geändert.
[ ] Workspace je Ziel bestätigt; keine neue Workspace-Struktur eingeführt.
[ ] Erwartete vorhandene States und Ressourcenzuordnungen nachgewiesen.
[ ] Terraform-/Terragrunt-/Provider-/Modulstände reproduzierbar.
[ ] Pipelineidentität, Backendauthentifizierung und Azure-Rechte getrennt geprüft.
[ ] Netzwerk/DNS vom echten GitLab-Runner geprüft.
[ ] Keine produktiven Zugangsdaten in ungeprüften Branch-Jobs verfügbar.
[ ] Wiederherstellungspunkt und geschützter Umgang mit State/Plan geklärt.
[ ] DEV-Einzel-Unit und vereinbarter MBPortal-Scope ohne unerklärte Diffs geplant.
[ ] Scope, Commit und native Planartefakte eindeutig dem Apply zugeordnet.
[ ] Fehlende/veraltete Pläne führen zum Abbruch, nicht zu einem stillen Neuplan.
[ ] Review, ServiceNow-Gate und geschützte TEST/PROD-Auslieferung nachgewiesen.
[ ] Überlappende GitLab-Jobs serialisiert; alter Applypfad für den Scope gesperrt.
[ ] Umgang mit partiellen Applies und Pipeline-Rückfall dokumentiert.
[ ] App Settings / Anwendungsauslieferung mit Entwicklerteam abgegrenzt.
[ ] Driftzeitplan, Benachrichtigung, Log-/Artefaktzugriff übernommen.
[ ] DEV, TEST und PROD separat abgenommen.
```

## 17. Was bekannt ist und was wir noch nachweisen müssen

**Bereits aus dem Quellstand bekannt:** Zielname, Azure-Backendtyp, drei Backendkonten, Container, Subscriptions, Unit-Pfade, Key-Formel, MBPortal-Scope, Tooldateien, Pipeline-Grundablauf und die ignorierten Provider-Lockdateien. Diese Angaben musst du nicht erneut zusammensuchen.

**Noch offen:** Tatsächlich aktiver Commit, echte Workspace-/Blobzuordnung, Stateinhalt beziehungsweise Ressourcenabgleich, zuletzt aufgelöste Provider-/Modulversionen, effektive GitLab-Anmeldung, Variablen-Scopes, Rollen, Netzwerkerreichbarkeit, Backupfunktion und wirksame Freigabeintegration.

Dafür reichen zunächst bereinigte Metadaten und gezielte Prüfergebnisse. Keine Azure-Zugangsdaten, vollständigen States, privaten Zertifikatschlüssel oder unbereinigten Plan-JSON-Dateien in den Chat laden.

**Dein erster technischer Schritt nach dem organisatorischen Onboarding:** Den DEV-Statepfad aus Kapitel 3 gegen die bisherige Ausführung bestätigen und den Metadatencheck aus Kapitel 8 durchführen. Erst anschließend die Initialisierung und den Plan einer einzelnen Unit vorbereiten.

## 18. Dateien, Quellen und Prüfstatus

### Paketinhalt

| Datei | Inhalt |
|---|---|
| `Technik_State_Terragrunt_GitLab.md` | Diese vollständige Anleitung. |
| `Quellen_Originalauszuege.md` | Originalauszüge mit Zeilennummern und SHA-256 der Quelldateien. |
| `state-inventar-aus-quellstand.json` | Drei Backendkonfigurationen und 64 erwartete Standard-Workspace-Keys für `mashub`. Keine Liveinventur. |
| `state_metadaten_pruefen.py` | Optionaler Offline-/Read-only-Azure-Metadatencheck. |
| `tests/test_state_metadaten.py` | 12 lokale Tests für Fehlerbehandlung, Scope, Credentialvermeidung und CLI-Aufrufe. |
| `README.md` | Einstieg und Testhinweise. |

### Quellregister für den konkreten Repositorybestand

Alle nachfolgenden `S`-Quellen sind aus `marktbearbeitung.zip > marktbearbeitung/ui-mb-infrastructure/`, außer S16–S18 aus `web-portale-templates.7z`.

| ID | Quelldatei / Bereich |
|---|---|
| S01 | `environment/root.hcl`, Z. 1–8, 26–66: Inputs, Provider, Backend und Key. |
| S02–S04 | `environment/dev/env.hcl`, `environment/test/env.hcl`, `environment/prod/env.hcl`, jeweils Z. 1–12. |
| S05 | `environment/dev/applications/mashub/identity/terragrunt.hcl`, Z. 1–11. |
| S06 | `environment/_apps/mashub/service-bus.hcl`, Z. 1–27 und 85–96: Abhängigkeiten/Identitäten. |
| S07 | `ci/templates/steps.setup.yml`, Z. 27–44, 55–70, 107–111. |
| S08 | `ci/templates/stages.validate-infrastructure.yml`, Z. 34–69. |
| S09 | `ci/templates/stages.deploy-infrastructure.yml`, insbesondere Z. 14–40 und 59–101. |
| S10 | `ci/pipeline.deploy-mbportal.yml`: Default-Scope und Planübergabe. |
| S11 | `.gitignore`, Z. 1–6 und 40–52. |
| S12–S13 | `environment/.terraform-version` und `environment/.terragrunt-version`, jeweils Z. 1. |
| S14 | `modules/functionapp/main.tf`, Z. 191–207: Lifecycle/App Settings. |
| S15 | `ci/templates/stages.drift-check.yml`, Z. 1–12, 78–106 und 139–165. |
| S16–S17 | `web-portale-templates/pipelines/tgtf/tg-plan.yml` und `tg-apply.yml`. |
| S18 | `web-portale-templates/cicd/oci/Dockerfile`. |
| S19 | Dateiinventur der Units unter `environment/{dev,test,prod}/applications/`. |

Die interne Migrationsanleitung vom 27.10.2026 und `Zukunftsdesign.html` begründen die organisatorische Trennung und das Freigabeziel. Sie legen keinen Wechsel eures vorhandenen Azure-State-Backends fest. Der Beibehalt ist deshalb als technischer Umsetzungsvorschlag beschrieben, nicht als wörtliche Vorgabe ausgegeben.

### Ergänzende offizielle Dokumentation, abgerufen am 27.10.2026

Die Dokumentation erklärt die Mechanismen. Ihre aktuelle CLI-Version ist nicht automatisch eure freigegebene Version; zuerst den oben genannten Repository-/Runnerstand abgleichen.

- **W01 – AzureRM-Backend, Stateablage und Authentifizierungsoptionen:** https://developer.hashicorp.com/terraform/language/backend/azurerm
- **W02 – Zweck des Terraform-States:** https://developer.hashicorp.com/terraform/language/state/purpose
- **W03 – Terraform-Workspaces:** https://developer.hashicorp.com/terraform/language/state/workspaces
- **W04 – State-Locking und Entsperren:** https://developer.hashicorp.com/terraform/language/state/locking
- **W05 – `terraform init`:** https://developer.hashicorp.com/terraform/cli/commands/init
- **W06 – `terraform plan`:** https://developer.hashicorp.com/terraform/cli/commands/plan
- **W07 – `terraform apply`:** https://developer.hashicorp.com/terraform/cli/commands/apply
- **W08 – Provider-Lockdatei:** https://developer.hashicorp.com/terraform/language/files/dependency-lock
- **W09 – Sensible Daten in Terraform:** https://developer.hashicorp.com/terraform/language/manage-sensitive-data
- **W10 – Terragrunt `run`, Scope und gespeicherte Pläne:** https://docs.terragrunt.com/reference/cli/commands/run/
- **W11 – Terragrunt-Funktionen, insbesondere `path_relative_to_include`:** https://docs.terragrunt.com/reference/hcl/functions/
- **W12 – Azure CLI, `az storage blob show`:** https://learn.microsoft.com/en-us/cli/azure/storage/blob
- **W13 – Azure Blob-Datenrollen:** https://learn.microsoft.com/en-us/azure/storage/blobs/assign-azure-role-data-access
- **W14 – GitLab Resource Groups:** https://docs.gitlab.com/ci/resource_groups/
- **W15 – Terraform-State in Azure Storage:** https://learn.microsoft.com/en-us/azure/developer/terraform/store-state-in-azure-storage
- **W16 – Terragrunt-Hooks:** https://docs.terragrunt.com/features/units/hooks/
- **W17 – Terragrunt-Blöcke, Dependencies und Mocks:** https://docs.terragrunt.com/reference/hcl/blocks/
- **W18 – Azure Blob-Versionierung:** https://learn.microsoft.com/en-us/azure/storage/blobs/versioning-overview
- **W19 – State-Speicherung und Fehler beim Remote-Speichern:** https://developer.hashicorp.com/terraform/language/state/backends
- **W20 – Manuelle State-Wiederherstellung und Sicherheitsprüfungen:** https://developer.hashicorp.com/terraform/cli/commands/state/push

**Zusammengefasst:** Neuer GitLab-Ausführungsweg, vorhandener Azure-State, gleiche Ressourcenzuordnung. Erst lesend nachweisen, dann kontrolliert planen, erst nach Freigabe schreiben. Keine automatische Neuerstellung, kein pauschaler Import und kein Wiederherstellen alter States als normaler CI-Rückfall.
