# Quellenanhang: Terraform-State und GitLab-Umstellung

Stand 27.10.2026. Die Auszüge stammen aus den hochgeladenen Archiven. Sie sind keine Bestätigung des aktuellen Azure-Bestands. Quellcode wurde gelesen, nicht ausgeführt.

## S01: `environment/root.hcl`

Archiv: `marktbearbeitung.zip` > `marktbearbeitung/ui-mb-infrastructure/environment/root.hcl`  
SHA-256: `2d8fd07de6960d330a4bfa925dd87fdaf8114123a067be325be2b0cef3e820d5`

```text
1: locals {
2:   # Load environment- and app-level variables
3:   environment_vars = read_terragrunt_config(find_in_parent_folders("env.hcl"))
4:   app_vars         = read_terragrunt_config(find_in_parent_folders("app.hcl"))
5: 
6:   workload_name        = local.environment_vars.locals.workload
7:   workload_environment = local.environment_vars.locals.environment
8:   subscription_id      = local.environment_vars.locals.subscription_id
```

```text
26: # Generate an AzureRM provider block
27: generate "provider" {
28:   path      = "provider.tf"
29:   if_exists = "overwrite_terragrunt"
30:   contents  = <<EOF
31: terraform {
32:   required_version = "~> 1.13"
33:   required_providers {
34:     azurerm = {
35:       source = "hashicorp/azurerm"
36:       version = "~>4.64"
37:     }
38:   }
39: }
40: 
41: provider "azurerm" {
42:   storage_use_azuread = true
43:   subscription_id = "${local.subscription_id}"
44:   features {
45:     resource_group {
46:       prevent_deletion_if_contains_resources = false
47:     }
48:   }
49: }
50: EOF
51: }
52: 
53: remote_state {
54:   backend = "azurerm"
55:   generate = {
56:     path      = "backend.tf"
57:     if_exists = "overwrite"
58:   }
59:   config = {
60:     subscription_id      = "${local.subscription_id}"
61:     key                  = "${path_relative_to_include()}/terraform.tfstate"
62:     resource_group_name  = local.environment_vars.locals.backend_resource_group_name
63:     storage_account_name = local.environment_vars.locals.backend_storage_account_name
64:     container_name       = local.environment_vars.locals.backend_container_name
65:   }
66: }
```

## S02: `environment/dev/env.hcl`

Archiv: `marktbearbeitung.zip` > `marktbearbeitung/ui-mb-infrastructure/environment/dev/env.hcl`  
SHA-256: `1410bc2db35ffb860fe55dac8409b5f8a79430abd2e78894245e4bd44a2cb453`

```text
1: locals {
2:   backend_container_name       = "terraform-state"
3:   backend_storage_account_name = "sawd514852ab080b6472"
4:   backend_resource_group_name  = "rg-marktbearbeitung-dev-managed-resources"
5: 
6:   workload        = "MARKTBEARBEITUNG"
7:   environment     = "dev"
8:   subscription_id = "6289fbfa-0b84-4f9e-8250-684455e9bb1a"
9: 
10:   tags = {
11:     environment = local.environment
12:   }
```

## S03: `environment/test/env.hcl`

Archiv: `marktbearbeitung.zip` > `marktbearbeitung/ui-mb-infrastructure/environment/test/env.hcl`  
SHA-256: `d12ff1890e85b7f7be8e88f8c78cf3ad180e6c51b5d16b9d932a925a369c8486`

```text
1: locals {
2:   backend_container_name       = "terraform-state"
3:   backend_storage_account_name = "sawd345ade3fb4f39a5a"
4:   backend_resource_group_name  = "rg-marktbearbeitung-test-managed-resources"
5: 
6:   workload        = "MARKTBEARBEITUNG"
7:   environment     = "test"
8:   subscription_id = "d98221c3-b24d-4770-a9a3-3716667d7353"
9: 
10:   tags = {
11:     environment = local.environment
12:   }
```

## S04: `environment/prod/env.hcl`

Archiv: `marktbearbeitung.zip` > `marktbearbeitung/ui-mb-infrastructure/environment/prod/env.hcl`  
SHA-256: `cf7dda5d55865863f85b22afcc9eadddf37c8b94e0ca5b1a318b40f4421ffeb1`

```text
1: locals {
2:   backend_container_name       = "terraform-state"
3:   backend_storage_account_name = "sawde3af87e25f0be60c"
4:   backend_resource_group_name  = "rg-marktbearbeitung-prod-managed-resources"
5: 
6:   workload        = "MARKTBEARBEITUNG"
7:   environment     = "prod"
8:   subscription_id = "a6c520e0-a1af-4c4c-82f0-8482ff82ecd8"
9: 
10:   tags = {
11:     environment = local.environment
12:   }
```

## S05: `environment/dev/applications/mashub/identity/terragrunt.hcl`

Archiv: `marktbearbeitung.zip` > `marktbearbeitung/ui-mb-infrastructure/environment/dev/applications/mashub/identity/terragrunt.hcl`  
SHA-256: `6774042d2b1602d372539909018b2b69d6be89a3d18004a2370e8ac5f64f5b3c`

```text
1: include "root" {
2:   path           = find_in_parent_folders("root.hcl")
3:   merge_strategy = "deep"
4: }
5: 
6: include "app" {
7:   path           = "${get_terragrunt_dir()}/../../../../_apps/mashub/identity.hcl"
8:   merge_strategy = "deep"
9: }
10: 
11: inputs = {}
```

## S06: `environment/_apps/mashub/service-bus.hcl`

Archiv: `marktbearbeitung.zip` > `marktbearbeitung/ui-mb-infrastructure/environment/_apps/mashub/service-bus.hcl`  
SHA-256: `89189eef6902e22fa0dfca5b6227fdd1c70db412b917cfbf56a52460d46f38b9`

```text
1: terraform {
2:   source = "../../../../../modules//servicebus"
3: }
4: 
5: dependency "identity" {
6:   config_path = "${get_terragrunt_dir()}/../identity"
7:   mock_outputs = {
8:     resource_id  = "/subscriptions/12345678-1234-9876-4563-123456789012/resourceGroups/example-resource-group/providers/Microsoft.ManagedIdentity/userAssignedIdentities/identityValue"
9:     principal_id = "12345678-1234-1234-1234-123456789012"
10:   }
11: }
12: 
13: dependency "datenprodukt_identity" {
14:   config_path = "${get_terragrunt_dir()}/../datenprodukt-identity"
15:   mock_outputs = {
16:     resource_id  = "/subscriptions/12345678-1234-9876-4563-123456789012/resourceGroups/example-resource-group/providers/Microsoft.ManagedIdentity/userAssignedIdentities/identityValue"
17:     principal_id = "12345678-1234-1234-1234-123456789012"
18:   }
19: }
20: 
21: dependency "monitoring" {
22:   config_path = "${get_terragrunt_dir()}/../monitoring"
23: 
24:   mock_outputs = {
25:     resource_id = "/subscriptions/12345678-1234-9876-4563-123456789012/resourceGroups/example-resource-group/providers/Microsoft.OperationalInsights/workspaces/workspaceValue"
26:   }
27: }
```

```text
85:   role_assignments = {
86:     uai_owner = {
87:       principal_id         = dependency.identity.outputs.principal_id
88:       role_definition_name = "Azure Service Bus Data Owner"
89:       description          = "User Assigned Identity has Owner Role on Service Bus"
90:     }
91:     datenprodukt_identity_owner = {
92:       principal_id         = dependency.datenprodukt_identity.outputs.principal_id
93:       role_definition_name = "Azure Service Bus Data Owner"
94:       description          = "Datenprodukt Identity has Owner Role on Service Bus"
95:     }
96:   }
```

## S07: `ci/templates/steps.setup.yml`

Archiv: `marktbearbeitung.zip` > `marktbearbeitung/ui-mb-infrastructure/ci/templates/steps.setup.yml`  
SHA-256: `7e257946c3c6427216e2646ff7cc5819025b858ccaa1f5f3c9c169896fa85cdb`

```text
27:         case $APP in
28:           'All' ) appDir=$(echo ".")
29:                   echo "Request App 'All'"; ;;
30: 
31:           'IW Beratungsunterstützung' ) appDir=$(echo "applications/beratungsunterstuetzung")
32:                                         echo "Process App 'IW Beratungsunterstützung' in dir $appDir"; ;;
33:           'IW Marktbearbeitung' ) appDir=$(echo "applications/marktbearbeitung")
34:                                   echo "Process App 'IW Marktbearbeitung' in dir $appDir"; ;;
35:           'MB Portal' ) appDir=$(echo "applications/mashub")
36:                         echo "Process App 'MB Portal' in dir $appDir"; ;;
37:           'Plattform' ) appDir=$(echo "applications/plattform")
38:                         echo "Process App 'Plattform' in dir $appDir"; ;;
39:           'Verbundschnittstelle' )  appDir=$(echo "applications/verbundintegration")
40:                                     echo "Process App 'Verbundschnittstelle' in dir $appDir"; ;;
41:           'IM Action Hub' )  appDir=$(echo "applications/im-action-hub")
42:                              echo "Process App 'IM Action Hub' in dir $appDir"; ;;
43:           'UBA-Anbindung' )  appDir=$(echo "applications/uba-anbindung")
44:                              echo "Process App 'UBA-Anbindung' in dir $appDir"; ;;
```

```text
55:   - task: Bash@3
56:     displayName: "Directory Setup"
57:     inputs:
58:       targetType: "inline"
59:       script: |
60:         terragruntBaseDir=$(echo "environment")
61:         terragruntWorkingDir=$(echo "${{ parameters.environment }}/$(APP_SELECTION)" | tr "[:upper:]" "[:lower:]")
62:         # terragruntAppStackDir=$(echo "$(APP_SELECTION)" | tr "[:upper:]" "[:lower:]")
63:         terragruntConfigDir=$(echo "$terragruntBaseDir/$terragruntWorkingDir")
64:         if [[ -d "$terragruntConfigDir" ]]
65:           then
66:             echo "Initialize Terragrunt in directory (PIPE_BASE_DIR): $terragruntBaseDir"
67:             echo "Use Terragrunt Config in directory (PIPE_WORKING_DIR): $terragruntWorkingDir"
68:             # echo "Process App-Stack in directory (PIPE_STACK_DIR): $terragruntAppStackDir"
69:             echo "##vso[task.setvariable variable=PIPE_BASE_DIR;]${terragruntBaseDir}"
70:             echo "##vso[task.setvariable variable=PIPE_WORKING_DIR;]${terragruntWorkingDir}"
```

```text
107:     displayName: "Install required Terraform & Terragrunt versions"
108:     inputs:
109:       targetType: "inline"
110:       script: |
111:         cd $(PIPE_BASE_DIR) && TFENV_CURL_OUTPUT=0 tfenv install && tgenv install
```

## S08: `ci/templates/stages.validate-infrastructure.yml`

Archiv: `marktbearbeitung.zip` > `marktbearbeitung/ui-mb-infrastructure/ci/templates/stages.validate-infrastructure.yml`  
SHA-256: `4d4c0a4c0869a5c4b4b619497617b2cf52432485c5b8eb5faf125daa9475399b`

```text
34:           - task: AzureCLI@2
35:             displayName: "Validate/Plan Terraform configuration"
36:             inputs:
37:               azureSubscription: "${{ variables.subscriptionName }}"
38:               scriptType: "bash"
39:               scriptLocation: "InlineScript"
40:               addSpnToEnvironment: true
41:               inlineScript: |
42:                 export ARM_CLIENT_ID=$servicePrincipalId
43:                 export ARM_CLIENT_SECRET=$servicePrincipalKey
44:                 export ARM_SUBSCRIPTION_ID=$(az account show --query id | xargs)
45:                 export ARM_TENANT_ID=$(az account show --query tenantId | xargs)
46: 
47:                 outDir=$(echo "$(Pipeline.Workspace)/tfplan")
48:                 echo "##vso[task.setvariable variable=TFPLAN_OUT_DIR;]${outDir}"
49: 
50:                 base_cmd=$(echo "terragrunt run --all --non-interactive --queue-exclude-external --provider-cache --provider-cache-dir $(Agent.TempDirectory)/tg_cache_dir --provider-cache-registry-names registry.terraform.io")
51: 
52:                 echo "Terragrunt Working Dir: $(PIPE_WORKING_DIR)"
53:                 echo "Terragrunt Plan Dir: $outDir"
54:                 echo " --- --- ---"
55:                 echo
56:                 echo "Validating terragrunt config in $(PIPE_BASE_DIR)/$(PIPE_WORKING_DIR)"
57: 
58:                 cd $(PIPE_BASE_DIR)/$(PIPE_WORKING_DIR)
59:                 $base_cmd validate
60: 
61:                 echo " --- --- ---"
62:                 echo
63:                 echo "Run Plan"
64:                 $base_cmd --out-dir $outDir --json-out-dir $outDir plan
65: 
66:           - publish: $(TFPLAN_OUT_DIR)
67:             condition: and(succeeded(), ${{ parameters.doPublishPlan }})
68:             artifact: tfplan
69:             displayName: "Publish terraform plan"
```

## S09: `ci/templates/stages.deploy-infrastructure.yml`

Archiv: `marktbearbeitung.zip` > `marktbearbeitung/ui-mb-infrastructure/ci/templates/stages.deploy-infrastructure.yml`  
SHA-256: `3c6c1e43bc63fd2ff6ca5c3633ded945974de656258d043e7e095508e552a701`

```text
14:     # Allow deployments to TEST and PROD from main-branch only.
15:     condition: >-
16:       and(
17:         succeeded(),
18:         or(
19:           eq('${{ parameters.environment }}', 'DEV'),
20:           and(
21:             or(eq('${{ parameters.environment }}', 'TEST'), eq('${{ parameters.environment }}', 'PROD')),
22:             eq(variables['Build.SourceBranchName'], 'main')
23:           )
24:         )
25:       )
26:     jobs:
27:       - job: Approval
28:         displayName: "Wait for approval of deployment to ${{ parameters.environment }}"
29:         pool: server # i.e. an agentless job
30:         timeoutInMinutes: 45
31:         condition: >-
32:           and(succeeded(), or(eq('${{ parameters.environment }}', 'TEST'), eq('${{ parameters.environment }}', 'PROD')))
33:         steps:
34:           - task: ManualValidation@1
35:             displayName: "Approval"
36:             timeoutInMinutes: 30
37:             inputs:
38:               notifyUsers: ""
39:               instructions: "Please check the tfplan and approve its deployment into the ${{ parameters.environment }} environment."
40:               onTimeout: "reject"
```

```text
59:           - download: current
60:             displayName: "Download tfplan"
61:             condition: and(succeeded(), eq(${{parameters.usePublishedPlan}}, true))
62:             artifact: tfplan
```

```text
70:           - task: AzureCLI@2
71:             displayName: "Execute terragrunt apply"
72:             env:
73:               USE_PLAN: ${{ parameters.usePublishedPlan }}
74:             inputs:
75:               azureSubscription: "${{ variables.subscriptionName }}"
76:               scriptType: "bash"
77:               scriptLocation: "InlineScript"
78:               addSpnToEnvironment: true
79:               inlineScript: |
80:                 export ARM_CLIENT_ID=$servicePrincipalId
81:                 export ARM_CLIENT_SECRET=$servicePrincipalKey
82:                 export ARM_SUBSCRIPTION_ID=$(az account show --query id | xargs)
83:                 export ARM_TENANT_ID=$(az account show --query tenantId | xargs)
84: 
85:                 echo "Terragrunt Working Dir: $(PIPE_WORKING_DIR)"
86:                 echo " --- --- ---"
87:                 echo
88:                 # conditional TG parameters
89:                 if [[ "${USE_PLAN,,}" == "true" ]];
90:                   then
91:                     outDir=$(echo "$(Pipeline.Workspace)/tfplan") ## the one from 'Download' task
92: 
93:                     export TG_OUT_DIR=$outDir
94:                     echo "Use existing tfplan-files in Dir: $outDir"
95:                     echo "Apply existing plan for terragrunt config in $(PIPE_BASE_DIR)/$(PIPE_WORKING_DIR)"
96:                   else
97:                     echo "Apply terragrunt config in $(PIPE_BASE_DIR)/$(PIPE_WORKING_DIR)"
98:                 fi
99: 
100:                 cd $(PIPE_BASE_DIR)/$(PIPE_WORKING_DIR)
101:                 terragrunt apply --all --non-interactive --queue-exclude-external --provider-cache --provider-cache-dir $(Agent.TempDirectory)/tg_cache_dir --provider-cache-registry-names registry.terraform.io
```

## S10: `ci/pipeline.deploy-mbportal.yml`

Archiv: `marktbearbeitung.zip` > `marktbearbeitung/ui-mb-infrastructure/ci/pipeline.deploy-mbportal.yml`  
SHA-256: `82453a23334762a1b775b5953f30c48ff8b6e62fa2f79958854297ba36be955e`

```text
1: trigger: none # No automated runs
2: 
3: parameters:
4:   - name: "environment"
5:     displayName: "Workload Environment to apply to"
6:     type: string
7:     default: DEV
8:     values:
9:       - DEV
10:       - TEST
11:       - PROD
12:   - name: "application"
13:     displayName: "Application Name to apply"
14:     type: string
15:     default: "MB Portal"
16:     values:
17:       - "MB Portal"
18:   - name: "workload"
19:     displayName: "Workload"
20:     type: string
21:     default: MARKTBEARBEITUNG
22:     values:
23:       - MARKTBEARBEITUNG
24:   - name: "doPublishPlan"
25:     displayName: "Use tfplan during apply"
26:     type: boolean
27:     default: true
28: 
29: stages:
30:   - template: templates/stages.validate-infrastructure.yml
31:     parameters:
32:       workload: ${{ parameters.workload }}
33:       environment: ${{ parameters.environment }}
34:       application: ${{ parameters.application }}
35:       doPublishPlan: ${{ parameters.doPublishPlan }}
36: 
37:   - template: templates/stages.deploy-infrastructure.yml
38:     parameters:
39:       workload: ${{ parameters.workload }}
40:       environment: ${{ parameters.environment }}
41:       application: ${{ parameters.application }}
42:       usePublishedPlan: ${{ parameters.doPublishPlan }}
```

## S11: `.gitignore`

Archiv: `marktbearbeitung.zip` > `marktbearbeitung/ui-mb-infrastructure/.gitignore`  
SHA-256: `e144fea9d82e12ead1e17c04b21ee214e9775b4158597cf470c13017c29b0867`

```text
1: # Local .terraform directories
2: **/.terraform/*
3: 
4: # .tfstate files
5: *.tfstate
6: *.tfstate.*
```

```text
40: # Ignore terragrunt cache directories
41: .terragrunt-cache
42: 
43: # Ignore providers.tf?
44: providers.tf
45: 
46: # Ignore terraform plans
47: tfplan
48: tfplan.json
49: tfplan.txt
50: 
51: # Ignore terraform lock files
52: .terraform.lock.hcl
```

## S12: `environment/.terraform-version`

Archiv: `marktbearbeitung.zip` > `marktbearbeitung/ui-mb-infrastructure/environment/.terraform-version`  
SHA-256: `7271649782b35cb0f95c6fba1a16558af18484876eb4db660f1f1c69e6e9c752`

```text
1: 1.13.4
```

## S13: `environment/.terragrunt-version`

Archiv: `marktbearbeitung.zip` > `marktbearbeitung/ui-mb-infrastructure/environment/.terragrunt-version`  
SHA-256: `e2838ed7c5be2511406357f78c090db048de374a32b51d4fa35f278e339dd55b`

```text
1: 0.92.1
```

## S14: `modules/functionapp/main.tf`

Archiv: `marktbearbeitung.zip` > `marktbearbeitung/ui-mb-infrastructure/modules/functionapp/main.tf`  
SHA-256: `0de6f7de519fde613eba1ba82ea1568d3ecb1b8d995810e477ea198d61801d0d`

```text
191:   # App Settings with Key Vault reference for client secret (only when auth is enabled and client_secret_setting_name is set)
192:   app_settings = var.auth_settings != null && var.auth_settings.client_secret_setting_name != null ? {
193:     "${var.auth_settings.client_secret_setting_name}" = var.auth_settings.client_secret_keyvault_reference
194:   } : {}
195: 
196:   tags = local.func_tags
197: 
198:   lifecycle {
199:     ignore_changes = [
200:       # Ignore app_settings changes except for the auth secret which is managed by Terraform
201:       # This allows the application to add its own app settings without Terraform removing them
202:       app_settings,
203:       sticky_settings,
204: 
205:       # The following are set automatically. Ignore them so terraform doesn't
206:       # try to remove them.
207:       tags["hidden-link: /app-insights-resource-id"],
```

## S15: `ci/templates/stages.drift-check.yml`

Archiv: `marktbearbeitung.zip` > `marktbearbeitung/ui-mb-infrastructure/ci/templates/stages.drift-check.yml`  
SHA-256: `49983d1f9aedda030f5109b0ae593db4a13a0bce6209e30b06bd5e3816608dac`

```text
1: # Stage template for a single-environment drift check.
2: #
3: # Reuses steps.setup.yml with application="All" so that the case statement
4: # resolves the working directory to `environment/<env>/.` and `terragrunt
5: # run --all plan` walks all application stacks (mashub, plattform, marktbearbeitung,
6: # beratungsunterstuetzung, verbundintegration, im-action-hub, uba-anbindung).
7: #
8: # Each environment runs as its own stage with `dependsOn: []` so that DEV/TEST/PROD
9: # checks run in parallel. A failure in DEV does not block the PROD signal.
10: #
11: # Automatic runs only execute TEST/PROD.
12: # Manual runs execute all environments, including DEV.
```

```text
78:                 cd $(PIPE_BASE_DIR)/$(PIPE_WORKING_DIR)
79: 
80:                 # Build Terraform/OpenTofu plan arguments.
81:                 # `-lock-timeout` must be passed after `-- plan`, because it is
82:                 # a Terraform/OpenTofu plan argument, not a Terragrunt argument.
83:                 LOCK_TIMEOUT="${{ parameters.lockTimeout }}"
84:                 PLAN_ARGS=(-detailed-exitcode)
85: 
86:                 if [[ -n "$LOCK_TIMEOUT" ]]; then
87:                   PLAN_ARGS+=("-lock-timeout=$LOCK_TIMEOUT")
88:                 fi
89: 
90:                 # Run plan, capture exit code without aborting the step.
91:                 # `terragrunt run --all -- plan -detailed-exitcode` returns:
92:                 #   0 = no changes across all modules
93:                 #   1 = at least one module errored
94:                 #   2 = at least one module has changes (and no errors)
95:                 # The `--` separator is required so Terragrunt does not try to
96:                 # interpret `-detailed-exitcode` as one of its own flags.
97:                 set +e
98:                 terragrunt run --all \
99:                   --non-interactive \
100:                   --queue-exclude-external \
101:                   --provider-cache \
102:                   --provider-cache-dir $(Agent.TempDirectory)/tg_cache_dir \
103:                   --provider-cache-registry-names registry.terraform.io \
104:                   --out-dir "$outDir" \
105:                   -- plan "${PLAN_ARGS[@]}" 2>&1 | tee "$planLog"
106:                 EXIT_CODE=${PIPESTATUS[0]}
```

```text
139:                 case "$EXIT_CODE" in
140:                   0)
141:                     echo "✅ No drift detected in ${{ parameters.environment }}."
142:                     ;;
143:                   2)
144:                     echo "##vso[task.logissue type=warning]Drift detected in ${{ parameters.environment }}"
145:                     echo "##vso[task.complete result=SucceededWithIssues;]"
146:                     ;;
147:                   *)
148:                     echo "##vso[task.logissue type=error]Plan failed in ${{ parameters.environment }} (exit ${EXIT_CODE})"
149:                     echo "##vso[task.complete result=Failed;]"
150:                     ;;
151:                 esac
152: 
153:           - publish: $(Pipeline.Workspace)/tfplan
154:             artifact: tfplan-${{ parameters.environment }}
155:             condition: succeededOrFailed()
156:             displayName: "Publish plan binaries"
157: 
158:           - publish: $(Pipeline.Workspace)/plan.log
159:             artifact: plan-log-${{ parameters.environment }}
160:             condition: succeededOrFailed()
161:             displayName: "Publish full plan log"
162: 
163:           - publish: $(Pipeline.Workspace)/drift-summary.txt
164:             artifact: drift-summary-${{ parameters.environment }}
165:             condition: succeededOrFailed()
```

## S16: `web-portale-templates/pipelines/tgtf/tg-plan.yml`

Archiv: `web-portale-templates.7z`  
SHA-256: `b242253be68e9b00443726a18d0df5393e170fac7054feaa7e8ac703f32572a9`

```text
1: spec:
2:   inputs:
3:     environment:
4:       description: "Select the deployment environment"
5:       options: ["development", "staging", "production"]
6:       default: "development"
7: ---
8: 
9: workflow:
10:   rules:
11:     # Pipeline automatisch starten bei Merge Requests auf master oder Push auf master
12:     - if: '$CI_MERGE_REQUEST_TARGET_BRANCH_NAME =~ /^(main|master)$/ || $CI_COMMIT_BRANCH =~ /^(main|master)$/'
13:       when: always
14:     # Pipeline darf ueber die Gitlab UI manuell gestartet werden
15:     - if: '$CI_PIPELINE_SOURCE == "web"'
16:       when: always
17:     # Unter sonstigen Bedingungen darf die Pipeline nicht starten
18:     - when: never
19: 
20: variables:
21:   GITLAB_RUNNER_TAG: "azure"
22: 
23: terragrunt_plan:
24:   # Ueber Resource Group sicherstellen das nur ein Job gleichzeitig läuft
25:   resource_group: $[[ inputs.environment ]]
26:   stage: plan-$[[ inputs.environment ]]
27:   image:
28:     name: image-dev.nexus.apps.union-investment.de/$CI_PROJECT_ROOT_NAMESPACE/oci:1.0.0
29:     entrypoint: [""]
30:   tags:
31:     # Auswahl des entsprechenden Gitlab Runners
32:     - $GITLAB_RUNNER_TAG
33:   environment:
34:     name: $[[ inputs.environment ]]
35:   script: |
36:     echo "Selected environment: $[[ inputs.environment ]]"
37: 
38:     ENVIRONMENT="$[[ inputs.environment ]]"
39:     NS="$CI_PROJECT_ROOT_NAMESPACE"
40: 
41:     if [ "$NS" = "synfonic" ]; then
42:       ENV_SHORT="$ENVIRONMENT"
43: 
44:       echo "Namespace is synfonic. Using ENV_SHORT=$ENV_SHORT"
45: 
46:       cd "environment/$ENV_SHORT" || {
47:         printf "unknown environment %s\n" "$ENVIRONMENT"
48:         exit 1
49:       }
50:       # Aktivieren des Terragrunt Provider Caches, damit Module gecached werden
51:       export TG_PROVIDER_CACHE=1
52: 
53:       echo "Namespace is synfonic. Iterating over Terragrunt module folders."
54: 
55:       find . -type f -name "terragrunt.hcl" -exec dirname {} \; | sort -u | while IFS= read -r module_dir; do
56:         echo "----------------------------------------"
57:         echo "Running terragrunt plan in: $module_dir"
58:         echo "----------------------------------------"
59: 
60:         (
61:           cd "$module_dir"
62:           terragrunt plan
63:         )
64:       done
65: 
66:       exit 0
67:     fi
68: 
69:     BASE_DIR="environment"
70: 
71:     if [ -d "$BASE_DIR/development" ] && [ -d "$BASE_DIR/staging" ] && [ -d "$BASE_DIR/production" ]; then
72:       echo "Using full environment folder names (development, staging, production)"
73:       case "$ENVIRONMENT" in
74:         development) ENV_SHORT="development" ;;
75:         staging)     ENV_SHORT="staging" ;;
76:         production)  ENV_SHORT="production" ;;
77:         *)
78:           echo "Unknown environment!"
79:           exit 1
80:           ;;
81:       esac
82: 
83:     elif [ -d "$BASE_DIR/dev" ] && [ -d "$BASE_DIR/test" ] && [ -d "$BASE_DIR/prod" ]; then
84:       echo "Using short environment folder names (dev, test, prod)"
85:       case "$ENVIRONMENT" in
86:         development) ENV_SHORT="dev" ;;
87:         staging)     ENV_SHORT="test" ;;
88:         production)  ENV_SHORT="prod" ;;
89:         *)
90:           echo "Unknown environment!"
91:           exit 1
92:           ;;
93:       esac
94: 
95:     else
96:       echo "Neither full nor short environment folders found in $BASE_DIR"
97:       exit 1
98:     fi
99: 
100:     echo "Using environment folder: $BASE_DIR/$ENV_SHORT"
101: 
102:     cd "$BASE_DIR/$ENV_SHORT" || {
103:       printf "unknown environment folder %s\n" "$ENV_SHORT"
104:       exit 1
105:     }
106: 
107:     export TG_PROVIDER_CACHE=1
108: 
109:     echo "Namespace is $NS. Running single terragrunt plan."
110:     terragrunt plan
111: 
112:   rules:
113:     # Automatisch bei MR auf master oder Push auf master
114:     - if: '$CI_MERGE_REQUEST_TARGET_BRANCH_NAME =~ /^(main|master)$/ || $CI_COMMIT_BRANCH =~ /^(main|master)$/'
115:       when: always
116:     # Manuelle Ausführung über Gitlab UI zulassen
117:     - if: '$CI_PIPELINE_SOURCE == "web"'
118:       when: always
119:     # Pipeline darf nur erstellt werden, sofern einer der obigen Rules zutrifft. Sonst via Never verbieten.
120:     - when: never
```

## S17: `web-portale-templates/pipelines/tgtf/tg-apply.yml`

Archiv: `web-portale-templates.7z`  
SHA-256: `1e39439b76fb561621a84fec2041a8e5125a0a17a7dcef2e2569914ffe061f98`

```text
1: spec:
2:   inputs:
3:     environment:
4:       description: "Select the deployment environment"
5:       options: ["development", "staging", "production"]
6:       default: "development"
7: ---
8: 
9: variables:
10:   GITLAB_RUNNER_TAG: "azure"
11:   DEPLOY_ENVIRONMENT: $[[ inputs.environment ]]
12: 
13: terragrunt_apply:
14:   stage: apply-$[[ inputs.environment ]]
15:   image:
16:     name: image-dev.nexus.apps.union-investment.de/$CI_PROJECT_ROOT_NAMESPACE/oci:1.0.0
17:     entrypoint: [""]
18:   environment:
19:     name: $[[ inputs.environment ]]
20:   tags:
21:     - $GITLAB_RUNNER_TAG
22:   script: |
23:     ENVIRONMENT="$[[ inputs.environment ]]"
24:     NS="$CI_PROJECT_ROOT_NAMESPACE"
25:     BASE_DIR="environment"
26: 
27:     all_dirs_exist() {
28:       local base=$1
29:       shift
30:       for dir in "$@"; do
31:         if [ ! -d "$base/$dir" ]; then
32:           return 1
33:         fi
34:       done
35:       return 0
36:     }
37: 
38:     if [ "$NS" = "synfonic" ]; then
39:       case "$ENVIRONMENT" in
40:         development) ENV_SHORT="dev" ;;
41:         staging)     ENV_SHORT="test" ;;
42:         production)  ENV_SHORT="prod" ;;
43:         *) echo "Unknown environment!"; exit 1 ;;
44:       esac
45: 
46:       cd "$BASE_DIR/$ENV_SHORT" || { printf "unknown environment %s\n" "$ENVIRONMENT"; exit 1; }
47: 
48:       find . -type f -name "terragrunt.hcl" -print0 | sort -z | while IFS= read -r -d '' tg_file; do
49:         module_dir="$(dirname "$tg_file")"
50:         echo "Running terragrunt apply in: $module_dir"
51:         ( cd "$module_dir" && terragrunt apply --auto-approve )
52:       done
53:       exit 0
54:     fi
55: 
56:     if all_dirs_exist "$BASE_DIR" development staging production; then
57:       ENV_SHORT="$ENVIRONMENT"
58:     elif all_dirs_exist "$BASE_DIR" dev test prod; then
59:       case "$ENVIRONMENT" in
60:         development) ENV_SHORT="dev" ;;
61:         staging)     ENV_SHORT="test" ;;
62:         production)  ENV_SHORT="prod" ;;
63:         *) echo "Unknown environment!"; exit 1 ;;
64:       esac
65:     else
66:       echo "Neither full nor short environment folders found in $BASE_DIR"
67:       exit 1
68:     fi
69: 
70:     cd "$BASE_DIR/$ENV_SHORT" || { printf "unknown environment folder %s\n" "$ENV_SHORT"; exit 1; }
71:     export TG_PROVIDER_CACHE=1
72:     terragrunt apply --auto-approve
73:   rules:
74:     - if: '$CI_PIPELINE_SOURCE == "web" && $DEPLOY_ENVIRONMENT == "staging" && $CI_COMMIT_BRANCH =~ /^(main|master)$/'
75:       when: manual
76:     - if: '$CI_PIPELINE_SOURCE == "web" && $DEPLOY_ENVIRONMENT == "staging" && $CI_COMMIT_TAG'
77:       when: manual
78:     - if: '$CI_PIPELINE_SOURCE == "web" && $DEPLOY_ENVIRONMENT == "production" && $CI_COMMIT_BRANCH =~ /^(main|master)$/'
79:       when: manual
80:     - if: '$CI_PIPELINE_SOURCE == "web" && $DEPLOY_ENVIRONMENT == "production" && $CI_COMMIT_TAG'
81:       when: manual
82:     - if: '$DEPLOY_ENVIRONMENT == "development"'
83:       when: manual
84:     - when: never
85:   allow_failure: false
86:   needs:
87:     - terragrunt_plan
```

## S18: `web-portale-templates/cicd/oci/Dockerfile`

Archiv: `web-portale-templates.7z`  
SHA-256: `58bb4f24d6ae3dfd633c725ea95270a646c9d9ded4e765a76c5d1dff7794e82d`

```text
1: #
2: # OCI Image for UNiCLARA TG/TF apply
3: #
4: ARG IMAGEPATH
5: FROM image-dev.nexus.apps.union-investment.de/${IMAGEPATH}/ubuntu-24-daily:1.0.0
6: 
7: # "An ARG declared before a FROM is outside of a build stage,
8: #  so it can't be used in any instruction after a FROM."
9: #
10: ARG USERNAME
11: ARG PASSWORD
12: ARG SNOWCTL_VERSION=v0.2.0
13: ARG SNOWCTL_NEXUS_USERNAME
14: ARG SNOWCTL_NEXUS_PASSWORD
15: 
16: RUN echo "machine nexus.apps.union-investment.de login $USERNAME password $PASSWORD" > /etc/apt/auth.conf.d/nexus-union.conf
17: COPY apt-proxy-packages-microsoft-com.sources /etc/apt/sources.list.d/
18: COPY apt-proxy-apt-proxy-ubuntu-org.sources /etc/apt/sources.list.d/ubuntu.sources
19: 
20: COPY microsoft-rolling.asc microsoft.asc .uilogo.ansi /root
21: RUN cat /root/microsoft-rolling.asc | /usr/bin/gpg --dearmor -o /etc/apt/trusted.gpg.d/microsoft-rolling.gpg; \
22:     cat /root/microsoft.asc | /usr/bin/gpg --dearmor -o /etc/apt/trusted.gpg.d/microsoft.gpg; \
23:     rm -vf /root/microsoft-rolling.asc \
24:            /root/microsoft.asc; \
25:     echo 'debconf debconf/frontend select Noninteractive' | debconf-set-selections; \
26:     apt update -qq && apt install -y azure-cli; \
27:     az version --query '"azure-cli"' -o tsv > /tmp/azcli_version
28: 
29: RUN TF_VERSION=$(curl -s https://releases.hashicorp.com/terraform/ \
30:     | sed -n 's|.*<a href="/terraform/.*/">\([a-zA-Z_0-9.]*\)</a>|\1|p' \
31:     | head -n1 | cut -d"_" -f2); \
32:     printf "Detected TF_VERSION = %s.\n" ${TF_VERSION}; \
33:     TG_VERSION=$(git ls-remote --tags https://github.com/gruntwork-io/terragrunt \
34:     | awk '{ print $2 }' \
35:     | cut -d "/" -f 3 \
36:     | sed 's/v//' \
37:     | grep -E '^[0-9]+\.[0-9]+\.[0-9]+$' \
38:     | sort -Vr \
39:     | head -n1); \
40:     printf "Detected TG_VERSION = %s.\n" ${TG_VERSION}; \
41:     NX="https://nexus.apps.union-investment.de/repository/raw-proxy-"; \
42:     curl --no-progress-meter -u ${USERNAME}:${PASSWORD} -LOJ \
43:     "${NX}github-com/gruntwork-io/terragrunt/releases/download/v${TG_VERSION}/terragrunt_linux_amd64" && \
44:     mv terragrunt_linux_amd64 /usr/local/bin/terragrunt && \
45:     curl --no-progress-meter -u ${USERNAME}:${PASSWORD} -LOJ \
46:     "${NX}releases-hashicorp-com/terraform/${TF_VERSION}/terraform_${TF_VERSION}_linux_amd64.zip" && \
47:     unzip terraform_${TF_VERSION}_linux_amd64.zip terraform -d /usr/local/bin/ && \
48:     chmod ugo+x /usr/local/bin/terraform /usr/local/bin/terragrunt && \
49:     rm -vf terraform_${TF_VERSION}_linux_amd64.zip && \
50:     # Write versions to a file for label extraction
51:     printf "%s" "${TF_VERSION}" > /tmp/tf_version && \
52:     printf "%s" "${TG_VERSION}" > /tmp/tg_version
53: 
54: RUN KL_VERSION=$(git ls-remote --tags https://github.com/Azure/kubelogin \
55:     | awk '{ print $2 }' \
56:     | cut -d "/" -f 3 \
57:     | sort -Vr \
58:     | head -n1) \
59:     NX="https://nexus.apps.union-investment.de/repository/raw-proxy-"; \
60:     curl --no-progress-meter -u ${USERNAME}:${PASSWORD} -LOJ \
61:     "${NX}github-com/Azure/kubelogin/releases/download/${KL_VERSION}/kubelogin-linux-amd64.zip" && \
62:     unzip -j kubelogin-linux-amd64.zip bin/linux_amd64/kubelogin -d /usr/local/bin && \
63:     chmod ugo+x /usr/local/bin/kubelogin && \
64:     rm -vf kubelogin-linux-amd64.zip && \
65:     printf "%s" "${KL_VERSION}" > /tmp/kl_version
66: 
67: RUN NX="https://nexus.apps.union-investment.de/repository/raw-proxy-"; \
68:     K_VERSION=$(curl -s \
69:                      -u ${USERNAME}:${PASSWORD} \
70:                 ${NX}dl-k8s-io/release/stable.txt); \
71:     printf "Detected KUBECTL Version = %s.\n" ${K_VERSION}; \
72:     curl --no-progress-meter --output-dir /usr/local/bin \
73:          -u ${USERNAME}:${PASSWORD} -LOJ \
74:     "${NX}dl-k8s-io/release/${K_VERSION}/bin/linux/amd64/kubectl" && \
75:     chmod ugo+x /usr/local/bin/kubectl && \
76:     printf "%s" "${K_VERSION}" > /tmp/kubectl_version
77: 
78:     RUN test -n "${SNOWCTL_VERSION}" && \
79:     test -n "${SNOWCTL_NEXUS_USERNAME}" && \
80:     test -n "${SNOWCTL_NEXUS_PASSWORD}" && \
81:     NX="https://nexus.apps.union-investment.de/repository/raw-dev"; \
82:     curl --fail --silent --show-error \
83:       -u "${SNOWCTL_NEXUS_USERNAME}:${SNOWCTL_NEXUS_PASSWORD}" \
84:       "${NX}/b2c-initiation-web-portale/kidstarter/snowctl/${SNOWCTL_VERSION}/snowctl-linux-amd64" \
85:       -o /usr/local/bin/snowctl && \
86:     chmod ugo+x /usr/local/bin/snowctl && \
87:     snowctl --version && \
88:     printf "%s" "${SNOWCTL_VERSION}" > /tmp/snowctl_version
89: 
90: COPY provider.tf .
91: 
92: RUN terraform init
93: 
94: RUN LABEL_TF=$(cat /tmp/tf_version) && \
95:     LABEL_TG=$(cat /tmp/tg_version) && \
96:     LABEL_KL=$(cat /tmp/kl_version) && \
97:     LABEL_K=$(cat /tmp/kubectl_version) && \
98:     LABEL_AZ=$(cat /tmp/azcli_version) && \
99:     LABEL_SNOWCTL=$(cat /tmp/snowctl_version) && \
100:     printf "Versions: TF=%s TG=%s KL=%s K=%s AZ=%s SNOWCTL=%s\n" \
101:         "$LABEL_TF" "$LABEL_TG" "$LABEL_KL" "$LABEL_K" "$LABEL_AZ" "$LABEL_SNOWCTL"
102: 
103: LABEL org.opencontainers.image.created="" \
104:       org.opencontainers.image.source="" \
105:       com.union-investment.terraform.version="see /etc/image-versions.json" \
106:       com.union-investment.terragrunt.version="see /etc/image-versions.json" \
107:       com.union-investment.kubelogin.version="see /etc/image-versions.json" \
108:       com.union-investment.kubectl.version="see /etc/image-versions.json" \
109:       com.union-investment.azure-cli.version="see /etc/image-versions.json" \
110:       com.union-investment.snowctl.version="see /etc/image-versions.json"
111: 
112: RUN printf '{\n  "terraform": "%s",\n  "terragrunt": "%s",\n  "kubelogin": "%s",\n  "kubectl": "%s",\n  "azure-cli": "%s",\n  "snowctl": "%s"\n}\n' \
113:     "$(cat /tmp/tf_version)" \
114:     "$(cat /tmp/tg_version)" \
115:     "$(cat /tmp/kl_version)" \
116:     "$(cat /tmp/kubectl_version)" \
117:     "$(cat /tmp/azcli_version)" \
118:     "$(cat /tmp/snowctl_version)" \
119:     > /etc/image-versions.json && \
120:     rm -f /tmp/tf_version /tmp/tg_version /tmp/kl_version /tmp/kubectl_version /tmp/azcli_version /tmp/snowctl_version
121: 
122: RUN apt autoclean &&\
123:     apt --purge autoremove && \
124:     rm -rf /var/lib/apt/lists/* && \
125:     rm -vf \
126:     /terragrunt.hcl \
127:     /provider.tf \
128:     /.terraform.lock.hcl \
129:     /etc/apt/auth.conf.d/nexus-union.conf
```

## S19: Verzeichnisinventur

| Umgebung | Alle Terragrunt-Units im Repo | Davon `mashub` |
|---|---:|---:|
| DEV | 60 | 21 |
| TEST | 60 | 21 |
| PROD | 61 | 22 |

Die Namen und abgeleiteten Standard-Workspace-Schlüssel der 64 `mashub`-Units stehen in `state-inventar-aus-quellstand.json`. Sie sind Soll-Adressen aus dem Code, keine gezählten existierenden Azure-Blobs. Im Archiv sind keine `.terraform.lock.hcl`-Dateien vorhanden.
