#!/usr/bin/env python3
"""Read-only state metadata check. Python 3.10+, Azure CLI only for --azure.

Default: offline lookup in the supplied source inventory. With --azure, calls only
az account show, az storage account show and az storage blob show. Never reads the
state body, acquires/releases a lease, initializes Terraform, or changes Azure.
"""
from __future__ import annotations

import argparse
import datetime as dt
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
from typing import Any

DEFAULT_MANIFEST = Path(__file__).with_name('state-inventar-aus-quellstand.json')


class CheckError(Exception):
    """Expected failure with a message that contains no CLI credentials."""


def load_target(manifest: Path, environment: str, unit: str) -> dict[str, Any]:
    try:
        data = json.loads(manifest.read_text(encoding='utf-8'))
        if data['schema_version'] != 1:
            raise CheckError('Unbekannte Inventarversion.')
        backend = data['environments'][environment]
        matches = [u for u in data['units']
                   if u['environment'] == environment and u['unit'] == unit
                   and u['application'] == 'mashub']
        if len(matches) != 1:
            raise CheckError('Diese mashub-Unit ist in der gewaehlten Umgebung nicht eindeutig im Inventar enthalten.')
        selected = matches[0]
        expected_key = f'{environment}/applications/mashub/{unit}/terraform.tfstate'
        if selected['expected_default_workspace_blob_key'] != expected_key:
            raise CheckError('State-Key passt nicht zum erwarteten Schema. Inventar manuell pruefen.')
        for key in ('subscription_id', 'resource_group_name', 'storage_account_name', 'container_name'):
            if not isinstance(backend[key], str) or not backend[key]:
                raise CheckError('Unvollstaendige Backendkonfiguration.')
        return {'environment': environment, 'unit': unit,
                **{k: backend[k] for k in ('subscription_id', 'resource_group_name', 'storage_account_name', 'container_name')},
                'blob_key': expected_key, 'workspace_assumption': data['workspace_assumption']}
    except (OSError, ValueError, KeyError, TypeError) as exc:
        raise CheckError(f'Inventar nicht nutzbar ({type(exc).__name__}).') from exc


def clean_azure_env() -> dict[str, str]:
    # Do not permit storage keys, SAS or connection strings to override Entra login.
    env = {k: v for k, v in os.environ.items() if not k.upper().startswith('AZURE_STORAGE_')}
    env['AZURE_CORE_COLLECT_TELEMETRY'] = 'false'
    env['AZURE_EXTENSION_USE_DYNAMIC_INSTALL'] = 'no'
    return env


def run_az_json(arguments: list[str], stage: str) -> dict[str, Any]:
    executable = shutil.which('az')
    if executable is None:
        raise CheckError('Azure CLI fehlt. Ohne --azure ist die Offline-Pruefung nutzbar.')
    try:
        result = subprocess.run(
            [executable, *arguments, '--only-show-errors', '--output', 'json'],
            capture_output=True, text=True, check=False, timeout=90,
            env=clean_azure_env(), shell=False,
        )
    except subprocess.TimeoutExpired as exc:
        raise CheckError(f'{stage}: Zeitlimit. Netzwerk/DNS pruefen; kein Aenderungsbefehl wurde angefordert.') from exc
    except OSError as exc:
        raise CheckError(f'{stage}: Azure CLI konnte nicht ausgefuehrt werden ({type(exc).__name__}).') from exc
    if result.returncode:
        # Report known error classes only, not arbitrary stderr or tokens.
        known = ('AuthorizationPermissionMismatch', 'AuthorizationFailure', 'AuthorizationFailed',
                 'AuthenticationFailed', 'BlobNotFound', 'ContainerNotFound',
                 'ResourceNotFound', 'SubscriptionNotFound', 'Please run', 'AADSTS')
        category = next((x for x in known if x.lower() in result.stderr.lower()), 'CLI-Fehler')
        raise CheckError(f'{stage}: {category}, Exitcode {result.returncode}. '
                         'Berechtigung, Anmeldung, Netzwerk oder Objektadresse intern pruefen. '
                         'Keine Keys abrufen und keine Ressourcen automatisch anlegen.')
    try:
        payload = json.loads(result.stdout)
    except ValueError as exc:
        raise CheckError(f'{stage}: CLI lieferte kein gueltiges JSON.') from exc
    if not isinstance(payload, dict):
        raise CheckError(f'{stage}: unerwartetes Ergebnisformat.')
    return payload


def inspect_azure(target: dict[str, Any]) -> dict[str, Any]:
    subscription = target['subscription_id']
    account = run_az_json([
        'account', 'show', '--subscription', subscription,
        '--query', '{subscription_id:id,tenant_id:tenantId,state:state}',
    ], 'Subscription lesen')
    if account.get('subscription_id', '').lower() != subscription.lower():
        raise CheckError('Abbruch: Subscription stimmt nicht mit dem gewaehlten Quellstand ueberein.')
    if account.get('state') != 'Enabled':
        raise CheckError('Abbruch: Subscription ist nicht als Enabled gemeldet.')
    storage = run_az_json([
        'storage', 'account', 'show', '--subscription', subscription,
        '--resource-group', target['resource_group_name'], '--name', target['storage_account_name'],
        '--query', '{id:id,name:name,blob_endpoint:primaryEndpoints.blob,public_network_access:publicNetworkAccess,network_default_action:networkRuleSet.defaultAction}',
    ], 'Storage-Account lesen')
    expected_id = (f'/subscriptions/{subscription}/resourceGroups/{target["resource_group_name"]}'
                   f'/providers/Microsoft.Storage/storageAccounts/{target["storage_account_name"]}')
    if str(storage.get('id', '')).lower() != expected_id.lower():
        raise CheckError('Abbruch: Storage-Account-ID passt nicht zum erwarteten Backend.')
    blob = run_az_json([
        'storage', 'blob', 'show', '--subscription', subscription,
        '--account-name', target['storage_account_name'], '--container-name', target['container_name'],
        '--name', target['blob_key'], '--auth-mode', 'login',
        '--query', '{name:name,size:properties.contentLength,etag:properties.etag,last_modified:properties.lastModified,lease:properties.lease,version_id:versionId}',
    ], 'State-Blob-Metadaten lesen')
    if blob.get('name') != target['blob_key']:
        raise CheckError('Abbruch: Blobname passt nicht zum erwarteten State-Key.')
    if not isinstance(blob.get('size'), (int, float)) or blob['size'] <= 0:
        raise CheckError('Abbruch: Blob ist leer oder die Groesse konnte nicht festgestellt werden.')
    return {'account': account, 'storage_account': storage, 'blob': blob,
            'verdict': 'Blob-Metadaten lesbar; Inhalt, Workspace-Zuordnung, Schreibrechte und Terraform-Plan NICHT verifiziert.'}


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--env', required=True, choices=('dev', 'test', 'prod'), help='Explizite Zielumgebung')
    parser.add_argument('--unit', default='identity', help='mashub-Unit aus dem Inventar; Standard: identity')
    parser.add_argument('--manifest', type=Path, default=DEFAULT_MANIFEST)
    parser.add_argument('--azure', action='store_true', help='Drei nur lesende Azure-CLI-Aufrufe ausfuehren; erfordert freigegebene Anmeldung')
    parser.add_argument('--output', type=Path, help='Metadatenbericht lokal speichern; bestehende Datei wird nicht ueberschrieben')
    args = parser.parse_args(argv)
    try:
        if args.output and args.output.exists():
            raise CheckError('Ausgabedatei existiert bereits; anderen Namen verwenden.')
        target = load_target(args.manifest, args.env, args.unit)
        report: dict[str, Any] = {
            'checked_at_utc': dt.datetime.now(dt.timezone.utc).isoformat(),
            'mode': 'azure-metadata-read-only' if args.azure else 'offline-source-inventory',
            'target': target,
            'warning': 'Quellstand ist kein Live-Nachweis. Ein Test mit deinem Benutzer bestaetigt nicht die Pipelineidentitaet.',
        }
        if args.azure:
            report['result'] = inspect_azure(target)
        else:
            report['result'] = {'verdict': 'Nur Quelle gelesen; keine Azure-Verbindung aufgebaut.'}
        text = json.dumps(report, ensure_ascii=False, indent=2) + '\n'
        if args.output:
            # Exclusive creation prevents overwriting reports. Permission mode applies on POSIX.
            fd = os.open(args.output, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
            with os.fdopen(fd, 'w', encoding='utf-8') as handle:
                handle.write(text)
        sys.stdout.write(text)
        return 0
    except (CheckError, OSError) as exc:
        print(f'PRUEFUNG ABGEBROCHEN: {exc}', file=sys.stderr)
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
