# Mitgelieferte Originalvorlagen

Diese Dateien sind Kopien der bereitgestellten Originale. Sie sind keine bereits für Marktbearbeitung ausgefüllten oder eingereichten Anträge. Die angepassten Texte stehen in [Anträge und Vorgehen](../Marktbearbeitungsplattform_Infra_Antraege_und_Vorgehen.md).

| Datei | Zweck / Grenze |
|---|---|
| [GitLab_Namespace_Formular.pdf](GitLab_Namespace_Formular.pdf) | Originalfelder für den Namespace-Antrag. |
| [Nexus_Namespace_Formular.pdf](Nexus_Namespace_Formular.pdf) | Originalfelder für eine gegebenenfalls benötigte Nexus-Ablage. |
| [Azure_GitLab_Integration_Formular.pdf](Azure_GitLab_Integration_Formular.pdf) | Originalformular für die Anbindung der neuen Gruppe an Azure. |
| [Firewall_Change_Beispiel_DIGITALASSETHUB.pdf](Firewall_Change_Beispiel_DIGITALASSETHUB.pdf) | Fremdes Projekt, nur als Strukturvorlage. Keine Netze, Genehmigungen oder Termine ungeprüft übernehmen. |
| [GitLab_Migrationsanleitung_2026-10-27.pdf](GitLab_Migrationsanleitung_2026-10-27.pdf) | Interne Onboardinganleitung, bereitgestellter Stand vom 27.10.2026. |
| [Zielbild_Release_Governance.png](Zielbild_Release_Governance.png) | Zielbild als Bild, auch ohne HTML-Anzeige lesbar. |
| [Zukunftsdesign.html](Zukunftsdesign.html) | Original des Release-Governance-Zielbilds. |
| [DBI-6605_Anwendungsmigration.doc](DBI-6605_Anwendungsmigration.doc) | Vorhandenes Epic für Frontend/Backend; APIM separat. |
| [DBI-8123_Jira_Strukturbeispiel.doc](DBI-8123_Jira_Strukturbeispiel.doc) | Vom Nutzer bereitgestellte Vorlage für die Ticketstruktur. Fachfremde Inhalte und Statuswerte nicht übernehmen. |

Die ursprünglichen Dateinamen und Seitenverweise der Quellenprüfung beziehen sich auf die bereitgestellten Originale. Hier sind einige Dateinamen für eine einfachere Navigation verkürzt; ihre Inhalte wurden nicht verändert.

[Zurück zur README](../README.md)
