# Inactive placeholder: both includes below are intentionally disabled.
# Comments alone do not exclude a unit from `terragrunt run --all`.
# Keep this unit out of multi-unit runs until a real Terraform module is wired.
# This avoids the missing .tf/.tofu error seen in drift run 1254344 without
# ignoring errors in active units or creating/deleting Azure resources.
exclude {
  if                   = true
  actions              = ["all"]
  exclude_dependencies = false
}

# include "root" {
#   path           = find_in_parent_folders("root.hcl")
#   merge_strategy = "deep"
# }

# include "app" {
#   path           = "${get_terragrunt_dir()}/../../../../_apps/mashub/keyvault-aadb2c.hcl"
#   merge_strategy = "deep"
# }
