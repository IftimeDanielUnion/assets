# vDWH: Quellenregister zum Lern- und Betriebsleitfaden

Stand: 26.10.2026. Grundlage sind alt.zip und alt (1).zip sowie die bereitgestellten Screenshots. Keine Builds, Deployments oder Liveabfragen.

Die Reponamen im Export sind keine verifizierten aktiven Remote-Adressen. Keine .git-Historie enthalten.

## A01: ADF-Auslieferung

**Datei:** `WL-VDWHDataHub-Application/adf/azure_pipelines.yml`  
**Zeilen:** 1-168  
**SHA-256:** `fd1d34571cc7b423173e74c45798c3bae428f5e2d8a42ca764619e044b3b738b`

**Datei:** `WL-VDWHDataHub-Application/adf/variables-dev.yml`  
**Zeilen:** 1-7  
**SHA-256:** `b26be15c68e4fcaef4699c041b46ad5ad3577c965100d21aef30a9d3d043c1cb`

**Datei:** `WL-VDWHDataHub-Application/adf/build-deploy/package.json`  
**Zeilen:** 1-8  
**SHA-256:** `ba0a4d8b7621fca405c1b61db0bc5712f17af320c831af19bf068c806bcd0ca3`

## A02: Blob-Trigger

**Datei:** `WL-VDWHDataHub-Application/adf/trigger/trg_atx_prov_pipelines.json`  
**Zeilen:** 1-28  
**SHA-256:** `358d54dd34a1d01cbce938d9362a9ad7f19908c3fb95bb3a15b24c1e498f5994`

```text
1: {
2: 	"name": "trg_atx_prov_pipelines",
3: 	"properties": {
4: 		"annotations": [],
5: 		"runtimeState": "Started",
6: 		"pipelines": [
7: 			{
8: 				"pipelineReference": {
9: 					"referenceName": "handle_attrax_trigger_event",
10: 					"type": "PipelineReference"
11: 				},
12: 				"parameters": {
13: 					"fileName": "@triggerBody().fileName"
14: 				}
15: 			}
16: 		],
17: 		"type": "BlobEventsTrigger",
18: 		"typeProperties": {
19: 			"blobPathBeginsWith": "/inbound/blobs/",
20: 			"blobPathEndsWith": "METADATEN.json",
21: 			"ignoreEmptyBlobs": false,
22: 			"scope": "/subscriptions/02f8323c-c809-4acd-aac0-70ac642d9b83/resourceGroups/rg-attraxdth-dev-storage/providers/Microsoft.Storage/storageAccounts/stattraxdthdevstorageho9",
23: 			"events": [
24: 				"Microsoft.Storage.BlobCreated"
25: 			]
26: 		}
27: 	}
28: }
```

## A03: Orchestrierung und Typverzweigung

**Datei:** `WL-VDWHDataHub-Application/adf/pipeline/handle_attrax_trigger_event.json`  
**Zeilen:** 1-414  
**SHA-256:** `3e79553f756e6a50ce6ec3b310d1d44f71627da45cd944e9bee9255946792cc6`

## A04: Metadaten-Mappings

**Datei:** `WL-VDWHDataHub-Application/adf/pipeline/generic_load_attrax_vdwh_metadaten_provisionen.json`  
**Zeilen:** 1-259  
**SHA-256:** `fed15e88e2b9dc7666e45869cee21b708575ba5fc729b5e3ab0e67fec3096491`

**Datei:** `WL-VDWHDataHub-Application/adf/pipeline/generic_load_attrax_vdwh_metdaten_gebuehren.json`  
**Zeilen:** 1-219  
**SHA-256:** `2a6eb065b77c87eaadf95ba435c180a41aada89c3c7678f33209207f76b2ada1`

## A05: Parquet nach Oracle

**Datei:** `WL-VDWHDataHub-Application/adf/pipeline/generic_load_parquet_data_to_vdwh.json`  
**Zeilen:** 1-158  
**SHA-256:** `826c513ed6037ee62ba7dd66f1cdfc90a1a6704930b94ece91d94d79101389bc`

## A06: Archivierung und Quelllöschung

**Datei:** `WL-VDWHDataHub-Application/adf/pipeline/generic_archive_files.json`  
**Zeilen:** 1-283  
**SHA-256:** `15c5b0edb06c6b290688bf79e165dd0b6644961e4da098451f652cf6e287e8d8`

## A07: Datensätze und Verbindungen

**Datei:** `WL-VDWHDataHub-Application/adf/linkedService/ls_vdwh_oracle_externe_datenlieferungen.json`  
**Zeilen:** 1-26  
**SHA-256:** `6a8c25f7e197b976868bcb82bc96cbf7ab77a3ccf670ac48a335a8e2708e645c`

**Datei:** `WL-VDWHDataHub-Application/adf/linkedService/ls_attrax.json`  
**Zeilen:** 1-19  
**SHA-256:** `2e4ecd0697f0bb7dc8e8b9512d8472a1b823652a1c83c8b661b9742ba6d3fc0d`

**Datei:** `WL-VDWHDataHub-Application/adf/dataset/ds_vdwh_oracle_table.json`  
**Zeilen:** 1-31  
**SHA-256:** `a0197aa3c5b53bfbd8f4a9130e60a4fb42a0c435307ed33874c27598ded4ae23`

**Datei:** `WL-VDWHDataHub-Application/adf/dataset/ds_vdwh_datahub_parquet.json`  
**Zeilen:** 1-27  
**SHA-256:** `a718e2ce41087605c8d97de2f2112c64f81aa99a8e3a3607c2b78b2b573d5305`

## A08: Runtime, Identität und privater Pfad

**Datei:** `WL-VDWHDataHub-Application/adf/integrationRuntime/AutoResolveIntegrationRuntime.json`  
**Zeilen:** 1-21  
**SHA-256:** `963e631f2cfc3e9eb3be1f5658bd3a0767ebde0003551cb3138d4a48492bbcf4`

**Datei:** `WL-VDWHDataHub-Application/adf/credential/blob-contributor.json`  
**Zeilen:** 1-9  
**SHA-256:** `f0cb46506d5a80349a84351e3a33bc3139f87c73bc34be6aa1be40729997705a`

**Datei:** `WL-VDWHDataHub-Application/adf/managedVirtualNetwork/default/managedPrivateEndpoint/pe_adf_vdwh_gateway_to_onpremvdwh.json`  
**Zeilen:** 1-10  
**SHA-256:** `170b3cd2509d3b85f76bbaa4a029566ded4684c10d9116b73bb24d87d08a8751`

## A09: Publish-Konfiguration

**Datei:** `WL-VDWHDataHub-Application/adf/publish_config.json`  
**Zeilen:** 1-1  
**SHA-256:** `b6e7baaf7c8540ff4c30d2069bcc2eb89f8e65aacfaf91b90fdf401ea1d5e6a7`

```text
1: {"publishBranch":"adf_publish","includeGlobalParamsTemplate":true}
```

## I01: Plan-/Deploy-Einstiege

**Datei:** `WL-VDWHDataHub-Infrastructure/ci/pipeline.plan.yml`  
**Zeilen:** 1-30  
**SHA-256:** `5acf5d77382f29aa57bd11151e95ca8a5484963eacb409c0c8596291d3578d57`

```text
1: trigger: none # No automated runs
2: 
3: parameters:
4:   - name: "environment"
5:     displayName: "Workload Environment to plan for"
6:     type: string
7:     default: DEV
8:     values:
9:       - DEV
10:       - TEST
11:       - PROD
12:   - name: "application"
13:     displayName: "Application Name to plan for"
14:     type: string
15:     default: All
16:     values:
17:       - All
18:       - "Attrax DTH"
19:       - "NAT Gateway"
20: 
21: variables:
22:   - name: "workload"
23:     value: "VDWHDATAHUB"
24: 
25: stages:
26:   - template: templates/stages.validate-infrastructure.yml
27:     parameters:
28:       workload: ${{ variables.workload }}
29:       environment: ${{ parameters.environment }}
30:       application: ${{ parameters.application }}
```

**Datei:** `WL-VDWHDataHub-Infrastructure/ci/pipeline.deploy.yml`  
**Zeilen:** 1-42  
**SHA-256:** `b530248a2aad93ddd3e193f586676320c862c63ab7b07084b597c5610e9d2a2a`

```text
1: trigger: none # No automated runs
2: 
3: parameters:
4:   - name: "environment"
5:     displayName: "Workload Environment to apply to"
6:     type: string
7:     default: DEV
8:     values:
9:       - DEV
10:       - TEST
11:       - PROD
12:   - name: "application"
13:     displayName: "Application Name to apply"
14:     type: string
15:     default: All
16:     values:
17:       - All
18:       - "Attrax DTH"
19:       - "NAT Gateway"
20:   - name: "doPublishPlan"
21:     displayName: "Use tfplan during apply"
22:     type: boolean
23:     default: true
24: 
25: variables:
26:   - name: "workload"
27:     value: "VDWHDATAHUB"
28: 
29: stages:
30:   - template: templates/stages.validate-infrastructure.yml
31:     parameters:
32:       workload: ${{ variables.workload }}
33:       environment: ${{ parameters.environment }}
34:       application: ${{ parameters.application }}
35:       doPublishPlan: ${{ parameters.doPublishPlan }}
36: 
37:   - template: templates/stages.deploy-infrastructure.yml
38:     parameters:
39:       workload: ${{ variables.workload }}
40:       environment: ${{ parameters.environment }}
41:       application: ${{ parameters.application }}
42:       usePublishedPlan: ${{ parameters.doPublishPlan }}
```

## I02: Validation und Setup

**Datei:** `WL-VDWHDataHub-Infrastructure/ci/templates/stages.validate-infrastructure.yml`  
**Zeilen:** 13-74  
**SHA-256:** `b82dbc3256b3d670b852f0570c3bd4dec0637857d745a0bf9a4041b5d28500da`

**Datei:** `WL-VDWHDataHub-Infrastructure/ci/templates/steps.setup.yml`  
**Zeilen:** 27-62  
**SHA-256:** `0555c700be83da7c9e7473014754ee9c709e615652362eb92930d304f8f04559`

## I03: Freigabe und Apply

**Datei:** `WL-VDWHDataHub-Infrastructure/ci/templates/stages.deploy-infrastructure.yml`  
**Zeilen:** 12-108  
**SHA-256:** `13527d1b74ccabe1037b3774515694ebea43d3642d541581bbee97eb0f146d0a`

## I04: Provider und State

**Datei:** `WL-VDWHDataHub-Infrastructure/live/root.hcl`  
**Zeilen:** 13-58  
**SHA-256:** `c348cf145baa3d325bc18cde12ed2f5c21b4de55cf4045ddfdfe9db5b48aa93a`

```text
13: # Generate an AzureRM provider block
14: generate "provider" {
15:   path      = "provider.tf"
16:   if_exists = "overwrite_terragrunt"
17:   contents  = <<EOF
18: terraform {
19:   required_version = "~> 1.10"
20:   required_providers {
21:     azurerm = {
22:       source = "hashicorp/azurerm"
23:       version = "~>4.18"
24:     }
25:   }
26: }
27: 
28: provider "azurerm" {
29:   storage_use_azuread = true
30:   subscription_id = "${local.subscription_id}"
31:   features {
32:     resource_group {
33:       prevent_deletion_if_contains_resources = false
34:     }
35:   }
36: }
37: provider "azurerm" {
38:   alias = "computegallery"
39:   subscription_id = "1a0ab7e3-df9b-4926-9ef6-df6af7e15351"
40:   features {}
41: }
42: EOF
43: }
44: 
45: remote_state {
46:   backend = "azurerm"
47:   generate = {
48:     path      = "backend.tf"
49:     if_exists = "overwrite"
50:   }
51:   config = {
52:     subscription_id      = "${local.subscription_id}"
53:     key                  = "${path_relative_to_include()}/terraform.tfstate"
54:     resource_group_name  = local.environment_vars.locals.backend_resource_group_name
55:     storage_account_name = local.environment_vars.locals.backend_storage_account_name
56:     container_name       = local.environment_vars.locals.backend_container_name
57:   }
58: }
```

**Datei:** `WL-VDWHDataHub-Infrastructure/live/dev/environment.hcl`  
**Zeilen:** 1-19  
**SHA-256:** `6ee852caca65706d35675ba8150a051be4ec64f2411a38a8ed2f88a42f29073a`

```text
1: ## Environment specific variables
2: ## Required to access the subscription_id in root.hcl (for the azure provider).
3: ## 'environment' will also be added to the inputs by root.hcl and therefore, including this file is not necessary in another unit.
4: locals {
5:   backend_container_name       = "terraform-state"
6:   backend_storage_account_name = "sawd12c0b27e906b0710"
7:   backend_resource_group_name  = "rg-vdwhdatahub-dev-managed-resources"
8: 
9:   environment     = "dev"
10:   subscription_id = "02f8323c-c809-4acd-aac0-70ac642d9b83"
11:   workload        = "VDWHDATAHUB"
12: 
13:   tags = {
14:     environment = local.environment
15:   }
16: }
17: 
18: # inputs is referenced in root.hcl
19: inputs = {}
```

**Datei:** `WL-VDWHDataHub-Infrastructure/live/test/environment.hcl`  
**Zeilen:** 1-19  
**SHA-256:** `40953233e44182b16d12a0d66f6a8de842ad61ec9af024338fb5485e8666c46c`

```text
1: ## Environment specific variables
2: ## Required to access the subscription_id in root.hcl (for the azure provider).
3: ## 'environment' will also be added to the inputs by root.hcl and therefore, including this file is not necessary in another unit.
4: locals {
5:   backend_container_name       = "terraform-state"
6:   backend_storage_account_name = "sawd37d75955849fea63"
7:   backend_resource_group_name  = "rg-vdwhdatahub-test-managed-resources"
8: 
9:   environment     = "test"
10:   subscription_id = "543fd8c7-d97d-4d91-bb6d-fa1ffd757acb"
11:   workload        = "VDWHDATAHUB"
12: 
13:   tags = {
14:     environment = local.environment
15:   }
16: }
17: 
18: # inputs is referenced in root.hcl
19: inputs = {}
```

**Datei:** `WL-VDWHDataHub-Infrastructure/live/prod/environment.hcl`  
**Zeilen:** 1-19  
**SHA-256:** `34ccd573be21acfa35f963b688d9c54f4468ebdf378742b58ab2c64803de6424`

```text
1: ## Environment specific variables
2: ## Required to access the subscription_id in root.hcl (for the azure provider).
3: ## 'environment' will also be added to the inputs by root.hcl and therefore, including this file is not necessary in another unit.
4: locals {
5:   backend_container_name       = "terraform-state"
6:   backend_storage_account_name = "sawd63653943907f43eb"
7:   backend_resource_group_name  = "rg-vdwhdatahub-prod-managed-resources"
8: 
9:   environment     = "prod"
10:   subscription_id = "4a499682-180c-476a-95f9-5273d5ef2ce0"
11:   workload        = "VDWHDATAHUB"
12: 
13:   tags = {
14:     environment = local.environment
15:   }
16: }
17: 
18: # inputs is referenced in root.hcl
19: inputs = {}
```

## I05: Umgebungs-Stacks und Oracle-Ziele

**Datei:** `WL-VDWHDataHub-Infrastructure/live/dev/terragrunt.stack.hcl`  
**Zeilen:** 1-68  
**SHA-256:** `e00ff9fac9725f590a678403965f57c05af104b2e251719e1de7c5a5a8acc7f2`

**Datei:** `WL-VDWHDataHub-Infrastructure/live/test/terragrunt.stack.hcl`  
**Zeilen:** 1-68  
**SHA-256:** `3f818dc995f5e3639461c16ea6c6b046c4bfa226daf07a792c0a456d8a1c273a`

**Datei:** `WL-VDWHDataHub-Infrastructure/live/prod/terragrunt.stack.hcl`  
**Zeilen:** 1-64  
**SHA-256:** `6b0a1a6b4baa5389edc399304df2563b7303f25c7e7637a9e190d336502fb1ab`

## I06: ADF-Stack und Units

**Datei:** `WL-VDWHDataHub-Infrastructure/stacks/attrax-data-transfer-hub/terragrunt.stack.hcl`  
**Zeilen:** 33-224  
**SHA-256:** `9f977cd5b070aabdbf1aa3f9ca8d127e276b59342041f813fac1285562ea7141`

**Datei:** `WL-VDWHDataHub-Infrastructure/units/data-factory/terragrunt.hcl`  
**Zeilen:** 1-54  
**SHA-256:** `9a8195c849603b108a334d87d945aafdc4dc0c09063b35df259f80c650dd0371`

## I07: Gateway-Implementierung

**Datei:** `WL-VDWHDataHub-Infrastructure/modules/nat-gateway/main.tf`  
**Zeilen:** 9-111  
**SHA-256:** `2f6830f09b1003b5a47ee4240094f187b703cec60fcf4a0d088d536dd4881fd8`

**Datei:** `WL-VDWHDataHub-Infrastructure/modules/nat-gateway/iptables-init.tftpl`  
**Zeilen:** 21-57  
**SHA-256:** `c9153ae6170b3da6f3d0677c8daf2dbda0487eacdbf26e501e0b9d42e7ff78d2`

## I08: Data-Factory-Ressource

**Datei:** `WL-VDWHDataHub-Infrastructure/modules/data-factory/main.tf`  
**Zeilen:** 10-58  
**SHA-256:** `5efa5359994efa70e6237be00307a5168fdcfcb2a631afe2e05f626cdb51f77c`

## I09: Storage-Schutz und Rechte

**Datei:** `WL-VDWHDataHub-Infrastructure/modules/blob-storage/main.tf`  
**Zeilen:** 17-38  
**SHA-256:** `7feb3748fc82ea1dfd6b835c7807f9ce2f5ef4f29240159eebb74496014ecadf`

**Datei:** `WL-VDWHDataHub-Infrastructure/units/private-blob-storage-for-datafactory/terragrunt.hcl`  
**Zeilen:** 31-61  
**SHA-256:** `a6e86893e14daa4dc0085aa66c2b9b1b98062a508abbcb789a3ffe70dbda7307`

## V01: VMgr-Umgebungen und State

**Datei:** `WL-VDWHDataHub-Infrastructure-VMgr/live/root.hcl`  
**Zeilen:** 13-53  
**SHA-256:** `e120705aa44a18ceb6fd0e9d5f984332dc31b1ad203b8a81ddfd32df71c88ea2`

**Datei:** `WL-VDWHDataHub-Infrastructure-VMgr/live/dev/environment.hcl`  
**Zeilen:** 1-13  
**SHA-256:** `560f23d8ea738a0942839011326153794575af991ee6c828c6adb88efc6e29a5`

**Datei:** `WL-VDWHDataHub-Infrastructure-VMgr/live/test/environment.hcl`  
**Zeilen:** 1-12  
**SHA-256:** `67557d56d8b23b5322d87f1c2878eec0285d2088dff8db6db55a9de65fd9b4ee`

**Datei:** `WL-VDWHDataHub-Infrastructure-VMgr/live/prod/environment.hcl`  
**Zeilen:** 1-12  
**SHA-256:** `89dff5a5902ad95e7ffc327d7dc46288bc047f1a6195fe69d8a7aff47f3cc8bf`

**Datei:** `WL-VDWHDataHub-Infrastructure-VMgr/live/dev/terragrunt.stack.hcl`  
**Zeilen:** 29-63  
**SHA-256:** `b78ed0f14318a1e7baa8e01e5fbd6d8ac48342b55407fea13aaccdb331eeef57`

**Datei:** `WL-VDWHDataHub-Infrastructure-VMgr/live/test/terragrunt.stack.hcl`  
**Zeilen:** 29-96  
**SHA-256:** `4c1869cd0c86af8fe935fc2cffb92c74ca035f9bbedcf0622b00051abdbb7f52`

**Datei:** `WL-VDWHDataHub-Infrastructure-VMgr/live/prod/terragrunt.stack.hcl`  
**Zeilen:** 29-76  
**SHA-256:** `1f28067f4192691c2370bda71394b1b4337aa0126015ed944a8e358049c1b2ab`

## V02: BO-Version-Manager-Stack

**Datei:** `WL-VDWHDataHub-Infrastructure-VMgr/stacks/bo-version-manager/terragrunt.stack.hcl`  
**Zeilen:** 1-125  
**SHA-256:** `edf9b55dcdee0e14a17681fba5fe71ac958570f0e514d759bd02b4e48572c76b`

## V03: Backup-Policy und VM-Schutz

**Datei:** `WL-VDWHDataHub-Infrastructure-VMgr/modules/recovery-vault/main.tf`  
**Zeilen:** 9-42  
**SHA-256:** `e00872092915b3562496dad1ee9cd338cffb6d5211fab051748991120d75122e`

**Datei:** `WL-VDWHDataHub-Infrastructure-VMgr/modules/backup-of-vm/main.tf`  
**Zeilen:** 1-7  
**SHA-256:** `8815c95adf5eb9ab938ea81520e8a7d4444007e8f8f515a062060ff4c86af2cb`

## P01: PoC-Zweck und Architektur

**Datei:** `legacy-poc/README.md`  
**Zeilen:** 1-66  
**SHA-256:** `2ea013fac7e6ba2d684e5413ba8fa2634ff1a87a6afa1b78e8a9a9b4357878cc`

## P02: PoC-Toolchain und Image

**Datei:** `legacy-poc/environment/.terraform-version`  
**Zeilen:** 1-1  
**SHA-256:** `44712a66e62881fe24778a22d0f57d0e74084311fd2cd84070fc7fa9ce0f65bf`

**Datei:** `legacy-poc/environment/.terragrunt-version`  
**Zeilen:** 1-1  
**SHA-256:** `0b5701658df6c18019072c71f2c5c76ac6a01e1e9ba1cca5f84ecd29ce9d6045`

**Datei:** `legacy-poc/docker/Dockerfile`  
**Zeilen:** 1-17  
**SHA-256:** `5277ed54c4433f118bb6f73c3855ef4c8a638b400f4e7484478ee6c03b0673cf`

## Screenshots und Kontext

S01: 1000134602.jpg, Azure-DevOps-Runübersicht.
S02: image(20261026-143002).png, GitLab-Gruppenübersicht.
S03: image-1793025077709.jpg, sichtbare leere DataHub-Untergruppe.
D01: Zukunftsdesign.html, separates Governance-Zielbild.

## Herstellerquellen (nur Grundwissen)

- G01: Azure Pipelines: Begriffe und Aufbau. https://learn.microsoft.com/en-us/azure/devops/pipelines/get-started/key-pipelines-concepts?view=azure-devops
- G02: ADF: Pipelines, Activities und Datasets. https://learn.microsoft.com/en-us/azure/data-factory/concepts-pipelines-activities
- G03: Terraform: Wirkung von plan. https://developer.hashicorp.com/terraform/cli/commands/plan
- G04: Terraform: Zweck des State. https://developer.hashicorp.com/terraform/language/state/purpose
- G05: Azure Pipelines: Approvals and checks. https://learn.microsoft.com/en-us/azure/devops/pipelines/process/approvals?view=azure-devops
- G06: Azure Pipelines: benutzerdefinierte Conditions. https://learn.microsoft.com/en-us/azure/devops/pipelines/process/conditions?view=azure-devops
- G07: ADF: Pipeline- und Activity-Runs überwachen. https://learn.microsoft.com/en-us/azure/data-factory/monitor-visually
- G08: ADF: automatisierter Export aus Repositorydateien. https://learn.microsoft.com/en-us/azure/data-factory/continuous-integration-delivery-improvements