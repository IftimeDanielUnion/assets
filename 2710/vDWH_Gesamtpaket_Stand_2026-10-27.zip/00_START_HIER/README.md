# vDWH-Gesamtpaket | Stand: 27.10.2026

Dieses ZIP bündelt den bis heute im Gespräch erarbeiteten **vDWH-/Azure-DevOps-Lernstand** mit seinen wesentlichen Originalquellen. Die Analyse und die PDF wurden am 26.10.2026 erstellt. Die Archivierung erfolgt am 27.10.2026.

## Empfohlene Reihenfolge

1. **`01_Leitfaden/vDWH_Azure_DevOps_Lern_und_Betriebsleitfaden.pdf`** (28 Seiten): Einstieg, Architektur, Datenfluss, Azure-Ressourcen, Terraform, Pipelines und praktische Übungen.
2. **`01_Leitfaden/vDWH_Guide_Quellenregister.md`**: technische Nachweise, konkrete Dateipfade und relevante Auszüge aus den gelieferten Quellen.
3. **`00_START_HIER/Naechste_Schritte_und_Status.md`**: Was belegt ist, welche Informationen fehlen und wie du die Betriebsübernahme beginnen kannst.
4. **`03_Bildmaterial/`**: GitLab- und Azure-DevOps-Ansichten, die wir gemeinsam betrachtet haben.
5. **`02_Quellarchive/`**: ursprüngliche Repo-Exporte. Nur für eigene technische Prüfung, nicht als bestätigter Stand eines aktuellen Azure-DevOps-Branches.
6. **`04_PDF_Vorschau/`**: optionale Kontaktbögen mit Seitenvorschauen aus dem Leitfaden.

## Was ist wo enthalten?

| Archiv | Inhalt | Einordnung |
| --- | --- | --- |
| `alt.zip` | Oracle/AKS-Infrastruktur-PoC, Terraform, Docker/Oracle und SQL-Inhalte | Separater Legacy-PoC; **nicht** mit DataHub gleichsetzen. |
| `alt (1).zip` | Verschachtelte Archive `WL-VDWHDataHub-Application.zip`, `WL-VDWHDataHub-Infrastructure.zip` und `WL-VDWHDataHub-Infrastructure-VMgr.zip` | Drei fachlich zusammengehörige DataHub-/BO-Infrastruktur-Repositories. |

## Belastbarkeit und Datenschutz

- Aus den Quellarchiven lassen sich **Konfigurationen und beabsichtigte Datenwege**, aber weder aktuelle Produktivfreigaben noch letzte Commits verlässlich bestätigen. Die Archiven enthalten keine vollständige Git-Historie.
- Der Azure-DevOps-Screenshot zeigt erfolgreiche historische Pipeline-Runs. Er beweist keine aktuelle Ende-zu-Ende-Verarbeitung oder den Istzustand in Azure.
- Die GitLab-Gruppe `vDWH/AzureCloud/vdwhdatahub` war auf dem geteilten Screenshot ohne sichtbare Projekte. Das ist **kein Nachweis**, dass die zugehörige Azure-Workload stillgelegt wurde.
- Die Roharchive enthalten internen Quellcode und möglicherweise sensible Konfigurationen. **Nur innerhalb der berechtigten Unternehmensumgebung speichern und teilen.** Den früher identifizierten Passwortwert im Oracle-PoC bei einer möglichen Wiederverwendung prüfen.
- Keine Secrets aus Pipeline-Variablen, Key Vault oder vollständige Datenbank-Verbindungszeichenfolgen diesem Paket hinzufügen.

`SHA256SUMS.txt` enthält Datei-Prüfsummen der im ZIP mitgelieferten Dateien.
