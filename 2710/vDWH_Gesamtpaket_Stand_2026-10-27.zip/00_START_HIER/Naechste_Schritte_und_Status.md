# Betriebsübernahme vDWH: Status und nächster Arbeitsweg

Stand: 27.10.2026. Diese Liste ist eine **Arbeitsorientierung**, keine bestätigte Produktionsinventur.

## A. Aus Unterlagen und Screenshots bekannt

- `WL-VDWHDataHub-Application`: Azure Data Factory (ADF) verarbeitet angelieferte Attrax-Daten aus Blob Storage und lädt strukturierte Daten in die Oracle-vDWH-Umgebung. Trigger und ADF-Pipelines sind im Code enthalten.
- `WL-VDWHDataHub-Infrastructure`: Terraform-/Terragrunt-Definitionen für Data Factory, Storage, Key Vault, Identität und die Verbindung zur vorhandenen On-Premises-Datenbank. DEV, TEST, PROD sind im Code vorhanden.
- `WL-VDWHDataHub-Infrastructure-VMgr`: Infrastruktur für BO-Version-Manager-/VM-Ressourcen, Backup und Monitoring.
- `alt.zip`: älterer, separat zu betrachtender Oracle-/AKS-Proof-of-Concept.
- Im geteilten Azure-DevOps-Screenshot sind erfolgreiche ADF-Runs vom **25.08.2026** und historische Infrastruktur-Runs aus 2025 erkennbar; Umfang der Deployments pro Run im Detail noch offen.
- Die abgebildete GitLab-Untergruppe `vDWH / AzureCloud / vdwhdatahub` zeigt keine enthaltenen Projekte; die drei DataHub-Repositories wurden in dieser Gruppe nicht sichtbar gemacht.

## B. Was die Unterlagen nicht beweisen

- Ob ADF aktuell erfolgreich Daten bis in Oracle liefert, wie oft Runs stattfinden und ob Alerts aktiv sind.
- Ob die vorhandenen Infrastruktur-Pipelines aktuell in DEV, TEST und PROD benutzt werden oder durch andere Pipelines ersetzt wurden.
- Welche Azure-Subscriptions, Ressourcen, Managed Identities, Key Vaults, State-Objekte und On-Premises-Routen tatsächlich produktiv sind.
- Wer Änderungs- und Betriebsfreigaben besitzt sowie welcher Branch aktuell die produktive Wahrheit darstellt.

## C. Konkreter read-only Lernpfad in Azure DevOps

1. Azure DevOps **vDWH > Repos**: Alle drei DataHub-Repositories öffnen. Default Branch, Commitdatum, README und `azure-pipelines*.yml` notieren.
2. **Pipelines > Pipelines**: Pro Repo die zugehörigen Pipeline-Definitionen und Trigger zuordnen.
3. **Pipelines > Runs**: Einen ADF-Run und einen Infra-Validate-Run öffnen. Stages/Jobs/Logs vergleichen. Nur ansehen, nicht erneut starten.
4. **Pipelines > Library und Environments**: Vorhandene Variablengruppen, Benennung, Freigaben und Zugriffsanforderungen erfassen. **Keine Secret-Werte exportieren.**
5. Im Azure-Portal **Data Factory > Monitor**: Tatsächliche Datenverarbeitungs-Runs, Fehler, Trigger und Zielsystem prüfen.
6. Im Azure-Portal **Storage / Data Factory / Key Vault / VMs / Monitoring**: Ressourcen mit den Repo-Namen und Umgebungen abgleichen.
7. Terraform-/Terragrunt-State-Backend und State-Key-Struktur feststellen. Vor Migration ein Plan-only auf freigegebener Testumgebung mit dem Team abstimmen; keinen unkontrollierten Apply.
8. Bei GitLab-Migrationsplanung: Zielgruppen und Projektberechtigungen bestätigen, bestehende Pipeline-Templates prüfen und den CI-Wechsel **ohne gleichzeitigen Infrastrukturumbau** planen.

## D. Bei der Übergabe schriftlich bestätigen lassen

| Frage | Sinnvoller Nachweis |
| --- | --- |
| Wer ist fachlicher Owner? | Anwendungs-/CMDB-Eintrag oder schriftliche Zuordnung |
| Welcher Datenfluss ist produktiv? | ADF-Monitoring inklusive letzter erfolgreicher fachlicher Ladung |
| Welche Deploymentpipeline ist verbindlich? | Pipeline-URL, YAML/Branch, letzter deployender Run |
| Wo liegen Terraform-States? | Backend-Konfiguration, State-Keys und berechtigte Betreiber |
| Wer genehmigt TEST-/PROD-Änderungen? | Environment-Checks, Change-Prozess und Rolle |
| Wie werden Fehler bemerkt? | Alerts, Runbook, Eskalation, On-Call-Zuordnung |
| Gibt es eine Abschalt-/Migrationsplanung? | Jira-/Change-Referenz und Zieltermin |

## Wichtig

**Ein grüner Azure-DevOps-Run bedeutet, dass die im Run ausgeführten Schritte erfolgreich waren.** Er beweist nicht, dass die Data-Factory-Pipeline heute fachlich korrekte Daten liefert. Die zweite Prüfung findet in ADF Monitor sowie im Zielsystem statt.
