# UMP: dein neuer vollständiger Arbeitsordner

**Stand: 02.10.2026, mit den neuen Belegen aus `12139.7z`.** WSL2 / Windows 11 / VS Code.

ZIP frisch entpacken. Keine alte Paketversion darüberkopieren. Deine echten Git-Repositories bleiben unangetastet. Alle vorbereiteten Code-Dateien und bisherigen Testbelege sind enthalten.

## Was ist jetzt erledigt?

**Die Storages existieren. DBI-12139 ist trotzdem noch offen: DEV liefert ein nicht zur Adresse passendes HTTPS-Zertifikat.** TEST war erfolgreich; für PROD fehlt ein Dateiabruf. Eine neue Storage-Anlage ist nicht nötig.

| Ticket | Stand | Nächste Arbeit | GitLab-Merge? |
|---|---|---|---|
| [DBI-12139](DBI-12139/README.md) | Bestandsprüfung aller drei Umgebungen erfolgreich. DEV-HTTPS fehlerhaft. | Zertifikat/Zuordnung prüfen, Fehler beheben, fehlende Abrufe nachholen. | Nur bei einer tatsächlichen IaC-Änderung. Nicht allein für die Prüfungen. |
| [DBI-11149](DBI-11149/README.md) | Mail an Marc gesendet. Antwort/Verbindung noch nicht belegt. | Rückmeldung auswerten, aus UMP testen. | Nur bei Codeänderung, z.B. Übernahme des optionalen Diagnosebefehls. |
| [DBI-6455](DBI-6455/README.md) | Monitoring-Code vorbereitet, nicht bereitgestellt. | Vorhandene Logs/Regeln prüfen, fehlende Alarmierung deployen und Mail testen. | Ja, wenn die vorbereitete Ergänzung benötigt wird: `live`. |
| [PB2B-27849](PB2B-27849/README.md) | App laut Jira angelegt; Login-Abnahme unklar. | Oliver nach bestehender Abnahme fragen; nur Fehlendes korrigieren. | Nur bei Konfigurationsänderung: `ansible-ump`. |
| [DBI-7161](DBI-7161/README.md) | Entwurf, noch keine freigegebene Integration. | Schnittstellenangaben von Sinan/OSC holen. | Später `catalog` plus Einbindung in `live`; ggf. Anwendungscode. |

**Die anderen vier Tickets bleiben offen; auch 12139 ist noch nicht vollständig abgenommen.** Es wurde kein Jira verändert.

## Jetzt nur diese Schritte

1. Die **[zwei Jira-Kommentare](JIRA_KOMMENTARE.md)** kopieren: SFTP-Mail und aktueller Storage-Stand. Beide sind ohne Platzhalter verwendbar.
2. Im WSL-Terminal des neuen `UMP`-Ordners:

```bash
bash start.sh 12139 tls --env dev
```

Das liest DNS, öffentliches Zertifikat und die Gateway-Zuordnung. **Keine Änderung, kein Testupload.** Ergebnis: neuer `tls.md`-Bericht unter `ergebnisse/DBI-12139/`. Er grenzt ein, wo der DEV-Fehler sitzt. Weiter geht es in der kurzen Ticket-README.

3. Während du auf Marc wartest, kannst du Monitoring starten:

```bash
bash start.sh 6455
```

Liest TEST-Logs und bestehende Regeln. Richtet noch nichts ein und verschickt keine Mail.

Nur den gespeicherten Stand anzeigen, ohne Azure-Verbindung:

```bash
bash start.sh status
```

## GitLab: ja, aber nur echte Änderungen

**Das ZIP ist ein Arbeits- und Vorbereitungspaket, kein bereits gemergtes oder deploytes Repository.** Nicht den ganzen `UMP`-Ordner ins GitLab-Repo kopieren.

Für benötigten Code: `bash start.sh 6455 code` (Ticketnummer entsprechend wählen). Es entsteht ein eigener Branch/Worktree unter `~/ump-worktrees/`, ohne deinen normalen Checkout umzuschalten. Bei Abweichungen zum ursprünglichen Repo-Snapshot stoppt die Übernahme.

Danach: Änderungen prüfen → committen/pushen → Merge Request → Pipeline/Plan prüfen und freigeben → mergen → Deployment/Apply durchführen → Funktion testen. **Merge allein ist noch keine Abnahme.** Im vorliegenden `live`-Pipeline-Code sind Apply-Jobs manuell; der aktuelle GitLab-Stand ist maßgeblich.

Nur die benötigten Dateien aus `Ticket/code/Repository/` übernehmen. `ergebnisse/`, Zugangsdaten und den Paketordner nicht pauschal committen. Auch vorbereiteter Code ist kein Pflicht-Merge, wenn die Funktion bereits vorhanden ist.

## Muss ich wieder fragen, ob die Assets extern sein sollen?

Wir arbeiten mit deiner Annahme: **Die öffentliche Asset-Adresse soll aus dem Kundennetz/Internet ohne Anmeldung funktionieren.** Keine weitere Grundsatznachfrage als Voraussetzung. Einen tatsächlichen externen Abruf ersetzt diese Annahme aber nicht. Das interne Storage-Netz nicht auf Verdacht öffnen.

Quellen und tatsächliche Prüfungen: [PRUEFPROTOKOLL.md](PRUEFPROTOKOLL.md). Keine Live-Abfrage von Jira oder deinem Postfach.
