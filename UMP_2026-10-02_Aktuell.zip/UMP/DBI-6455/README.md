# DBI-6455: Fehlermails einrichten

**Offen. Code vorbereitet, keine Bereitstellung oder Testmail durch deine Asset-Tests.** Unabhängig von Marc und DBI-12139.

## 1. Prüfen, was schon existiert

**Warum:** keine doppelten Alarme bauen; zuerst die echten Logs und vorhandenen Regeln prüfen.

```bash
bash start.sh 6455
```

Liest TEST. Bericht unter `ergebnisse/DBI-6455/`. Erwartung: aktuelle OTEL-Daten mit `ServiceName`/`SeverityText` und nachvollziehbarer Regelbestand. Rechtefehler oder leere Logs sind kein Erfolg.

## 2. Nur fehlende Alarmierung übernehmen

```bash
bash start.sh 6455 code
bash start.sh 6455 validate
```

`code` erstellt einen separaten `live`-Worktree. `validate` benötigt die Repository-Terraform-Version und prüft das Modul isoliert; kein Apply. Alternativ eure CI nutzen. Der echte Terragrunt-Plan braucht zusätzlich GitLab-/Katalog-/State-Zugriff, nicht nur `az login`.

## 3. In GitLab mergen und kontrolliert bereitstellen

**Ja, hier ist ein MR nötig, wenn die vorbereitete Ergänzung eingesetzt wird.** Repo: `live`. Vorgeschlagener Titel: `DBI-6455: Mail-Alarmierung für error/fatal`.

Die sechs Dateien enthalten Modul, Unit, drei Stack-Ergänzungen und CI-Anpassung. Nach inhaltlicher Prüfung im WSL-Terminal:

```bash
cd "$HOME/ump-worktrees/DBI-6455/live"
git add -- .gitlab-ci.yml live/dev/terragrunt.stack.hcl live/test/terragrunt.stack.hcl live/prod/terragrunt.stack.hcl modules/ump-exception-alerts/main.tf units/ump-exception-alerts/terragrunt.hcl
git diff --cached --check
git diff --cached --stat
```

Erst wenn die Änderungen passen, committen und pushen:

```bash
git commit -m "DBI-6455: Mail-Alarmierung vorbereiten"
git push -u origin HEAD
```

Merge Request in GitLab öffnen, vollständigen Plan prüfen und Review/Freigabe einholen. Danach mergen und den freigegebenen TEST-Apply ausführen. Im Snapshot ist Apply manuell. **Ein Merge allein stellt noch keine Mail zu.**

TEST ist im Code aktiviert vorgesehen; DEV/PROD bleiben zunächst deaktiviert. Die später benötigten Umgebungen erst nach TEST-Abnahme und Freigabe aktivieren. Kein pauschaler Apply ungeprüfter Änderungen.

## 4. Mail-Eingang wirklich prüfen

An Alex Köster:

> Hi Alex, ich ergänze bei DBI-6455 die noch offene Mail-Alarmierung für error/fatal. Nach dem TEST-Deployment würde ich mit dir gern einen kontrollierten Fehler auslösen und den Eingang bei ui-team@os-cillation.de bestätigen. Welchen sicheren Testfall können wir dafür nehmen? Danke dir!

**Warum:** Nur ein echter Fehler plus empfangene Mail beweist den gewünschten Ablauf. Der tatsächliche Betreff mit `ServiceName` muss dabei geprüft werden, er ist nicht vorab garantiert.

**Fertig:** Alarmierung in den benötigten Umgebungen aktiv und Mail-Eingang bestätigt. Bisher nicht erfolgt.
