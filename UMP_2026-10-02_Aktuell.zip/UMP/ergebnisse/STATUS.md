# UMP: Auswertung der vorhandenen Belege

Kein neuer Azure-Aufruf. Angezeigt werden die gespeicherten Prüfläufe, keine laufende Überwachung.
Erfolgreiche Teilprüfungen schließen ein Jira nicht automatisch.

## DBI-12139

| Umgebung | Infrastruktur | Letzter Asset-Abruf | Externer Abruf |
|---|---|---|---|
| dev | bestätigt (2026-10-02T08:56:49+00:00) | TLS-Zertifikat passt nicht zur aufgerufenen Adresse, intern (2026-10-02T10:28:57+00:00) | kein Nachweis |
| test | bestätigt (2026-10-02T08:56:49+00:00) | erfolgreich, intern (2026-10-02T09:00:16+00:00) | kein Nachweis |
| prod | bestätigt (2026-10-02T08:56:49+00:00) | offen | kein Nachweis |

Die Netzangabe intern/extern stammt vom ausführenden Menschen; das Skript bestätigt den Standort nicht.
Ein nicht ausgewiesener externer Test ist kein Beleg für einen Netzwerkdefekt.
Arbeitsannahme: öffentliche Asset-Domain aus dem Kundennetz/Internet erreichbar. Dafür fehlt ein Beleg.
Für einen Abschluss muss außerdem der DEV-HTTPS-Fehler behoben und PROD geprüft sein.
Keine weitere Storage-Neuanlage. Der nächste gezielte Schritt steht in DBI-12139/README.md.

### Noch nicht als bereinigt dokumentierte eigene Testblobs
- dev: `dbi-12139-check-20261002T102831Z-f1ddfbbb97ef.txt`
- test: `dbi-12139-check-20261002T085902Z-99cb2a98bb4b.txt`
Erst nach den benötigten Abrufen bereinigen. Ohne Löschbeleg ist unbekannt, ob zwischenzeitlich manuell gelöscht wurde.

## Andere Tickets: belegter Übergabestand

- DBI-11149: Anfrage an Marc am 01.10.2026 versendet (Screenshot). Keine Antwort im Upload. Falls eine Antwort inzwischen da ist, direkt weiterarbeiten.
- DBI-6455: Code vorbereitet. In deinen Uploads keine Log-/Alert-/Mail-Abnahme enthalten.
- PB2B-27849: App laut Jira-Kommentar vom 22.09.2026 angelegt. Kein aktueller Login-Test im Upload.
- DBI-7161: Infrastrukturentwurf vorhanden; Schnittstellenfreigabe und Zustellung nicht belegt.

Neuere eigene Ausgaben zu diesen Tickets stehen gegebenenfalls im jeweiligen ergebnisse/-Unterordner; diese Liste ist keine Live-Jira-Abfrage.

Nächster Schritt bei DEV-Zertifikatsfehler: bash start.sh 12139 tls --env dev. Kein erneuter TEST-Upload.
