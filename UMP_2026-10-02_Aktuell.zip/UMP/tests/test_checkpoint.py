"""Offline regressions for the new handover. Azure/HTTP calls are simulated."""
from __future__ import annotations
import argparse
from contextlib import ExitStack, redirect_stdout
from datetime import datetime, timezone
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]

def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec)
    sys.modules[name] = value
    spec.loader.exec_module(value)
    return value

w = load("checkpoint_start", ROOT / "start.py")
p = load("checkpoint_progress", ROOT / "fortschritt.py")
lp = w.lp()

def args(*items):
    return w.parser().parse_args(list(items))

class CheckpointTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.base = Path(self.temp.name)
        self.stack = ExitStack()
        self.stack.enter_context(patch.object(w, "RESULTS", self.base / "ergebnisse"))
        self.stack.enter_context(patch.object(w, "LOCAL", self.base / "lokal.json"))
        self.stack.enter_context(patch.object(w, "lp", return_value=lp))
        self.stack.enter_context(redirect_stdout(io.StringIO()))
        self.root = w.RESULTS / "DBI-12139"
        self.root.mkdir(parents=True)

    def tearDown(self):
        self.stack.close()
        self.temp.cleanup()

    def write(self, rel, data):
        target = self.root / rel
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(json.dumps(data))
        return target

    def inventory(self, env="test", passed=True, at="2026-10-02T08:00:00+00:00"):
        cfg = lp.env_config(env)
        entry = {
            "errors": [],
            "storage": {"name": cfg["storage_account"], "provisioningState": "Succeeded"},
            "gateway": {"provisioningState": "Succeeded"},
            "checks": [{"passed": passed} for _ in range(7)],
            "gateway_checks": [{"passed": True} for _ in range(18)],
            "gateway_backend_matches_expected_storage": True,
        }
        return self.write(f"inv-{env}-{at[11:13]}/inventar.json",
                          {"ticket": "DBI-12139", "checked_at_utc": at, "environments": {env: entry}})

    def receipt(self, env="test", status="uploaded"):
        cfg = lp.env_config(env)
        blob = "dbi-12139-check-20261002T085902Z-99cb2a98bb4b.txt"
        sample = b"x" * 8192
        receipt = {
            "ticket": "DBI-12139", "environment": env, "campaign": "uniglobal",
            "created_at_utc": "2026-10-02T08:59:02+00:00",
            "storage_account": cfg["storage_account"], "container": "uniglobal-release-1",
            "blob": blob, "sample_file": "testdatei.txt", "sample_sha256": hashlib.sha256(sample).hexdigest(),
            "size_bytes": len(sample), "status": status,
        }
        target = self.write(f"run/{env}/upload.json", receipt)
        target.with_name("testdatei.txt").write_bytes(sample)
        return target

    def probe(self, env="test", network="intern", passed=True, at="2026-10-02T09:00:16+00:00"):
        receipt, _ = lp.read_receipt(self.root / f"run/{env}/upload.json")
        url = lp.urls(env, "uniglobal", receipt["blob"])[0]
        return self.write(f"run/{env}/probe-{network}-{at[11:13]}.json", {
            "ticket": "DBI-12139", "environment": env, "campaign": "uniglobal", "endpoint": "asset-domain",
            "checked_at_utc": at, "network_declared_by_operator": network, "passed": passed,
            "get": {"url": url, "http_status": 200 if passed else 403, "passed": passed, "content_matches_test_file": passed},
            "range_get": {"url": url, "http_status": 206 if passed else 403, "passed": passed, "content_matches_expected_range": passed},
        })

    def test_complete_inventory_is_confirmed(self):
        self.inventory()
        self.assertTrue(p.inventory_state(self.root, lp)["test"]["passed"])

    def test_empty_inventory_is_not_success(self):
        self.assertEqual(p.inventory_state(self.root, lp), {})

    def test_one_failed_check_is_not_success(self):
        self.inventory(passed=False)
        self.assertFalse(p.inventory_state(self.root, lp)["test"]["passed"])

    def test_missing_gateway_checks_is_not_success(self):
        file = self.inventory()
        value = json.loads(file.read_text())
        value["environments"]["test"]["gateway_checks"] = []
        file.write_text(json.dumps(value))
        self.assertFalse(p.inventory_state(self.root, lp)["test"]["passed"])

    def test_latest_inventory_failure_replaces_previous_success(self):
        self.inventory(at="2026-10-02T08:00:00+00:00")
        self.inventory(passed=False, at="2026-10-02T10:00:00+00:00")
        self.assertFalse(p.inventory_state(self.root, lp)["test"]["passed"])

    def test_internal_probe_does_not_prove_external_access(self):
        self.receipt(); self.probe()
        state = p.evidence_state(w)["environments"]["test"]
        self.assertTrue(state["last_probe"]["passed"])
        self.assertIsNone(state["last_external_probe"])

    def test_external_probe_is_separate_evidence(self):
        self.receipt(); self.probe(network="extern")
        self.assertTrue(p.evidence_state(w)["environments"]["test"]["last_external_probe"]["passed"])

    def test_wrong_content_cannot_pass_from_top_level_flag(self):
        self.receipt(); file = self.probe()
        record = json.loads(file.read_text())
        record["get"]["content_matches_test_file"] = False
        file.write_text(json.dumps(record))
        self.assertFalse(p.evidence_state(w)["environments"]["test"]["last_probe"]["passed"])

    def test_unrelated_url_is_not_accepted(self):
        self.receipt(); file = self.probe()
        record = json.loads(file.read_text())
        record["get"]["url"] = "https://example.invalid/unrelated"
        file.write_text(json.dumps(record))
        self.assertIsNone(p.evidence_state(w)["environments"]["test"]["last_probe"])

    def test_latest_failed_probe_does_not_get_masked(self):
        self.receipt()
        self.probe(at="2026-10-02T09:00:00+00:00")
        self.probe(passed=False, at="2026-10-02T10:00:00+00:00")
        self.assertFalse(p.evidence_state(w)["environments"]["test"]["last_probe"]["passed"])

    def test_cleanup_retains_historical_pass(self):
        self.receipt(status="current_test_blob_deleted")
        self.probe()
        state = p.evidence_state(w)
        self.assertTrue(state["environments"]["test"]["last_probe"]["passed"])
        self.assertEqual(state["open_uploads"], [])

    def test_summary_never_logs_in(self):
        self.inventory(); self.receipt(); self.probe()
        with patch.object(w, "ensure_login") as login, patch.object(lp, "az_json") as azure:
            self.assertEqual(p.summary(w), 0)
            login.assert_not_called(); azure.assert_not_called()

    def test_default_with_saved_inventory_reads_existing_status(self):
        self.inventory(); self.receipt(); self.probe()
        with patch.object(w, "asset_check") as live:
            self.assertEqual(w.assets("check", args("12139")), 0)
            live.assert_not_called()

    def test_explicit_inventory_refresh_still_available(self):
        with patch.object(w, "asset_check", return_value=0) as live:
            self.assertEqual(w.assets("inventar", args("12139")), 0)
            live.assert_called_once()

    def test_resume_skips_successful_test_without_upload(self):
        self.inventory(); self.receipt(); self.probe()
        with patch.object(lp, "upload_test") as upload, patch.object(lp, "probe") as probe:
            self.assertEqual(p.remaining(w, args("12139", "rest", "--env", "test", "--network", "intern")), 0)
            upload.assert_not_called(); probe.assert_not_called()

    def test_resume_reuses_existing_unprobed_receipt(self):
        receipt = self.receipt()
        with patch.object(lp, "upload_test") as upload, patch.object(lp, "probe", return_value=0) as probe:
            self.assertEqual(p.remaining(w, args("12139", "rest", "--env", "test", "--network", "intern")), 0)
            upload.assert_not_called()
            self.assertEqual(probe.call_args[0][0].receipt, receipt)

    def test_resume_missing_inventory_blocks_upload(self):
        with patch.object(lp, "upload_test") as upload, self.assertRaises(w.Stop):
            p.remaining(w, args("12139", "rest", "--env", "dev", "--network", "intern"))
        upload.assert_not_called()

    def test_resume_uncertain_upload_blocks_new_upload(self):
        self.inventory(); self.receipt(status="upload_failed_or_unconfirmed")
        with patch.object(lp, "upload_test") as upload, self.assertRaises(w.Stop):
            p.remaining(w, args("12139", "rest", "--env", "test", "--network", "intern"))
        upload.assert_not_called()

    def test_all_remaining_environments_resume_idempotently(self):
        for env in ("dev", "test", "prod"):
            self.inventory(env)
        self.receipt("test"); self.probe("test")
        uploaded, checked = [], []
        def fake_upload(values):
            uploaded.append(values.env)
            self.receipt(values.env)
            return 0
        def fake_probe(values):
            rec, _ = lp.read_receipt(values.receipt)
            checked.append(rec["environment"])
            self.probe(rec["environment"], network=values.network)
            return 0
        values = args("12139", "rest", "--network", "intern")
        with patch.object(w, "ensure_login") as login, patch.object(lp, "upload_test", side_effect=fake_upload), patch.object(lp, "probe", side_effect=fake_probe):
            self.assertEqual(p.remaining(w, values), 0)
            self.assertEqual(uploaded, ["dev", "prod"])
            self.assertEqual(checked, ["dev", "prod"])
            self.assertEqual(login.call_count, 2)
            self.assertEqual(p.remaining(w, values), 0)
            self.assertEqual(uploaded, ["dev", "prod"])
            self.assertEqual(checked, ["dev", "prod"])

    def test_external_never_creates_missing_testblob(self):
        with patch.object(w, "confirm") as confirm, patch.object(w, "ensure_login") as login, patch.object(lp, "upload_test") as upload:
            self.assertEqual(p.remaining(w, args("12139", "extern", "--env", "test"), external_only=True), 2)
            confirm.assert_called_once_with("NETZ EXTERN")
            upload.assert_not_called(); login.assert_not_called()

    def test_external_reuses_internal_testblob_without_azure(self):
        self.receipt(); self.probe()
        with patch.object(w, "confirm"), patch.object(w, "ensure_login") as login, patch.object(lp, "probe", return_value=0) as probe:
            self.assertEqual(p.remaining(w, args("12139", "extern", "--env", "test"), external_only=True), 0)
            self.assertEqual(probe.call_args[0][0].network, "extern")
            login.assert_not_called()

    def test_probe_failure_returns_failure(self):
        self.receipt()
        with patch.object(lp, "probe", return_value=2):
            self.assertEqual(p.remaining(w, args("12139", "rest", "--env", "test", "--network", "intern")), 2)

    def test_invalid_sample_stops(self):
        file = self.receipt()
        file.with_name("testdatei.txt").write_bytes(b"bad")
        with self.assertRaises(lp.TaskError):
            p.evidence_state(w)

    def test_bad_json_is_not_ignored_as_success(self):
        file = self.root / "inventar.json"; file.write_text("{invalid")
        with self.assertRaises(ValueError):
            p.inventory_state(self.root, lp)

    def test_media_uses_explicit_tail_range(self):
        total = 20 * 1024 * 1024
        replies = [
            ({"http_status": 206, "headers": {"content-type": "video/mp4", "content-range": f"bytes 0-1023/{total}"}}, b"a" * 1024),
            ({"http_status": 206, "headers": {"content-type": "video/mp4", "content-range": f"bytes {total-1024}-{total-1}/{total}"}}, b"z" * 1024),
        ]
        values = argparse.Namespace(env="test", campaign="uniglobal", blob="film.mp4", min_size_mib=10,
                                    network="intern", output=self.base/"medium.json")
        with patch.object(lp, "http_get", side_effect=replies) as get:
            self.assertEqual(lp.probe_media(values), 0)
            self.assertEqual(get.call_args_list[1].kwargs["byte_range"], f"bytes={total-1024}-{total-1}")

    def test_media_does_not_send_tail_request_after_bad_first_range(self):
        values = argparse.Namespace(env="test", campaign="uniglobal", blob="film.mp4", min_size_mib=10,
                                    network="intern", output=self.base/"medium.json")
        with patch.object(lp, "http_get", return_value=({"http_status": 403}, b"")) as get:
            self.assertEqual(lp.probe_media(values), 2)
            self.assertEqual(get.call_count, 1)

    def test_minimum_media_size_is_configurable(self):
        self.assertEqual(args("12139", "medium", "--min-size-mib", "3").min_size_mib, 3)

    def test_timestamp_order_is_timezone_aware(self):
        self.assertEqual(p.timestamp("2026-10-02T11:00:00+02:00"), p.timestamp("2026-10-02T09:00:00Z"))

    def test_invalid_timestamp_is_oldest(self):
        self.assertLess(p.timestamp(None), p.timestamp("2026-10-02T09:00:00Z"))

if __name__ == "__main__":
    unittest.main()
