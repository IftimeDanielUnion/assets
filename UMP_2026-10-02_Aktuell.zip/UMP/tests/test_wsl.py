"""WSL starter tests. All Azure/HTTP/SSH calls mocked; Git tests use temporary repos."""
from __future__ import annotations
import argparse
from contextlib import ExitStack, redirect_stdout
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('wsl_starter_for_tests', ROOT / 'start.py')
w = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = w
spec.loader.exec_module(w)
LP = w.lp()


def args(*items):
    return w.parser().parse_args(list(items))


def query_fixture(rows=None):
    return {'tables': [{'name': 'PrimaryResult', 'columns': [{'name': n} for n in
            ['ServiceName', 'SeverityText', 'Records', 'Latest']],
            'rows': [['ump', 'ERROR', 1, '2026-10-01T12:00:00Z']] if rows is None else rows}]}


class WslBasics(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(prefix='ump wsl test ')
        self.folder = Path(self.tmp.name)
        self.stack = ExitStack()
        self.stack.enter_context(patch.object(w, 'LOCAL', self.folder/'lokal.json'))
        self.stack.enter_context(patch.object(w, 'RESULTS', self.folder/'ergebnisse'))
        self.stack.enter_context(redirect_stdout(io.StringIO()))
    def tearDown(self):
        self.stack.close(); self.tmp.cleanup()
    def test_windows_path_with_spaces_converted(self):
        self.assertEqual(str(w.user_path(r'"C:\Users\Daniel\Mein Repo"')), '/mnt/c/Users/Daniel/Mein Repo')
    def test_windows_forward_path_converted(self):
        self.assertEqual(str(w.user_path('D:/repos/live')), '/mnt/d/repos/live')
    def test_wsl_unc_current_distro(self):
        with patch.dict(os.environ, {'WSL_DISTRO_NAME':'Ubuntu'}):
            self.assertEqual(str(w.user_path(r'\\wsl.localhost\Ubuntu\home\daniel\repo')), '/home/daniel/repo')
    def test_wrong_wsl_distro_rejected(self):
        with patch.dict(os.environ, {'WSL_DISTRO_NAME':'Ubuntu'}), self.assertRaises(w.Stop):
            w.user_path(r'\\wsl.localhost\Debian\home\daniel')
    def test_network_unc_not_guessed(self):
        with self.assertRaises(w.Stop): w.user_path(r'\\server\share\repo')
    def test_path_control_characters_rejected(self):
        for value in ['', '/tmp/one\nnext','/tmp/one\rnext','a\0b']:
            with self.subTest(value=value), self.assertRaises(w.Stop): w.user_path(value)
    def test_linux_path_spaces_preserved(self):
        self.assertEqual(w.user_path(str(self.folder / 'repo with spaces')),self.folder/'repo with spaces')
    def test_windows_cli_rejected(self):
        for path in ['/mnt/c/Program Files/Microsoft SDKs/az','/tmp/az.cmd','/tmp/az.exe']:
            with patch.object(w.shutil, 'which', return_value=path), self.assertRaises(w.Stop): w.executable('az')
    def test_missing_cli_explained(self):
        with patch.object(w.shutil, 'which', return_value=None), self.assertRaises(w.Stop): w.executable('az')
    def test_linux_cli_accepted(self):
        with patch.object(w.shutil, 'which', return_value='/usr/bin/az'):
            self.assertEqual(w.executable('az'),'/usr/bin/az')
    def test_config_merge_keeps_other_ticket(self):
        w.save_local('live','/home/daniel/live','repos')
        w.save_local('catalog','/home/daniel/catalog','repos')
        self.assertEqual(w.local_config()['repos'],{'live':'/home/daniel/live','catalog':'/home/daniel/catalog'})
        self.assertEqual(w.LOCAL.stat().st_mode & 0o777,0o600)
    def test_non_object_config_rejected(self):
        w.LOCAL.write_text('[]')
        with self.assertRaises(w.Stop): w.local_config()
    def test_oversized_config_rejected(self):
        w.LOCAL.write_text('x'*65537)
        with self.assertRaises(w.Stop): w.local_config()
    def test_noninteractive_confirmation_refuses(self):
        with patch('sys.stdin.isatty',return_value=False),self.assertRaises(w.Stop): w.confirm('UPLOAD test')
    def test_noninteractive_missing_required_input_explained(self):
        with patch('sys.stdin.isatty',return_value=False),self.assertRaises(w.Stop): w.ask('Repo')
    def test_noninteractive_default_does_not_block(self):
        with patch('sys.stdin.isatty',return_value=False): self.assertEqual(w.ask('Netz','unbekannt'),'unbekannt')
    def test_login_no_automatic_call_if_signed_in(self):
        with patch.object(w,'executable',return_value='/usr/bin/az'), \
             patch.object(w.subprocess,'run',return_value=subprocess.CompletedProcess([],0)) as proc, \
             patch.object(w,'run') as runner:
            w.ensure_login(); runner.assert_not_called()
            self.assertIn('none',proc.call_args.args[0])
    def test_login_noninteractive_fails_cleanly(self):
        with patch.object(w,'executable',return_value='/usr/bin/az'), \
             patch.object(w.subprocess,'run',return_value=subprocess.CompletedProcess([],1)), \
             patch('sys.stdin.isatty',return_value=False),self.assertRaises(w.Stop): w.ensure_login()
    def test_portal_map_no_live_call(self):
        with patch.object(w,'ensure_login') as auth, patch.object(LP,'az_json') as cli:
            p=w.create_portal_map()
            self.assertIn('rg-monitoring-test',p.read_text())
            self.assertIn('stumpdevlpassetsyws91x59',p.read_text())
            auth.assert_not_called(); cli.assert_not_called()
    def test_timestamped_reports_do_not_overwrite(self):
        first=w.new_run('DBI-12139');second=w.new_run('DBI-12139')
        self.assertNotEqual(first,second)
        w.report(first,'DBI-12139','Inventar',['kein Abruf bestätigt'])
        self.assertIn('Kein Nachweis einer vollständigen Jira-Abnahme', (first/'STATUS.md').read_text())
    def test_all_ticket_aliases_exist(self):
        self.assertEqual(set(w.ALIASES),{'12139','11149','6455','27849','7161'})
    def test_default_actions_read_only(self):
        self.assertEqual(args('12139').action,'check')
        self.assertIsNone(args('12139').network)
    def test_no_implicit_upload_all(self):
        with self.assertRaises(w.Stop): w.assets('upload',args('12139','upload','--env','all'))
    def test_missing_receipt_is_actionable(self):
        with self.assertRaises(w.Stop): w.latest_receipt(args('12139','probe'))
    def test_raw_token_commands_not_in_starter(self):
        text=(ROOT/'start.py').read_text()
        self.assertNotIn('get-access-token',text)
        self.assertNotIn('az account set',text)
        self.assertNotIn('shell=True',text)
    def test_terraform_filter_is_declared(self):
        text=(ROOT/'pruefen.py').read_text()
        self.assertIn('module_ticket != ticket',text)
        self.assertIn("native_terraform(args.ticket)",text)
    def test_launcher_has_lf_and_is_valid_bash(self):
        content=(ROOT/'start.sh').read_bytes()
        self.assertNotIn(b'\r',content)
        proc=subprocess.run(['bash','-n',str(ROOT/'start.sh')],capture_output=True,text=True)
        self.assertEqual(proc.returncode,0,proc.stderr)
    def test_vscode_tasks_use_wsl_bash_and_no_apply(self):
        tasks=json.loads((ROOT/'.vscode/tasks.json').read_text())['tasks']
        for task in tasks:
            self.assertEqual(task['command'],'bash')
            self.assertEqual(task['type'],'process')
            self.assertNotIn('apply',task['args'])
    def test_fresh_package_has_no_legacy_powershell_or_patch_stub(self):
        self.assertFalse((ROOT/'DBI-12139/check_lp_assets.ps1').exists())
        self.assertFalse((ROOT/'DBI-6455/monitoring-test.patch').exists())


class MonitoringChecks(unittest.TestCase):
    setUp=WslBasics.setUp
    tearDown=WslBasics.tearDown
    def test_workspace_mapping_matches_snapshot_names(self):
        for env in ['dev','test','prod']:
            target=w.monitoring_target(env)
            self.assertEqual(target['name'],'log-ump-'+env)
            self.assertEqual(target['resource_group'],'rg-monitoring-'+env)
            self.assertIn(LP.env_config(env)['subscription_id'],target['id'])
    def test_log_schema_read_and_empty_table(self):
        self.assertEqual(w.log_rows(query_fixture())[0]['Records'],1)
        self.assertEqual(w.log_rows(query_fixture([])),[])
    def test_partial_log_error_not_success(self):
        data=query_fixture();data['error']={'code':'PartialError'}
        with self.assertRaises(w.Stop): w.log_rows(data)
    def test_missing_or_wrong_table_not_success(self):
        for data in [{}, {'tables':[{'name':'Other'}]}, {'tables':[{'name':'PrimaryResult','columns':[]}]}]:
            with self.subTest(data=data),self.assertRaises(w.Stop): w.log_rows(data)
    def test_arm_pagination_rejects_foreign_host(self):
        with self.assertRaises(w.Stop): w.arm_pages(LP,'https://other.invalid/items','x')
    def test_arm_repeated_page_rejected(self):
        url='https://management.azure.com/a'
        with patch.object(LP,'az_json',return_value={'value':[],'nextLink':url}),self.assertRaises(w.Stop):
            w.arm_pages(LP,url,'x')
    def test_read_only_monitoring_e2e_mock(self):
        cfg=w.monitoring_target('test');calls=[]
        def mock_cli(command):
            calls.append(command)
            if command[:4]==['monitor','log-analytics','workspace','show']:
                return {'id':cfg['id'],'customerId':'12345678-1234-1234-1234-123456789abc'}
            if 'post' in command: return query_fixture()
            if 'scheduledQueryRules' in command[command.index('--url')+1]:
                return {'value':[{'name':'existing','properties':{'scopes':[cfg['id']]}}]}
            raise AssertionError(command)
        with patch.object(w,'ensure_login'),patch.object(w,'lp',return_value=LP),patch.object(LP,'az_json',side_effect=mock_cli):
            self.assertEqual(w.monitoring(args('6455')),0)
        for cmd in calls:
            self.assertIn('--subscription',cmd)
            self.assertNotIn('put',cmd);self.assertNotIn('delete',cmd)
            self.assertNotIn('create',cmd);self.assertNotIn('get-access-token',cmd)
        result=list(w.RESULTS.glob('DBI-6455/*/details.json'))
        self.assertEqual(len(result),1)
        self.assertEqual(len(json.loads(result[0].read_text())['test']['related_rules']),1)
    def test_empty_logs_leave_checkpoint_open(self):
        cfg=w.monitoring_target('test')
        replies=[{'id':cfg['id'],'customerId':'12345678-1234-1234-1234-123456789abc'},query_fixture([]),{'value':[]}]
        with patch.object(w,'ensure_login'),patch.object(w,'lp',return_value=LP),patch.object(LP,'az_json',side_effect=replies):
            self.assertEqual(w.monitoring(args('6455')),2)
    def test_no_permission_not_missing_resource_claim(self):
        with patch.object(w,'ensure_login'),patch.object(w,'lp',return_value=LP),patch.object(LP,'az_json',side_effect=LP.TaskError('403 Forbidden')):
            self.assertEqual(w.monitoring(args('6455')),2)
        report=next(w.RESULTS.glob('DBI-6455/*/STATUS.md')).read_text()
        self.assertIn('keine Aussage über fehlende',report)


class RemoteChecks(unittest.TestCase):
    setUp=WslBasics.setUp
    tearDown=WslBasics.tearDown
    def test_remote_command_uses_strict_keys(self):
        command=w.sftp_command('admin@ump-host','/srv/ump with spaces/current','/usr/bin/php8.5',False)
        self.assertIn('StrictHostKeyChecking=yes',command)
        self.assertNotIn('--connect',command[-1])
        self.assertIn("cd -- '/srv/ump with spaces/current'",command[-1])
        self.assertIn('sudo -u www-data /usr/bin/php8.5',command[-1])
        self.assertNotIn('app:export',command[-1])
    def test_connect_requires_explicit_action(self):
        command=w.sftp_command('ump-host','/srv/ump','php',True)
        self.assertTrue(command[-1].endswith('--connect'))
    def test_bad_ssh_targets_rejected(self):
        for target in ['-oProxyCommand=x','host;touch x','host name','host\nnext','']:
            with self.subTest(target=target),self.assertRaises(w.Stop):w.sftp_command(target,'/srv/ump','php',False)
    def test_bad_remote_path_rejected(self):
        for directory in ['relative','/srv/ump\nrm other','/srv/ump\0x']:
            with self.subTest(directory=directory),self.assertRaises(w.Stop):w.sftp_command('host',directory,'php',False)
    def test_public_key_check_never_contacts_server(self):
        with patch.object(w,'run') as runner:
            self.assertEqual(w.sftp('check',args('11149')),0);runner.assert_not_called()
    def test_saml_check_never_fetches_metadata(self):
        with patch.object(w,'run') as runner:
            self.assertEqual(w.saml('check',args('27849')),0);runner.assert_not_called()
    def test_saml_requires_worktree_before_prepare(self):
        with self.assertRaises(w.Stop):w.saml('prepare',args('27849','prepare'))
    def test_saml_generated_command_restores_env(self):
        text=(ROOT/'start.py').read_text()
        self.assertIn('ANSIBLE_HOST_KEY_CHECKING="True"',text)
        self.assertIn('"ANSIBLE_HOST_KEY_CHECKING=True", *cmd',text)
        self.assertIn('"cd -- " + shlex.quote(str(repo))',text)


@unittest.skipUnless(shutil.which('git'),'Git fehlt: Worktree-Integration nicht ausgeführt')
class WorktreeIntegration(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(prefix='ump git space ')
        self.folder=Path(self.tmp.name)
        self.bundle=self.folder/'bundle';self.bundle.mkdir()
        self.source=self.folder/'original live';(self.source/'live').mkdir(parents=True)
        (self.source/'live/root.hcl').write_text('')
        (self.source/'x.txt').write_text('old\n')
        for arguments in [['init','-b','main'],['config','user.name','Unit Test'],['config','user.email','test@example.invalid'],
                          ['add','.'],['-c','commit.gpgsign=false','commit','-m','base']]:
            self.g(*arguments)
        src=self.bundle/'DBI-6455/code/live/x.txt';src.parent.mkdir(parents=True);src.write_text('new\n')
        shutil.copyfile(ROOT/'uebernehmen.py',self.bundle/'uebernehmen.py')
        manifest={'files':[{'ticket':'DBI-6455','repository':'live','repository_path':'x.txt',
            'package_path':'DBI-6455/code/live/x.txt','sha256':hashlib.sha256(b'new\n').hexdigest(),
            'original_sha256':hashlib.sha256(b'old\n').hexdigest()}]}
        (self.bundle/'paket.json').write_text(json.dumps(manifest))
        self.stack=ExitStack()
        self.stack.enter_context(patch.object(w,'BASE',self.bundle))
        self.stack.enter_context(patch.object(w,'LOCAL',self.bundle/'lokal.json'))
        self.stack.enter_context(patch.object(Path,'home',return_value=self.folder/'home'))
        self.stack.enter_context(patch('sys.stdin.isatty',return_value=True))
        self.stack.enter_context(patch('builtins.input',return_value='DBI-6455'))
        self.stack.enter_context(redirect_stdout(io.StringIO()))
    def tearDown(self):
        self.stack.close();self.tmp.cleanup()
    def g(self,*arguments,cwd=None):
        p=subprocess.run(['git','-C',str(cwd or self.source),*arguments],capture_output=True,text=True,check=False)
        if p.returncode:raise AssertionError(p.stderr)
        return p.stdout.strip()
    def test_copy_in_worktree_keeps_original_and_branch(self):
        self.assertEqual(w.code('DBI-6455',args('6455','code','--repo',str(self.source))),0)
        target=Path(w.local_config()['worktrees']['DBI-6455'])
        self.assertEqual((self.source/'x.txt').read_text(),'old\n')
        self.assertEqual(self.g('branch','--show-current'),'main')
        self.assertEqual((target/'x.txt').read_text(),'new\n')
        self.assertEqual(self.g('branch','--show-current',cwd=target),'feat/DBI-6455-ump-checkpoint')
        self.assertEqual(self.g('status','--porcelain'),'')
    def test_repeated_import_is_idempotent(self):
        a=args('6455','code','--repo',str(self.source))
        self.assertEqual(w.code('DBI-6455',a),0)
        self.assertEqual(w.code('DBI-6455',a),0)
    def test_dirty_original_not_silently_ignored(self):
        (self.source/'x.txt').write_text('mine\n')
        with self.assertRaises(w.Stop):w.code('DBI-6455',args('6455','code','--repo',str(self.source)))
        self.assertFalse((self.folder/'home/ump-worktrees').exists())
    def test_newer_committed_original_not_overwritten(self):
        (self.source/'x.txt').write_text('colleague\n');self.g('add','.');self.g('-c','commit.gpgsign=false','commit','-m','newer')
        with self.assertRaises(ValueError):w.code('DBI-6455',args('6455','code','--repo',str(self.source)))
        self.assertEqual((self.source/'x.txt').read_text(),'colleague\n')
    def test_unrelated_existing_branch_not_used(self):
        self.g('branch','feat/DBI-6455-ump-checkpoint')
        with self.assertRaises(w.Stop):w.code('DBI-6455',args('6455','code','--repo',str(self.source)))


class LineEndingChecks(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name)
        self.pkg=self.root/'pkg';self.pkg.mkdir();self.target=self.root/'target';self.target.mkdir()
        self.new=self.pkg/'new.txt';self.old=self.target/'old.txt'
        self.new.write_bytes(b'new\n');self.old.write_bytes(b'old\n')
        self.helper=w.load_module('wsl_crlf_helper',ROOT/'uebernehmen.py')
        self.manifest={'files':[{'ticket':'T','package_path':'new.txt','repository_path':'old.txt',
          'sha256':hashlib.sha256(b'new\n').hexdigest(), 'lf_sha256':hashlib.sha256(b'new\n').hexdigest(),
          'original_sha256':hashlib.sha256(b'old\r\n').hexdigest(), 'original_lf_sha256':hashlib.sha256(b'old\n').hexdigest()}]}
        self.stack=ExitStack();self.stack.enter_context(patch.object(self.helper,'BASE',self.pkg))
        self.stack.enter_context(redirect_stdout(io.StringIO()))
    def tearDown(self):self.stack.close();self.tmp.cleanup()
    def test_original_lf_matches_windows_snapshot(self):
        self.assertEqual(len(self.helper.inspect('T',self.target,self.manifest)),1)
    def test_original_crlf_still_accepted(self):
        self.old.write_bytes(b'old\r\n')
        self.assertEqual(len(self.helper.inspect('T',self.target,self.manifest)),1)
    def test_newer_real_change_still_rejected(self):
        self.old.write_bytes(b'other\r\n')
        with self.assertRaises(ValueError):self.helper.inspect('T',self.target,self.manifest)
    def test_source_crlf_only_change_allowed(self):
        self.new.write_bytes(b'new\r\n')
        self.assertEqual(len(self.helper.inspect('T',self.target,self.manifest)),1)
    def test_already_copied_crlf_detected_as_current(self):
        self.old.write_bytes(b'new\r\n')
        self.assertEqual(self.helper.inspect('T',self.target,self.manifest),[])

class AssetRunnerChecks(unittest.TestCase):
    setUp=WslBasics.setUp
    tearDown=WslBasics.tearDown
    def test_all_environment_inventory_mocked(self):
        from test_ticketcode import gateway_fixture, containers
        calls=[]
        def fake_az(cmd):
            calls.append(cmd)
            sub=cmd[cmd.index('--subscription')+1]
            env=next(e for e,c in LP.load_config()['environments'].items() if c['subscription_id']==sub)
            if cmd[:3]==['storage','account','show']:
                return {'id':LP.account_id(LP.env_config(env)), 'allowBlobPublicAccess':True,'publicNetworkAccess':'Disabled'}
            if cmd[:3]==['rest','--method','get']:return {'value':containers()}
            if cmd[:3]==['network','application-gateway','show']:return gateway_fixture(env)
            raise AssertionError(cmd)
        with patch.object(w,'ensure_login'), patch.object(w,'lp',return_value=LP), \
             patch.object(w,'find_repo',return_value=None), patch.object(LP,'az_json',side_effect=fake_az):
            self.assertEqual(w.asset_check(args('12139')),0)
        self.assertEqual(len(calls),9)
        report=next(w.RESULTS.glob('DBI-12139/*/STATUS.md')).read_text()
        for env in ['dev','test','prod']:self.assertIn('| '+env+' |',report)
        self.assertIn('Asset-Abruf steht aus',report)
        for cmd in calls:
            self.assertNotIn('upload',cmd);self.assertNotIn('create',cmd);self.assertNotIn('delete',cmd)
    def test_latest_receipt_skips_deleted_and_filters_environment(self):
        from test_ticketcode import receipt_at
        first=w.RESULTS/'DBI-12139/older';second=w.RESULTS/'DBI-12139/newer'
        first.mkdir(parents=True);second.mkdir(parents=True)
        p1,_=receipt_at(first);p2,_=receipt_at(second)
        data=json.loads(p2.read_text());data['status']='current_test_blob_deleted'
        p2.write_text(json.dumps(data))
        with patch.object(w,'lp',return_value=LP):
            self.assertEqual(w.latest_receipt(args('12139','probe','--env','dev')),p1)
            with self.assertRaises(w.Stop):w.latest_receipt(args('12139','probe','--env','test'))
    def test_explicit_receipt_is_validated(self):
        bad=self.folder/'bad.json';bad.write_text('{}')
        with patch.object(w,'lp',return_value=LP),self.assertRaises(LP.TaskError):
            w.latest_receipt(args('12139','probe','--receipt',str(bad)))
    def test_inventory_read_failure_keeps_ticket_open(self):
        with patch.object(w,'ensure_login'),patch.object(w,'lp',return_value=LP),patch.object(w,'find_repo',return_value=None), \
             patch.object(LP,'az_json',side_effect=LP.TaskError('403 Forbidden')):
            self.assertEqual(w.asset_check(args('12139','--env','test')),2)
        report=next(w.RESULTS.glob('DBI-12139/*/STATUS.md')).read_text()
        self.assertIn('kein Nachweis fehlender Ressourcen',report)

if __name__=='__main__':
    unittest.main(verbosity=2)
