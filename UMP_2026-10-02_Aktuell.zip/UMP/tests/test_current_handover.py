"""TLS/regression checks. Network, Azure and remote OpenSSL calls are simulated."""
from __future__ import annotations
import argparse
from contextlib import redirect_stdout
import importlib.util
import io
import json
from pathlib import Path
import socket
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]

def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec)
    sys.modules[name] = value
    spec.loader.exec_module(value)
    return value

w = load("handover_wsl", ROOT / "start.py")
p = load("handover_progress", ROOT / "fortschritt.py")
lp = w.lp()
FAKE_PUBLIC_CERT = "-----BEGIN CERTIFICATE-----\nZmFrZQ==\n-----END CERTIFICATE-----"

class HandoverTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.folder = Path(self.temp.name)
        self.addCleanup(self.temp.cleanup)

    def gateway(self):
        c = lp.env_config("dev")
        gid = (f"/subscriptions/{c['subscription_id']}/resourceGroups/{c['gateway_resource_group']}"
               f"/providers/Microsoft.Network/applicationGateways/{c['gateway']}")
        cert = gid + "/sslCertificates/landing-internal-certificate"
        return {"id": gid, "listeners": [{"name": "landingassets-private", "hostNames": [c["asset_host"]],
                                         "sslCertificate": {"id": cert}}],
                "certificates": [{"name": "landing-internal-certificate", "id": cert,
                                  "keyVaultSecretId": "https://approved-vault.vault.azure.net/secrets/landing"}]}

    def run_tls(self, *, gateway=None, dns_error=False, verified=True):
        resultfile = self.folder / "tls.json"
        with redirect_stdout(io.StringIO()), \
             patch.object(lp, "direct_tls_certificate", return_value={"verified": verified}), \
             patch.object(lp.socket, "getaddrinfo", side_effect=socket.gaierror("DNS failed") if dns_error else None,
                          return_value=[(socket.AF_INET, socket.SOCK_STREAM, 6, "", ("192.0.2.10", 443))]), \
             patch.object(lp, "az_json", return_value=gateway if gateway is not None else self.gateway()) as az, \
             patch("urllib.request.getproxies", return_value={"https": "http://secret:password@proxy.invalid"}), \
             patch("urllib.request.proxy_bypass", return_value=False):
            rc = lp.tls_diagnose(argparse.Namespace(env="dev", output=resultfile))
            command = az.call_args[0][0]
        return rc, json.loads(resultfile.read_text()), command

    def test_hostname_mismatch_is_explained(self):
        self.assertIn("passt nicht", p.failure_reason({"passed": False, "error": "Hostname mismatch"}))

    def test_other_certificate_error_is_not_misreported_as_hostname(self):
        text = p.failure_reason({"passed": False, "error": "CERTIFICATE_VERIFY_FAILED: unknown CA"})
        self.assertIn("Zertifikatsprüfung", text)
        self.assertNotIn("passt nicht", text)

    def test_http_and_missing_status_remain_distinct(self):
        self.assertEqual(p.failure_reason({"passed": False, "http_status": 403}), "HTTP 403")
        self.assertIn("ohne", p.failure_reason({"passed": False}))
        self.assertEqual(p.failure_reason({"passed": True}), "")

    def test_openssl_keeps_validation_enabled(self):
        replies = [subprocess.CompletedProcess([], 0, FAKE_PUBLIC_CERT, "verify return:1"),
                   subprocess.CompletedProcess([], 0, "DNS:landing-assets.dev.apps.union-investment.de", "")]
        with patch.object(lp.shutil, "which", return_value="/usr/bin/openssl"), \
             patch.object(lp.subprocess, "run", side_effect=replies) as runner:
            result = lp.direct_tls_certificate("landing-assets.dev.apps.union-investment.de")
        self.assertTrue(result["verified"])
        cmd = runner.call_args_list[0].args[0]
        for item in ("-verify_hostname", "-verify_return_error", "-servername"):
            self.assertIn(item, cmd)
        self.assertEqual(runner.call_args_list[0].kwargs["input"], "")
        self.assertNotIn("-no_check_time", cmd)

    def test_bad_certificate_cannot_be_a_pass(self):
        replies = [subprocess.CompletedProcess([], 1, FAKE_PUBLIC_CERT, "hostname mismatch"),
                   subprocess.CompletedProcess([], 0, "DNS:wrong.example", "")]
        with patch.object(lp.shutil, "which", return_value="openssl"), \
             patch.object(lp.subprocess, "run", side_effect=replies):
            result = lp.direct_tls_certificate("landing-assets.dev.apps.union-investment.de")
        self.assertFalse(result["verified"])
        self.assertIn("wrong", result["public_certificate_details"])

    def test_zero_exit_without_certificate_is_not_pass(self):
        with patch.object(lp.shutil, "which", return_value="openssl"), \
             patch.object(lp.subprocess, "run", return_value=subprocess.CompletedProcess([], 0, "", "")):
            self.assertFalse(lp.direct_tls_certificate("host.example")["verified"])

    def test_missing_openssl_does_not_fake_success(self):
        with patch.object(lp.shutil, "which", return_value=None), patch.object(lp.subprocess, "run") as runner:
            self.assertFalse(lp.direct_tls_certificate("host.example")["verified"])
            runner.assert_not_called()

    def test_tls_timeout_is_reported(self):
        with patch.object(lp.shutil, "which", return_value="openssl"), \
             patch.object(lp.subprocess, "run", side_effect=subprocess.TimeoutExpired([], 25)):
            result = lp.direct_tls_certificate("host.example")
            self.assertFalse(result["verified"])
            self.assertIn("error", result)

    def test_diagnose_reads_only_gateway_metadata_and_no_proxy_credentials(self):
        rc, data, cmd = self.run_tls()
        self.assertEqual(rc, 0)
        self.assertEqual(cmd[:3], ["network", "application-gateway", "show"])
        self.assertIn("--subscription", cmd)
        self.assertTrue(data["diagnostic_only"])
        self.assertFalse(data["azure_changes"])
        self.assertTrue(data["proxy"]["https_proxy_configured"])
        text = json.dumps(data)
        self.assertNotIn("password", text)
        self.assertNotIn("proxy.invalid", text)
        self.assertNotIn("publicCertData", cmd[cmd.index("--query") + 1])
        self.assertTrue((self.folder / "tls.md").is_file())

    def test_diagnose_reports_wrong_gateway(self):
        rc, data, _ = self.run_tls(gateway={"id": "wrong"})
        self.assertEqual(rc, 2)
        self.assertTrue(data["errors"])

    def test_diagnose_missing_listener_is_not_pass(self):
        g = self.gateway(); g["listeners"] = []
        rc, data, _ = self.run_tls(gateway=g)
        self.assertEqual(rc, 2)
        self.assertTrue(any("Listener" in x for x in data["errors"]))

    def test_diagnose_dns_error_is_recorded(self):
        rc, data, _ = self.run_tls(dns_error=True)
        self.assertEqual(rc, 2)
        self.assertEqual(data["dns_addresses"], [])

    def test_diagnose_failed_tls_does_not_pass_from_good_azure(self):
        rc, _, _ = self.run_tls(verified=False)
        self.assertEqual(rc, 2)

    def test_cli_tls_parser(self):
        a = lp.parser().parse_args(["tls", "--env", "dev"])
        self.assertIs(a.func, lp.tls_diagnose)

    def test_starter_routes_tls_to_dev(self):
        with patch.object(w, "ensure_login") as login, patch.object(w, "lp", return_value=lp), \
             patch.object(w, "new_run", return_value=self.folder), \
             patch.object(lp, "tls_diagnose", return_value=2) as diagnose:
            self.assertEqual(w.assets("tls", w.parser().parse_args(["12139", "tls"])), 2)
            login.assert_called_once()
            self.assertEqual(diagnose.call_args.args[0].env, "dev")

    def test_tls_all_is_rejected_before_connection(self):
        with patch.object(w, "ensure_login") as login:
            with self.assertRaises(w.Stop):
                w.assets("tls", w.parser().parse_args(["12139", "tls", "--env", "all"]))
            login.assert_not_called()

    def test_newest_receipt_uses_evidence_time_not_extraction_order(self):
        from test_ticketcode import receipt_at
        a = self.folder / "DBI-12139/z_older"; a.mkdir(parents=True)
        b = self.folder / "DBI-12139/a_newer"; b.mkdir(parents=True)
        r1, _ = receipt_at(a); r2, _ = receipt_at(b)
        for r, stamp in ((r1, "2026-10-02T08:00:00Z"), (r2, "2026-10-02T10:00:00Z")):
            d = json.loads(r.read_text()); d["created_at_utc"] = stamp
            r.write_text(json.dumps(d))
        with patch.object(w, "RESULTS", self.folder), patch.object(w, "lp", return_value=lp), \
             redirect_stdout(io.StringIO()):
            self.assertEqual(w.latest_receipt(w.parser().parse_args(["12139", "probe", "--env", "dev"])), r2)

if __name__ == "__main__":
    unittest.main()
