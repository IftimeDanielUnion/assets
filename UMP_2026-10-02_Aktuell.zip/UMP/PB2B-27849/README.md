# PB2B-27849: temporären Login prüfen

**App laut Oliver am 22.09. angelegt. Aktuelle Login-Abnahme nicht belegt.** Das Jira ist im Export Oliver zugewiesen. Keine neue App auf Verdacht erstellen.

## 1. Oliver nach dem tatsächlichen Rest fragen

**Warum:** Vielleicht fehlt nur die Dokumentation; dann ist kein Codechange nötig.

> Hi Oliver, laut deinem Kommentar ist die temporäre UMP-App bereits angelegt. Ist die Mellon-Anbindung inzwischen ebenfalls umgesetzt und der Login erfolgreich getestet? Falls ja, reicht mir der Testbeleg für den Ticketabschluss. Falls noch etwas fehlt, schick mir bitte die konkrete temporäre UMP-URL und den Zielhost, dann gleiche ich die aktive Konfiguration ab. Danke dir!

## 2. Nur bei noch offener Integration den Code nutzen

**Warum:** Die temporäre Policy darf nur die bestätigte temporäre Instanz treffen, nicht den normalen PROD-Login.

```bash
bash start.sh 27849 code
bash start.sh 27849 prepare
bash start.sh 27849 dry-run
```

`code`: eigener `ansible-ump`-Worktree. `prepare`: fragt bestätigten Host, Entity-ID, Rücksprungadresse und öffentliche SP-Metadaten ab; erzeugt lokale Konfiguration. `dry-run`: Ansible-Prüfung mit deinem Inventory/Serverzugang, noch kein normales Deployment.

Temporäre Policy aus Jira: `B2C_1A_signin_saml_ump_tmp`. Die öffentliche Metadatenquelle ist im vorbereiteten Werkzeug hinterlegt. Keine privaten Schlüssel oder SAML-Login-Tokens ins Jira/Git kopieren.

## GitLab und Abschluss

Bei echter Konfigurationsänderung: MR im Repo `ansible-ump`, Review/Freigabe, gezielte Bereitstellung gemäß geprüftem Bericht. Nicht allein wegen der beigefügten Dateien einen Merge erzeugen.

Danach vollständigen Login auf der temporären Instanz und den unveränderten normalen Login prüfen. Temporären Rückbau mit Oliver festhalten.

**Fertig:** richtige App-/Instanzzuordnung und erfolgreicher Login nachgewiesen. Ist das bereits erledigt, kann Oliver den vorhandenen Beleg nutzen, ohne neue Codeübernahme.
