# Zwei Kommentare zum direkten Einfügen

Noch nichts wurde von hier aus ins Jira geschrieben. Der SFTP-Text gilt, solange Marc noch nicht geantwortet hat.

## DBI-11149: Mail an Marc

```text
Marc Hintz wurde am 01.10.2026 per E-Mail zum Lukas-PROD-SFTP-Zugang angeschrieben. Der neue öffentliche RSA-Schlüssel wurde zur zusätzlichen Hinterlegung übermittelt; der bisherige Schlüssel soll erhalten bleiben. Außerdem wurden die Verbindungseinstellungen, ein geeignetes Testverzeichnis und der SSH-Host-Key-Fingerabdruck angefragt.

Die Bestätigung der Schlüsselhinterlegung steht noch aus. Danach folgen Anmeldung und Verzeichnisprüfung aus der UMP-Instanz sowie ein abgestimmter Transfer-Test. Die weiteren im Ticket genannten Verbindungen und die Firewall-Change-Dokumentation bleiben Teil der Abnahme.

Status: offen, Rückmeldung der Gegenstelle ausstehend.
```

## DBI-12139: vorhandener Storage und durchgeführte Tests

```text
Die LP-Asset-Storages für DEV, TEST und PROD sind bereits vorhanden. Die Prüfung vom 02.10.2026 bestätigt die vorgesehenen Storage-, Container- und Gateway-Einstellungen. Eine zusätzliche Storage-Anlage war nicht erforderlich.

Getestet wurde:
- DEV/TEST/PROD: Bestands- und Konfigurationsprüfung erfolgreich.
- TEST: Upload einer 8-KiB-Testdatei erfolgreich. Anonymer HTTPS-Abruf mit HTTP 200 und übereinstimmendem Inhalt; Teilabruf mit HTTP 206 erfolgreich. Test aus dem internen Netz.
- DEV: Upload erfolgreich. Der anschließende HTTPS-Abruf scheitert an einem Zertifikats-/Hostname-Mismatch für landing-assets.dev.apps.union-investment.de, noch vor einer HTTP-Antwort.

Für PROD liegt noch kein Dateiabruf vor. Die externe Erreichbarkeit ist bisher nicht nachgewiesen. Die kleinen Testdateien sind kein Nachweis für das Verhalten großer Produktmedien.

Die Storage-Bereitstellung ist bestätigt. Offen bleiben die DEV-TLS-Korrektur und die fehlenden Zugriffsprüfungen. Keine neue Storage-Anlage und keine pauschale Öffnung des direkten Storage-Netzzugangs vorgesehen.

Status: offen, kein vollständiger Abschlussnachweis.
```

Die DEV-Fehlermeldung ist ein echter neuer Befund, nicht nur eine fehlende Zusatzprüfung. Darum ist der zweite Text noch kein Abschlusskommentar.
