#!/usr/bin/env python3
"""Read existing evidence and continue only missing LP checks. No automatic deployment."""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import json
from pathlib import Path
from typing import Any

ENVS = ("dev", "test", "prod")


def read_json(path: Path) -> dict[str, Any]:
    if path.is_symlink() or path.stat().st_size > 8_000_000:
        raise ValueError(f"Unerwartete Belegdatei: {path}")
    value = json.loads(path.read_text(encoding="utf-8-sig"))
    if not isinstance(value, dict):
        raise ValueError(f"Kein JSON-Objekt: {path}")
    return value


def timestamp(value: Any) -> datetime:
    try:
        result = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
        return result.replace(tzinfo=timezone.utc) if result.tzinfo is None else result.astimezone(timezone.utc)
    except (ValueError, TypeError):
        return datetime.min.replace(tzinfo=timezone.utc)


def records(root: Path, pattern: str):
    for path in sorted(root.glob(pattern)):
        if path.is_file():
            yield path, read_json(path)


def inventory_state(root: Path, tool: Any) -> dict[str, dict]:
    state: dict[str, dict] = {}
    for path, record in records(root, "**/inventar.json"):
        if record.get("ticket") != "DBI-12139":
            continue
        for env, entry in record.get("environments", {}).items():
            if env not in ENVS:
                continue
            date = timestamp(record.get("checked_at_utc"))
            if env in state and date < timestamp(state[env]["at"]):
                continue
            cfg = tool.env_config(env)
            storage = entry.get("storage", {})
            checks = entry.get("checks", []) + entry.get("gateway_checks", [])
            ok = (
                entry.get("errors") == []
                and storage.get("name") == cfg["storage_account"]
                and storage.get("provisioningState") == "Succeeded"
                and entry.get("gateway", {}).get("provisioningState") == "Succeeded"
                and len(entry.get("checks", [])) >= 7
                and len(entry.get("gateway_checks", [])) >= 18
                and all(c.get("passed") is True for c in checks)
                and entry.get("gateway_backend_matches_expected_storage") is True
            )
            state[env] = {"passed": ok, "at": record.get("checked_at_utc"), "path": path}
    return state


def receipts(root: Path, tool: Any, env: str, campaign: str) -> list[tuple[Path, dict]]:
    result = []
    for path in root.glob("**/upload.json"):
        data, _ = tool.read_receipt(path)
        if data["environment"] == env and data["campaign"] == campaign:
            result.append((path, data))
    result.sort(key=lambda item: (timestamp(item[1].get("created_at_utc")), str(item[0])), reverse=True)
    return result


def probes(root: Path, tool: Any, env: str, campaign: str, network: str | None = None) -> list[dict]:
    allowed_urls = {tool.urls(env, campaign, data["blob"])[0]
                    for _, data in receipts(root, tool, env, campaign)}
    found = []
    for path, data in records(root, "**/probe*.json"):
        if (data.get("ticket") != "DBI-12139" or data.get("environment") != env
                or data.get("campaign") != campaign or data.get("endpoint") != "asset-domain"):
            continue
        if network and data.get("network_declared_by_operator") != network:
            continue
        full, partial = data.get("get", {}), data.get("range_get", {})
        if full.get("url") not in allowed_urls or partial.get("url") != full.get("url"):
            continue
        ok = (
            data.get("passed") is True
            and full.get("passed") is True
            and full.get("http_status") == 200
            and full.get("content_matches_test_file") is True
            and partial.get("passed") is True
            and partial.get("http_status") == 206
            and partial.get("content_matches_expected_range") is True
        )
        found.append({"passed": ok, "at": data.get("checked_at_utc"), "path": path,
                      "network": data.get("network_declared_by_operator", "unbekannt"),
                      "error": full.get("error") or partial.get("error"),
                      "http_status": full.get("http_status")})
    found.sort(key=lambda item: (timestamp(item["at"]), str(item["path"])), reverse=True)
    return found


def evidence_state(w: Any, campaign: str = "uniglobal") -> dict[str, Any]:
    root, tool = w.RESULTS / "DBI-12139", w.lp()
    inv = inventory_state(root, tool)
    result = {"environments": {}, "open_uploads": []}
    for env in ENVS:
        seen = probes(root, tool, env, campaign)
        external = probes(root, tool, env, campaign, "extern")
        result["environments"][env] = {
            "inventory": inv.get(env),
            "last_probe": seen[0] if seen else None,
            "last_external_probe": external[0] if external else None,
        }
        for path, data in receipts(root, tool, env, campaign):
            if data.get("status") == "uploaded":
                result["open_uploads"].append({"environment": env, "path": path, "blob": data["blob"]})
    return result


def failure_reason(probe: dict | None) -> str:
    if not probe or probe.get("passed"):
        return ""
    error = str(probe.get("error") or "").lower()
    if "hostname mismatch" in error or "certificate is not valid for" in error:
        return "TLS-Zertifikat passt nicht zur aufgerufenen Adresse"
    if "certificate_verify_failed" in error:
        return "TLS-Zertifikatsprüfung fehlgeschlagen"
    status = probe.get("http_status")
    return f"HTTP {status}" if status else "Abruf ohne erfolgreiches HTTP-Ergebnis"


def summary(w: Any, campaign: str = "uniglobal") -> int:
    """Historical evidence is not an assertion that all live systems are healthy now."""
    data = evidence_state(w, campaign)
    lines = [
        "# UMP: Auswertung der vorhandenen Belege",
        "",
        "Kein neuer Azure-Aufruf. Angezeigt werden die gespeicherten Prüfläufe, keine laufende Überwachung.",
        "Erfolgreiche Teilprüfungen schließen ein Jira nicht automatisch.",
        "",
        "## DBI-12139",
        "",
        "| Umgebung | Infrastruktur | Letzter Asset-Abruf | Externer Abruf |",
        "|---|---|---|---|",
    ]
    for env, state in data["environments"].items():
        i, p, e = state["inventory"], state["last_probe"], state["last_external_probe"]
        inv_text = ("bestätigt" if i["passed"] else "Abweichung/Lesefehler") + f" ({i['at']})" if i else "kein Beleg"
        probe_text = (("erfolgreich" if p["passed"] else failure_reason(p)) + f", {p['network']} ({p['at']})") if p else "offen"
        ext_text = (("erfolgreich" if e["passed"] else "fehlgeschlagen") + f" ({e['at']})") if e else "kein Nachweis"
        lines.append(f"| {env} | {inv_text} | {probe_text} | {ext_text} |")
    lines += [
        "",
        "Die Netzangabe intern/extern stammt vom ausführenden Menschen; das Skript bestätigt den Standort nicht.",
        "Ein nicht ausgewiesener externer Test ist kein Beleg für einen Netzwerkdefekt.",
        "Arbeitsannahme: öffentliche Asset-Domain aus dem Kundennetz/Internet erreichbar. Dafür fehlt ein Beleg.",
        "Für einen Abschluss muss außerdem der DEV-HTTPS-Fehler behoben und PROD geprüft sein.",
        "Keine weitere Storage-Neuanlage. Der nächste gezielte Schritt steht in DBI-12139/README.md.",
        "",
        "### Noch nicht als bereinigt dokumentierte eigene Testblobs",
    ]
    if data["open_uploads"]:
        lines += [f"- {item['environment']}: `{item['blob']}`" for item in data["open_uploads"]]
        lines += ["Erst nach den benötigten Abrufen bereinigen. Ohne Löschbeleg ist unbekannt, ob zwischenzeitlich manuell gelöscht wurde."]
    else:
        lines += ["Keine als erfolgreich hochgeladen und unbereinigt markierten Belege gefunden."]
    lines += [
        "",
        "## Andere Tickets: belegter Übergabestand",
        "",
        "- DBI-11149: Anfrage an Marc am 01.10.2026 versendet (Screenshot). Keine Antwort im Upload. Falls eine Antwort inzwischen da ist, direkt weiterarbeiten.",
        "- DBI-6455: Code vorbereitet. In deinen Uploads keine Log-/Alert-/Mail-Abnahme enthalten.",
        "- PB2B-27849: App laut Jira-Kommentar vom 22.09.2026 angelegt. Kein aktueller Login-Test im Upload.",
        "- DBI-7161: Infrastrukturentwurf vorhanden; Schnittstellenfreigabe und Zustellung nicht belegt.",
        "",
        "Neuere eigene Ausgaben zu diesen Tickets stehen gegebenenfalls im jeweiligen ergebnisse/-Unterordner; diese Liste ist keine Live-Jira-Abfrage.",
        "",
        "Nächster Schritt bei DEV-Zertifikatsfehler: bash start.sh 12139 tls --env dev. Kein erneuter TEST-Upload.",
    ]
    text = "\n".join(lines) + "\n"
    target = w.RESULTS / "STATUS.md"
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(text, encoding="utf-8")
    print(text + "\nGespeichert: " + str(target))
    return 0


def remaining(w: Any, args: argparse.Namespace, external_only: bool = False) -> int:
    """Reuse evidence; never create a blob during an external-only check."""
    tool = w.lp()
    campaign = args.campaign
    network = "extern" if external_only else (args.network or w.ask("Tatsächliches Testnetz: intern / extern / unbekannt", "unbekannt"))
    if network not in ("intern", "extern", "unbekannt"):
        raise w.Stop("Ungültige Netzangabe.")
    if network == "extern":
        w.confirm("NETZ EXTERN")
        print("Nur von einem freigegebenen externen Teststandort verwenden. Keine Azure-Anmeldung nötig; keine Uploads.")
    environments = [args.env] if args.env and args.env != "all" else list(ENVS)
    result_root = w.RESULTS / "DBI-12139"
    inv = inventory_state(result_root, tool)
    pending = False
    for env in environments:
        candidates = probes(result_root, tool, env, campaign, "extern" if network == "extern" else None)
        if candidates and candidates[0]["passed"]:
            print(f"{env}: bereits erfolgreich belegt ({candidates[0]['at']}); kein erneuter Upload/Abruf.")
            continue
        uploaded = receipts(result_root, tool, env, campaign)
        ready = [item for item in uploaded if item[1].get("status") == "uploaded"]
        if ready:
            receipt = ready[0][0]
            print(f"{env}: vorhandenen eigenen Testblob weiterverwenden.")
        elif network == "extern":
            print(f"{env}: kein aktiver eigener Testbeleg. Hier kein Upload; vorhandenes freigegebenes Asset separat prüfen.")
            pending = True
            continue
        else:
            uncertain = [item for item in uploaded if item[1].get("status") not in ("uploaded", "current_test_blob_deleted")]
            if uncertain:
                raise w.Stop(f"{env}: unklarer früherer Uploadzustand. Zuerst {uncertain[0][0]} prüfen, nicht blind erneut hochladen.")
            if env not in inv or not inv[env]["passed"]:
                raise w.Stop(f"{env}: kein erfolgreicher Inventarbeleg. Erst bash start.sh 12139 inventar --env {env}.")
            print(f"{env}: Abruf noch offen. Eine neue synthetische 8-KiB-Datei nur nach deiner Freigabe.")
            if env == "prod":
                print("PROD: nur fortfahren, wenn dieser Testupload nach eurem Betriebsprozess freigegeben ist.")
            w.ensure_login()
            code = tool.upload_test(argparse.Namespace(env=env, campaign=campaign, output_dir=w.new_run("DBI-12139")))
            if code:
                return code
            ready = [item for item in receipts(result_root, tool, env, campaign) if item[1].get("status") == "uploaded"]
            if not ready:
                raise w.Stop(f"{env}: kein gültiger Uploadbeleg entstanden.")
            receipt = ready[0][0]
        output = receipt.with_name("probe-" + datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ") + ".json")
        code = tool.probe(argparse.Namespace(receipt=receipt, endpoint="asset-domain", origin=None, network=network, output=output))
        if code:
            summary(w, campaign)
            return code
    summary(w, campaign)
    return 2 if pending else 0
