# Prüfprotokoll: neuer Stand aus 12139.7z

## Ergebnis

**Storage-Bereitstellung bestätigt; kein vollständiger Abschluss von DBI-12139.** Der neue DEV-Upload funktioniert, sein HTTPS-Abruf scheitert an einem Zertifikats-/Hostname-Mismatch. TEST war zuvor erfolgreich. PROD-Dateiabruf und externer Zugriff fehlen als Beleg.

## Tatsächlich gelieferte Ergebnisse

| Quelle / Prüfung | Befund |
|---|---|
| Azure-Inventar vom 02.10., 08:56 UTC | In DEV/TEST/PROD je 7 Storage-/Container- und 18 Gateway-Vergleiche erfolgreich, insgesamt 75. Backend-Ziel ebenfalls passend. Kein vollständiger Terraform-Drift-Test. |
| TEST, 09:00 UTC | 8.192-Byte-Datei anonym gelesen: HTTP 200, Inhalt stimmt. Bereich 0-1023: HTTP 206, Inhalt/Content-Range stimmen. Netzangabe: intern. |
| DEV, 10:28 UTC | 8.192-Byte-Upload erfolgreich. Beide gelieferten Abrufversuche scheitern bei TLS an `Hostname mismatch`, vor HTTP. Netzangabe: intern. |
| PROD | Kein tatsächlicher Dateiabruf geliefert. |
| Extern | Kein externer Test geliefert; daraus folgt nicht automatisch ein Netzwerkdefekt. |
| Bereinigung | Kein Löschbeleg geliefert. Ob Dateien inzwischen manuell gelöscht wurden, ist unbekannt. |
| Mail an Marc | Screenshot aus `2139.7z`: Mail vom 01.10., 12:48 Uhr an `hintz@msu.biz`, Public-Key-Anhang und zusätzliche Hinterlegung angefragt. Keine Antwort geliefert. |

Die Hashes beider mitgelieferten Testdateien passen zu ihren Uploadbelegen. [Archiv-/Belegprüfung](ergebnisse/eingangsbelege.json). Alle neuen und bisherigen JSON-Testbelege liegen unverändert unter `ergebnisse/DBI-12139/`.

Konkreter DEV-Fehler: [letzter Abrufbericht](ergebnisse/DBI-12139/20261002T102824451768Z/dev/dbi-12139-check-20261002T102831Z-f1ddfbbb97ef/probe-20261002T102857001661Z.json).

TEST-Erfolg: [Abrufbericht](ergebnisse/DBI-12139/20261002T085855379770Z/test/dbi-12139-check-20261002T085902Z-99cb2a98bb4b/probe-20261002T090016306962Z.json).

## Was der Code zusätzlich erklärt

Im ursprünglichen `live/live/dev/appgateway.hcl`, Zeilen 28-39, verwenden `landingassets_private_listener` und `landingpages_private_listener` denselben Eintrag `landing-internal-certificate`. Der Asset-Hostname ist tatsächlich `landing-assets.dev.apps.union-investment.de`; er wurde nicht erst vom Prüfsystem erfunden.

Das Azure-Inventar bestätigt diese Listener-/Zertifikatsreferenz. **Den Inhalt des tatsächlich ausgelieferten Zertifikats enthält es nicht.** DNS-Ziel, Zertifikatsinhalt, Zuordnung oder vorgelagerte TLS-Stelle bleiben zur Eingrenzung offen. Keine automatische Zuordnung des Fehlers allein zu Key Vault oder Application Gateway.

Die Storage-Accounts sind für anonymen Blob-Zugriff freigegeben, ihr direkter öffentlicher Netzzugang bleibt deaktiviert. Release-Container sind anonym lesbar konfiguriert. Eine notwendige öffentliche Veröffentlichung kann vorgeschaltet erfolgen; `publicNetworkAccess = Disabled` darf nicht ohne Prüfung des vorgesehenen Wegs geändert werden.

## Was im Paket geändert wurde

- Neuer eigenständiger Ordner `UMP`, ohne Abhängigkeit von alten Paketversionen.
- Neuer DEV-Upload und beide fehlgeschlagenen Abrufbelege übernommen, nichts in Erfolg umgedeutet.
- Kurze READMEs mit Status, nächsten Schritten und GitLab-Zuordnung. Zwei separate kopierfertige Jira-Kommentare.
- Lesende TLS-Diagnose als `bash start.sh 12139 tls --env dev`: DNS, öffentliches Zertifikat und Gateway-Referenz. Kein Lesen privater Key-Vault-Secrets, kein TLS-Bypass, keine Azure-Änderung.
- Statusausgabe erklärt den TLS-Fehler. Wahl des letzten Uploadbelegs folgt nun dem Belegzeitpunkt statt der beim Entpacken veränderten Dateizeit.
- Veraltete PowerShell-/Patch-Hinweisdateien entfernt. Alle **14 vollständigen vorbereiteten Repository-Dateien** bleiben enthalten. Davon wurde hier nur das LP-Prüfwerkzeug geändert; keine unbewiesene Infrastrukturkorrektur erzeugt.

## Lokale Softwareprüfung

[Maschinenlesbares Ergebnis](ergebnisse/lokale-pruefung.json): **182 Tests, 0 Fehler, 0 Fehlschläge, 0 übersprungen.** Außerdem 28 Paketdatei-Prüfsummen erfolgreich, 10 Python-Dateien geparst, beide PHP-Dateien mit `php -l` und `start.sh` mit `bash -n` geprüft.

[Struktureller Quellcodeabgleich](ergebnisse/quellcode.json): 48 Vergleiche gegen den ursprünglichen `live`-Snapshot erfolgreich. Das ist keine aktuelle GitLab-Abfrage und keine Terraform-Validierung.

Die lokalen Tests simulieren Azure, HTTP und die neue entfernte TLS-Abfrage. Sie liefen im Linux-Testcontainer. Sie beweisen nicht, dass DEV inzwischen repariert ist.

**Nicht ausgeführt:** Terraform-/Terragrunt-/Ansible-Gesamtprüfung, Deployment/Apply, reale neue Azure-/Server-Abfragen, SFTP-Anmeldung, Monitoring-Mail, SAML-Login oder Event-Grid-Zustellung. Keine Jira-Kommentare automatisch eingestellt, keine Mail versendet, kein GitLab-Push/Merge.

## Ticket- und Technikquellen

Jira-Grundlage: die vier Exporte aus `ump_jiras.zip` vom 30.09.2026 und die bereitgestellten DBI-12139-Screenshots. Noch kein Live-Abgleich späterer Jira-Kommentare oder Postfachantworten.

- DBI-12139: dev/test/prod und öffentlich lesbare Assets gefordert. Keine feste Mindestgröße oder Performance-Grenze angegeben. Die 8-KiB-Tests sind keine Prüfung großer realer Produktmedien.
- DBI-11149: letzte Schritte betreffen zusätzliche Schlüsselhinterlegung bei Lukas; weitere Verbindungen und Firewall-Change-Dokumentation gehören zum Scope.
- DBI-6455: OSC meldete am 11.09. getestete OTEL-Anbindung, fehlenden Mail-Versand für error/fatal.
- PB2B-27849: Oliver meldete am 22.09. App-Anlage und temporäre IdP-Metadaten. Kein neuer Login-Beleg geliefert.
- DBI-7161: tatsächliche Zustellung und Dead-Letter-Funktion sind gefordert; Infrastrukturentwurf allein genügt nicht.

Technische Primärquellen:
- [Microsoft: Listener-Zertifikate und ihre Zuordnung](https://learn.microsoft.com/en-us/azure/application-gateway/ssl-certificate-management)
- [Microsoft: Hostnamen und SAN-/Wildcard-Zertifikate](https://learn.microsoft.com/en-us/azure/application-gateway/multiple-site-overview)
- [Microsoft: anonymer Blob-Zugriff hebt Netzwerkregeln nicht auf](https://learn.microsoft.com/en-us/azure/storage/blobs/anonymous-read-access-configure)
- [GitLab: Merge-Request-Pipelines](https://docs.gitlab.com/ci/pipelines/merge_request_pipelines/)
- [GitLab: separate Deployment-Jobs](https://docs.gitlab.com/ci/environments/deployments/)
