# DBI-7161: Event Grid zwischen ProductHub und UMP

**Offen. Infrastrukturentwurf vorhanden, Schnittstelle noch nicht bestätigt.** Der LP-Asset-Storage ist nicht die Fehlerablage dieses Tickets.

## 1. Fehlende Angaben von Sinan/OSC holen

**Warum:** Ein Event-Grid-Topic allein bringt nichts, wenn Empfänger, Zugriffsrechte und Nachrichtenformat fehlen.

An Sinan Balcin:

> Hi Sinan, ich bereite DBI-7161 vor. Kannst du mir bitte das aktuelle Konzept, eine Beispielnachricht, die UMP-Empfänger-URL und die erste Zielumgebung geben? Außerdem brauche ich die vorgesehenen Identitäten, freizugebenden Publisher-Netze und die Verantwortlichen für ProductHub-Sender und UMP-Empfänger. Damit kann ich die Azure-Seite gezielt fertigstellen. Danke dir!

Nur wenn die Anwendungsteile noch unklar sind, an Alex Köster:

> Hi Alex, gibt es für DBI-7161 bereits einen ProductHub-Sender und einen UMP-Webhook in einem anderen Branch? Falls noch nicht, wer übernimmt die beiden Teile? Für den gemeinsamen Test brauche ich auch das erwartete Verhalten bei wiederholter Zustellung. Danke dir!

## 2. Code erst danach integrieren

```bash
bash start.sh 7161 code
bash start.sh 7161 validate
```

Der vorbereitete `catalog`-Baustein deckt Topic, Rechte, Webhook-Zustellung und Fehlerablage ab. Er ist **noch nicht in `live` eingebunden**. `validate` ist nur eine isolierte Modulprüfung, kein Deployment.

Der Schutz `approved_for_deployment = false` ist Absicht. Nicht ohne bestätigte Eingaben ausschalten. Sender- und Empfänger-Authentifizierung getrennt klären; die B2C-Scopes aus dem Ticket sind nicht automatisch eine fertige native Event-Grid-Anmeldung.

## GitLab

Später MR im Repo `catalog`. Anschließend über euren Katalog-Releaseprozess den bestätigten Stand im Repo `live` einbinden und dort ebenfalls reviewen/mergen. Fehlender ProductHub-/UMP-Code benötigt eigene Änderungen in den betroffenen Anwendungs-Repos.

**Jetzt nicht den Entwurf blind deployen.** Eine leere Infrastruktur ohne Sender/Empfänger erfüllt die Abnahmekriterien nicht.

## Fertig, wenn

Echtes Ereignis wird zugestellt und fachlich verarbeitet; unberechtigte Zugriffe scheitern; dauerhaft nicht zustellbare Events landen in der Fehlerablage; doppelte Zustellung erzeugt keine doppelte fachliche Wirkung. Erst dann Abschluss dokumentieren.
