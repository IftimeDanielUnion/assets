# DBI-11149: SFTP, Antwort von Marc ausstehend

**Deine Mail vom 01.10. ist versendet. Nicht nochmals die Erstmail schicken.** Eine Antwort oder erfolgreiche SFTP-Verbindung ist in den Uploads nicht enthalten.

## Jetzt

Den ersten Text aus [JIRA_KOMMENTARE.md](../JIRA_KOMMENTARE.md) ins Jira kopieren. Auf die Bestätigung warten bzw. die inzwischen erhaltene Antwort auswerten. Währenddessen Monitoring oder den DEV-Zertifikatsfehler bearbeiten.

**Warum warten?** Nur die Gegenstelle kann bestätigen, dass der neue Benutzer-Public-Key zusätzlich hinterlegt wurde. Deine Mail ist noch keine erfolgreiche Anmeldung.

Nur bei nötiger Nachfrage, im bestehenden Mailverlauf an Marc:

> Hallo Marc, konntest du meine Anfrage zum Lukas-PROD-SFTP-Zugang schon prüfen? Für den Verbindungstest brauche ich noch die Bestätigung der zusätzlichen Schlüsselhinterlegung, die Verbindungseinstellungen und den Server-Host-Key-Fingerabdruck. Danke dir!

## Nach seiner Antwort

1. Host/Benutzer/Port/Zielverzeichnis und Server-Fingerprint abgleichen.
2. Anmeldung und Verzeichniszugriff **aus der echten UMP-Instanz** testen. Ein Test allein aus WSL reicht nicht, weil die UMP einen anderen Netzweg und Schlüssel nutzt.
3. Mit Alex einen sicheren vollständigen Transfer testen. Kein echter Produktionsauftrag nur zu Testzwecken.
4. Übrige benötigte Verbindungen und Firewall-Changes dokumentieren. Das Jira betrifft nicht nur Lukas; `UI-CHG-0094446` ist im Export genannt.

An Alex, sobald du den technischen Test vorbereitest:

> Hi Alex, ich bearbeite den Lukas-SFTP-Zugang. Sobald die Schlüsselhinterlegung bestätigt ist, möchte ich Anmeldung und anschließend einen sicheren Transfer aus der UMP testen. Welchen freigegebenen Testfall können wir dafür verwenden? Gibt es bereits aktuelle Restbelege für Emailing und die Ablösung bzw. weitere Nutzung von Strato/MOVEit? Danke dir!

## Code und GitLab

Die zwei PHP-Dateien unter `code/unioninvestment/` sind **optionale Diagnosehilfe**, keine bereits ausgerollte Fehlerbehebung. Ein etablierter sicherer Betriebstest kann ohne diesen Code erfolgen.

Nur falls diese Hilfe gebraucht wird:

```bash
bash start.sh 11149 code
```

MR im Repo `unioninvestment`, Review und reguläre Bereitstellung. Erst danach sind diese Aufrufe nutzbar:

```bash
bash start.sh 11149 server
bash start.sh 11149 connect
```

`server` liest die tatsächliche MBO-Konfiguration. `connect` benötigt bestätigte Schlüssel und prüft Anmeldung/Verzeichnis ohne Upload. Der Starter fragt den echten UMP-SSH-Zugang ab. `az login` ersetzt ihn nicht.

**Nicht `app:export:mbo` als bloßen Verbindungstest starten.** Der Befehl verarbeitet Bestellungen.

**Fertig:** notwendige Transfers nachgewiesen und Firewall-Dokumentation vollständig. Mailversand oder ein Merge allein reichen nicht.
