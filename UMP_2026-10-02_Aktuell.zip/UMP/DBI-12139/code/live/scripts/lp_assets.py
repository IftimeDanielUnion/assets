#!/usr/bin/env python3
"""DBI-12139: Bestehende LP-Asset-Infrastruktur prüfen.

Nur Python-Standardbibliothek. Azure CLI wird ausschließlich für inventory,
upload-test und cleanup benötigt. probe führt nur anonyme HTTPS-GETs aus.
Keine Infrastruktur, Rechte oder Netzwerke werden verändert.
"""
from __future__ import annotations

import argparse
import hashlib
from http.client import HTTPException
import json
import os
import re
import shutil
import socket
import subprocess
import sys
import time
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
from urllib.error import HTTPError, URLError
from urllib.parse import quote, urlparse
from urllib.request import HTTPRedirectHandler, Request, build_opener

SNAPSHOT_CONFIG = {'ticket': 'DBI-12139',
 'source': 'UMP_repos.zip; live-Snapshot HEAD dd42ccc; nicht aus Azure ausgelesen',
 'environments': {'dev': {'subscription_id': 'daa58c0d-c970-4aac-886a-c88e3c8eb620',
                          'resource_group': 'rg-corecomponents-dev',
                          'storage_account': 'stumpdevlpassetsyws91x59',
                          'asset_host': 'landing-assets.dev.apps.union-investment.de',
                          'gateway': 'appgw-2f3edc709db6462f',
                          'gateway_resource_group': 'rg-unionmarketingplattform-dev-networking-appgateways'},
                  'test': {'subscription_id': '4cc30493-9746-4edb-a404-1aad8388c81c',
                           'resource_group': 'rg-corecomponents-test',
                           'storage_account': 'stumptestlpassetsjjh3lzn',
                           'asset_host': 'landing-assets.test.apps.union-investment.de',
                           'gateway': 'appgw-efba4b04a0714355',
                           'gateway_resource_group': 'rg-unionmarketingplattform-test-networking-appgateways'},
                  'prod': {'subscription_id': 'f8b0b9a0-4f58-4fd3-a504-1a21a87a6ae3',
                           'resource_group': 'rg-corecomponents-prod',
                           'storage_account': 'stumpprodlpassetsxvhfz3h',
                           'asset_host': 'landing-assets.apps.union-investment.de',
                           'gateway': 'appgw-80cdf05bda4199c9',
                           'gateway_resource_group': 'rg-unionmarketingplattform-prod-networking-appgateways'}},
 'campaigns': {'uniglobal': {'container': 'uniglobal-release-1', 'public_path': 'uniglobal'},
               've': {'container': 've-release-1', 'public_path': 'VE-Impuls-Junge-Neukunden'},
               'zukunft': {'container': 'zukunft-release-1', 'public_path': 'zukunft-2026'}}}
ARM = "https://management.azure.com"
STORAGE_API = "2025-01-01"
READ_LIMIT = 65536
SAMPLE_SIZE = 8192
BLOB_RE = re.compile(r"^dbi-12139-check-\d{8}T\d{6}Z-[0-9a-f]{12}\.txt$")


class TaskError(RuntimeError):
    """Erwartbarer Bedienungs- oder Umgebungsfehler."""


def now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def load_config() -> dict[str, Any]:
    return json.loads(json.dumps(SNAPSHOT_CONFIG))


def save_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(path.name + ".tmp")
    temp.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    temp.replace(path)


def az_json(arguments: list[str]) -> Any:
    executable = shutil.which("az")
    if not executable:
        raise TaskError("Azure CLI fehlt. In einer Umgebung mit Azure CLI starten und zuerst az login ausführen.")
    env = os.environ.copy()
    # Keine unabsichtliche Nutzung alter Storage-Schlüssel oder SAS-Umgebungswerte.
    for key in ("AZURE_STORAGE_KEY", "AZURE_STORAGE_SAS_TOKEN", "AZURE_STORAGE_CONNECTION_STRING",
                "AZURE_STORAGE_ACCOUNT", "AZURE_STORAGE_SERVICE_ENDPOINT"):
        env.pop(key, None)
    env["AZURE_STORAGE_AUTH_MODE"] = "login"
    try:
        result = subprocess.run(
            [executable, *arguments, "--only-show-errors", "--output", "json"],
            check=False, capture_output=True, text=True, encoding="utf-8", errors="replace",
            timeout=180, env=env,
        )
    except subprocess.TimeoutExpired as exc:
        raise TaskError("Azure CLI hat nach 180 Sekunden nicht geantwortet. Ergebnis der Operation separat prüfen.") from exc
    if result.returncode:
        raise TaskError(result.stderr.strip() or "Azure CLI meldet einen Fehler ohne Fehlertext.")
    try:
        return json.loads(result.stdout) if result.stdout.strip() else None
    except json.JSONDecodeError as exc:
        raise TaskError("Azure CLI hat keine gültige JSON-Antwort geliefert.") from exc


def env_config(env: str) -> dict[str, Any]:
    return load_config()["environments"][env]


def account_id(cfg: dict[str, Any]) -> str:
    return (f"/subscriptions/{cfg['subscription_id']}/resourceGroups/{cfg['resource_group']}"
            f"/providers/Microsoft.Storage/storageAccounts/{cfg['storage_account']}")


def read_account(cfg: dict[str, Any]) -> dict[str, Any]:
    account = az_json([
        "storage", "account", "show", "--subscription", cfg["subscription_id"],
        "--resource-group", cfg["resource_group"], "--name", cfg["storage_account"],
    ])
    if not isinstance(account, dict) or account.get("id", "").lower() != account_id(cfg).lower():
        raise TaskError("Die gelesene Storage-Ressource passt nicht zum erwarteten Ziel. Kein automatischer Wechsel.")
    return account


def read_containers(cfg: dict[str, Any]) -> list[dict[str, Any]]:
    url = f"{ARM}{account_id(cfg)}/blobServices/default/containers?api-version={STORAGE_API}"
    items: list[dict[str, Any]] = []
    visited: set[str] = set()
    while url:
        if url in visited or urlparse(url).scheme != "https" or urlparse(url).netloc != "management.azure.com":
            raise TaskError("Unerwarteter oder wiederholter ARM-Folgelink. Abbruch.")
        visited.add(url)
        page = az_json(["rest", "--method", "get", "--url", url, "--subscription", cfg["subscription_id"]])
        items.extend(page.get("value", []))
        url = page.get("nextLink")
    return items


def summarize_containers(items: list[dict[str, Any]]) -> list[dict[str, Any]]:
    return [{"name": item["name"].rsplit("/", 1)[-1],
             "publicAccess": item.get("properties", {}).get("publicAccess", "UNBEKANNT"),
             "id": item.get("id")} for item in items]


def storage_checks(account: dict[str, Any], containers: list[dict[str, Any]]) -> list[dict[str, Any]]:
    actual = {item["name"]: item["publicAccess"] for item in containers}
    expected = {"assets": "None", "statuspages": "Blob"}
    expected.update({c["container"]: "Blob" for c in load_config()["campaigns"].values()})
    checks = [
        {"check": "Account erlaubt Blob-Lesezugriff ohne Anmeldung", "expected": True,
         "actual": account.get("allowBlobPublicAccess"), "passed": account.get("allowBlobPublicAccess") is True},
        {"check": "Direkter öffentlicher Storage-Netzzugang bleibt aus", "expected": "Disabled",
         "actual": account.get("publicNetworkAccess"), "passed": account.get("publicNetworkAccess") == "Disabled"},
    ]
    for name, value in expected.items():
        checks.append({"check": f"Container {name}", "expected": value,
                       "actual": actual.get(name, "NICHT_GEFUNDEN"), "passed": actual.get(name) == value})
    return checks


def summarize_gateway(gateway: dict[str, Any]) -> dict[str, Any]:
    listeners = [v for v in gateway.get("httpListeners", []) if v.get("name", "").startswith("landingassets-")]
    frontend_ids = {v.get("frontendIPConfiguration", {}).get("id") for v in listeners}
    return {
        "id": gateway.get("id"), "provisioningState": gateway.get("provisioningState"),
        "listeners": listeners,
        "frontends": [v for v in gateway.get("frontendIPConfigurations", []) if v.get("id") in frontend_ids],
        "backend_pools": [v for v in gateway.get("backendAddressPools", []) if v.get("name") == "landingassets-backends"],
        "backend_settings": [v for v in gateway.get("backendHttpSettingsCollection", []) if v.get("name", "").startswith("lpa-")],
        "path_maps": [v for v in gateway.get("urlPathMaps", []) if v.get("name", "").startswith("lpa-")],
        "routes": [v for v in gateway.get("requestRoutingRules", []) if v.get("name", "").startswith("landingassets-")],
    }


def inventory(args: argparse.Namespace) -> int:
    config = load_config()
    envs = list(config["environments"]) if args.env == "all" else [args.env]
    report: dict[str, Any] = {"ticket": "DBI-12139", "checked_at_utc": now(),
        "mode": "Nur lesende Azure-Abfragen; kein Nachweis externer Erreichbarkeit", "environments": {}}
    failed = False
    for name in envs:
        cfg = env_config(name)
        entry: dict[str, Any] = {"expected": cfg, "errors": []}
        report["environments"][name] = entry
        print(f"Prüfe {name}: {cfg['storage_account']}")
        try:
            account = read_account(cfg)
            entry["storage"] = {k: account.get(k) for k in (
                "id", "name", "location", "provisioningState", "allowBlobPublicAccess", "publicNetworkAccess",
                "allowSharedKeyAccess", "enableHttpsTrafficOnly", "minimumTlsVersion", "primaryEndpoints",
                "privateEndpointConnections", "networkRuleSet", "sku")}
            entry["containers"] = summarize_containers(read_containers(cfg))
            entry["checks"] = storage_checks(account, entry["containers"])
            if not all(check["passed"] for check in entry["checks"]):
                failed = True
        except TaskError as exc:
            entry["errors"].append(f"Storage: {exc}")
            failed = True
        try:
            query = ("{id:id,provisioningState:provisioningState,httpListeners:httpListeners,"
                     "frontendIPConfigurations:frontendIPConfigurations,backendAddressPools:backendAddressPools,"
                     "backendHttpSettingsCollection:backendHttpSettingsCollection,urlPathMaps:urlPathMaps,"
                     "requestRoutingRules:requestRoutingRules}")
            gw = az_json(["network", "application-gateway", "show", "--subscription", cfg["subscription_id"],
                          "--resource-group", cfg["gateway_resource_group"], "--name", cfg["gateway"], "--query", query])
            entry["gateway"] = summarize_gateway(gw)
            entry["gateway_checks"] = gateway_checks(gw, cfg)
            if not all(c["passed"] for c in entry["gateway_checks"]):
                failed = True
            pools = entry["gateway"]["backend_pools"]
            hosts = {a.get("fqdn") for pool in pools for a in pool.get("backendAddresses", [])}
            entry["gateway_backend_matches_expected_storage"] = cfg["storage_account"] + ".blob.core.windows.net" in hosts
            if not entry["gateway_backend_matches_expected_storage"] or not entry["gateway"]["listeners"]:
                failed = True
        except TaskError as exc:
            entry["errors"].append(f"Application Gateway: {exc}")
            failed = True
    save_json(args.output, report)
    print(f"Bericht: {args.output.resolve()}")
    print("Abweichungen oder Lesefehler vorhanden." if failed else "Gelesene Storage-Sollwerte und Gateway-Zuordnung passen. Externen Zugriff separat testen.")
    return 2 if failed else 0


def safe_blob_name(blob: str) -> str:
    if not BLOB_RE.fullmatch(blob):
        raise TaskError("Keine von diesem Werkzeug erzeugte Testdatei. Operation abgebrochen.")
    return blob


def urls(env: str, campaign: str, blob: str) -> tuple[str, str]:
    cfg = env_config(env)
    item = load_config()["campaigns"][campaign]
    name = quote(safe_blob_name(blob), safe="")
    return (f"https://{cfg['asset_host']}/{item['public_path']}/{name}",
            f"https://{cfg['storage_account']}.blob.core.windows.net/{item['container']}/{name}")


def confirm(action: str, env: str) -> None:
    required = f"{action} {env}"
    if not sys.stdin.isatty():
        raise TaskError(f"Schreibzugriff benötigt eine interaktive Bestätigung: {required}. Nicht durch eine Pipe ausführen.")
    if input(f"Zum Bestätigen exakt '{required}' eingeben: ").strip() != required:
        raise TaskError("Abgebrochen; keine Schreiboperation ausgeführt.")


def upload_test(args: argparse.Namespace) -> int:
    cfg = env_config(args.env)
    campaign = load_config()["campaigns"][args.campaign]
    print(f"Ziel: {args.env} / {cfg['storage_account']} / {campaign['container']}")
    print("Legt nur eine neue, synthetische 8-KiB-Testdatei an. Überschreibt keine bestehenden Dateien.")
    account = read_account(cfg)
    containers = {v["name"]: v["publicAccess"] for v in summarize_containers(read_containers(cfg))}
    if account.get("allowBlobPublicAccess") is not True or containers.get(campaign["container"]) != "Blob":
        raise TaskError("Ziel entspricht nicht dem vorgesehenen anonym lesbaren Release-Container. Zuerst inventory prüfen.")
    confirm("UPLOAD", args.env)
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    blob = f"dbi-12139-check-{stamp}-{uuid.uuid4().hex[:12]}.txt"
    line = f"DBI-12139 synthetic public asset test {uuid.uuid4().hex}\n".encode("ascii")
    data = (line * (SAMPLE_SIZE // len(line) + 1))[:SAMPLE_SIZE]
    folder = args.output_dir / args.env / blob.removesuffix(".txt")
    folder.mkdir(parents=True, exist_ok=False)
    sample = folder / "testdatei.txt"
    sample.write_bytes(data)
    public_url, internal_url = urls(args.env, args.campaign, blob)
    receipt_path = folder / "upload.json"
    receipt = {"ticket": "DBI-12139", "created_at_utc": now(), "environment": args.env,
               "campaign": args.campaign, "storage_account": cfg["storage_account"], "container": campaign["container"],
               "blob": blob, "sample_file": sample.name, "sample_sha256": hashlib.sha256(data).hexdigest(),
               "size_bytes": len(data), "asset_url": public_url, "internal_blob_url": internal_url,
               "status": "upload_pending"}
    save_json(receipt_path, receipt)
    try:
        result = az_json([
            "storage", "blob", "upload", "--subscription", cfg["subscription_id"],
            "--account-name", cfg["storage_account"], "--container-name", campaign["container"],
            "--name", blob, "--file", str(sample.resolve()), "--auth-mode", "login", "--type", "block",
            "--overwrite", "false", "--if-none-match", "*", "--content-type", "text/plain",
            "--content-cache-control", "no-store", "--metadata", "ticket=DBI-12139", "synthetic=true",
        ])
    except TaskError as exc:
        receipt["status"] = "upload_failed_or_unconfirmed"
        receipt["error"] = str(exc)
        save_json(receipt_path, receipt)
        raise
    receipt["status"] = "uploaded"
    receipt["upload_etag"] = result.get("etag") if isinstance(result, dict) else None
    save_json(receipt_path, receipt)
    print(f"Testdatei: {public_url}\nBeleg für weitere Tests und Bereinigung: {receipt_path.resolve()}")
    print("Den gesamten Belegordner einschließlich testdatei.txt für den externen Test mitnehmen.")
    return 0


def read_receipt(path: Path) -> tuple[dict[str, Any], bytes]:
    receipt = json.loads(path.read_text(encoding="utf-8"))
    if receipt.get("ticket") != "DBI-12139" or receipt.get("environment") not in load_config()["environments"]:
        raise TaskError("Ungültiger Testbeleg.")
    if receipt.get("campaign") not in load_config()["campaigns"]:
        raise TaskError("Unbekannte Landingpage im Testbeleg.")
    safe_blob_name(receipt.get("blob", ""))
    if receipt.get("sample_file") != "testdatei.txt":
        raise TaskError("Unerwarteter Dateiverweis im Testbeleg.")
    sample = path.resolve().parent / "testdatei.txt"
    if sample.is_symlink() or sample.stat().st_size != SAMPLE_SIZE:
        raise TaskError("Testdatei muss die unveränderte 8-KiB-Datei aus dem Belegordner sein.")
    data = sample.read_bytes()
    if hashlib.sha256(data).hexdigest() != receipt.get("sample_sha256"):
        raise TaskError("Prüfsumme der Testdatei stimmt nicht. Abbruch.")
    cfg = env_config(receipt["environment"])
    campaign = load_config()["campaigns"][receipt["campaign"]]
    if receipt.get("storage_account") != cfg["storage_account"] or receipt.get("container") != campaign["container"]:
        raise TaskError("Ziel im Testbeleg weicht von dem eingebetteten Repository-Snapshot ab. Keine automatische Umleitung.")
    return receipt, data


class NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, req: Any, fp: Any, code: int, msg: str, headers: Any, newurl: str) -> None:
        return None


def http_get(url: str, byte_range: str | None = None, origin: str | None = None) -> tuple[dict[str, Any], bytes]:
    parsed = urlparse(url)
    if parsed.scheme != "https" or not parsed.hostname or parsed.username or parsed.password or parsed.query or parsed.fragment:
        raise TaskError("Es sind nur HTTPS-Asset-URLs ohne Zugangsdaten, Querystring oder Fragment erlaubt.")
    headers = {"User-Agent": "DBI-12139-asset-check/1.0", "Accept-Encoding": "identity"}
    if byte_range:
        headers["Range"] = byte_range
    if origin:
        headers["Origin"] = origin
    request = Request(url, headers=headers, method="GET")
    opener = build_opener(NoRedirect())
    start = time.monotonic()
    try:
        try:
            response = opener.open(request, timeout=30)
        except HTTPError as exc:
            response = exc
        with response:
            data = response.read(READ_LIMIT + 1)
            report = {"url": url, "http_status": response.code, "method": "GET", "range": byte_range,
                      "duration_seconds": round(time.monotonic() - start, 3), "body_truncated": len(data) > READ_LIMIT,
                      "headers": {k.lower(): v for k, v in response.headers.items() if k.lower() in {
                          "content-type", "content-length", "content-range", "etag", "cache-control", "location",
                          "access-control-allow-origin", "accept-ranges", "x-ms-error-code"}}}
            return report, data[:READ_LIMIT]
    except (URLError, HTTPException, TimeoutError, socket.timeout, OSError) as exc:
        return {"url": url, "http_status": None, "method": "GET", "range": byte_range,
                "duration_seconds": round(time.monotonic() - start, 3), "error": str(exc)}, b""


def probe(args: argparse.Namespace) -> int:
    receipt, expected = read_receipt(args.receipt)
    public_url, internal_url = urls(receipt["environment"], receipt["campaign"], receipt["blob"])
    url = internal_url if args.endpoint == "blob-intern" else public_url
    if args.origin:
        parsed = urlparse(args.origin)
        if parsed.scheme != "https" or not parsed.netloc or parsed.username or parsed.password or parsed.path not in ("", "/") or parsed.query or parsed.fragment:
            raise TaskError("Origin muss eine HTTPS-Landingpage-Domain ohne Pfad sein.")
    full, body = http_get(url, origin=args.origin)
    full["content_matches_test_file"] = body == expected
    full["passed"] = full.get("http_status") == 200 and body == expected and not full.get("body_truncated", False)
    partial, partial_body = http_get(url, byte_range="bytes=0-1023", origin=args.origin)
    partial["content_matches_expected_range"] = partial_body == expected[:1024]
    partial["passed"] = (partial.get("http_status") == 206 and partial_body == expected[:1024]
                         and partial.get("headers", {}).get("content-range") == f"bytes 0-1023/{len(expected)}")
    cors_ok = None
    if args.origin:
        cors_ok = all(v.get("headers", {}).get("access-control-allow-origin") in (args.origin, "*") for v in (full, partial))
    passed = full["passed"] and partial["passed"] and cors_ok is not False
    report = {"ticket": "DBI-12139", "checked_at_utc": now(), "environment": receipt["environment"],
              "campaign": receipt["campaign"], "network_declared_by_operator": args.network,
              "endpoint": args.endpoint, "authentication": "Keine Authorization-Header, SAS-Tokens oder Cookies",
              "redirects": "werden nicht verfolgt", "get": full, "range_get": partial,
              "origin": args.origin, "cors_check_passed": cors_ok, "passed": passed,
              "limitations": "Nur diese Testdatei von diesem Teststandort. Kein Beleg für alle Medien, andere Netze oder funktionierende Browser-Templates."}
    output = args.output or args.receipt.with_name(f"probe-{args.endpoint}-{args.network}.json")
    save_json(output, report)
    print(f"{'ERFOLGREICH' if passed else 'NICHT ERFOLGREICH'}: {url}\nBericht: {output.resolve()}")
    return 0 if passed else 2


def cleanup(args: argparse.Namespace) -> int:
    receipt, _ = read_receipt(args.receipt)
    cfg = env_config(receipt["environment"])
    print(f"Entfernt nur die Testdatei {receipt['container']}/{receipt['blob']} in {receipt['environment']}.")
    common = ["--subscription", cfg["subscription_id"], "--account-name", cfg["storage_account"],
              "--container-name", receipt["container"], "--name", receipt["blob"], "--auth-mode", "login"]
    blob = az_json(["storage", "blob", "show", *common])
    metadata = blob.get("metadata", {})
    if metadata.get("ticket") != "DBI-12139" or metadata.get("synthetic") != "true":
        raise TaskError("Testmarkierungen am Blob fehlen. Keine Löschung.")
    etag = blob.get("properties", {}).get("etag")
    if not etag:
        raise TaskError("ETag fehlt. Keine Löschung ohne Schutz vor gleichzeitiger Änderung.")
    uploaded_etag = receipt.get("upload_etag")
    if uploaded_etag and uploaded_etag != etag:
        raise TaskError("Blob wurde seit dem Upload geändert. Nicht automatisch löschen.")
    confirm("DELETE", receipt["environment"])
    az_json(["storage", "blob", "delete", *common, "--if-match", etag])
    receipt["status"] = "current_test_blob_deleted"
    receipt["deleted_at_utc"] = now()
    save_json(args.receipt, receipt)
    print("Aktuelle Testdatei gelöscht. Versionierung/Soft Delete können ältere Daten entsprechend der Aufbewahrung erhalten.")
    return 0


def block(text: str, marker: str) -> str:
    """Read a braced HCL block for snapshot checks, not a Terraform validator."""
    start = text.find(marker)
    if start < 0:
        raise TaskError(f"Im Quellcode fehlt: {marker}")
    start = text.find("{", start + len(marker))
    if start < 0:
        raise TaskError(f"Keine öffnende Klammer: {marker}")
    i, depth, quoted, escaped = start, 0, False, False
    while i < len(text):
        c = text[i]
        if quoted:
            if escaped:
                escaped = False
            elif c == "\\":
                escaped = True
            elif c == '"':
                quoted = False
        elif c == '"':
            quoted = True
        elif text.startswith("//", i) or c == "#":
            end = text.find("\n", i)
            i = len(text) if end < 0 else end
        elif text.startswith("/*", i):
            end = text.find("*/", i + 2)
            if end < 0:
                raise TaskError("Unvollständiger HCL-Kommentar.")
            i = end + 1
        elif c == "{":
            depth += 1
        elif c == "}":
            depth -= 1
            if depth == 0:
                return text[start + 1:i]
        i += 1
    raise TaskError(f"Unvollständiger HCL-Block: {marker}")


def source_check(args: argparse.Namespace) -> int:
    """Check exact existing resource names and paths without any Azure call."""
    checks = []
    for env, cfg in load_config()["environments"].items():
        stack = (args.repo / "live" / env / "terragrunt.stack.hcl").read_text(encoding="utf-8-sig")
        gw = (args.repo / "live" / env / "appgateway.hcl").read_text(encoding="utf-8-sig")
        subscription = (args.repo / "live" / env / "subscription.hcl").read_text(encoding="utf-8-sig")
        storage = block(stack, 'unit "storage-assets"')
        containers = block(storage, 'containers =')
        facts = {
            "existing_storage_unit": 'units/blob-storage-private' in storage,
            "account_allows_anonymous_blobs": bool(re.search(r'\banonymous_access_enabled\s*=\s*true', storage.split('containers =')[0])),
            "old_assets_stays_private": not re.search(r'anonymous_access_enabled\s*=\s*true', block(containers, 'assets =')),
            "storage_name_in_backend": cfg['storage_account'] + '.blob.core.windows.net' in gw,
            "host_in_listener": cfg['asset_host'] in gw,
            "subscription_matches": cfg['subscription_id'] in subscription,
            "gateway_matches": cfg['gateway'] in stack,
        }
        for campaign, details in load_config()['campaigns'].items():
            container_key = {'uniglobal': 'lp-uniglobal-r1', 've': 'lp-ve-r1', 'zukunft': 'lp-zukunft-r1'}[campaign]
            c = block(containers, container_key + ' =')
            facts[campaign + '_blob_read'] = bool(re.search(r'anonymous_access_enabled\s*=\s*true', c)) and f'"{details["container"]}"' in c
            facts[campaign + '_public_path'] = f'"/{details["public_path"]}/*"' in gw
            facts[campaign + '_backend_path'] = f'"/{details["container"]}/"' in gw
        checks.append({'environment': env, 'checks': facts, 'passed': all(facts.values())})
    passed = all(item['passed'] for item in checks)
    report = {'ticket': 'DBI-12139', 'mode': 'Lokaler Quellcodeabgleich; keine Azure-Abfrage, keine Terraform-Validierung',
              'checked_at_utc': now(), 'passed': passed, 'environments': checks}
    save_json(args.output, report)
    print(('QUELLCODE PASST' if passed else 'ABWEICHUNG') + f': {args.output.resolve()}')
    return 0 if passed else 2


def gateway_checks(gateway: dict[str, Any], cfg: dict[str, Any]) -> list[dict[str, Any]]:
    checks = []
    def record(name: str, passed: bool) -> None:
        checks.append({'check': name, 'passed': bool(passed)})
    record('Gateway-Bereitstellung erfolgreich', gateway.get('provisioningState') == 'Succeeded')
    listeners = {x.get('name'): x for x in gateway.get('httpListeners', [])}
    record('LP-Listener enthält erwarteten Host', any(
        cfg['asset_host'] in x.get('hostNames', []) or x.get('hostName') == cfg['asset_host']
        for x in listeners.values() if x.get('name', '').startswith('landingassets-')))
    maps = {x.get('name'): x for x in gateway.get('urlPathMaps', [])}
    rules = {x.get('name'): x for x in maps.get('lpa-default-route', {}).get('pathRules', [])}
    settings = {x.get('name'): x for x in gateway.get('backendHttpSettingsCollection', [])}
    for name, campaign in load_config()['campaigns'].items():
        setting_name = f'lpa-{name}-settings'
        setting = settings.get(setting_name, {})
        rule = rules.get(f'lpa-{name}-route', {})
        record(name + ': Pfad auf richtigen Container', setting.get('path') == '/' + campaign['container'] + '/')
        record(name + ': Storage-Hostname als Host-Header', setting.get('pickHostNameFromBackendAddress') is True)
        record(name + ': korrekte Pfadregel', '/' + campaign['public_path'] + '/*' in rule.get('paths', []))
        record(name + ': Backend-Setting verknüpft', rule.get('backendHttpSettings', {}).get('id', '').endswith('/' + setting_name))
        record(name + ': Storage-Pool verknüpft', rule.get('backendAddressPool', {}).get('id', '').endswith('/landingassets-backends'))
    record('Routing-Regel verknüpft LP-Pathmap', any(
        x.get('urlPathMap', {}).get('id', '').endswith('/lpa-default-route')
        and x.get('httpListener', {}).get('id', '').rsplit('/', 1)[-1] in listeners
        for x in gateway.get('requestRoutingRules', []) if x.get('name', '').startswith('landingassets-')))
    return checks


def media_url(env: str, campaign: str, blob: str) -> str:
    parts = blob.split('/')
    if not blob or len(blob) > 1024 or any(p in ('', '.', '..') for p in parts) or re.search(r'[\x00-\x20?#\\:]', blob):
        raise TaskError('Bitte den Blob-Dateinamen relativ zum Release-Container angeben, ohne URL, Leerzeichen oder ..')
    path = '/'.join(quote(p, safe='-._~') for p in parts)
    return f'https://{env_config(env)["asset_host"]}/{load_config()["campaigns"][campaign]["public_path"]}/{path}'


def probe_media(args: argparse.Namespace) -> int:
    """Sample beginning and end of a real large asset; never download the full file."""
    url = media_url(args.env, args.campaign, args.blob)
    first, first_body = http_get(url, byte_range='bytes=0-1023')
    head_range = re.fullmatch(r'bytes 0-1023/(\d+)', first.get('headers', {}).get('content-range', ''))
    total = int(head_range.group(1)) if head_range else 0
    if first.get('http_status') == 206 and total >= 1024 and len(first_body) == 1024:
        last, last_body = http_get(url, byte_range=f'bytes={total - 1024}-{total - 1}')
    else:
        last, last_body = {'http_status': None, 'error': 'Kein gültiger Anfangsbereich; Endabruf ausgelassen.'}, b''
    checks = {
        'prefix_206': first.get('http_status') == 206 and len(first_body) == 1024,
        'suffix_206': last.get('http_status') == 206 and len(last_body) == 1024,
        'size_at_least_requested_mib': total >= args.min_size_mib * 1024 * 1024,
        'last_range_correct': total >= 1024 and last.get('headers', {}).get('content-range') == f'bytes {total - 1024}-{total - 1}/{total}',
        'not_login_html': all('text/html' not in response.get('headers', {}).get('content-type', '').lower() for response in (first, last)),
    }
    report = {'ticket': 'DBI-12139', 'mode': 'Anonyme Stichprobe eines realen Mediums: Anfang und Ende, kein vollständiger Download',
              'checked_at_utc': now(), 'url': url, 'network_declared_by_operator': args.network,
              'size_bytes': total, 'checks': checks, 'passed': all(checks.values()), 'first': first, 'last': last}
    save_json(args.output, report)
    print(('MEDIENTEST ERFOLGREICH' if report['passed'] else 'MEDIENTEST FEHLGESCHLAGEN') + f': {args.output.resolve()}')
    return 0 if report['passed'] else 2


def direct_tls_certificate(host: str) -> dict[str, Any]:
    """Observe the public leaf certificate, with validation enabled; no HTTP data sent.

    OpenSSL uses a direct TCP connection, unlike urllib which can use HTTPS_PROXY.
    A direct result is therefore diagnostic, not an end-to-end application test.
    """
    executable = shutil.which("openssl")
    result: dict[str, Any] = {"route": "Direkt TCP 443, SNI gesetzt; kein HTTP-Proxy", "verified": False}
    if not executable:
        result["error"] = "OpenSSL fehlt. Im WSL-Terminal openssl installieren oder Zertifikat im Browser prüfen."
        return result
    command = [executable, "s_client", "-connect", host + ":443", "-servername", host,
               "-showcerts", "-verify_hostname", host, "-verify_return_error"]
    try:
        checked = subprocess.run(command, input="", capture_output=True, text=True,
                                 encoding="utf-8", errors="replace", timeout=25, check=False)
        result["exit_code"] = checked.returncode
        result["verified"] = False
        result["verification_output"] = checked.stderr[-6000:]
        certificate = re.search(r"-----BEGIN CERTIFICATE-----[\s\S]*?-----END CERTIFICATE-----", checked.stdout)
        if certificate:
            # Public certificate only, even when untrusted. Never read a PFX/private key.
            leaf = subprocess.run([executable, "x509", "-noout", "-subject", "-issuer", "-dates",
                                   "-fingerprint", "-sha256", "-ext", "subjectAltName"],
                                  input=certificate.group(0), capture_output=True, text=True,
                                  encoding="utf-8", errors="replace", timeout=10, check=False)
            result["public_certificate_details"] = leaf.stdout[:12000] if leaf.returncode == 0 else leaf.stderr[:1000]
            result["certificate_details_decoded"] = leaf.returncode == 0
            result["verified"] = checked.returncode == 0 and leaf.returncode == 0
        else:
            result["certificate_details_decoded"] = False
    except (OSError, subprocess.TimeoutExpired) as exc:
        result["error"] = type(exc).__name__ + ": TLS-Verbindung oder Zertifikatsauswertung nicht abgeschlossen."
    return result


def tls_diagnose(args: argparse.Namespace) -> int:
    """Read DNS, the public TLS certificate and the Azure listener binding. No changes."""
    from urllib.request import getproxies, proxy_bypass
    cfg = env_config(args.env)
    host = cfg["asset_host"]
    result: dict[str, Any] = {"ticket": "DBI-12139", "environment": args.env,
        "checked_at_utc": now(), "hostname": host, "diagnostic_only": True,
        "azure_changes": False, "errors": []}
    proxies = getproxies()
    # Do not log proxy URLs, credentials, tokens, or private certificates.
    result["proxy"] = {"https_proxy_configured": bool(proxies.get("https")),
                       "proxy_bypassed_for_host": proxy_bypass(host),
                       "note": "Python-Assetabruf kann einen Proxy nutzen; OpenSSL unten verbindet direkt."}
    try:
        result["dns_addresses"] = sorted({item[4][0] for item in socket.getaddrinfo(host, 443, type=socket.SOCK_STREAM)})
    except OSError as exc:
        result["dns_addresses"] = []
        result["errors"].append("DNS: " + str(exc))
    result["direct_tls"] = direct_tls_certificate(host)
    query = ("{id:id,provisioningState:provisioningState,"
             "listeners:httpListeners[].{name:name,hostName:hostName,hostNames:hostNames,"
             "sslCertificate:sslCertificate,requireServerNameIndication:requireServerNameIndication,"
             "frontendIPConfiguration:frontendIPConfiguration},"
             "certificates:sslCertificates[].{name:name,id:id,keyVaultSecretId:keyVaultSecretId}}")
    try:
        gateway = az_json(["network", "application-gateway", "show", "--subscription", cfg["subscription_id"],
                           "--resource-group", cfg["gateway_resource_group"], "--name", cfg["gateway"],
                           "--query", query])
        expected_id = (f"/subscriptions/{cfg['subscription_id']}/resourceGroups/{cfg['gateway_resource_group']}"
                       f"/providers/Microsoft.Network/applicationGateways/{cfg['gateway']}")
        if not isinstance(gateway, dict) or gateway.get("id", "").lower() != expected_id.lower():
            raise TaskError("Gateway-Antwort gehört nicht zum erwarteten Ziel.")
        listeners = [v for v in (gateway.get("listeners") or [])
                     if host in (v.get("hostNames") or []) or v.get("hostName") == host]
        cert_ids = {(v.get("sslCertificate") or {}).get("id", "").lower() for v in listeners}
        certificates = [v for v in (gateway.get("certificates") or []) if v.get("id", "").lower() in cert_ids]
        result["gateway"] = {"id": gateway["id"], "listeners": listeners,
                             "certificate_references": certificates}
        if not listeners:
            result["errors"].append("Keine Listener-Zuordnung für den erwarteten Asset-Host gefunden.")
        if not certificates:
            result["errors"].append("Keine passende Zertifikatsreferenz im Gateway gefunden.")
    except TaskError as exc:
        result["errors"].append("Azure-Leseabfrage: " + str(exc))
    result["limitations"] = (
        "Öffentliches Zertifikat und Listener-Referenz, kein Download privater Schlüssel/Key-Vault-Secrets. "
        "Der beim Client sichtbare TLS-Endpunkt kann ein Proxy oder vorgeschalteter Dienst sein. "
        "Ein grüner Direkt-TLS-Test beweist weder Asset-Inhalt noch Internet-Erreichbarkeit.")
    save_json(args.output, result)
    lines = ["# DBI-12139: gezielte TLS-Diagnose", "", f"Umgebung: {args.env}; Host: `{host}`.", "",
             "Nur gelesen. Keine Azure-Konfiguration geändert; keine Testdatei angelegt.", "",
             "DNS-Ziele: " + (", ".join(result["dns_addresses"]) or "nicht ermittelt"),
             "Direkte TLS-Prüfung: " + ("bestanden" if result["direct_tls"]["verified"] else "nicht bestanden"),
             "HTTPS-Proxy konfiguriert: " + str(result["proxy"]["https_proxy_configured"]), "",
             "## Öffentliches Zertifikat (Direktverbindung)", "```text",
             str(result["direct_tls"].get("public_certificate_details", "Keine Zertifikatsdetails ermittelt.")),
             "```", "", "## Azure-Listener"]
    for listener in result.get("gateway", {}).get("listeners", []):
        lines += [f"- `{listener['name']}`: `{(listener.get('sslCertificate') or {}).get('id', 'unbekannt')}`"]
    for reference in result.get("gateway", {}).get("certificate_references", []):
        lines += ["- Key-Vault-Referenz: `" + str(reference.get("keyVaultSecretId") or "keine Referenz angegeben") + "`"]
    if result["errors"]:
        lines += ["", "Lesefehler: " + "; ".join(result["errors"])]
    lines += ["", "## Was du damit machst", "",
              "Passt der Asset-Hostname nicht zu den Zertifikatsnamen, die zuständige TLS-Stelle korrigieren. "
              "Zuerst DNS-Ziel/Proxy und Listener-Zuordnung vergleichen; nicht blind Storage-Rechte öffnen.",
              "Das gespeicherte DEV-Gateway verwendet `landing-internal-certificate` auch für die Landingpage-Domain. "
              "Eine Zertifikatsänderung muss beide Namen berücksichtigen.",
              "Danach: `bash start.sh 12139 probe --env dev --network intern`.",
              "Details: `tls.json`. Kein Ticketabschluss allein durch diese Diagnose."]
    args.output.with_suffix(".md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print("TLS-Diagnose: " + str(args.output.with_suffix(".md").resolve()))
    return 0 if result["direct_tls"]["verified"] and not result["errors"] else 2


def parser() -> argparse.ArgumentParser:
    config = load_config()
    root = argparse.ArgumentParser(description=__doc__)
    commands = root.add_subparsers(dest="command", required=True)
    tls = commands.add_parser("tls", help="DNS, öffentliches Zertifikat und Listener-Zuordnung lesen")
    tls.add_argument("--env", choices=config["environments"], default="dev")
    tls.add_argument("--output", type=Path, default=Path("ergebnisse/tls.json"))
    tls.set_defaults(func=tls_diagnose)
    inv = commands.add_parser("inventory", help="Nur Azure-Metadaten lesen, keine Änderung")
    inv.add_argument("--env", choices=[*config["environments"], "all"], default="all")
    inv.add_argument("--output", type=Path, default=Path("ergebnisse/inventar.json"))
    inv.set_defaults(func=inventory)
    upload = commands.add_parser("upload-test", help="Eine synthetische Testdatei mit expliziter Bestätigung hochladen")
    upload.add_argument("--env", choices=config["environments"], required=True)
    upload.add_argument("--campaign", choices=config["campaigns"], default="uniglobal")
    upload.add_argument("--output-dir", type=Path, default=Path("ergebnisse"))
    upload.set_defaults(func=upload_test)
    check = commands.add_parser("probe", help="Testdatei mit anonymen GET- und Range-Anfragen abrufen")
    check.add_argument("--receipt", type=Path, required=True)
    check.add_argument("--network", choices=["intern", "extern", "unbekannt"], required=True)
    check.add_argument("--endpoint", choices=["asset-domain", "blob-intern"], default="asset-domain")
    check.add_argument("--origin", help="Optionale HTTPS-Landingpage-Origin für einen CORS-Lesetest")
    check.add_argument("--output", type=Path)
    check.set_defaults(func=probe)
    clean = commands.add_parser("cleanup", help="Nur die markierte Testdatei nach Bestätigung entfernen")
    clean.add_argument("--receipt", type=Path, required=True)
    clean.set_defaults(func=cleanup)
    source = commands.add_parser("source-check", help="Nur vorhandenen live-Quellcode abgleichen, ohne Azure")
    source.add_argument("--repo", type=Path, required=True)
    source.add_argument("--output", type=Path, default=Path("ergebnisse/quellcode.json"))
    source.set_defaults(func=source_check)
    media = commands.add_parser("probe-media", help="Vorhandenes großes Medium per zwei Range-GETs prüfen")
    media.add_argument("--env", choices=config["environments"], required=True)
    media.add_argument("--campaign", choices=config["campaigns"], required=True)
    media.add_argument("--blob", required=True)
    media.add_argument("--network", choices=["intern", "extern", "unbekannt"], required=True)
    media.add_argument("--min-size-mib", type=int, choices=range(1, 102401), default=10, metavar="MIB")
    media.add_argument("--output", type=Path, default=Path("ergebnisse/medientest.json"))
    media.set_defaults(func=probe_media)
    return root


def main() -> int:
    try:
        args = parser().parse_args()
        return args.func(args)
    except (TaskError, OSError, ValueError, KeyError) as exc:
        print(f"ABBRUCH: {exc}", file=sys.stderr)
        return 2
    except KeyboardInterrupt:
        print("\nAbgebrochen. Bereits ausgeführte Uploads nicht als automatisch zurückgenommen betrachten.", file=sys.stderr)
        return 130


if __name__ == "__main__":
    sys.exit(main())
