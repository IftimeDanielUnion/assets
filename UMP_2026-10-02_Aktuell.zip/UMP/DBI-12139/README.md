# DBI-12139: vorhandener Storage, DEV-Zertifikat korrigieren

**Offen wegen DEV-HTTPS-Fehler. Die Storages müssen nicht neu angelegt werden.**

| Prüfung | DEV | TEST | PROD |
|---|---|---|---|
| Azure-Bestand / Container / Gateway | erfolgreich | erfolgreich | erfolgreich |
| Kleine Testdatei hochgeladen | erfolgreich | erfolgreich | kein Beleg |
| Datei anonym über Asset-Adresse gelesen | Zertifikat passt nicht zum Host | HTTP 200, Inhalt korrekt | kein Beleg |
| Teilabruf | gleicher TLS-Fehler | HTTP 206, Inhalt korrekt | kein Beleg |
| Externer Zugriff | nicht belegt | nicht belegt | nicht belegt |

Der neue DEV-Test vom 02.10., 12:28 Uhr deutscher Zeit scheitert **vor HTTP**, nicht an einem nachgewiesenen Blob-Rechtefehler. Ein `rest`-Lauf stoppt an diesem Fehler, statt einfach alle weiteren Umgebungen als erfolgreich zu zählen.

## 1. Jira dokumentieren

Den Storage-Kommentar aus [JIRA_KOMMENTARE.md](../JIRA_KOMMENTARE.md) einfügen. Er nennt die vorhandene Infrastruktur, die bestandenen Tests und den konkreten Restfehler. Noch nicht auf Done setzen.

## 2. Gezielt den Zertifikatsfehler eingrenzen

**Warum:** Wir müssen wissen, ob falsches Zertifikat, falsche Zuordnung oder eine vorgeschaltete TLS-Stelle die Ursache ist. Ein weiterer Upload hilft dabei nicht.

```bash
bash start.sh 12139 tls --env dev
```

Nur lesend; benötigt Linux-Azure-CLI mit Anmeldung und OpenSSL in WSL. Das Skript liest **keine privaten Schlüssel**. Öffne danach die ausgegebene `tls.md`.

Im Quellcode und bisherigen Azure-Inventar zeigt der DEV-Listener `landingassets-private` auf `landing-internal-certificate`. Dasselbe Zertifikat wird im Repo auch für `landing.dev.apps.union-investment.de` verwendet. Der tatsächliche Zertifikatsinhalt fehlt in deinen bisherigen Belegen.

**Auswertung:**
- Stimmen DNS-Ziel und Gateway/Proxy nicht überein, zuerst diesen Weg korrigieren.
- Fehlt der Asset-Hostname im tatsächlich verwendeten Zertifikat, ein gültiges Zertifikat über euren bestehenden Zertifikatsprozess bereitstellen und korrekt zuordnen. Beide betroffenen Landing-Domains berücksichtigen.
- Eine im Python-Aufruf verwendete Proxy-Verbindung kann ein anderes Zertifikat zeigen als die direkte OpenSSL-Verbindung. Die Diagnose kennzeichnet den Unterschied; deshalb nicht automatisch das Gateway beschuldigen.

Im Portal: DEV Application Gateway → Listeners → `landingassets-private` → zugeordnetes Zertifikat. Der Bericht enthält die Gateway-/Key-Vault-Referenz, soweit lesbar. Keine Namen/Secrets raten.

**Nicht `-k` verwenden oder die Zertifikatsprüfung abschalten.** Das würde den Fehler nur übergehen.

## 3. Nach der Korrektur nur Fehlendes nachtesten

**Warum:** Der bereits erfolgreiche TEST-Abruf muss nicht wiederholt werden. Die DEV-Testdatei existiert laut Uploadbeleg und wird wiederverwendet.

```bash
bash start.sh 12139 rest --network intern
```

Das prüft DEV erneut, überspringt den erfolgreichen TEST-Lauf und fragt vor einem eventuell benötigten PROD-Testupload ausdrücklich nach. PROD nur entsprechend eurer Testfreigabe bestätigen. Kein automatisches Terraform-Apply.

## 4. Externen Abruf belegen

Arbeitsannahme: Kundenzugriff über die öffentliche Asset-Adresse. Keine zusätzliche Grundsatzfrage nötig; aber ein interner Test ersetzt keinen Internet-Test.

Nur von einem tatsächlich erlaubten externen Teststandort aus:

```bash
bash start.sh 12139 extern
```

Liest vorhandene synthetische Testdateien ohne Azure-Login. Keine neuen Uploads. Ein Firmen-/VPN-Test darf nicht lediglich als „extern“ bezeichnet werden. Alternativ ist ein dokumentierter externer Abruf durch den Betrieb ausreichend.

Ein freigegebenes großes Produktmedium ist eine sinnvolle zusätzliche Stichprobe; im Jira ist keine feste Mindestgröße/Performance-Grenze genannt. Eigene Testdateien anschließend über `cleanup --env dev` bzw. `test`/`prod` bereinigen, soweit dort angelegt.

## Muss ich etwas mergen?

**Für die vorhandenen Storages und die bisherigen Tests: nein.** Das Prüfwerkzeug ist optionales Betriebshilfsmittel, kein notwendiger Infrastruktur-Merge.

Falls eine falsche Listener-Referenz im IaC korrigiert werden muss: Datei `live/dev/appgateway.hcl` im Repo `live` gezielt ändern, Plan prüfen und per MR übernehmen. Ein Zertifikatsaustausch am bereits richtigen Key-Vault-Secret kann dagegen ohne Änderung dieser Datei auskommen. Das hängt vom Diagnosebefund ab.

**Abschluss:** korrekter DEV-HTTPS-Abruf, bestätigter PROD-Abruf und Nachweis des vorgesehenen öffentlichen Zugriffs. „Storage vorhanden“ allein überdeckt den aktuellen DEV-Fehler nicht.
