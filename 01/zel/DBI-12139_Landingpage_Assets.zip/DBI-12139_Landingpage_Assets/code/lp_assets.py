#!/usr/bin/env python3
"""DBI-12139: Bestehende LP-Asset-Infrastruktur prüfen.

Nur Python-Standardbibliothek. Azure CLI wird ausschließlich für inventory,
upload-test und cleanup benötigt. probe führt nur anonyme HTTPS-GETs aus.
Keine Infrastruktur, Rechte oder Netzwerke werden verändert.
"""
from __future__ import annotations

import argparse
import hashlib
from http.client import HTTPException
import json
import os
import re
import shutil
import socket
import subprocess
import sys
import time
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
from urllib.error import HTTPError, URLError
from urllib.parse import quote, urlparse
from urllib.request import HTTPRedirectHandler, Request, build_opener

CONFIG_FILE = Path(__file__).with_name("umgebungen.json")
ARM = "https://management.azure.com"
STORAGE_API = "2025-01-01"
READ_LIMIT = 65536
SAMPLE_SIZE = 8192
BLOB_RE = re.compile(r"^dbi-12139-check-\d{8}T\d{6}Z-[0-9a-f]{12}\.txt$")


class TaskError(RuntimeError):
    """Erwartbarer Bedienungs- oder Umgebungsfehler."""


def now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def load_config() -> dict[str, Any]:
    return json.loads(CONFIG_FILE.read_text(encoding="utf-8"))


def save_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(path.name + ".tmp")
    temp.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    temp.replace(path)


def az_json(arguments: list[str]) -> Any:
    executable = shutil.which("az")
    if not executable:
        raise TaskError("Azure CLI fehlt. In einer Umgebung mit Azure CLI starten und zuerst az login ausführen.")
    env = os.environ.copy()
    # Keine unabsichtliche Nutzung alter Storage-Schlüssel oder SAS-Umgebungswerte.
    for key in ("AZURE_STORAGE_KEY", "AZURE_STORAGE_SAS_TOKEN", "AZURE_STORAGE_CONNECTION_STRING",
                "AZURE_STORAGE_ACCOUNT", "AZURE_STORAGE_SERVICE_ENDPOINT"):
        env.pop(key, None)
    env["AZURE_STORAGE_AUTH_MODE"] = "login"
    try:
        result = subprocess.run(
            [executable, *arguments, "--only-show-errors", "--output", "json"],
            check=False, capture_output=True, text=True, encoding="utf-8", errors="replace",
            timeout=180, env=env,
        )
    except subprocess.TimeoutExpired as exc:
        raise TaskError("Azure CLI hat nach 180 Sekunden nicht geantwortet. Ergebnis der Operation separat prüfen.") from exc
    if result.returncode:
        raise TaskError(result.stderr.strip() or "Azure CLI meldet einen Fehler ohne Fehlertext.")
    try:
        return json.loads(result.stdout) if result.stdout.strip() else None
    except json.JSONDecodeError as exc:
        raise TaskError("Azure CLI hat keine gültige JSON-Antwort geliefert.") from exc


def env_config(env: str) -> dict[str, Any]:
    return load_config()["environments"][env]


def account_id(cfg: dict[str, Any]) -> str:
    return (f"/subscriptions/{cfg['subscription_id']}/resourceGroups/{cfg['resource_group']}"
            f"/providers/Microsoft.Storage/storageAccounts/{cfg['storage_account']}")


def read_account(cfg: dict[str, Any]) -> dict[str, Any]:
    account = az_json([
        "storage", "account", "show", "--subscription", cfg["subscription_id"],
        "--resource-group", cfg["resource_group"], "--name", cfg["storage_account"],
    ])
    if not isinstance(account, dict) or account.get("id", "").lower() != account_id(cfg).lower():
        raise TaskError("Die gelesene Storage-Ressource passt nicht zum erwarteten Ziel. Kein automatischer Wechsel.")
    return account


def read_containers(cfg: dict[str, Any]) -> list[dict[str, Any]]:
    url = f"{ARM}{account_id(cfg)}/blobServices/default/containers?api-version={STORAGE_API}"
    items: list[dict[str, Any]] = []
    visited: set[str] = set()
    while url:
        if url in visited or urlparse(url).scheme != "https" or urlparse(url).netloc != "management.azure.com":
            raise TaskError("Unerwarteter oder wiederholter ARM-Folgelink. Abbruch.")
        visited.add(url)
        page = az_json(["rest", "--method", "get", "--url", url, "--subscription", cfg["subscription_id"]])
        items.extend(page.get("value", []))
        url = page.get("nextLink")
    return items


def summarize_containers(items: list[dict[str, Any]]) -> list[dict[str, Any]]:
    return [{"name": item["name"].rsplit("/", 1)[-1],
             "publicAccess": item.get("properties", {}).get("publicAccess", "UNBEKANNT"),
             "id": item.get("id")} for item in items]


def storage_checks(account: dict[str, Any], containers: list[dict[str, Any]]) -> list[dict[str, Any]]:
    actual = {item["name"]: item["publicAccess"] for item in containers}
    expected = {"assets": "None", "statuspages": "Blob"}
    expected.update({c["container"]: "Blob" for c in load_config()["campaigns"].values()})
    checks = [
        {"check": "Account erlaubt Blob-Lesezugriff ohne Anmeldung", "expected": True,
         "actual": account.get("allowBlobPublicAccess"), "passed": account.get("allowBlobPublicAccess") is True},
        {"check": "Direkter öffentlicher Storage-Netzzugang bleibt aus", "expected": "Disabled",
         "actual": account.get("publicNetworkAccess"), "passed": account.get("publicNetworkAccess") == "Disabled"},
    ]
    for name, value in expected.items():
        checks.append({"check": f"Container {name}", "expected": value,
                       "actual": actual.get(name, "NICHT_GEFUNDEN"), "passed": actual.get(name) == value})
    return checks


def summarize_gateway(gateway: dict[str, Any]) -> dict[str, Any]:
    listeners = [v for v in gateway.get("httpListeners", []) if v.get("name", "").startswith("landingassets-")]
    frontend_ids = {v.get("frontendIPConfiguration", {}).get("id") for v in listeners}
    return {
        "id": gateway.get("id"), "provisioningState": gateway.get("provisioningState"),
        "listeners": listeners,
        "frontends": [v for v in gateway.get("frontendIPConfigurations", []) if v.get("id") in frontend_ids],
        "backend_pools": [v for v in gateway.get("backendAddressPools", []) if v.get("name") == "landingassets-backends"],
        "backend_settings": [v for v in gateway.get("backendHttpSettingsCollection", []) if v.get("name", "").startswith("lpa-")],
        "path_maps": [v for v in gateway.get("urlPathMaps", []) if v.get("name", "").startswith("lpa-")],
        "routes": [v for v in gateway.get("requestRoutingRules", []) if v.get("name", "").startswith("landingassets-")],
    }


def inventory(args: argparse.Namespace) -> int:
    config = load_config()
    envs = list(config["environments"]) if args.env == "all" else [args.env]
    report: dict[str, Any] = {"ticket": "DBI-12139", "checked_at_utc": now(),
        "mode": "Nur lesende Azure-Abfragen; kein Nachweis externer Erreichbarkeit", "environments": {}}
    failed = False
    for name in envs:
        cfg = env_config(name)
        entry: dict[str, Any] = {"expected": cfg, "errors": []}
        report["environments"][name] = entry
        print(f"Prüfe {name}: {cfg['storage_account']}")
        try:
            account = read_account(cfg)
            entry["storage"] = {k: account.get(k) for k in (
                "id", "name", "location", "provisioningState", "allowBlobPublicAccess", "publicNetworkAccess",
                "allowSharedKeyAccess", "enableHttpsTrafficOnly", "minimumTlsVersion", "primaryEndpoints",
                "privateEndpointConnections", "networkRuleSet", "sku")}
            entry["containers"] = summarize_containers(read_containers(cfg))
            entry["checks"] = storage_checks(account, entry["containers"])
            if not all(check["passed"] for check in entry["checks"]):
                failed = True
        except TaskError as exc:
            entry["errors"].append(f"Storage: {exc}")
            failed = True
        try:
            query = ("{id:id,provisioningState:provisioningState,httpListeners:httpListeners,"
                     "frontendIPConfigurations:frontendIPConfigurations,backendAddressPools:backendAddressPools,"
                     "backendHttpSettingsCollection:backendHttpSettingsCollection,urlPathMaps:urlPathMaps,"
                     "requestRoutingRules:requestRoutingRules}")
            gw = az_json(["network", "application-gateway", "show", "--subscription", cfg["subscription_id"],
                          "--resource-group", cfg["gateway_resource_group"], "--name", cfg["gateway"], "--query", query])
            entry["gateway"] = summarize_gateway(gw)
            pools = entry["gateway"]["backend_pools"]
            hosts = {a.get("fqdn") for pool in pools for a in pool.get("backendAddresses", [])}
            entry["gateway_backend_matches_expected_storage"] = cfg["storage_account"] + ".blob.core.windows.net" in hosts
            if not entry["gateway_backend_matches_expected_storage"] or not entry["gateway"]["listeners"]:
                failed = True
        except TaskError as exc:
            entry["errors"].append(f"Application Gateway: {exc}")
            failed = True
    save_json(args.output, report)
    print(f"Bericht: {args.output.resolve()}")
    print("Abweichungen oder Lesefehler vorhanden." if failed else "Gelesene Storage-Sollwerte und Gateway-Zuordnung passen. Externen Zugriff separat testen.")
    return 2 if failed else 0


def safe_blob_name(blob: str) -> str:
    if not BLOB_RE.fullmatch(blob):
        raise TaskError("Keine von diesem Werkzeug erzeugte Testdatei. Operation abgebrochen.")
    return blob


def urls(env: str, campaign: str, blob: str) -> tuple[str, str]:
    cfg = env_config(env)
    item = load_config()["campaigns"][campaign]
    name = quote(safe_blob_name(blob), safe="")
    return (f"https://{cfg['asset_host']}/{item['public_path']}/{name}",
            f"https://{cfg['storage_account']}.blob.core.windows.net/{item['container']}/{name}")


def confirm(action: str, env: str) -> None:
    required = f"{action} {env}"
    if not sys.stdin.isatty():
        raise TaskError(f"Schreibzugriff benötigt eine interaktive Bestätigung: {required}. Nicht durch eine Pipe ausführen.")
    if input(f"Zum Bestätigen exakt '{required}' eingeben: ").strip() != required:
        raise TaskError("Abgebrochen; keine Schreiboperation ausgeführt.")


def upload_test(args: argparse.Namespace) -> int:
    cfg = env_config(args.env)
    campaign = load_config()["campaigns"][args.campaign]
    print(f"Ziel: {args.env} / {cfg['storage_account']} / {campaign['container']}")
    print("Legt nur eine neue, synthetische 8-KiB-Testdatei an. Überschreibt keine bestehenden Dateien.")
    account = read_account(cfg)
    containers = {v["name"]: v["publicAccess"] for v in summarize_containers(read_containers(cfg))}
    if account.get("allowBlobPublicAccess") is not True or containers.get(campaign["container"]) != "Blob":
        raise TaskError("Ziel entspricht nicht dem vorgesehenen anonym lesbaren Release-Container. Zuerst inventory prüfen.")
    confirm("UPLOAD", args.env)
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    blob = f"dbi-12139-check-{stamp}-{uuid.uuid4().hex[:12]}.txt"
    line = f"DBI-12139 synthetic public asset test {uuid.uuid4().hex}\n".encode("ascii")
    data = (line * (SAMPLE_SIZE // len(line) + 1))[:SAMPLE_SIZE]
    folder = args.output_dir / args.env / blob.removesuffix(".txt")
    folder.mkdir(parents=True, exist_ok=False)
    sample = folder / "testdatei.txt"
    sample.write_bytes(data)
    public_url, internal_url = urls(args.env, args.campaign, blob)
    receipt_path = folder / "upload.json"
    receipt = {"ticket": "DBI-12139", "created_at_utc": now(), "environment": args.env,
               "campaign": args.campaign, "storage_account": cfg["storage_account"], "container": campaign["container"],
               "blob": blob, "sample_file": sample.name, "sample_sha256": hashlib.sha256(data).hexdigest(),
               "size_bytes": len(data), "asset_url": public_url, "internal_blob_url": internal_url,
               "status": "upload_pending"}
    save_json(receipt_path, receipt)
    try:
        result = az_json([
            "storage", "blob", "upload", "--subscription", cfg["subscription_id"],
            "--account-name", cfg["storage_account"], "--container-name", campaign["container"],
            "--name", blob, "--file", str(sample.resolve()), "--auth-mode", "login", "--type", "block",
            "--overwrite", "false", "--if-none-match", "*", "--content-type", "text/plain",
            "--content-cache-control", "no-store", "--metadata", "ticket=DBI-12139", "synthetic=true",
        ])
    except TaskError as exc:
        receipt["status"] = "upload_failed_or_unconfirmed"
        receipt["error"] = str(exc)
        save_json(receipt_path, receipt)
        raise
    receipt["status"] = "uploaded"
    receipt["upload_etag"] = result.get("etag") if isinstance(result, dict) else None
    save_json(receipt_path, receipt)
    print(f"Testdatei: {public_url}\nBeleg für weitere Tests und Bereinigung: {receipt_path.resolve()}")
    print("Den gesamten Belegordner einschließlich testdatei.txt für den externen Test mitnehmen.")
    return 0


def read_receipt(path: Path) -> tuple[dict[str, Any], bytes]:
    receipt = json.loads(path.read_text(encoding="utf-8"))
    if receipt.get("ticket") != "DBI-12139" or receipt.get("environment") not in load_config()["environments"]:
        raise TaskError("Ungültiger Testbeleg.")
    if receipt.get("campaign") not in load_config()["campaigns"]:
        raise TaskError("Unbekannte Landingpage im Testbeleg.")
    safe_blob_name(receipt.get("blob", ""))
    if receipt.get("sample_file") != "testdatei.txt":
        raise TaskError("Unerwarteter Dateiverweis im Testbeleg.")
    sample = path.resolve().parent / "testdatei.txt"
    if sample.is_symlink() or sample.stat().st_size != SAMPLE_SIZE:
        raise TaskError("Testdatei muss die unveränderte 8-KiB-Datei aus dem Belegordner sein.")
    data = sample.read_bytes()
    if hashlib.sha256(data).hexdigest() != receipt.get("sample_sha256"):
        raise TaskError("Prüfsumme der Testdatei stimmt nicht. Abbruch.")
    cfg = env_config(receipt["environment"])
    campaign = load_config()["campaigns"][receipt["campaign"]]
    if receipt.get("storage_account") != cfg["storage_account"] or receipt.get("container") != campaign["container"]:
        raise TaskError("Ziel im Testbeleg weicht von umgebungen.json ab. Keine automatische Umleitung.")
    return receipt, data


class NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, req: Any, fp: Any, code: int, msg: str, headers: Any, newurl: str) -> None:
        return None


def http_get(url: str, byte_range: str | None = None, origin: str | None = None) -> tuple[dict[str, Any], bytes]:
    parsed = urlparse(url)
    if parsed.scheme != "https" or not parsed.hostname or parsed.username or parsed.password or parsed.query or parsed.fragment:
        raise TaskError("Es sind nur HTTPS-Asset-URLs ohne Zugangsdaten, Querystring oder Fragment erlaubt.")
    headers = {"User-Agent": "DBI-12139-asset-check/1.0", "Accept-Encoding": "identity"}
    if byte_range:
        headers["Range"] = byte_range
    if origin:
        headers["Origin"] = origin
    request = Request(url, headers=headers, method="GET")
    opener = build_opener(NoRedirect())
    start = time.monotonic()
    try:
        try:
            response = opener.open(request, timeout=30)
        except HTTPError as exc:
            response = exc
        with response:
            data = response.read(READ_LIMIT + 1)
            report = {"url": url, "http_status": response.code, "method": "GET", "range": byte_range,
                      "duration_seconds": round(time.monotonic() - start, 3), "body_truncated": len(data) > READ_LIMIT,
                      "headers": {k.lower(): v for k, v in response.headers.items() if k.lower() in {
                          "content-type", "content-length", "content-range", "etag", "cache-control", "location",
                          "access-control-allow-origin", "accept-ranges", "x-ms-error-code"}}}
            return report, data[:READ_LIMIT]
    except (URLError, HTTPException, TimeoutError, socket.timeout, OSError) as exc:
        return {"url": url, "http_status": None, "method": "GET", "range": byte_range,
                "duration_seconds": round(time.monotonic() - start, 3), "error": str(exc)}, b""


def probe(args: argparse.Namespace) -> int:
    receipt, expected = read_receipt(args.receipt)
    public_url, internal_url = urls(receipt["environment"], receipt["campaign"], receipt["blob"])
    url = internal_url if args.endpoint == "blob-intern" else public_url
    if args.origin:
        parsed = urlparse(args.origin)
        if parsed.scheme != "https" or not parsed.netloc or parsed.username or parsed.password or parsed.path not in ("", "/") or parsed.query or parsed.fragment:
            raise TaskError("Origin muss eine HTTPS-Landingpage-Domain ohne Pfad sein.")
    full, body = http_get(url, origin=args.origin)
    full["content_matches_test_file"] = body == expected
    full["passed"] = full.get("http_status") == 200 and body == expected and not full.get("body_truncated", False)
    partial, partial_body = http_get(url, byte_range="bytes=0-1023", origin=args.origin)
    partial["content_matches_expected_range"] = partial_body == expected[:1024]
    partial["passed"] = (partial.get("http_status") == 206 and partial_body == expected[:1024]
                         and partial.get("headers", {}).get("content-range") == f"bytes 0-1023/{len(expected)}")
    cors_ok = None
    if args.origin:
        cors_ok = all(v.get("headers", {}).get("access-control-allow-origin") in (args.origin, "*") for v in (full, partial))
    passed = full["passed"] and partial["passed"] and cors_ok is not False
    report = {"ticket": "DBI-12139", "checked_at_utc": now(), "environment": receipt["environment"],
              "campaign": receipt["campaign"], "network_declared_by_operator": args.network,
              "endpoint": args.endpoint, "authentication": "Keine Authorization-Header, SAS-Tokens oder Cookies",
              "redirects": "werden nicht verfolgt", "get": full, "range_get": partial,
              "origin": args.origin, "cors_check_passed": cors_ok, "passed": passed,
              "limitations": "Nur diese Testdatei von diesem Teststandort. Kein Beleg für alle Medien, andere Netze oder funktionierende Browser-Templates."}
    output = args.output or args.receipt.with_name(f"probe-{args.endpoint}-{args.network}.json")
    save_json(output, report)
    print(f"{'ERFOLGREICH' if passed else 'NICHT ERFOLGREICH'}: {url}\nBericht: {output.resolve()}")
    return 0 if passed else 2


def cleanup(args: argparse.Namespace) -> int:
    receipt, _ = read_receipt(args.receipt)
    cfg = env_config(receipt["environment"])
    print(f"Entfernt nur die Testdatei {receipt['container']}/{receipt['blob']} in {receipt['environment']}.")
    common = ["--subscription", cfg["subscription_id"], "--account-name", cfg["storage_account"],
              "--container-name", receipt["container"], "--name", receipt["blob"], "--auth-mode", "login"]
    blob = az_json(["storage", "blob", "show", *common])
    metadata = blob.get("metadata", {})
    if metadata.get("ticket") != "DBI-12139" or metadata.get("synthetic") != "true":
        raise TaskError("Testmarkierungen am Blob fehlen. Keine Löschung.")
    etag = blob.get("properties", {}).get("etag")
    if not etag:
        raise TaskError("ETag fehlt. Keine Löschung ohne Schutz vor gleichzeitiger Änderung.")
    uploaded_etag = receipt.get("upload_etag")
    if uploaded_etag and uploaded_etag != etag:
        raise TaskError("Blob wurde seit dem Upload geändert. Nicht automatisch löschen.")
    confirm("DELETE", receipt["environment"])
    az_json(["storage", "blob", "delete", *common, "--if-match", etag])
    receipt["status"] = "current_test_blob_deleted"
    receipt["deleted_at_utc"] = now()
    save_json(args.receipt, receipt)
    print("Aktuelle Testdatei gelöscht. Versionierung/Soft Delete können ältere Daten entsprechend der Aufbewahrung erhalten.")
    return 0


def parser() -> argparse.ArgumentParser:
    config = load_config()
    root = argparse.ArgumentParser(description=__doc__)
    commands = root.add_subparsers(dest="command", required=True)
    inv = commands.add_parser("inventory", help="Nur Azure-Metadaten lesen, keine Änderung")
    inv.add_argument("--env", choices=[*config["environments"], "all"], default="all")
    inv.add_argument("--output", type=Path, default=Path("ergebnisse/inventar.json"))
    inv.set_defaults(func=inventory)
    upload = commands.add_parser("upload-test", help="Eine synthetische Testdatei mit expliziter Bestätigung hochladen")
    upload.add_argument("--env", choices=config["environments"], required=True)
    upload.add_argument("--campaign", choices=config["campaigns"], default="uniglobal")
    upload.add_argument("--output-dir", type=Path, default=Path("ergebnisse"))
    upload.set_defaults(func=upload_test)
    check = commands.add_parser("probe", help="Testdatei mit anonymen GET- und Range-Anfragen abrufen")
    check.add_argument("--receipt", type=Path, required=True)
    check.add_argument("--network", choices=["intern", "extern", "unbekannt"], required=True)
    check.add_argument("--endpoint", choices=["asset-domain", "blob-intern"], default="asset-domain")
    check.add_argument("--origin", help="Optionale HTTPS-Landingpage-Origin für einen CORS-Lesetest")
    check.add_argument("--output", type=Path)
    check.set_defaults(func=probe)
    clean = commands.add_parser("cleanup", help="Nur die markierte Testdatei nach Bestätigung entfernen")
    clean.add_argument("--receipt", type=Path, required=True)
    clean.set_defaults(func=cleanup)
    return root


def main() -> int:
    try:
        args = parser().parse_args()
        return args.func(args)
    except (TaskError, OSError, ValueError, KeyError) as exc:
        print(f"ABBRUCH: {exc}", file=sys.stderr)
        return 2
    except KeyboardInterrupt:
        print("\nAbgebrochen. Bereits ausgeführte Uploads nicht als automatisch zurückgenommen betrachten.", file=sys.stderr)
        return 130


if __name__ == "__main__":
    sys.exit(main())
