# Quellen aus dem Upload

Diese Auszüge stammen ausschließlich aus dem gelieferten Repository-Snapshot und den sichtbaren Ticketfotos. Zeilennummern beziehen sich auf den Upload. Azure wurde nicht abgefragt.

## Q1: Ticket

**Quelle:** Fotos `1000132040.jpg` und `1000132041.jpg`, von dir in dieser Unterhaltung bereitgestellt. Keine OCR eingesetzt. Im Paket liegen die Fotos nicht erneut bei.

- Schlüssel: DBI-12139.
- Titel: „Blobstorages für digitale Assets der Landingpages anlegen“.
- Priorität: Prio 1.
- Technischer Hinweis: LP-Asset-BlobStorage in dev, test und prod anlegen.
- Akzeptanz: Storage angelegt, Assets darin public lesbar.
- Inhalt: auch sehr große digitale Medien verfügbar machen.
- Feature Toggle: keines.
- Im sichtbaren Kommentarbereich sind noch keine Kommentare vorhanden.

Die sichtbaren Template-Fragen unter „Offene Punkte“, „Vorbedingungen“ und „Fehlerhandling“ sind keine ausgefüllten fachlichen Vorgaben. Aus ihnen wurden keine zusätzlichen Anforderungen erfunden.

## Q2: Vorhandene Speicherdefinitionen

### DEV storage-assets

Original: `live/live/dev/terragrunt.stack.hcl`, Zeilen 346 bis 395.

```text
 346: unit "storage-assets" {
 347:   source = "git::${local.tg_catalog_uri}//units/blob-storage-private?ref=${local.tg_catalog_version}"
 348:   path   = "storage-assets"
 349: 
 350:   values = {
 351:     anonymous_access_enabled           = true
 352:     component_name                     = "lpassets"
 353:     data_scanner_enabled               = true
 354:     location                           = local.location
 355:     environment                        = local.environment
 356:     prefix                             = local.prefix
 357:     private_endpoints_network_settings = local.private_endpoints_network_settings
 358:     resource_group_name                = local.rg_core_name
 359:     tags                               = local.tags
 360: 
 361:     blob_properties = {
 362:       versioning_enabled = true
 363:     }
 364:     containers = {
 365:       assets = {
 366:         name = "assets"
 367:       }
 368:       statuspages = {
 369:         anonymous_access_enabled = true
 370:         name                     = "statuspages"
 371:       }
 372:       lp-uniglobal-r1 = {
 373:         anonymous_access_enabled = true
 374:         name                     = "uniglobal-release-1"
 375:         identity_role            = "Storage Blob Data Reader"
 376:         principal_id             = local.entra_groups.admins.oid # i.e. App.UMP.DEV.Azure.Administrator
 377:       }
 378:       lp-ve-r1 = {
 379:         anonymous_access_enabled = true
 380:         name                     = "ve-release-1"
 381:         identity_role            = "Storage Blob Data Reader"
 382:         principal_id             = local.entra_groups.admins.oid # i.e. App.UMP.DEV.Azure.Administrator
 383:       }
 384:       lp-zukunft-r1 = {
 385:         anonymous_access_enabled = true
 386:         name                     = "zukunft-release-1"
 387:         identity_role            = "Storage Blob Data Reader"
 388:         principal_id             = local.entra_groups.admins.oid # i.e. App.UMP.DEV.Azure.Administrator
 389:       }
 390:     }
 391: 
 392:     # Dependency paths
 393:     dependencies_paths = ["../resourcegroup-core"]
 394:   }
 395: }
```

### TEST storage-assets

Original: `live/live/test/terragrunt.stack.hcl`, Zeilen 628 bis 677.

```text
 628: unit "storage-assets" {
 629:   source = "git::${local.tg_catalog_uri}//units/blob-storage-private?ref=${local.tg_catalog_version}"
 630:   path   = "storage-assets"
 631: 
 632:   values = {
 633:     anonymous_access_enabled           = true
 634:     component_name                     = "lpassets"
 635:     data_scanner_enabled               = true
 636:     location                           = local.location
 637:     environment                        = local.environment
 638:     prefix                             = local.prefix
 639:     private_endpoints_network_settings = local.private_endpoints_network_settings
 640:     resource_group_name                = local.rg_core_name
 641:     tags                               = local.tags
 642: 
 643:     blob_properties = {
 644:       versioning_enabled = true
 645:     }
 646:     containers = {
 647:       assets = {
 648:         name = "assets"
 649:       }
 650:       statuspages = {
 651:         anonymous_access_enabled = true
 652:         name                     = "statuspages"
 653:       }
 654:       lp-uniglobal-r1 = {
 655:         anonymous_access_enabled = true
 656:         name                     = "uniglobal-release-1"
 657:         identity_role            = "Storage Blob Data Reader"
 658:         principal_id             = local.entra_groups.admins.oid # i.e. App.UMP.ABN.Azure.Administrator
 659:       }
 660:       lp-ve-r1 = {
 661:         anonymous_access_enabled = true
 662:         name                     = "ve-release-1"
 663:         identity_role            = "Storage Blob Data Reader"
 664:         principal_id             = local.entra_groups.admins.oid # i.e. App.UMP.ABN.Azure.Administrator
 665:       }
 666:       lp-zukunft-r1 = {
 667:         anonymous_access_enabled = true
 668:         name                     = "zukunft-release-1"
 669:         identity_role            = "Storage Blob Data Reader"
 670:         principal_id             = local.entra_groups.admins.oid # i.e. App.UMP.ABN.Azure.Administrator
 671:       }
 672:     }
 673: 
 674:     # Dependency paths
 675:     dependencies_paths = ["../resourcegroup-core"]
 676:   }
 677: }
```

### PROD storage-assets

Original: `live/live/prod/terragrunt.stack.hcl`, Zeilen 523 bis 572.

```text
 523: unit "storage-assets" {
 524:   source = "git::${local.tg_catalog_uri}//units/blob-storage-private?ref=${local.tg_catalog_version}"
 525:   path   = "storage-assets"
 526: 
 527:   values = {
 528:     anonymous_access_enabled           = true
 529:     component_name                     = "lpassets"
 530:     data_scanner_enabled               = true
 531:     location                           = local.location
 532:     environment                        = local.environment
 533:     prefix                             = local.prefix
 534:     private_endpoints_network_settings = local.private_endpoints_network_settings
 535:     resource_group_name                = local.rg_core_name
 536:     tags                               = local.tags
 537: 
 538:     blob_properties = {
 539:       versioning_enabled = true
 540:     }
 541:     containers = {
 542:       assets = {
 543:         name = "assets"
 544:       }
 545:       statuspages = {
 546:         anonymous_access_enabled = true
 547:         name                     = "statuspages"
 548:       }
 549:       lp-uniglobal-r1 = {
 550:         anonymous_access_enabled = true
 551:         name                     = "uniglobal-release-1"
 552:         identity_role            = "Storage Blob Data Reader"
 553:         principal_id             = local.entra_groups.admins.oid # i.e. App.UMP.PROD.Azure.Administrator
 554:       }
 555:       lp-ve-r1 = {
 556:         anonymous_access_enabled = true
 557:         name                     = "ve-release-1"
 558:         identity_role            = "Storage Blob Data Reader"
 559:         principal_id             = local.entra_groups.admins.oid # i.e. App.UMP.PROD.Azure.Administrator
 560:       }
 561:       lp-zukunft-r1 = {
 562:         anonymous_access_enabled = true
 563:         name                     = "zukunft-release-1"
 564:         identity_role            = "Storage Blob Data Reader"
 565:         principal_id             = local.entra_groups.admins.oid # i.e. App.UMP.PROD.Azure.Administrator
 566:       }
 567:     }
 568: 
 569:     # Dependency paths
 570:     dependencies_paths = ["../resourcegroup-core"]
 571:   }
 572: }
```

## Q3: Privater Netzwerkzugang

### catalog/modules/blob-storage/main.tf

Original: `catalog/modules/blob-storage/main.tf`, Zeilen 10 bis 48.

```text
  10: resource "azurerm_storage_account" "main" {
  11:   name                = coalesce(var.name, module.naming.storage_account.name_unique)
  12:   resource_group_name = (local.create_resource_group) ? one(azurerm_resource_group.main).name : var.resource_group_name
  13:   location            = var.location
  14: 
  15:   access_tier                       = var.access_tier
  16:   account_kind                      = "StorageV2"
  17:   account_tier                      = "Standard"
  18:   account_replication_type          = var.account_replication_type
  19:   allow_nested_items_to_be_public   = var.anonymous_access_enabled
  20:   allowed_copy_scope                = "PrivateLink"
  21:   cross_tenant_replication_enabled  = false
  22:   default_to_oauth_authentication   = true
  23:   https_traffic_only_enabled        = true
  24:   infrastructure_encryption_enabled = false
  25:   is_hns_enabled                    = var.hierarchical_namespace_enabled
  26:   large_file_share_enabled          = false
  27:   local_user_enabled                = false
  28:   min_tls_version                   = "TLS1_2"
  29:   nfsv3_enabled                     = false
  30:   public_network_access_enabled     = false
  31:   sftp_enabled                      = false
  32:   shared_access_key_enabled         = var.shared_access_key_enabled
  33:   tags                              = local.tags
  34: 
  35:   dynamic "blob_properties" {
  36:     for_each = var.blob_properties == null ? [] : [var.blob_properties]
  37: 
  38:     content {
  39:       change_feed_enabled           = blob_properties.value.change_feed_enabled
  40:       change_feed_retention_in_days = blob_properties.value.change_feed_retention_in_days
  41:       default_service_version       = blob_properties.value.default_service_version
  42:       last_access_time_enabled      = blob_properties.value.last_access_time_enabled
  43:       versioning_enabled            = blob_properties.value.versioning_enabled
  44: 
  45:       dynamic "container_delete_retention_policy" {
  46:         for_each = blob_properties.value.container_delete_retention_policy == null ? [] : [
  47:           blob_properties.value.container_delete_retention_policy
  48:         ]
```

### catalog/modules/blob-storage/main.tf

Original: `catalog/modules/blob-storage/main.tf`, Zeilen 110 bis 127.

```text
 110: resource "azurerm_private_endpoint" "main" {
 111:   name                = "pe-${azurerm_storage_account.main.name}-blob"
 112:   resource_group_name = azurerm_storage_account.main.resource_group_name
 113:   location            = azurerm_storage_account.main.location
 114:   subnet_id           = data.azurerm_subnet.default.id
 115: 
 116:   private_service_connection {
 117:     is_manual_connection           = false
 118:     name                           = "psc-${azurerm_storage_account.main.name}-blob"
 119:     private_connection_resource_id = azurerm_storage_account.main.id
 120:     subresource_names              = ["blob"]
 121:   }
 122:   tags = local.tags
 123: }
 124: 
 125: # put a lock on the account if required
 126: resource "azurerm_management_lock" "storage_account" {
 127:   count = var.lock != null ? 1 : 0
```

## Q4: Containerrechte und Katalogeinbindung

### catalog/modules/blob-storage/main.blobs.tf

Original: `catalog/modules/blob-storage/main.blobs.tf`, Zeilen 1 bis 16.

```text
   1: # Create containers using azapi in order to avoid problems with private endpoint and data plane permissions
   2: resource "azapi_resource" "containers" {
   3:   for_each = var.containers
   4: 
   5:   name      = each.value.name
   6:   parent_id = "${azurerm_storage_account.main.id}/blobServices/default"
   7:   type      = "Microsoft.Storage/storageAccounts/blobServices/containers@2025-01-01"
   8:   body = {
   9:     properties = {
  10:       metadata                       = each.value.metadata == null ? {} : each.value.metadata
  11:       publicAccess                   = each.value.anonymous_access_enabled ? "Blob" : "None"
  12:       immutableStorageWithVersioning = each.value.immutable_storage_with_versioning
  13:     }
  14:   }
  15: }
  16: 
```

### catalog/modules/blob-storage/variables.blobs.tf

Original: `catalog/modules/blob-storage/variables.blobs.tf`, Zeilen 80 bis 91.

```text
  80: variable "containers" {
  81:   type = map(object({
  82:     name                     = string
  83:     anonymous_access_enabled = optional(bool, false)
  84:     metadata                 = optional(map(string))
  85:     immutable_storage_with_versioning = optional(object({
  86:       enabled = bool
  87:     }))
  88:   }))
  89:   default     = {}
  90:   description = <<-DESCRIPTION
  91:   A map of containers to create within the storage account.
```

### catalog/units/blob-storage-private/terragrunt.hcl

Original: `catalog/units/blob-storage-private/terragrunt.hcl`, Zeilen 33 bis 65.

```text
  33: inputs = {
  34:   ## REQUIRED Inputs
  35:   component_name                     = values.component_name
  36:   location                           = values.location
  37:   prefix                             = values.prefix
  38:   private_endpoints_network_settings = values.private_endpoints_network_settings
  39:   workload_environment               = values.environment
  40: 
  41:   ## OPTIONAL Inputs (use the module defaults, if no value exists)
  42:   anonymous_access_enabled       = try(values.anonymous_access_enabled, false)
  43:   blob_properties                = try(values.blob_properties, {})
  44:   blob_uploads                   = try(values.blobs, {})
  45:   containers                     = try(values.containers, {})
  46:   data_scanner_enabled           = try(values.data_scanner_enabled, false)
  47:   hierarchical_namespace_enabled = try(values.hierarchical_namespace_enabled, null)
  48:   name                           = try(values.name, null)
  49:   resource_group_name            = try(values.resource_group_name, null)
  50:   shared_access_key_enabled      = try(values.shared_access_key_enabled, false)
  51:   storage_management_policy_rule = try(values.storage_management_policy, {})
  52: 
  53: 
  54:   role_assignments = { for k, v in try(values.containers, {}) : k => {
  55:     principal_id         = try(v.principal_id, dependency.identity.outputs.principal_id)
  56:     role_definition_name = v.identity_role
  57:     container_scope      = k
  58:     } if try(v.identity_role, null) != null
  59:   }
  60: 
  61:   ## DEFAULT Settings
  62:   access_tier              = "Hot"
  63:   account_replication_type = (lower(values.environment) == "dev") ? "LRS" : "ZRS"
  64:   tags                     = local.tags
  65: }
```

## Q5: Gateway, Pfade und WAF

### DEV Listener

Original: `live/live/dev/appgateway.hcl`, Zeilen 28 bis 34.

```text
  28:     landingassets_private_listener = {
  29:       certificate_secret = "landing-internal-certificate"
  30:       firewall_policy    = "landingassets"
  31:       host_names         = ["landing-assets.dev.apps.union-investment.de"]
  32:       name               = "landingassets-private"
  33:       type               = "private"
  34:     }
```

### DEV Storage-Ziel

Original: `live/live/dev/appgateway.hcl`, Zeilen 253 bis 256.

```text
 253:     landingassets_pool = {
 254:       name  = "landingassets-backends"
 255:       fqdns = ["stumpdevlpassetsyws91x59.blob.core.windows.net"]
 256:     }
```

### TEST Listener

Original: `live/live/test/appgateway.hcl`, Zeilen 34 bis 40.

```text
  34:     landingassets_private_listener = {
  35:       certificate_secret = "landing-internal-certificate"
  36:       firewall_policy    = "landingassets"
  37:       host_names         = ["landing-assets.test.apps.union-investment.de"]
  38:       name               = "landingassets-private"
  39:       type               = "private"
  40:     }
```

### TEST Storage-Ziel

Original: `live/live/test/appgateway.hcl`, Zeilen 279 bis 282.

```text
 279:     landingassets_pool = {
 280:       name  = "landingassets-backends"
 281:       fqdns = ["stumptestlpassetsjjh3lzn.blob.core.windows.net"]
 282:     }
```

### PROD Listener

Original: `live/live/prod/appgateway.hcl`, Zeilen 35 bis 41.

```text
  35:     landingassets_private_listener = {
  36:       certificate_secret = "landing-internal-certificate"
  37:       firewall_policy    = "landingassets"
  38:       host_names         = ["landing-assets.apps.union-investment.de"]
  39:       name               = "landingassets-private-tmo"
  40:       type               = "private"
  41:     }
```

### PROD Storage-Ziel

Original: `live/live/prod/appgateway.hcl`, Zeilen 286 bis 289.

```text
 286:     landingassets_pool = {
 287:       name  = "landingassets-backends"
 288:       fqdns = ["stumpprodlpassetsxvhfz3h.blob.core.windows.net"]
 289:     }
```

### DEV Backend-Pfade und Timeouts

Original: `live/live/dev/appgateway.hcl`, Zeilen 159 bis 189.

```text
 159:     landingassets_default_settings = {
 160:       ## default-settings do reroute any non-matching request to a page and include the original path as query-string.
 161:       ## This will be blocked by the firewall-policy (because query string) and result in 403, thus never reaching the
 162:       ## storage account and avoiding blob-transactions.
 163:       name                                = "lpa-default-settings"
 164:       pick_host_name_from_backend_address = true
 165:       path                                = "/statuspages/404.html?"
 166:       probe_name                          = local.probe_configurations.storage_account_probe.name
 167:       request_timeout                     = 1
 168:     }
 169:     landingassets_uniglobal_settings = {
 170:       name                                = "lpa-uniglobal-settings"
 171:       pick_host_name_from_backend_address = true
 172:       path                                = "/uniglobal-release-1/"
 173:       probe_name                          = local.probe_configurations.storage_account_probe.name
 174:       request_timeout                     = 1
 175:     }
 176:     landingassets_ve_settings = {
 177:       name                                = "lpa-ve-settings"
 178:       pick_host_name_from_backend_address = true
 179:       path                                = "/ve-release-1/"
 180:       probe_name                          = local.probe_configurations.storage_account_probe.name
 181:       request_timeout                     = 1
 182:     }
 183:     landingassets_zukunft_settings = {
 184:       name                                = "lpa-zukunft-settings"
 185:       pick_host_name_from_backend_address = true
 186:       path                                = "/zukunft-release-1/"
 187:       probe_name                          = local.probe_configurations.storage_account_probe.name
 188:       request_timeout                     = 1
 189:     }
```

### DEV öffentliche Pfadnamen

Original: `live/live/dev/appgateway.hcl`, Zeilen 273 bis 302.

```text
 273:     landing_assets_path_based = {
 274:       cors_rewrite_enabled               = true
 275:       default_backend_address_pool_name  = local.backend_address_pools.landingassets_pool.name
 276:       default_backend_http_settings_name = local.backend_http_settings.landingassets_default_settings.name
 277:       name                               = "lpa-default-route"
 278: 
 279:       path_rules = {
 280:         lpa_uniglobal = {
 281:           backend_address_pool_name  = local.backend_address_pools.landingassets_pool.name
 282:           backend_http_settings_name = local.backend_http_settings.landingassets_uniglobal_settings.name
 283:           name                       = "lpa-uniglobal-route"
 284:           paths                      = ["/uniglobal/*"]
 285:         }
 286:         lpa_ve = {
 287:           backend_address_pool_name  = local.backend_address_pools.landingassets_pool.name
 288:           backend_http_settings_name = local.backend_http_settings.landingassets_ve_settings.name
 289:           name                       = "lpa-ve-route"
 290:           paths                      = ["/VE-Impuls-Junge-Neukunden/*"]
 291:         }
 292:         lpa_zukunft = {
 293:           backend_address_pool_name  = local.backend_address_pools.landingassets_pool.name
 294:           backend_http_settings_name = local.backend_http_settings.landingassets_zukunft_settings.name
 295:           name                       = "lpa-zukunft-route"
 296:           paths                      = ["/zukunft-2026/*"]
 297:         }
 298:       }
 299:     }
 300:   }
 301: 
 302:   request_routing_rules = {
```

### DEV WAF-Regeln; gleicher GET-/Querystring-Grundsatz in TEST und PROD

Original: `live/live/dev/appgateway-policies.hcl`, Zeilen 353 bis 392.

```text
 353:     landingassets = {
 354:       enabled       = true
 355:       firewall_mode = "Prevention"
 356:       custom_rules = {
 357:         method_get_only = {
 358:           action    = "Block"
 359:           enabled   = true
 360:           name      = "BlockOtherThanHttpGet"
 361:           priority  = "10"
 362:           rule_type = "MatchRule"
 363:           match_conditions = [
 364:             {
 365:               match_variables = [{
 366:                 variable_name = "RequestMethod"
 367:               }]
 368:               operator           = "Equal"
 369:               negation_condition = true
 370:               match_values       = ["GET"]
 371:             }
 372:           ]
 373:         }
 374:         query_disallowed = {
 375:           action    = "Block"
 376:           enabled   = true
 377:           name      = "BlockIfContainsQueryString"
 378:           priority  = "20"
 379:           rule_type = "MatchRule"
 380:           match_conditions = [
 381:             {
 382:               match_variables = [{
 383:                 variable_name = "QueryString"
 384:               }]
 385:               operator           = "Regex"
 386:               negation_condition = true
 387:               match_values       = ["^$"]
 388:             }
 389:           ]
 390:         }
 391:       }
 392:     }
```

### catalog/modules/application-gateway/main.tf

Original: `catalog/modules/application-gateway/main.tf`, Zeilen 68 bis 77.

```text
  68:     rewrite_rule {
  69:       name          = "CORS-Rewrite"
  70:       rule_sequence = 110
  71:       response_header_configuration {
  72:         header_name  = "Access-Control-Allow-Origin"
  73:         header_value = "{http_req_Origin}"
  74:       }
  75:     }
  76:   }
  77: 
```

## Q6: Git-Historie

Die folgenden Meldungen wurden mit `git show` aus dem enthaltenen Git-Repository gelesen. Sie sind keine Aussagen über den Deploymentstand.

```text
15f0135 2026-09-10 16:26:25 +0000
feat: use release-specific containers

Use a release-specific container with each landingpage


 live/dev/appgateway.hcl       |  8 ++++----
 live/dev/terragrunt.stack.hcl | 22 ++++++++++++++++++++++
 2 files changed, 26 insertions(+), 4 deletions(-)
```

```text
e84d685 2026-09-11 08:17:07 +0000
fix: dev - disable access to obsolete container

Old container 'assets' on the lp asset storage is not accessible anymore
without authentication


 live/dev/terragrunt.stack.hcl | 7 +++----
 1 file changed, 3 insertions(+), 4 deletions(-)
```

```text
46ec1e1 2026-09-11 09:58:19 +0000
fix: remove access on obsolete 'assets' container

Disable anonymous access and remove rbac on container 'assets' in both
dev and test environment


 live/dev/terragrunt.stack.hcl  | 4 +---
 live/test/terragrunt.stack.hcl | 5 +----
 2 files changed, 2 insertions(+), 7 deletions(-)
```

## Q7: Anwendung und DEV-Domainabweichung

### ui-landingpagetool/config/app.php

Original: `ui-landingpagetool/config/app.php`, Zeilen 72 bis 89.

```text
  72: 
  73:     'url' => env('APP_URL', 'http://localhost'),
  74: 
  75:     'asset_url' => env('ASSET_URL', null),
  76: 
  77:     /*
  78:     |--------------------------------------------------------------------------
  79:     | Foreign URL
  80:     |--------------------------------------------------------------------------
  81:     |
  82:     | This URL is the System you want to contact and tell them to start the double opt-in process
  83:     |
  84:     */
  85: 
  86:     'double_opt_in_url' => env('DOUBLE_OPT_IN_URL'),
  87:     'single_object_doi_url' => env('SINGLE_OBJECT_DOI_URL'),
  88:     'assets_base_url' => env('ASSETS_BASE_URL'),
  89: 
```

### ui-landingpagetool/app/Listeners/LandingPageDataListener.php

Original: `ui-landingpagetool/app/Listeners/LandingPageDataListener.php`, Zeilen 22 bis 27.

```text
  22:         $context = [
  23:             'order_id' =>  $order->id,
  24:             'order_blz' => $order->blz,
  25:             'assetsBaseUrl' => config('app.assets_base_url'),
  26:         ];
  27: 
```

Original: `ansible-ump/inventories/dev.yml`.

```text
75:       host_landingpages_assets_fqdn: "landing-assets.unionmarketingplattform.dev.azure.union-investment.de"
```

Original: `ansible-ump/inventories/test.yml`.

```text
75:       host_landingpages_assets_fqdn: "landing-assets.test.apps.union-investment.de"
```

Original: `ansible-ump/inventories/prod.yml`.

```text
75:       host_landingpages_assets_fqdn: "landing-assets.apps.union-investment.de"
```

## Q8: Werkzeugstände und Bereitstellung

### live/.terraform-version

Original: `live/.terraform-version`, Zeilen 1 bis 1.

```text
   1: 1.13.4
```

### live/.terragrunt-version

Original: `live/.terragrunt-version`, Zeilen 1 bis 1.

```text
   1: 1.1.6
```

### live/live/root.hcl

Original: `live/live/root.hcl`, Zeilen 20 bis 47.

```text
  20:   path      = "provider.tf"
  21:   if_exists = "overwrite_terragrunt"
  22:   contents  = <<EOF
  23: terraform {
  24:   required_version = "~> 1.13"
  25:   required_providers {
  26:     azapi = {
  27:       source  = "azure/azapi"
  28:       version = "~> 2.7"
  29:     }
  30:     azurerm = {
  31:       source = "hashicorp/azurerm"
  32:       version = "~>4.63"
  33:     }
  34:   }
  35: }
  36: 
  37: provider "azurerm" {
  38:   storage_use_azuread = true
  39:   subscription_id = "${local.subscription_vars.subscription_id}"
  40:   features {
  41:     resource_group {
  42:       prevent_deletion_if_contains_resources = false
  43:     }
  44:   }
  45: }
  46: EOF
  47: }
```

### live/.gitlab-ci.yml

Original: `live/.gitlab-ci.yml`, Zeilen 23 bis 30.

```text
  23: .stackGenerate:
  24:   before_script:
  25:     - !reference [default, before_script]
  26:     - cd live
  27:     - TG_PROVIDER_CACHE=0 terragrunt stack generate --filter "$FOLDER | type=stack" --filter "$FOLDER/** | type=stack"
  28:     - export TG_FEATURE="appgateway=true"
  29: 
  30: .checkTemplate:
```

### live/.gitlab-ci.yml

Original: `live/.gitlab-ci.yml`, Zeilen 111 bis 136.

```text
 111: .applyTemplate:
 112:   extends: .stackGenerate
 113:   stage: apply
 114:   rules:
 115:     - if: '$CI_COMMIT_BRANCH == "main"'
 116:       changes:
 117:         - live/$FOLDER/**/*
 118:       when: manual
 119:     - if: '$ENVIRONMENT == "development" && $CI_PIPELINE_SOURCE == "merge_request_event" && $CI_MERGE_REQUEST_SOURCE_BRANCH_NAME =~ /^feat.*$/'
 120:       changes:
 121:         - live/dev/**/*
 122:       when: manual
 123:     - when: never
 124:   environment:
 125:     name: $ENVIRONMENT
 126:   variables:
 127:     outDir: "${CI_PROJECT_DIR}/tfplan/$FOLDER"
 128:     usePlan: true
 129:   script:
 130:     - echo "Starting apply job for $FOLDER"
 131:     - '[[ "${usePlan,,}" == "true" ]] && export TG_OUT_DIR=$outDir && echo "Using tfplan from $outDir" || echo "Applying without plan"'
 132:     - terragrunt stack run --no-stack-generate --non-interactive --provider-cache-registry-names registry.terraform.io -- apply
 133:   manual_confirmation: "Please check the tfplan and confirm its deployment. Set usePlan=false to apply without using stored plan (in case of included mock values)."
 134: 
 135: applyDevEnvironment:
 136:   extends: .applyTemplate
```

