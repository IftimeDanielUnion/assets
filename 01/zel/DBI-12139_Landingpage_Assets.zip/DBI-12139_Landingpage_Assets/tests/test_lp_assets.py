"""Lokale Tests ohne Azure-Konto und ohne Netzwerkzugriffe."""
from __future__ import annotations
import argparse
import hashlib
import importlib.util
import io
import json
import os
import subprocess
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

MODULE = Path(__file__).resolve().parents[1] / "code" / "lp_assets.py"
spec = importlib.util.spec_from_file_location("lp_assets", MODULE)
lp = importlib.util.module_from_spec(spec)
spec.loader.exec_module(lp)

BLOB = "dbi-12139-check-20261001T100000Z-123456abcdef.txt"


def receipt_at(folder: Path) -> tuple[Path, bytes]:
    data = (b"Synthetic DBI-12139 check\n" * 400)[:lp.SAMPLE_SIZE]
    (folder / "testdatei.txt").write_bytes(data)
    cfg = lp.env_config("dev")
    receipt = {"ticket": "DBI-12139", "environment": "dev", "campaign": "uniglobal",
        "blob": BLOB, "storage_account": cfg["storage_account"], "container": "uniglobal-release-1",
        "sample_file": "testdatei.txt", "sample_sha256": hashlib.sha256(data).hexdigest(),
        "upload_etag": '"etag-one"'}
    path = folder / "upload.json"
    lp.save_json(path, receipt)
    return path, data


def containers():
    names = {"assets": "None", "statuspages": "Blob", "uniglobal-release-1": "Blob", "ve-release-1": "Blob", "zukunft-release-1": "Blob"}
    return [{"name": k, "properties": {"publicAccess": v}} for k, v in names.items()]


class Checks(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.folder = Path(self.tmp.name)
        self.output = io.StringIO()
        self.stdout = patch("sys.stdout", self.output)
        self.stdout.start()

    def tearDown(self):
        self.stdout.stop()
        self.tmp.cleanup()

    def test_config_has_only_ticket_environments(self):
        self.assertEqual(set(lp.load_config()["environments"]), {"dev", "test", "prod"})
        self.assertEqual(len(lp.load_config()["campaigns"]), 3)

    def test_exact_existing_route(self):
        public, internal = lp.urls("test", "ve", BLOB)
        self.assertIn("/VE-Impuls-Junge-Neukunden/", public)
        self.assertIn("/ve-release-1/", internal)
        self.assertNotIn("?", public)

    def test_arbitrary_blob_rejected(self):
        for value in ["actual-video.mp4", "../x", BLOB + "?sig=secret", "https://other.example/x", ""]:
            with self.subTest(value=value), self.assertRaises(lp.TaskError):
                lp.safe_blob_name(value)

    def test_expected_storage_configuration(self):
        checks = lp.storage_checks({"allowBlobPublicAccess": True, "publicNetworkAccess": "Disabled"}, lp.summarize_containers(containers()))
        self.assertTrue(all(c["passed"] for c in checks))

    def test_old_assets_must_stay_private(self):
        values = lp.summarize_containers(containers())
        values[0]["publicAccess"] = "Blob"
        checks = lp.storage_checks({"allowBlobPublicAccess": True, "publicNetworkAccess": "Disabled"}, values)
        self.assertFalse(all(c["passed"] for c in checks))

    def test_listing_permission_is_not_expected(self):
        values = lp.summarize_containers(containers())
        values[2]["publicAccess"] = "Container"
        checks = lp.storage_checks({"allowBlobPublicAccess": True, "publicNetworkAccess": "Disabled"}, values)
        self.assertFalse(all(c["passed"] for c in checks))

    def test_absent_container_not_success(self):
        checks = lp.storage_checks({"allowBlobPublicAccess": True, "publicNetworkAccess": "Disabled"}, [])
        self.assertFalse(all(c["passed"] for c in checks))

    def test_wrong_resource_id_rejected(self):
        with patch.object(lp, "az_json", return_value={"id": "/wrong/resource"}), self.assertRaises(lp.TaskError):
            lp.read_account(lp.env_config("prod"))

    def test_pagination_stays_in_azure_management(self):
        with patch.object(lp, "az_json", return_value={"value": [], "nextLink": "https://other.example/"}), self.assertRaises(lp.TaskError):
            lp.read_containers(lp.env_config("dev"))

    def test_repeated_pagination_rejected(self):
        cfg = lp.env_config("dev")
        url = f"{lp.ARM}{lp.account_id(cfg)}/blobServices/default/containers?api-version={lp.STORAGE_API}"
        with patch.object(lp, "az_json", return_value={"value": [], "nextLink": url}), self.assertRaises(lp.TaskError):
            lp.read_containers(cfg)

    def test_receipt_roundtrip_and_tamper_detection(self):
        path, data = receipt_at(self.folder)
        self.assertEqual(lp.read_receipt(path)[1], data)
        (self.folder / "testdatei.txt").write_bytes(b"X" * lp.SAMPLE_SIZE)
        with self.assertRaises(lp.TaskError): lp.read_receipt(path)

    def test_receipt_cannot_read_arbitrary_file(self):
        path, _ = receipt_at(self.folder)
        value = json.loads(path.read_text())
        value["sample_file"] = "../../private-key"
        lp.save_json(path, value)
        with self.assertRaises(lp.TaskError): lp.read_receipt(path)

    def test_environment_target_tampering_rejected(self):
        path, _ = receipt_at(self.folder)
        value = json.loads(path.read_text())
        value["storage_account"] = "anotheraccount"
        lp.save_json(path, value)
        with self.assertRaises(lp.TaskError): lp.read_receipt(path)

    def test_probe_checks_bytes_and_range(self):
        path, data = receipt_at(self.folder)
        replies = [({"http_status": 200, "headers": {}}, data),
                   ({"http_status": 206, "headers": {"content-range": "bytes 0-1023/8192"}}, data[:1024])]
        args = argparse.Namespace(receipt=path, endpoint="asset-domain", origin=None, network="extern", output=None)
        with patch.object(lp, "http_get", side_effect=replies) as getter:
            self.assertEqual(lp.probe(args), 0)
            self.assertEqual(getter.call_args_list[1].kwargs["byte_range"], "bytes=0-1023")
        report = json.loads(path.with_name("probe-asset-domain-extern.json").read_text())
        self.assertTrue(report["passed"])
        self.assertEqual(report["network_declared_by_operator"], "extern")

    def test_login_html_200_is_not_success(self):
        path, data = receipt_at(self.folder)
        replies = [({"http_status": 200, "headers": {}}, b"<html>Sign in</html>"),
                   ({"http_status": 206, "headers": {"content-range": "bytes 0-1023/8192"}}, data[:1024])]
        args = argparse.Namespace(receipt=path, endpoint="asset-domain", origin=None, network="intern", output=None)
        with patch.object(lp, "http_get", side_effect=replies): self.assertEqual(lp.probe(args), 2)

    def test_range_ignored_is_failure(self):
        path, data = receipt_at(self.folder)
        replies = [({"http_status": 200, "headers": {}}, data), ({"http_status": 200, "headers": {}}, data)]
        args = argparse.Namespace(receipt=path, endpoint="asset-domain", origin=None, network="intern", output=None)
        with patch.object(lp, "http_get", side_effect=replies): self.assertEqual(lp.probe(args), 2)

    def test_optional_cors_requires_matching_origin(self):
        path, data = receipt_at(self.folder)
        replies = [({"http_status": 200, "headers": {}}, data),
                   ({"http_status": 206, "headers": {"content-range": "bytes 0-1023/8192"}}, data[:1024])]
        args = argparse.Namespace(receipt=path, endpoint="asset-domain", origin="https://example.org", network="intern", output=None)
        with patch.object(lp, "http_get", side_effect=replies): self.assertEqual(lp.probe(args), 2)

    def test_no_http_credentials_query_or_fragment(self):
        for url in ["http://example.org/a", "https://user:pass@example.org/a", "https://example.org/a?sig=x", "https://example.org/a#x"]:
            with self.subTest(url=url), self.assertRaises(lp.TaskError): lp.http_get(url)

    def test_http_get_has_no_auth_or_cookies(self):
        class Response:
            code = 200
            headers = {"Content-Type": "text/plain"}
            def __enter__(self): return self
            def __exit__(self, *args): return None
            def read(self, limit): return b"hello"
        class Opener:
            def open(self, request, timeout):
                self.request = request
                return Response()
        opener = Opener()
        with patch.object(lp, "build_opener", return_value=opener):
            info, body = lp.http_get("https://example.org/a", byte_range="bytes=0-1023")
        self.assertEqual(opener.request.get_method(), "GET")
        keys = {k.lower() for k, _ in opener.request.header_items()}
        self.assertNotIn("authorization", keys)
        self.assertNotIn("cookie", keys)
        self.assertEqual(info["http_status"], 200)
        self.assertEqual(body, b"hello")

    def test_no_redirect_following(self):
        self.assertIsNone(lp.NoRedirect().redirect_request(None, None, 302, "Found", {}, "https://example.org/login"))

    def test_azure_cli_environment_does_not_reuse_storage_keys(self):
        result = subprocess.CompletedProcess([], 0, stdout="{}", stderr="")
        with patch.object(lp.shutil, "which", return_value="/usr/bin/az"), patch.object(lp.subprocess, "run", return_value=result) as run:
            with patch.dict(os.environ, {"AZURE_STORAGE_KEY": "secret", "AZURE_STORAGE_SAS_TOKEN": "sig"}):
                lp.az_json(["storage", "account", "show"])
        env = run.call_args.kwargs["env"]
        self.assertNotIn("AZURE_STORAGE_KEY", env)
        self.assertNotIn("AZURE_STORAGE_SAS_TOKEN", env)
        self.assertEqual(env["AZURE_STORAGE_AUTH_MODE"], "login")

    def test_inventory_only_uses_read_commands(self):
        cfg = lp.env_config("dev")
        called = []
        def fake(command):
            called.append(command)
            if command[:3] == ["storage", "account", "show"]:
                return {"id": lp.account_id(cfg), "allowBlobPublicAccess": True, "publicNetworkAccess": "Disabled"}
            if command[:1] == ["rest"]: return {"value": containers()}
            if command[:3] == ["network", "application-gateway", "show"]:
                return {"httpListeners": [{"name": "landingassets-private"}],
                        "backendAddressPools": [{"name": "landingassets-backends", "backendAddresses": [{"fqdn": cfg["storage_account"] + ".blob.core.windows.net"}]}]}
            raise AssertionError(command)
        args = argparse.Namespace(env="dev", output=self.folder / "inventory.json")
        with patch.object(lp, "az_json", side_effect=fake): self.assertEqual(lp.inventory(args), 0)
        self.assertEqual(len(called), 3)
        self.assertFalse(any(word in {"create", "update", "delete", "list-keys"} for call in called for word in call))

    def test_inventory_denied_is_not_missing_resource_proof(self):
        args = argparse.Namespace(env="dev", output=self.folder / "inventory.json")
        with patch.object(lp, "az_json", side_effect=lp.TaskError("AuthorizationFailed")):
            self.assertEqual(lp.inventory(args), 2)
        report = json.loads(args.output.read_text())
        self.assertIn("AuthorizationFailed", report["environments"]["dev"]["errors"][0])

    def test_upload_has_nonoverwrite_and_login_guards(self):
        cfg = lp.env_config("dev")
        args = argparse.Namespace(env="dev", campaign="uniglobal", output_dir=self.folder)
        with patch.object(lp, "read_account", return_value={"allowBlobPublicAccess": True}), \
             patch.object(lp, "read_containers", return_value=containers()), patch.object(lp, "confirm") as confirm, \
             patch.object(lp, "az_json", return_value={"etag": '"etag-one"'}) as az:
            self.assertEqual(lp.upload_test(args), 0)
        cmd = az.call_args.args[0]
        self.assertEqual(cmd[cmd.index("--overwrite") + 1], "false")
        self.assertEqual(cmd[cmd.index("--if-none-match") + 1], "*")
        self.assertEqual(cmd[cmd.index("--auth-mode") + 1], "login")
        confirm.assert_called_once_with("UPLOAD", "dev")
        receipts = list(self.folder.rglob("upload.json"))
        self.assertEqual(len(receipts), 1)
        self.assertEqual(len(lp.read_receipt(receipts[0])[1]), lp.SAMPLE_SIZE)

    def test_upload_not_performed_without_container_access(self):
        args = argparse.Namespace(env="dev", campaign="uniglobal", output_dir=self.folder)
        with patch.object(lp, "read_account", return_value={"allowBlobPublicAccess": True}), \
             patch.object(lp, "read_containers", return_value=[]), patch.object(lp, "az_json") as az, \
             self.assertRaises(lp.TaskError): lp.upload_test(args)
        az.assert_not_called()

    def test_cleanup_rejects_unmarked_blob(self):
        path, _ = receipt_at(self.folder)
        with patch.object(lp, "az_json", return_value={"metadata": {}, "properties": {"etag": "one"}}) as az, \
             self.assertRaises(lp.TaskError): lp.cleanup(argparse.Namespace(receipt=path))
        self.assertEqual(az.call_count, 1)

    def test_cleanup_rejects_changed_blob(self):
        path, _ = receipt_at(self.folder)
        blob = {"metadata": {"ticket": "DBI-12139", "synthetic": "true"}, "properties": {"etag": '"etag-changed"'}}
        with patch.object(lp, "az_json", return_value=blob) as az, self.assertRaises(lp.TaskError):
            lp.cleanup(argparse.Namespace(receipt=path))
        self.assertEqual(az.call_count, 1)

    def test_cleanup_is_conditional_on_etag(self):
        path, _ = receipt_at(self.folder)
        blob = {"metadata": {"ticket": "DBI-12139", "synthetic": "true"}, "properties": {"etag": '"etag-one"'}}
        with patch.object(lp, "az_json", side_effect=[blob, None]) as az, patch.object(lp, "confirm") as confirm:
            self.assertEqual(lp.cleanup(argparse.Namespace(receipt=path)), 0)
        command = az.call_args_list[1].args[0]
        self.assertEqual(command[command.index("--if-match") + 1], '"etag-one"')
        confirm.assert_called_once_with("DELETE", "dev")

    def test_noninteractive_confirmation_rejected(self):
        with patch.object(lp.sys.stdin, "isatty", return_value=False), self.assertRaises(lp.TaskError):
            lp.confirm("UPLOAD", "prod")


if __name__ == "__main__":
    unittest.main(verbosity=2)
