# DBI-12139: Abnahme und Nachweise

**Diese Liste ist noch nicht abgearbeitet.** Die Vorbereitung und die lokalen Programmlogiktests sind kein Azure-Abnahmetest.

## Je Umgebung

| Nachweis | DEV | TEST | PROD |
|---|---|---|---|
| Vorhandener Storage Account mit erwartetem oder nachvollziehbar aktualisiertem Namen bestätigt | [ ] | [ ] | [ ] |
| Gewählter Release-Container vorhanden; Leserecht `Blob`, nicht Container-Listing | [ ] | [ ] | [ ] |
| Alter Container `assets` nicht versehentlich geöffnet | [ ] | [ ] | [ ] |
| Gateway zeigt auf den richtigen Storage Account und Release-Pfad | [ ] | [ ] | [ ] |
| Asset-Adresse ohne Anmeldung aus dem vorgesehenen Kundennetz erreichbar | [ ] | [ ] | [ ] |
| Normales GET liefert exakt die erwartete Testdatei | [ ] | [ ] | [ ] |
| Range-GET liefert den richtigen Ausschnitt | [ ] | [ ] | [ ] |
| Repräsentative große Datei in der vorgesehenen Landingpage geprüft | [ ] | [ ] | [ ] |
| Upload-Verantwortung, berechtigte Identität und Netzwerkweg geklärt | [ ] | [ ] | [ ] |
| Konkrete URLs, Datum und Ergebnisse im Jira dokumentiert | [ ] | [ ] | [ ] |
| Synthetische Testdatei nach Abschluss gezielt entfernt oder begründet noch vorhanden | [ ] | [ ] | [ ] |

Die Rollentrennung und die Erreichbarkeit gehen über ein bloßes „Account angelegt“ hinaus, sind aber nötig, um die sichtbare Anforderung „Assets public lesbar“ tatsächlich nachzuweisen. Eine bewusst vereinbarte Einschränkung für DEV oder TEST ausdrücklich im Ticket festhalten.

## Was als Nachweis ins Ticket gehört

Den relevanten Ausschnitt aus `inventar.json` und die zugehörigen `probe-*.json` anhängen. Für den echten Medientest zusätzlich Dateigröße, Browser, Datum, konkrete Landingpage und Beobachtung dokumentieren. Nur freigegebene öffentliche Test-URLs verwenden, keine SAS-Tokens, privaten Schlüssel oder vollständigen Umgebungsdateien.

Die Testberichte enthalten Ressourcen- und Hostnamen. Sie gehören in das interne Ticket, nicht in ein öffentliches Repository.

## Wann du das Ticket noch nicht abschließt

Ein vorhandener Account allein genügt nicht. Auch ein interner Test, eine HTTP-200-Anmeldeseite, ein erfolgreicher Upload mit deinem Login oder ein kleiner Testblob allein beweisen die geforderte Funktion nicht vollständig. Offene Umgebungen oder ein fehlender öffentlicher Zugangsweg bleiben im Ticket sichtbar.

## Rückfallweg bei Problemen

Bei reinen Tests nur die eigene markierte Testdatei entfernen. Wurden tatsächlich Infrastruktur- oder Routingänderungen notwendig, diese einzeln dokumentieren und über einen geprüften Rücknahmeplan zurücksetzen. Keine vorhandenen Accounts oder Release-Container als vermeintliches Rollback löschen. Veröffentlichung neuer Medien ist von ihrer späteren Löschung getrennt zu betrachten; bereits abgerufene Dateien lassen sich nicht durch eine Storage-Einstellung aus fremden Browsern zurückholen.
