# DBI-12139: Was du konkret erledigen sollst

## Worum geht es?

Kunden sollen größere Dateien, zum Beispiel Videos, auf Landingpages ansehen können. Die Dateien sollen in Azure gespeichert und ohne Anmeldung abrufbar sein. Das Ticket fordert das für **dev, test und prod**. [Ticketabschrift](quellen/code-auszuege.md#q1-ticket)

Ein **Storage Account** ist hier der Dateispeicher. Ein **Container** ist eine abgegrenzte Ablage darin. Die **Asset-Domain** ist die Adresse, über die eine Landingpage diese Dateien lädt.

## Was schon vorbereitet ist

Im Repository `live` gibt es pro Umgebung einen Baustein `storage-assets`. Er enthält bereits Ablagen für UniGlobal, VE und Zukunft. Für diese Ablagen sind passende Adresspfade am Application Gateway definiert. Das Gateway ist der vorgeschaltete Webzugang. [Q2 bis Q5](04_Codebefunde_und_Quellen.md)

Wichtig: **Im Code vorhanden bedeutet nicht automatisch in Azure fertig.** Außerdem ist der konfigurierte Gateway-Eingang privat. Ob davor ein öffentlicher Zugang existiert, belegt der Upload nicht.

## Schritt 1: Den tatsächlichen Bestand prüfen

**Kannst du sofort selbst machen. Keine Rückmeldung aus den anderen Tickets nötig.**

- [ ] Die erste Bestandsprüfung aus der Anleitung ausführen. Sie liest nur Einstellungen.
- [ ] Für jede Umgebung festhalten: Speicher vorhanden, passende Container vorhanden, Gateway auf den richtigen Speicher gerichtet?
- [ ] Abweichungen im Bericht ansehen, statt sofort neue Ressourcen anzulegen.

**Was du mit dem Ergebnis machst:**

| Ergebnis | Dein nächster Schritt |
|---|---|
| Speicher und Ablagen existieren wie vorgesehen. | Mit Schritt 2 weitermachen. Es muss nichts neu angelegt werden. |
| Dir fehlen Leserechte oder eine Anmeldung. | Den bestehenden Zugriffsweg nutzen. Ein Berechtigungsfehler beweist nicht, dass der Speicher fehlt. |
| Der Speichername stimmt nicht mehr mit dem Snapshot überein. | Aktuellen Branch und vorhandenen Terraform-State vergleichen. Keinen zweiten Account erzeugen, nur weil ein Name anders ist. |
| Ressourcen fehlen wirklich und sind auch nicht anderweitig verwaltet. | Den vorhandenen `storage-assets`-Baustein gezielt planen und über euren freigegebenen Prozess bereitstellen. Anleitung Abschnitt 7. |

## Schritt 2: Die richtigen Ablagen verwenden

**Baut auf Schritt 1 auf.**

Die bestehende Zuordnung lautet:

| Landingpage | Ablage im Speicher | Sichtbarer URL-Pfad |
|---|---|---|
| UniGlobal | `uniglobal-release-1` | `/uniglobal/` |
| VE | `ve-release-1` | `/VE-Impuls-Junge-Neukunden/` |
| Zukunft | `zukunft-release-1` | `/zukunft-2026/` |

- [ ] Bestehende Zuordnung mit dem tatsächlichen Stand abgleichen.
- [ ] Für den technischen Test einen passenden vorhandenen Container auswählen. Das Werkzeug nimmt standardmäßig UniGlobal.
- [ ] Für den anschließenden Anwendungstest eine freigegebene größere Beispieldatei und die dazugehörige Landingpage bestimmen. Dafür ist eine Nachricht an Alex vorbereitet.

**Nicht den alten Container `assets` wieder öffnen.** Die Git-Historie dokumentiert ausdrücklich die Umstellung auf Release-Container. Auch `statuspages` ist keine allgemeine Medienablage. [Q6](04_Codebefunde_und_Quellen.md)

Der Screenshot nennt keine neuen Kampagnennamen. Zusätzliche Ablagen deshalb nur für einen tatsächlich bestätigten Bedarf ergänzen. Eine neue Version erfordert gegebenenfalls auch eine Anpassung des Gateway-Pfads, nicht nur einen leeren Container.

## Schritt 3: Den Weg zum Kunden prüfen

**Baut auf Schritt 1 auf; die Bestandsanalyse geht ohne Testdatei. Der echte Lesetest braucht Schritt 4.**

Der vorgesehene Weg im Paket ist:

```text
Kunde ruft die freigegebene Asset-Adresse auf
  -> vorhandener externer Webzugang, sofern eingerichtet
  -> Application Gateway
  -> privater Storage-Zugang
  -> konkrete Datei im Release-Container
```

- [ ] Prüfen, wie die Asset-Domain von außerhalb erreichbar ist.
- [ ] Bestehende DNS-, Zertifikats- und Gateway-Konfiguration verwenden, soweit sie diesen Weg bereits ermöglicht.
- [ ] Fehlt nur der externe Zugang, die vorbereitete Nachricht an dessen zuständigen Betriebskontakt geben. Die Zuständigkeit ist im Upload nicht namentlich belegt.

**Nicht als Abkürzung alle Storage-Firewalls öffnen.** Anonymes Lesen und öffentliche Netzwerkerreichbarkeit sind zwei getrennte Einstellungen. Der vorhandene Aufbau hält den direkten Storage-Netzzugang geschlossen. [W1 und W2](04_Codebefunde_und_Quellen.md#öffentliche-primärquellen)

Ein erfolgreicher Test nur aus dem Firmennetz beweist noch keinen öffentlichen Kundenzugriff. Falls DEV oder TEST ausdrücklich nur intern nutzbar sein sollen, muss diese abweichende Auslegung von „public“ im Ticket bestätigt werden, statt sie stillschweigend anzunehmen.

## Schritt 4: Den Zugriff wirklich testen

**Baut auf Schritt 2 auf. Für den externen Test muss Schritt 3 funktionieren. Reihenfolge: dev, dann test, dann prod.**

- [ ] Eine harmlose Testdatei über die berechtigte Upload-Verbindung ablegen. Das Werkzeug erzeugt selbst einen eindeutigen Namen und überschreibt keine vorhandene Datei.
- [ ] Datei ohne Anmeldung über die Asset-Adresse abrufen. Das Werkzeug vergleicht den Inhalt, damit eine Anmeldeseite mit HTTP 200 nicht versehentlich als Erfolg zählt.
- [ ] Auch einen Teilabruf testen. Bei Videos ist das für das Springen im Video relevant; technisch prüft das Werkzeug eine Byte-Range.
- [ ] Danach eine repräsentative größere Mediendatei auf der tatsächlichen Landingpage testen. Bei einem Video Start und Sprung in die Mitte prüfen.
- [ ] Bericht und verwendete URL je Umgebung im Ticket ablegen.

**Die kleine Testdatei beweist nicht die Funktion jeder großen Mediendatei.** Dateityp, Browserdarstellung, tatsächliche Ladezeit und die Verwendung der richtigen Adresse in der Anwendung separat prüfen. [W4](04_Codebefunde_und_Quellen.md#öffentliche-primärquellen)

## Schritt 5: Übergeben und abschließen

**Baut auf den bestandenen Tests auf.**

- [ ] Asset-Adressen und Containerzuordnung sind dokumentiert.
- [ ] Es ist klar, wer Dateien mit welcher berechtigten Identität hochlädt. Lesen ohne Anmeldung bedeutet nicht Schreiben ohne Anmeldung.
- [ ] Der Anwendungstest ist dokumentiert. Bei Abweichungen bleiben diese ausdrücklich offen.
- [ ] Synthetische Testdateien nach der Abnahme gezielt entfernen.
- [ ] Erst danach die Abschlussnachricht aus `02_Nachrichten.md` verwenden.

## Abhängigkeiten

| Arbeit | Voraussetzung | Parallel möglich? |
|---|---|---|
| Bestand lesen | Eigene Azure-Leserechte | Sofort, unabhängig von anderen Jiras. |
| Fehlende bestehende Ressourcen nachliefern | Geklärter Terraform-State, geprüfter Plan, Bereitstellungsrechte | Während die Beispieldatei organisiert wird. |
| Technische Testdatei hochladen | Richtiger Container, Schreibrecht, privater Netzwerkweg | Unabhängig von Monitoring, SAML und Event Grid. |
| Öffentlichen Abruf bestätigen | Funktionierende Domain und vollständiger Zugriffsweg | Interne und externe Diagnose können getrennt erfolgen. |
| Ticket abschließen | Nachweise für alle vereinbarten Umgebungen | Nicht vor den Zugriffstests. |

**Keine Aufgabe wird an die abwesenden Kollegen zurückgegeben.** Der Code liefert die technische Ausgangslage. Benötigt werden allenfalls eine Beispieldatei, eine berechtigte Upload-Identität oder ein noch fehlender externer Zugangsweg.
