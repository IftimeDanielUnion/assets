# DBI-12139: Konkrete Anleitung und Testwerkzeug

## 1. Voraussetzungen

Die folgenden Shell-Blöcke sind für Bash unter Linux, macOS oder WSL gedacht. Im entpackten Paketordner starten. Benötigt werden **Python 3.10 oder neuer** und für Azure-Abfragen beziehungsweise Upload/Bereinigung die **Azure CLI mit deiner Anmeldung**. Zusätzliche Python-Pakete sind nicht erforderlich.

Die Zielnamen in `code/umgebungen.json` stammen aus dem Upload. Sie sind keine aus Azure bestätigten Ist-Werte. Bei Abweichungen zuerst den aktuellen Repo-/State-Stand prüfen. Keine Namen auf Verdacht ändern und keine Zugangsdaten in diese Datei schreiben.

Für die Metadatenprüfung reichen passende Verwaltungs-Leserechte. Upload und Bereinigung benötigen gesonderte Datenrechte sowie den Netzwerkweg zum Private Endpoint. Ein allgemeines Leserecht oder die im Snapshot vergebenen `Storage Blob Data Reader`-Rollen erlauben keinen Upload. [Q2, W5](04_Codebefunde_und_Quellen.md)

## 2. Zuerst nur den Bestand lesen

```bash
python3 --version
az version
az login
python3 code/lp_assets.py inventory --env all
```

Ergebnis: `ergebnisse/inventar.json`. Das Werkzeug gibt den Berichtspfad aus. Es führt nur `show`- und ARM-GET-Abfragen aus, fragt keine Storage-Schlüssel ab und verändert weder Accounts noch Container, Rechte oder Netzwerkregeln. Es setzt die Subscription pro Befehl explizit und verändert nicht deine Standard-Subscription.

Nur eine Umgebung prüfen:

```bash
python3 code/lp_assets.py inventory --env dev --output ergebnisse/inventar-dev.json
```

**Exitcode 0:** Die gelesenen Storage-Sollwerte und die Gateway-Zuordnung passen in den geprüften Punkten. Das ist noch kein HTTP- oder Abnahmenachweis.

**Exitcode 2:** Es gibt eine Abweichung, eine fehlende Ressource oder einen Lesefehler. Der Bericht trennt die Ergebnisse. Bei `AuthorizationFailed` fehlt gegebenenfalls lediglich das Recht. Ein Timeout ist ebenfalls kein Beweis für eine nicht vorhandene Ressource.

Die Container werden über die Azure-Verwaltungsschnittstelle gelesen. Daher erfordert diese Bestandsprüfung keinen direkten Lesezugriff auf die Mediendateien. [W3](04_Codebefunde_und_Quellen.md#öffentliche-primärquellen)

## 3. Optional eine harmlose Testdatei hochladen

Diesen Schritt aus einer Umgebung ausführen, die den privaten Storage-Endpunkt erreicht. In der ausgewählten Ablage wird eine **neue synthetische Textdatei mit 8 KiB** erstellt. Der Name ist zufällig und eindeutig. Der Befehl überschreibt keine vorhandene Datei, erzeugt keine Container und vergibt keine Rechte.

```bash
python3 code/lp_assets.py upload-test --env dev --campaign uniglobal
```

Nach der Zielanzeige musst du interaktiv exakt `UPLOAD dev` eingeben. Ohne Bestätigung erfolgt kein Upload. Das Werkzeug verwendet `--auth-mode login`, nicht Storage-Schlüssel. [W5 und W6](04_Codebefunde_und_Quellen.md#öffentliche-primärquellen)

Unter `ergebnisse/dev/` entsteht ein eigener Belegordner mit `upload.json` und `testdatei.txt`. Beide Dateien zusammen aufbewahren. Die Testdatei ist unkritischer, synthetischer Inhalt, keine Kundendatei.

Die anderen bereits konfigurierten Ablagen sind über `--campaign ve` oder `--campaign zukunft` auswählbar. Verwende die zur ausgewählten Test-Landingpage passende Ablage. Keine dieser Kampagnen wird durch das neue Ticket ausdrücklich zusätzlich beauftragt.

**Bei fehlenden Rechten oder DNS-/Netzwerkfehlern:** Nicht Public Network Access einschalten. Den bestehenden Upload-Prozess oder eine passend berechtigte Umgebung verwenden.

## 4. Ohne Anmeldung lesen und einen Teilabruf prüfen

Für den internen Test der zuletzt erzeugten DEV-Testdatei:

```bash
RECEIPT="$(find ergebnisse/dev -type f -name upload.json | sort | tail -n 1)"
test -n "$RECEIPT" || { echo "Kein DEV-Testbeleg gefunden."; exit 1; }
python3 code/lp_assets.py probe --receipt "$RECEIPT" --network intern
```

Das Werkzeug sendet einen normalen **GET** und einen **GET mit `Range: bytes=0-1023`**. Erwartet werden HTTP 200 mit exakt dem Testinhalt und HTTP 206 mit den korrekten ersten 1.024 Bytes. Es verwendet keine Cookies, keine Authorization-Header und keinen SAS-Token. Umleitungen werden nicht als Erfolg akzeptiert. [W4](04_Codebefunde_und_Quellen.md#öffentliche-primärquellen)

**Warum nicht `curl -I`?** Die vorhandene WAF-Regel blockiert alle Methoden außer GET. `curl -I` sendet HEAD und kann deshalb einen Fehler erzeugen, obwohl der normale Download funktioniert. Querystrings sind ebenfalls gesperrt. Keine Testparameter wie `?test=1`, keine SAS-Links und keine Cachebuster an die Asset-Adresse hängen. [Q5](04_Codebefunde_und_Quellen.md)

### Den öffentlichen Kundenzugriff nachweisen

Den Belegordner einschließlich `testdatei.txt` und dieses Werkzeug an den freigegebenen externen Teststandort mitnehmen. Nur dort mit `--network extern` testen:

```bash
read -r -p "Pfad zur upload.json des zu prüfenden Belegs: " RECEIPT
python3 code/lp_assets.py probe --receipt "$RECEIPT" --network extern
```

`--network extern` ändert kein Routing. Es dokumentiert ausschließlich deine Angabe zum tatsächlichen Teststandort. Ein Firmenrechner mit internem DNS, VPN oder Unternehmensproxy ist nicht automatisch ein externer Test. Auch ein privates Browserfenster beweist das nicht.

### Nur zur Eingrenzung: direkt über den privaten Blob-Endpunkt

```bash
read -r -p "Pfad zur upload.json des zu prüfenden Belegs: " RECEIPT
python3 code/lp_assets.py probe --receipt "$RECEIPT" --network intern --endpoint blob-intern
```

Wenn dieser Test funktioniert, die Asset-Domain aber nicht, liegt die zu untersuchende Lücke eher bei Domain, Gateway, WAF oder vorgelagertem Zugang. Das ist eine Eingrenzung, kein Beweis einer einzelnen Fehlerursache. Der Blob-Test ist nur aus einem Netz mit Zugriff auf den Private Endpoint sinnvoll.

### Optional die Browser-Origin mitprüfen

Nur erforderlich, wenn die konkrete Einbindung einen Cross-Origin-Lesetest benötigt:

```bash
read -r -p "Pfad zur upload.json: " RECEIPT
read -r -p "HTTPS-Origin der tatsächlichen Landingpage, ohne Pfad: " ORIGIN
python3 code/lp_assets.py probe --receipt "$RECEIPT" --network intern --origin "$ORIGIN"
```

Das ist ein GET-Test des zurückgelieferten Origin-Headers, **kein vollständiger Browser- oder OPTIONS-Preflight-Test**. OPTIONS wird vom aktuellen WAF-Muster blockiert. Keine pauschale CORS-Aufweitung vornehmen. Zuerst die wirkliche Einbindung betrachten. [Q5](04_Codebefunde_und_Quellen.md)

## 5. TEST und PROD sowie größere Dateien

Nach erfolgreichem DEV-Test einzeln fortsetzen:

```bash
python3 code/lp_assets.py upload-test --env test --campaign uniglobal
```

Später, nach dem vorgesehenen Freigabeprozess:

```bash
python3 code/lp_assets.py upload-test --env prod --campaign uniglobal
```

Jeweils muss `UPLOAD test` beziehungsweise `UPLOAD prod` bestätigt werden. Den zurückgegebenen Beleg mit den Testbefehlen aus Abschnitt 4 verwenden. Keine Schleife deployt oder beschreibt ungeprüft alle drei Umgebungen.

**Zusätzlicher Medientest:** Auf einer passenden Landingpage eine bereits freigegebene große Datei verwenden. Dateityp und Ladeverhalten prüfen, bei Videos auch Springen und Weiterspielen. Datum, Dateigröße, Browser, URL und Beobachtung im Ticket dokumentieren. Die 8-KiB-Prüfung ersetzt diesen Test nicht.

In den vorhandenen Gateway-Backend-Einstellungen steht für die Asset-Pfade `request_timeout = 1`. Das ist ein Anlass für einen realen Last-/Medientest, nicht automatisch ein Beweis, dass große Dateien scheitern. Ein Request-Timeout ist keine Dateigrößenbegrenzung. Bei tatsächlich gemessenen Timeoutfehlern nur die betroffenen `lpa-*`-Einstellungen in `live/<umgebung>/appgateway.hcl` gezielt untersuchen. [Q5, W7](04_Codebefunde_und_Quellen.md)

## 6. Die eigene Testdatei wieder entfernen

Nach dokumentierter Abnahme:

```bash
read -r -p "Pfad zur upload.json der zu löschenden Testdatei: " RECEIPT
python3 code/lp_assets.py cleanup --receipt "$RECEIPT"
```

Der Befehl prüft den generierten Dateinamen, die Testmarkierungen und den ETag, also die Versionskennung. Erst nach `DELETE dev`, `DELETE test` oder `DELETE prod` wird genau dieser Blob entfernt. Kein rekursives Löschen. Bei fremden oder zwischenzeitlich geänderten Dateien bricht das Werkzeug ab.

Versionierung und Soft Delete können ältere Daten entsprechend der konfigurierten Aufbewahrung erhalten. Es wird nicht behauptet, dass die Bereinigung diese Historie sofort löscht. Keine Retention-Regeln für eine 8-KiB-Testdatei aufweichen. [Q2, W6](04_Codebefunde_und_Quellen.md)

## 7. Wenn tatsächlich Infrastruktur fehlt

**Nur nach Repo-/Azure-/State-Abgleich.** Im aktuellen Arbeitsklon des Repositories `live` arbeiten, nicht im entpackten Testpaket. Falls Ressourcen schon existieren, aber nicht im erwarteten State stehen, erst die Verwaltung klären. Kein neuer State und kein Ersatzaccount auf Verdacht.

Die vorhandene Implementierung steht in:

```text
live/live/dev/terragrunt.stack.hcl
live/live/test/terragrunt.stack.hcl
live/live/prod/terragrunt.stack.hcl
```

Der erste Pfadteil ist der Repositoryname. Innerhalb des geklonten Repositories beginnt der Pfad also bei `live/dev/...`.

Für einen gezielten DEV-Plan, aus dem Wurzelverzeichnis des `live`-Repositories:

```bash
(
  set -euo pipefail
  tfenv install
  tgenv install
  (
    cd live
    TG_PROVIDER_CACHE=0 terragrunt stack generate --filter "dev | type=stack" --filter "dev/** | type=stack"
  )
  cd live/dev/.terragrunt-stack/storage-assets
  terragrunt run -- init
  terragrunt run -- validate
  terragrunt run -- plan -out=dbi-12139.tfplan
)
```

Dieser Block erzeugt lokale Arbeitsdateien, initialisiert das bestehende Backend und erstellt einen Plan. Er enthält **kein Apply**. Die Azure- und GitLab-Backend-Anmeldung muss über euren bestehenden Prozess vorhanden sein. Keine Zugangsdaten aus früheren Paketen oder Chats übernehmen. Wenn der generierte Pfad wegen eines neueren Repository-Aufbaus anders ist, dessen tatsächlichen Pfad verwenden und den erwarteten State prüfen.

**Plan prüfen:** Keine Account-Ersetzung, keine Containerlöschung, keine Freigabe des alten `assets`-Containers, keine Öffnung fremder Storage Accounts. Anschließend nur den geprüften Plan über den bestehenden Bereitstellungsprozess ausführen. Die vorhandene CI kann auch weitere Änderungen eines Umgebungsstacks enthalten; den gesamten Plan lesen, nicht nur den Ticketnamen. [Q8 und W8](04_Codebefunde_und_Quellen.md)

Der Katalog ist im Snapshot auf `v0.13.0` gepinnt. Für die bereits vorhandenen Storage-Bausteine ist aus den geprüften Dateien kein neuer Katalog-Release erforderlich. Die im Upload enthaltenen Werkzeugversionen sind Terraform `1.13.4` und Terragrunt `1.1.6`.

## 8. Fehler schnell einordnen

| Beobachtung | Zuerst prüfen |
|---|---|
| Verwaltungsabfrage meldet fehlende Rechte. | Azure-Anmeldung, Subscription und Leserechte. Nicht „Account fehlt“ melden. |
| Upload scheitert, Verwaltungsabfrage funktioniert. | Daten-Schreibrecht und privater Netzwerk-/DNS-Weg. |
| Datei ist intern abrufbar, extern nicht. | Externer Einstieg, DNS, Zertifikat, Routing und vorgelagerte Beschränkungen. |
| HEAD liefert 403. | Bestehende GET-only-WAF-Regel; stattdessen normalen GET verwenden. |
| GET liefert 403. | WAF-Ereignis, Containerzugriff und Netzwerkweg getrennt prüfen. |
| GET liefert 404. | Dateiname, Groß-/Kleinschreibung und Pfadzuordnung zum Release-Container. |
| GET liefert HTML statt Testdatei. | Falsche Route, Anmeldeseite oder Fehlervorlage; nicht als Erfolg werten. |
| Kleine Datei funktioniert, echtes Medium nicht. | Dateityp, Browserkonsole, Range-Verhalten, Einbindungsadresse und gemessene Timeouts. |
| Nur die DEV-Landingpage verwendet eine andere Adresse. | `ASSETS_BASE_URL` und tatsächlichen Deployment-Stand prüfen. Der Ansible-Snapshot und das Gateway verwenden dort unterschiedliche Hostnamen. |

## 9. Lokale Tests des Werkzeugs

```bash
python3 -m unittest discover -s tests -v
```

Die Tests simulieren Azure und HTTP. Sie schreiben nur temporäre lokale Testdateien. Das Ergebnis belegt die geprüfte Programmlogik, nicht eure Azure-Konfiguration. Details im Prüfprotokoll.
