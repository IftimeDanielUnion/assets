# Fertige Nachrichten für DBI-12139

Alle Texte sind Entwürfe. Es wurde nichts versendet. Bedingungen über dem jeweiligen Text beachten, damit du keinen ungetesteten Erfolg meldest.

## 1. Jetzt an Zeljko per Teams

**Empfänger:** Zeljko aus deinem Screenshot. **Zeitpunkt:** sofort.

```text
Hi Zeljko, ja, ich kümmere mich darum und prüfe den vorhandenen Aufbau für dev, test und prod. Ich gebe dir danach ein Update.
```

## 2. Erster Kommentar direkt ins Jira

**Empfänger:** Beteiligte an DBI-12139. **Zeitpunkt:** nach Übernahme des Tickets. Die Codeprüfung ist bereits erfolgt, eine Azure-Prüfung noch nicht.

```text
Ich übernehme die Prüfung und Umsetzung von DBI-12139.

Im vorhandenen Infrastrukturcode sind die Landingpage-Asset-Storages für dev, test und prod bereits definiert. Ich gleiche zunächst den tatsächlichen Azure-Stand damit ab und prüfe anschließend den Zugriff ohne Anmeldung über die vorgesehenen Asset-Adressen.

Ich nutze dabei die bestehenden Release-Container. Der alte Container „assets“ wurde laut Git-Historie bewusst gesperrt und bleibt unverändert. Falls nur Bereitstellung oder Zugriffsweg fehlen, ergänze ich gezielt diese Teile, statt zusätzliche Storage Accounts anzulegen.
```

## 3. An Alex für Beispieldatei und Anwendungstest

**Empfänger:** Alex Köster als bisheriger OSC-Ansprechpartner aus den vorhandenen Jiras. Seine konkrete Zuständigkeit für dieses neue Ticket ist nicht bestätigt. **Zeitpunkt:** parallel zur Bestandsprüfung. Darauf musst du für die reine Code- und Azure-Prüfung nicht warten.

```text
Hi Alex, ich kümmere mich um DBI-12139, also die Dateien für die Landingpages in dev, test und prod.

Im Code sind bereits die Ablagen für UniGlobal, VE und Zukunft vorgesehen. Ich prüfe die Infrastruktur und den Zugriff ohne Anmeldung. Hast du eine freigegebene größere Beispieldatei samt passender Landingpage für den anschließenden Test? Sag mir bitte auch kurz, über welche Identität oder welchen bestehenden Prozess die Dateien normalerweise hochgeladen werden.

Falls das Thema bei jemand anderem liegt, gib mir bitte kurz den passenden Kontakt. Danke dir!
```

## 4. Nur bei fehlender externer Erreichbarkeit: an den Webzugangs-Kontakt

**Empfänger:** Der tatsächlich zuständige Betriebskontakt für externen Webzugang, DNS und Zertifikate. Im Upload ist dafür kein belastbarer Name enthalten. Den bestehenden Service-/Change-Kanal nutzen. Zeljko nur nach der Zuordnung fragen, wenn sie darüber nicht ermittelbar ist. **Zeitpunkt:** wenn aus dem Azure-Abgleich oder dem externen Test eine konkrete Lücke hervorgeht.

```text
Hi, kannst du mich bitte beim externen Zugriff für DBI-12139 unterstützen?

Die vorhandene Konfiguration sieht die folgenden Asset-Domains vor:
- landing-assets.dev.apps.union-investment.de
- landing-assets.test.apps.union-investment.de
- landing-assets.apps.union-investment.de

Dahinter ist jeweils ein privater Application-Gateway-Eingang vorgesehen. Die Dateien sollen ohne Anmeldung über die freigegebene Asset-Adresse gelesen werden können; den direkten öffentlichen Netzwerkzugang der Storage Accounts möchte ich dafür nicht öffnen.

Kannst du bitte prüfen, ob der vorgelagerte externe Zugang einschließlich DNS und Zertifikat bereits eingerichtet ist und welcher Change gegebenenfalls noch fehlt? Die Testnachweise und die genaue Gateway-Zuordnung stehen im Ticket. Danke dir!
```

**Vor dem Senden:** Die im letzten Satz genannten eigenen Nachweise tatsächlich ins Ticket legen. Nur die betroffenen Domains im Text stehen lassen, falls die anderen bereits funktionieren. Ein unbekannter Ansprechpartner ist kein Grund, die drei Speicher neu zu bauen.

## 5. Falls für die Tests nur das Schreibrecht fehlt: an Alex

**Empfänger:** Alex beziehungsweise der von ihm benannte Upload-Verantwortliche. **Zeitpunkt:** nur bei einem bestätigten fehlenden Upload-Recht oder fehlendem Upload-Netzwerkweg.

```text
Hi Alex, für den nächsten Schritt brauche ich nur noch eine Testdatei im vorgesehenen Release-Container. Ich möchte dafür weder anonyme Schreibrechte noch Storage-Schlüssel freigeben.

Kannst du die synthetische Testdatei über euren vorhandenen Upload-Prozess ablegen oder mir den zuständigen Upload-Verantwortlichen nennen? Container und Dateiname stimmen wir für die betroffene Umgebung direkt ab. Anschließend prüfe ich den Abruf ohne Anmeldung. Danke dir!
```

Das beigefügte Werkzeug braucht bei `upload-test` bereits einen berechtigten Netzwerkweg. Bei einem Rechteproblem nicht versuchen, es durch öffentliche Netzwerkfreigaben zu umgehen. Für die Vorbereitung der übrigen Umgebungen musst du auf diese Zuarbeit nicht warten.

## 6. Abschluss an Zeljko, erst nach vollständiger Abnahme

**Empfänger:** Zeljko. **Zeitpunkt:** nur wenn alle Punkte in `05_Abnahme.md` erfüllt und die Nachweise im Jira hinterlegt sind. Nicht verwenden, solange nur interne Tests bestanden sind oder eine vereinbarte Umgebung fehlt.

```text
Hi Zeljko, DBI-12139 ist umgesetzt und geprüft. Die vorgesehenen Landingpage-Dateien sind in dev, test und prod über die freigegebenen Asset-Adressen ohne Anmeldung erreichbar. Den Test mit einer größeren Mediendatei haben wir ebenfalls durchgeführt. Die Adressen, Ablagen und Testnachweise stehen im Ticket. Danke dir!
```
