# CI/CD Pipeline Templates
## Java Azure Function
A standardized Gitlab Pipeline for building and deploying Java Function Apps to Azure.

### Pipeline Overview

The pipeline uses the Blueprint pipelines and extends them for usage in the Context of the Sudomain Marktbearbeitung. 

### Usage

#### Include

The pipeline can be included using one of the version tags.
e.G. like this

```yaml filename=.gitlab-ci.yml
include:
  - project: marktbearbeitungsplattform/cicd/templates/java-function-template
    ref: 'v1.0.0'
    file: java-azure-function.yml

variables:
  DISCOVERY_KEY: func-bff-api
  MAVEN_ARTIFACT_GROUP: de.unioninvestment.marktbearbeitungsplattform.investmentwelt
  MAVEN_ARTIFACT_NAME: iw-bff-api
```

#### Azure Functions Zip

The pipeline assumes that a zip file for the deployment to azure function is created with the maven assembly plugin.
A configuration looks like this

```xml filename=pom.xml
<plugin>
    <groupId>org.apache.maven.plugins</groupId>
    <artifactId>maven-assembly-plugin</artifactId>
    <version>3.8.0</version>
    <executions>
        <execution>
            <id>azure-functions-zip</id>
            <phase>package</phase>
            <goals>
                <goal>single</goal>
            </goals>
            <configuration>
                <descriptors>
                    <descriptor>src/assembly/azure-functions.xml</descriptor>
                </descriptors>
            </configuration>
        </execution>
    </executions>
</plugin>
```

```xml filename=src/assembly/azure-functions.xml
<assembly xmlns="http://maven.apache.org/ASSEMBLY/2.1.0">
    <id>azure-functions</id>
    <formats>
        <format>zip</format>
    </formats>
    <includeBaseDirectory>false</includeBaseDirectory>
    <fileSets>
        <fileSet>
            <directory>${project.build.directory}/azure-functions/bff-api-local</directory>
            <outputDirectory>/</outputDirectory>
        </fileSet>
    </fileSets>
</assembly>
```

As the id is appended to the created zip file by maven assembly, you have to overwrite the `FUNCTION_APP_ZIP_IDENTIFIER` variable if you use a different value then the default `azure-functions`
#### Variables

| Variable                          | Description                                                                                                                   | Required | Default         |
|-----------------------------------|-------------------------------------------------------------------------------------------------------------------------------|----------|-----------------|
| `DISCOVERY_KEY`                   | The Discovery key used to find the azure resources to deploy to                                                               | yes      |                 |
| `MAVEN_ARTIFACT_GROUP`            | The maven artifact group as defined in the pom.xml                                                                            | yes      |                 |
| `MAVEN_ARTIFACT_NAME`             | The maven artifact name as defined in the pom.xml                                                                             | yes      |                 |
| `CONFLUENCE_PAGE_ID`              | Set to enable Confluence Documentation generation step. Has to contain the Page ID that should be updated,                    | no       |                 |
| `CONFLUENCE_SPACE`                | Set to enable Confluence Documentation generation step. Has to contain the Confluence Space that contains page to be updated. | no       |                 |
| `JAVA_VERSION`                    | The Java version to compile with                                                                                              | no       | 21              |
| `CONFLUENCE_ASCIIDOC_ROOT_FOLDER` | The folder that contains the markdown files that should be used for generating confluence documentation.                      | no       | documentation   |
| `FUNCTION_APP_ZIP_IDENTIFIER`     | The identifier used in the maven assembly configuration that creates the azure function zip file                              | no       | azure-functions |

#### Maven Extension

By overwriting the job `.gitlab-services-extension` maven build steps can be extended, e.G. to define services that need to be started alongside the build.

```yaml
.gitlab-services-extension:
  services:
    - name: image-external.nexus.apps.union-investment.de/postgres:16
      alias: database
    - name: image-external.nexus.apps.union-investment.de/mssql/server:2022-CU25-ubuntu-22.04
      alias: sqlserver
    - name: image-prod.nexus.apps.union-investment.de/marktbearbeitungsplattform/cicd/images/servicebusemulator-team-mandalorian:0.0.2
      alias: sb-emulator
```

## NPM Frontend
A standardized Gitlab Pipeline for building and deploying Frontends as StaticWebapps built with npm.

### Pipeline Overview

The pipeline uses the Blueprint pipelines and extends them for usage in the Context of the Sudomain Marktbearbeitung.

### Usage

#### Include

The pipeline can be included using one of the version tags.
e.G. like this

```yaml filename=.gitlab-ci.yml
include:
  - project: marktbearbeitungsplattform/cicd/templates/pipeline-templates
    ref: 'v1.0.0'
    file: npm-frontend.yml

variables:
  ENABLE_PLAYWRIGHT: yes
```

For the Deployment to work you must specify the "SWA_DEPLOYMENT_TOKEN" variable in your CI/CD variables

#### Variables

| Variable                          | Description                                                                                                                   | Required | Default         |
|-----------------------------------|-------------------------------------------------------------------------------------------------------------------------------|----------|-----------------|
| `NPM_PROJECT_NAME`               | Name of the Project to build. Used to determine the build folder                                                               | yes      |                 |
| `ENABLE_PLAYWRIGHT`               | Enables the Playwright test step                                                                                              | no       | no              |
| `CONFLUENCE_PAGE_ID`              | Set to enable Confluence Documentation generation step. Has to contain the Page ID that should be updated,                    | no       |                 |
| `CONFLUENCE_SPACE`                | Set to enable Confluence Documentation generation step. Has to contain the Confluence Space that contains page to be updated. | no       |                 |
| `CONFLUENCE_ASCIIDOC_ROOT_FOLDER` | The folder that contains the markdown files that should be used for generating confluence documentation.                      | no       | documentation   |

#### Known Issues
* The node:publish step doesn't include the cache and therefore has no access to the npm artifact.Therefore the step is overriden to solve this.
* The npm recipe doesn't download the artifact from the previous build so it's available for deployment on tag pipelines. The pull-artifact step solves that.
* Sonar runs in the Main Pipeline although there is no build running in the main pipeline. This causes sonar to fail. This is a known issue with the npm recipe.
* The node recipe uses npm install instead of npm ci. This is a known issue with the npm recipe.
* The publish step is using npm unpublish which is not supported by nexus. This is a known issue with the npm recipe.